/* 
    Main JS for Moshi Public Secondary School Management System 
*/

// --- GLOBAL DELETION HANDLER (Top Level for max reliability) ---
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.btn-delete-confirm');
    
    if (btn) {
        // Debug Log
        console.log('Delete button clicked (SWAL):', btn);
        e.preventDefault();
        
        const url = btn.getAttribute('data-url');
        const name = btn.getAttribute('data-name') || 'this record';
        const type = btn.getAttribute('data-type') || 'item';
        
        if (!url) {
            console.error('Delete error: No URL found for button', btn);
            return;
        }

        let title = `Delete ${type}?`;
        let text = `Are you sure you want to PERMANENTLY delete "${name}"? This action cannot be undone.`;
        
        if (type === 'Assignment') {
            text = `This will remove the link between "${name}". The subject and teacher records will remain safe.`;
        }

        Swal.fire({
            title: title,
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#940000',
            cancelButtonColor: '#7f8c8d',
            confirmButtonText: 'Yes, Delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                console.log('Redirecting to:', url);
                window.location.href = url;
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    console.log('Moshi SMS initialized.');
    
    // Auto-hide alerts after 5 seconds
    try {
        const alerts = document.querySelectorAll('.alert-auto-dismiss');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            }, 5000);
        });
    } catch(err) { console.error('Alert error:', err); }

    // Global Phone Number Formatter
    try {
        const phoneInputs = document.querySelectorAll('input[type="tel"], .phone-input-9');
        phoneInputs.forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (!/[0-9]/.test(e.key)) {
                    e.preventDefault();
                }
            });
        });
    } catch(err) { console.error('Phone input error:', err); }
});
