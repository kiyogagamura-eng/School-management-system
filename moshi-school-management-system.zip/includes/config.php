<?php
/**
 * Load Environment Variables from .env file
 */
function loadEnv($path) {
    if (!file_exists($path)) {
        return;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        if (!array_key_exists($name, $_ENV)) {
            putenv(sprintf('%s=%s', $name, $value));
            $_ENV[$name] = $value;
        }
    }
}

// Load .env file
loadEnv(dirname(__DIR__) . '/.env');

// Helper function to get environment variable with fallback
function env($key, $default = null) {
    $value = getenv($key);
    if ($value === false) {
        return $default;
    }
    return $value;
}

// System Constants
define('APP_NAME', 'Moshi Public Secondary Schools Management System');
define('APP_LOCATION', 'Moshi, Tanzania');
define('DEFAULT_PASSWORD', 'moshi123');

// NextSMS SMS Gateway (from .env)
define('NEXTSMS_USERNAME', env('NEXTSMS_USERNAME', 'machaka'));
define('NEXTSMS_PASSWORD', env('NEXTSMS_PASSWORD', 'Machaka29@@'));
define('NEXTSMS_SENDER_ID', env('NEXTSMS_SENDER_ID', 'SCHOOL'));
define('NEXTSMS_ENVIRONMENT', env('NEXTSMS_ENVIRONMENT', 'production'));

// SMS OTP Settings
define('SMS_OTP_LENGTH', env('SMS_OTP_LENGTH', 6));
define('SMS_OTP_EXPIRY_MINUTES', env('SMS_OTP_EXPIRY_MINUTES', 10));
define('SMS_OTP_MAX_ATTEMPTS', env('SMS_OTP_MAX_ATTEMPTS', 3));

// Database Configuration (from .env)
define('DB_HOST', env('DB_HOST', 'localhost'));
define('DB_USER', env('DB_USERNAME', 'root'));
define('DB_PASS', env('DB_PASSWORD', ''));
define('DB_NAME', env('DB_DATABASE', 'moshi_sms'));

// Base URL Auto-Detection (Works for both subfolder and root domain/vhost)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$base_dir = str_replace('\\', '/', dirname(__DIR__));
$doc_root = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']) : $base_dir;
$rel_path = str_replace($doc_root, '', $base_dir);
$auto_base_url = $protocol . $host . rtrim($rel_path, '/') . '/';

define('BASE_URL', $auto_base_url);

// Security
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_TIME', 1800); // 30 minutes

// CSRF Token Settings
define('CSRF_TOKEN_NAME', 'csrf_token');
define('CSRF_TOKEN_EXPIRY', 3600); // 1 hour

// Design Tokens (Colors)
define('COLOR_PRIMARY_WHITE', '#FFFFFF');
define('COLOR_CORPORATE_RED', '#940000');
define('COLOR_ACCENT_SOFT_RED', '#FFF5F5');
define('COLOR_PRIMARY_TEXT', '#2C3E50');
define('COLOR_SECONDARY_TEXT', '#7F8C8D');

// Grading Scale (Now loaded from database - this is fallback only)
$grading_scale = [
    'A' => ['min' => 80, 'max' => 100, 'label' => 'Excellent'],
    'B' => ['min' => 70, 'max' => 79, 'label' => 'Very Good'],
    'C' => ['min' => 60, 'max' => 69, 'label' => 'Good'],
    'D' => ['min' => 50, 'max' => 59, 'label' => 'Satisfactory'],
    'E' => ['min' => 40, 'max' => 49, 'label' => 'Pass'],
    'F' => ['min' => 0, 'max' => 39, 'label' => 'Fail'],
];

// Paths
define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_DIR', BASE_PATH . '/assets/uploads/');

// Allowed File Upload Types
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('ALLOWED_DOCUMENT_TYPES', ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
?>
