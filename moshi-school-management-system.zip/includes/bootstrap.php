<?php
/**
 * System Bootstrap File
 * Handles sessions and core includes
 */

// 1. Session Start (Must be first)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Include core files using absolute paths
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/exam_names_helper.php';

// 3. Role Monitor - Auto-detect role changes (only for logged in users)
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    require_once __DIR__ . '/role_monitor.php';
}

// 4. Trigger Auto-backup
if (function_exists('checkAndRunAutoBackup')) {
    checkAndRunAutoBackup();
}
