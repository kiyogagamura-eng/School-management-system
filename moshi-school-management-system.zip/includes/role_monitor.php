<?php
/**
 * ROLE MONITOR - Real-time Role Change Detection
 * Checks if user's role has changed and redirects automatically
 */

// Only run if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    return;
}

try {
    // Check current role in database
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $current_db_role = $stmt->fetchColumn();
    
    // If role changed in database
    if ($current_db_role && $current_db_role !== $_SESSION['role']) {
        
        // Log the change
        $old_role = $_SESSION['role'];
        $new_role = $current_db_role;
        
        logActivity(
            $_SESSION['user_id'], 
            'role_changed_auto_redirect', 
            "Role changed from '$old_role' to '$new_role' - Auto redirecting"
        );
        
        // Update session
        $_SESSION['role'] = $new_role;
        
        // Determine redirect URL based on new role
        $redirect_map = [
            'admin' => BASE_URL . 'admin/dashboard.php',
            'headteacher' => BASE_URL . 'admin/dashboard.php',
            'dos' => BASE_URL . 'dos/dashboard.php',
            'teacher' => BASE_URL . 'teacher/dashboard.php',
            'student' => BASE_URL . 'student/dashboard.php',
            'parent' => BASE_URL . 'student/dashboard.php',
        ];
        
        $redirect_url = $redirect_map[$new_role] ?? BASE_URL . 'logout.php';
        
        // Set flash message
        $_SESSION['role_changed_notice'] = "Your role has been updated to: " . strtoupper($new_role) . ". You have been redirected to the appropriate portal.";
        
        // JavaScript redirect with notification
        echo <<<HTML
        <script>
        (function() {
            // Show notification
            alert('Your role has been updated to: {$new_role}\\n\\nYou will be redirected to your new portal.');
            
            // Redirect
            window.location.href = '{$redirect_url}';
        })();
        </script>
HTML;
        
        exit();
    }
    
} catch (PDOException $e) {
    // Silent fail - don't break the page
    error_log("Role monitor error: " . $e->getMessage());
}
?>
