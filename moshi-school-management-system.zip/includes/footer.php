        </div> <!-- End main-content -->
    </div> <!-- End wrapper -->
    
    <footer style="background: white; padding: 20px; text-align: center; border-top: 1px solid #eee; font-size: 0.8rem; color: var(--secondary-text);">
        &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> | <span style="color: var(--corporate-red); font-weight: 700;">Government Management System</span>
    </footer>

    <!-- Scripts -->
    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
</body>
</html>
