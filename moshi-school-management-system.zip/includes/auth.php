<?php
/**
 * Authentication and Access Control with Enhanced Security
 */

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION) && isset($_SESSION['user_id']);
}

/**
 * Check and enforce session timeout
 */
function checkSessionTimeout() {
    if (!isLoggedIn()) return;
    
    if (isset($_SESSION['last_activity'])) {
        $inactive = time() - $_SESSION['last_activity'];
        if ($inactive > SESSION_TIMEOUT) {
            // Session expired
            session_unset();
            session_destroy();
            header("Location: " . BASE_URL . "index.php?error=session_expired");
            exit();
        }
    }
    
    $_SESSION['last_activity'] = time();
}

/**
 * Require user to be logged in
 */
function requireLogin() {
    // Prevent browser from caching authenticated/protected pages
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "index.php");
        exit();
    }
    
    // Check session timeout
    checkSessionTimeout();
}

/**
 * Check if user has specific role(s)
 */
function hasRole($roles) {
    if (!isLoggedIn()) return false;
    
    $user_role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
    if (!$user_role) return false;

    if (is_array($roles)) {
        return in_array($user_role, $roles);
    }
    
    return $user_role === $roles;
}

/**
 * Require user to have specific role(s)
 */
function requireRole($roles) {
    requireLogin();
    if (!hasRole($roles)) {
        header("Location: " . BASE_URL . "index.php?error=unauthorized");
        exit();
    }
}

/**
 * Get current user details
 */
function getCurrentUser() {
    global $pdo;
    if (!isLoggedIn()) return null;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

/**
 * Generate CSRF Token
 */
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME]) || !isset($_SESSION['csrf_token_time']) || 
        (time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_EXPIRY) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Validate CSRF Token
 */
function validateCSRFToken($token) {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }
    
    if (!isset($_SESSION['csrf_token_time']) || 
        (time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_EXPIRY) {
        return false;
    }
    
    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Require valid CSRF token (call this at top of POST handlers)
 */
function requireCSRF() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST[CSRF_TOKEN_NAME] ?? '';
        if (!validateCSRFToken($token)) {
            http_response_code(403);
            die('CSRF token validation failed. Please refresh the page and try again.');
        }
    }
}

/**
 * Check and enforce login rate limiting
 */
function checkLoginAttempts($username) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT failed_attempts, locked_until FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) return true; // User doesn't exist, let it proceed (will fail anyway)
    
    // Check if account is locked
    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
        $remaining = ceil((strtotime($user['locked_until']) - time()) / 60);
        return "Account is locked. Please try again in {$remaining} minutes.";
    }
    
    // Check if max attempts reached
    if ($user['failed_attempts'] >= MAX_LOGIN_ATTEMPTS) {
        // Lock the account
        $lock_until = date('Y-m-d H:i:s', time() + LOCK_TIME);
        $stmt = $pdo->prepare("UPDATE users SET locked_until = ?, status = 'locked' WHERE username = ?");
        $stmt->execute([$lock_until, $username]);
        
        $minutes = LOCK_TIME / 60;
        return "Too many failed attempts. Account locked for {$minutes} minutes.";
    }
    
    return true;
}

/**
 * Record failed login attempt
 */
function recordFailedLogin($username) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE username = ?");
    $stmt->execute([$username]);
}

/**
 * Reset failed login attempts on successful login
 */
function resetFailedLogins($username) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL, status = 'active' WHERE username = ?");
    $stmt->execute([$username]);
}

/**
 * Sanitize output to prevent XSS
 */
function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Validate file upload
 */
function validateFileUpload($file, $allowed_types = ALLOWED_IMAGE_TYPES) {
    $errors = [];
    
    // Check if file was uploaded
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'error' => 'No file uploaded'];
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'File upload error: ' . $file['error']];
    }
    
    // Check file size
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        $max_mb = MAX_UPLOAD_SIZE / (1024 * 1024);
        return ['success' => false, 'error' => "File size exceeds {$max_mb}MB limit"];
    }
    
    // Check file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime, $allowed_types)) {
        return ['success' => false, 'error' => 'Invalid file type'];
    }
    
    // Additional check: verify file extension matches MIME type
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $valid_extensions = [
        'image/jpeg' => ['jpg', 'jpeg'],
        'image/png' => ['png'],
        'image/gif' => ['gif'],
        'application/pdf' => ['pdf'],
        'application/msword' => ['doc'],
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => ['docx']
    ];
    
    if (isset($valid_extensions[$mime]) && !in_array($ext, $valid_extensions[$mime])) {
        return ['success' => false, 'error' => 'File extension does not match content'];
    }
    
    return ['success' => true, 'mime' => $mime, 'extension' => $ext];
}
?>
