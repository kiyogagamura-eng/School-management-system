<?php
/**
 * Global Helper Functions
 */

/**
 * Log activity to database
 */
function logActivity($user_id, $action, $description = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $user_id,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
    } catch (PDOException $e) {
        // Fail silently or log to file
        error_log("Activity Log Error: " . $e->getMessage());
    }
}

/**
 * Create a system notification for a specific user ID or a full role group
 */
function createNotification($recipient_role, $recipient_id, $message, $link = null) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO system_notifications (recipient_role, recipient_id, message, link, is_read) VALUES (?, ?, ?, ?, 0)");
        $stmt->execute([
            empty($recipient_role) ? null : $recipient_role,
            empty($recipient_id) ? null : $recipient_id,
            $message,
            $link
        ]);
        return true;
    } catch (PDOException $e) {
        error_log("Notification Create Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark a specific notification or all notifications as read
 */
function markNotificationRead($notification_id = null, $user_id = null, $user_role = null) {
    global $pdo;
    try {
        if ($notification_id) {
            $stmt = $pdo->prepare("UPDATE system_notifications SET is_read = 1 WHERE notification_id = ?");
            $stmt->execute([$notification_id]);
        } elseif ($user_id && $user_role) {
            // Mark all as read for this user/role
            $stmt = $pdo->prepare("UPDATE system_notifications SET is_read = 1 WHERE recipient_id = ? OR recipient_role = ?");
            $stmt->execute([$user_id, $user_role]);
        }
        return true;
    } catch (PDOException $e) {
        error_log("Notification Mark Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get Base URL
 */
function base_url($path = '') {
    return BASE_URL . ltrim($path, '/');
}

/**
 * Format date to standard Tanzanian school format
 */
function formatDate($date) {
    return date('d/m/Y', strtotime($date));
}

/**
 * Format currency (if needed, though financial features are excluded)
 */
function formatMoney($amount) {
    return "TSh " . number_format($amount, 0);
}

/**
 * Redirect with message
 */
function redirect($url, $message = '', $type = 'success') {
    if ($message) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header("Location: $url");
    exit();
}

/**
 * Get current term
 */
function getCurrentTerm() {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT * FROM academic_terms WHERE is_current = 1 LIMIT 1");
        $stmt->execute();
        $term = $stmt->fetch();
        if (!$term) {
            // Seeding fallback if no active term
            return ['term_id' => 1, 'term_name' => 'Term 1, 2026'];
        }
        return $term;
    } catch (PDOException $e) {
        return ['term_id' => 1, 'term_name' => 'Term 1, 2026'];
    }
}

/**
 * Calculate Grade based on Marks using database scale
 */
function calculateGrade($marks) {
    global $pdo;
    static $scale = null;
    
    if ($scale === null) {
        try {
            $stmt = $pdo->query("SELECT * FROM grading_scale ORDER BY min_marks DESC");
            $scale = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $scale = [];
        }
    }

    foreach ($scale as $row) {
        if ($marks >= $row['min_marks'] && $marks <= $row['max_marks']) {
            return $row['grade'];
        }
    }
    
    return 'F'; // Fallback
}


/**
 * Send SMS via NextSMS API
 * @param string $phone  Recipient phone number (e.g. +255711444501 or 0711444501)
 * @param string $message SMS message content
 * @return bool True if sent successfully, false otherwise
 */
function sendSMS($phone, $message) {
    global $pdo;
    
    // Format phone number to NextSMS format (255...)
    $phone = trim($phone);
    if (strpos($phone, '0') === 0) {
        $phone = '255' . substr($phone, 1);
    } elseif (strpos($phone, '+') === 0) {
        $phone = substr($phone, 1);
    } elseif (strpos($phone, '255') !== 0) {
        $phone = '255' . $phone;
    }

    $url = 'https://messaging-service.co.tz/api/sms/v1/text/single';
    $credentials = base64_encode(NEXTSMS_USERNAME . ':' . NEXTSMS_PASSWORD);

    // Build POST data for NextSMS
    $postData = [
        'from' => NEXTSMS_SENDER_ID,
        'to'   => $phone,
        'text' => $message
    ];

    // Send via cURL
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($postData),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Basic ' . $credentials,
            'Content-Type: application/json',
            'Accept: application/json'
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    // Parse response
    $status = 'failed';
    $apiMessage = '';
    
    if ($curlError) {
        $apiMessage = "cURL Error: $curlError";
    } elseif ($httpCode == 200 || $httpCode == 201) {
        $result = json_decode($response, true);
        if (isset($result['messages'][0]['status']['id']) && (
            $result['messages'][0]['status']['id'] == 0 || // pending/accepted
            $result['messages'][0]['status']['id'] == 1 || // delivered
            $result['messages'][0]['status']['id'] == 26   // accepted
        ) || isset($result['messages'][0]['messageId'])) {
            $status = 'sent';
            $apiMessage = $result['messages'][0]['status']['name'] ?? 'Sent';
        } else {
            $apiMessage = $result['messages'][0]['status']['description'] ?? 'Unknown status';
            if(empty($apiMessage)) { $apiMessage = json_encode($result); }
        }
    } else {
        $apiMessage = "HTTP $httpCode: $response";
    }

    // Log to database
    try {
        $stmt = $pdo->prepare("INSERT INTO communications (comm_type, recipient, message, status, api_response) VALUES ('sms', ?, ?, ?, ?)");
        $stmt->execute([$phone, $message, $status, $apiMessage]);
    } catch (PDOException $e) {
        error_log("SMS Log Error: " . $e->getMessage());
    }

    return ($status === 'sent');
}
/**
 * Get Class Short Name (e.g., "Form 1A" -> "F1A")
 */
function getClassShortName($class_name) {
    return str_replace('Form ', 'F', str_replace(' ', '', $class_name));
}

/**
 * Generate Next Available Admission Number
 */
function generateAdmissionNumber($class_id) {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT MAX(student_id) FROM students");
        $max_id = (int)$stmt->fetchColumn();
        $next_sequence = $max_id + 1;
        $year = date('Y');
        return "STD-" . $year . "-" . str_pad($next_sequence, 3, '0', STR_PAD_LEFT);
    } catch (PDOException $e) {
        return "STD-" . date('Y') . "-000";
    }
}

/**
 * Generate Next Available Employee ID
 */
function generateEmployeeID() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT MAX(teacher_id) FROM teachers");
        $max_id = (int)$stmt->fetchColumn();
        $next_sequence = $max_id + 1;
        $year = date('Y');
        return "EMP-" . $year . "-" . str_pad($next_sequence, 3, '0', STR_PAD_LEFT);
    } catch (PDOException $e) {
        return "EMP-" . date('Y') . "-000";
    }
}

/**
 * Normalize phone number to +255 format
 */
function normalizePhone($phone) {
    $phone = trim($phone);
    if (empty($phone)) return '';
    
    // Remove any non-numeric characters EXCEPT '+'
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    
    if (strpos($phone, '0') === 0) {
        $phone = '+255' . substr($phone, 1);
    } elseif (strpos($phone, '255') === 0 && strpos($phone, '+') !== 0) {
        $phone = '+' . $phone;
    } elseif (strpos($phone, '+') !== 0) {
        $phone = '+255' . $phone;
    }
    return $phone;
}

/**
 * Check if phone is in +255 format with 9 digits after code
 */
function isValidTanzanianPhone($phone) {
    return preg_match('/^\+255[0-9]{9}$/', $phone);
}

/**
 * Check if a name contains only letters and spaces (no numbers or special characters)
 */
function isValidName($name) {
    if (empty(trim($name))) return true; // Allow empty (for optional middle names)
    return preg_match('/^[A-Za-z ]+$/', trim($name));
}

/**
 * Check if password is alphanumeric (standard format machaka123)
 * Requires at least one letter and at least one number
 */
function isValidPasswordFormat($pass) {
    if (strlen($pass) < 6) return false;
    // Check for at least one letter and one number
    return preg_match('/[A-Za-z]/', $pass) && preg_match('/[0-9]/', $pass);
}

/**
 * Sanitize string for use in filename
 */
function safeFilename($filename) {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '_', $filename);
}

/**
 * Calculate Division Points for O-Level (Best 7)
 * @param array $marks Array of objects with 'point_value'
 * @return array ['total_points' => int, 'division' => string]
 */
function calculateOLevelDivision($marks) {
    if (empty($marks)) return ['total_points' => 0, 'division' => 'N/A'];

    // Filter out items without point_value and sort
    $valid_marks = array_filter($marks, function($m) {
        return isset($m['point_value']);
    });

    if (empty($valid_marks)) return ['total_points' => 0, 'division' => 'N/A'];

    // count how many subjects were SAT (even if failed)
    $total_subjects = count($valid_marks);

    // Filter subjects that are "Pass" (D or better)
    // Assuming grades are A, B, C, D (pass) and E, F (fail/near fail)
    // In NECTA points: A=1, B=2, C=3, D=4 are passes. E=5, F=5 (or F=7) are fails.
    // Let's check how many subjects have points <= 4
    $passing_subjects = 0;
    foreach ($valid_marks as $m) {
        if ((int)$m['point_value'] > 0 && (int)$m['point_value'] <= 4) {
            $passing_subjects++;
        }
    }

    usort($valid_marks, function($a, $b) {
        return (int)$a['point_value'] <=> (int)$b['point_value'];
    });

    // Take best 7
    $best_7 = array_slice($valid_marks, 0, 7);
    $total_points = 0;
    foreach ($best_7 as $m) {
        $total_points += (int)$m['point_value'];
    }

    $has_c_or_better = false;
    foreach ($best_7 as $m) {
        if ((int)$m['point_value'] > 0 && (int)$m['point_value'] <= 3) {
            $has_c_or_better = true;
            break;
        }
    }

    // NECTA logic: Missing subjects out of 7 act as failures (5 points)
    $missing_subjects = max(0, 7 - count($best_7));
    $total_points += ($missing_subjects * 5);
    
    $div = "0"; // Default failure
    
    if ($passing_subjects >= 2 || $has_c_or_better) {
        if ($total_points >= 7 && $total_points <= 17) $div = "I";
        elseif ($total_points >= 18 && $total_points <= 21) $div = "II";
        elseif ($total_points >= 22 && $total_points <= 25) $div = "III";
        elseif ($total_points >= 26 && $total_points <= 33) $div = "IV";
        // Some systems allow 34/35 if they meet the pass criteria, but strictly speaking 34/35 is Div 0 unless they have a pass...
        elseif ($total_points >= 34) $div = "IV"; // Necta allows DIV IV as long as you have 2 Ds or 1 C.
    }

    return [
        'total_points' => $total_points, 
        'division' => $div, 
        'subjects_counted' => count($best_7),
        'total_subjects' => $total_subjects,
        'passing_subjects' => $passing_subjects
    ];
}

/**
 * Get full academic history for a student
 */
function getStudentAcademicHistory($student_id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT 
                r.*, 
                e.exam_name, e.exam_type, e.max_marks,
                s.subject_name, s.subject_code,
                t.term_name, t.academic_year,
                gs.point_value
            FROM results r
            JOIN exams e ON r.exam_id = e.exam_id
            JOIN subjects s ON r.subject_id = s.subject_id
            JOIN academic_terms t ON e.term_id = t.term_id
            LEFT JOIN grading_scale gs ON r.grade = gs.grade
            WHERE r.student_id = ? AND r.status = 'published'
            ORDER BY t.academic_year DESC, t.term_name ASC, s.subject_name ASC
        ");
        $stmt->execute([$student_id]);
        $all_results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Group by year, then by term, then by exam
        $history = [];
        foreach ($all_results as $res) {
            $year = $res['academic_year'];
            $term = $res['term_name'];
            $exam = $res['exam_name'];
            $exam_id = $res['exam_id'];
            
            if (!isset($history[$year])) {
                $history[$year] = [
                    'terms' => [],
                    'overall_stats' => null
                ];
            }
            
            if (!isset($history[$year]['terms'][$term])) {
                $history[$year]['terms'][$term] = [
                    'exams' => []
                ];
            }
            
            if (!isset($history[$year]['terms'][$term]['exams'][$exam_id])) {
                $history[$year]['terms'][$term]['exams'][$exam_id] = [
                    'exam_name' => $exam,
                    'details' => $res, // Meta data from one row
                    'results' => []
                ];
            }
            
            $history[$year]['terms'][$term]['exams'][$exam_id]['results'][] = $res;
        }

        // Calculate division for each year (based on all published exams in that year)
        foreach ($history as $year => &$data) {
            // We need one result per subject per year for Best-7
            // We'll take the best grade achieved in each subject across any exam for that year
            $best_per_subject = [];
            foreach ($data['terms'] as $term_results) {
                foreach ($term_results['exams'] as $exam_data) {
                    foreach ($exam_data['results'] as $r) {
                        $sid = $r['subject_id'];
                        if (!isset($best_per_subject[$sid]) || $r['point_value'] < $best_per_subject[$sid]['point_value']) {
                            $best_per_subject[$sid] = $r;
                        }
                    }
                }
            }
            $data['overall_stats'] = calculateOLevelDivision(array_values($best_per_subject));
        }

        return $history;
    } catch (PDOException $e) {
        error_log("History Fetch Error: " . $e->getMessage());
        return [];
    }
}

/**
 * Automatically check and create database backup if the last backup is older than 12 hours
 */
function checkAndRunAutoBackup() {
    global $pdo;
    
    // Auto-backup folder must be absolute and accessible
    $backup_dir = BASE_PATH . '/admin/backups/';
    if (!is_dir($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    // Find files matching backup_*.sql
    $files = glob($backup_dir . 'backup_*.sql');
    $run_backup = false;
    
    if (empty($files)) {
        $run_backup = true;
    } else {
        // Find the newest modified time
        $newest_mtime = 0;
        foreach ($files as $f) {
            $mtime = filemtime($f);
            if ($mtime > $newest_mtime) {
                $newest_mtime = $mtime;
            }
        }
        
        // 12 hours = 12 * 3600 = 43200 seconds
        if ((time() - $newest_mtime) >= 43200) {
            $run_backup = true;
        }
    }
    
    if ($run_backup) {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "backup_moshi_sms_auto_{$timestamp}.sql";
        $filepath = $backup_dir . $filename;
        
        try {
            // Get all tables
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            $sql_dump = "-- ShuleXpert Auto Database Backup\n";
            $sql_dump .= "-- Generated: " . date('Y-m-d H:i:s') . " by System Auto-Backup (12 Hour Interval)\n";
            $sql_dump .= "-- Database: " . DB_NAME . "\n\n";
            $sql_dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
            
            foreach ($tables as $table) {
                // Table structure
                $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
                $createKey = array_key_exists('Create Table', $create) ? 'Create Table' : 'Create View';
                $sql_dump .= "\n-- Table: $table\n";
                $sql_dump .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql_dump .= $create[$createKey] . ";\n\n";
                
                // Table data
                $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($rows)) {
                    $cols = array_keys($rows[0]);
                    $col_list = implode('`, `', $cols);
                    $sql_dump .= "INSERT INTO `$table` (`$col_list`) VALUES\n";
                    $row_sqls = [];
                    foreach ($rows as $row) {
                        $values = array_map(function($val) use ($pdo) {
                            return $val === null ? 'NULL' : $pdo->quote($val);
                        }, array_values($row));
                        $row_sqls[] = "(" . implode(', ', $values) . ")";
                    }
                    $sql_dump .= implode(",\n", $row_sqls) . ";\n\n";
                }
            }
            
            $sql_dump .= "SET FOREIGN_KEY_CHECKS=1;\n";
            
            if (file_put_contents($filepath, $sql_dump)) {
                // Log system activity (using user id 0 or system)
                logActivity(0, 'auto_backup', "System Auto-Backup completed successfully: $filename");
                return true;
            }
        } catch(Exception $e) {
            error_log("Auto Backup Error: " . $e->getMessage());
        }
    }
    return false;
}
?>
