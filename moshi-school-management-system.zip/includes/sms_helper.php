<?php
/**
 * SMS Helper Functions for NextSMS Integration
 */

/**
 * Send SMS via NextSMS API
 * 
 * @param string|array $phone Phone number(s) to send to
 * @param string $message Message content
 * @return array Result with 'success' boolean and 'message' string
 */
function sendSMS($phone, $message) {
    $api_url = NEXTSMS_ENVIRONMENT === 'production' 
        ? 'https://messaging-service.co.tz/api/sms/v1/text/single'
        : 'https://messaging-service.co.tz/api/sms/v1/test/text/single';
    
    $username = NEXTSMS_USERNAME;
    $password = NEXTSMS_PASSWORD;
    $sender_id = NEXTSMS_SENDER_ID;
    
    // Prepare phone number(s)
    if (is_array($phone)) {
        $phone = implode(',', $phone);
    }
    
    // Clean phone number (remove spaces, dashes)
    $phone = preg_replace('/[^0-9,]/', '', $phone);
    
    // Ensure phone starts with country code (255 for Tanzania)
    $phones = explode(',', $phone);
    $cleaned_phones = [];
    foreach ($phones as $p) {
        $p = trim($p);
        if (substr($p, 0, 1) === '0') {
            $p = '255' . substr($p, 1);
        } elseif (substr($p, 0, 3) !== '255') {
            $p = '255' . $p;
        }
        $cleaned_phones[] = $p;
    }
    $phone = implode(',', $cleaned_phones);
    
    $data = [
        'from' => $sender_id,
        'to' => $phone,
        'text' => $message
    ];
    
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode($username . ':' . $password)
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return [
            'success' => false,
            'message' => 'Connection error: ' . $error,
            'response' => null
        ];
    }
    
    $result = json_decode($response, true);
    
    if ($http_code === 200 || $http_code === 201) {
        return [
            'success' => true,
            'message' => 'SMS sent successfully',
            'response' => $result
        ];
    } else {
        $error_msg = isset($result['message']) ? $result['message'] : 'Unknown error';
        return [
            'success' => false,
            'message' => 'API Error: ' . $error_msg,
            'response' => $result,
            'http_code' => $http_code
        ];
    }
}

/**
 * Send bulk SMS to multiple recipients
 * 
 * @param array $recipients Array of ['phone' => '0712345678', 'message' => 'Custom message']
 * @param string $default_message Default message if recipient doesn't have custom message
 * @return array Results with 'sent', 'failed', and 'details'
 */
function sendBulkSMS($recipients, $default_message = '') {
    $results = [
        'sent' => 0,
        'failed' => 0,
        'details' => []
    ];
    
    foreach ($recipients as $recipient) {
        $phone = $recipient['phone'];
        $message = isset($recipient['message']) ? $recipient['message'] : $default_message;
        
        if (empty($message)) {
            $results['failed']++;
            $results['details'][] = [
                'phone' => $phone,
                'status' => 'failed',
                'error' => 'No message provided'
            ];
            continue;
        }
        
        $result = sendSMS($phone, $message);
        
        if ($result['success']) {
            $results['sent']++;
            $results['details'][] = [
                'phone' => $phone,
                'status' => 'sent',
                'message' => $message
            ];
        } else {
            $results['failed']++;
            $results['details'][] = [
                'phone' => $phone,
                'status' => 'failed',
                'error' => $result['message']
            ];
        }
        
        // Small delay to avoid rate limiting
        usleep(500000); // 0.5 seconds
    }
    
    return $results;
}

/**
 * Check SMS credit balance via NextSMS API
 * 
 * @return array Result with 'success' and 'balance' or 'error'
 */
function getSMSBalance() {
    $api_url = 'https://messaging-service.co.tz/api/sms/v1/me';
    
    $username = NEXTSMS_USERNAME;
    $password = NEXTSMS_PASSWORD;
    
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Basic ' . base64_encode($username . ':' . $password)
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return [
            'success' => false,
            'error' => 'Connection error: ' . $error
        ];
    }
    
    $result = json_decode($response, true);
    
    if ($http_code === 200 && isset($result['balance'])) {
        return [
            'success' => true,
            'balance' => $result['balance'],
            'currency' => $result['currency'] ?? 'TSh'
        ];
    } else {
        return [
            'success' => false,
            'error' => 'Could not retrieve balance',
            'response' => $result
        ];
    }
}

/**
 * Calculate SMS count based on message length
 * 
 * @param string $message Message content
 * @return int Number of SMS segments
 */
function calculateSMSCount($message) {
    $length = strlen($message);
    
    if ($length <= 160) {
        return 1;
    } elseif ($length <= 306) {
        return 2;
    } elseif ($length <= 459) {
        return 3;
    } else {
        return ceil($length / 153);
    }
}

/**
 * Validate Tanzania phone number
 * 
 * @param string $phone Phone number to validate
 * @return bool True if valid, false otherwise
 */
function validateTanzaniaPhone($phone) {
    // Remove spaces and dashes
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Check if it starts with 0 or 255 and has correct length
    if (preg_match('/^0[67]\d{8}$/', $phone)) {
        return true; // Format: 0712345678
    }
    
    if (preg_match('/^255[67]\d{8}$/', $phone)) {
        return true; // Format: 255712345678
    }
    
    return false;
}

/**
 * Format phone number to E.164 format (255XXXXXXXXX)
 * 
 * @param string $phone Phone number to format
 * @return string|false Formatted phone or false if invalid
 */
function formatPhoneNumber($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    if (preg_match('/^0([67]\d{8})$/', $phone, $matches)) {
        return '255' . $matches[1];
    }
    
    if (preg_match('/^(255[67]\d{8})$/', $phone)) {
        return $phone;
    }
    
    return false;
}
?>
