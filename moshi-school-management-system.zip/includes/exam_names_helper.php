<?php
/**
 * Exam Names Helper
 * Centralized list of standard exam names for consistency across the system
 */

/**
 * Get standard exam name options for dropdowns
 * @return array List of exam names with categories
 */
function getStandardExamNames() {
    return [
        'Mock Exams' => [
            'Pre-Mock Exams',
            'Mock Exams',
        ],
        'Terminal Exams' => [
            'Midterm Exams',
            'Terminal Exams',
            'Annual Exams',
        ],
        'Tests & Assessments' => [
            'Monthly Test',
            'Weekly Test',
            'Quiz',
            'Assignment',
        ],
        'NECTA Preparation' => [
            'NECTA Practice',
        ],
    ];
}

/**
 * Get flat list of exam names (no categories)
 * @return array Simple list of exam names
 */
function getExamNamesList() {
    return [
        'Pre-Mock Exams',
        'Mock Exams',
        'Terminal Exams',
        'Midterm Exams',
        'Monthly Test',
        'Weekly Test',
        'Quiz',
        'Assignment',
        'NECTA Practice',
        'Annual Exams',
    ];
}

/**
 * Render exam name dropdown options (with optgroups)
 * @param string $selected Currently selected exam name
 * @param bool $include_blank Include blank "-- Select --" option
 */
function renderExamNameOptions($selected = '', $include_blank = true) {
    if ($include_blank) {
        echo '<option value="">-- Select Exam Name --</option>';
    }
    
    $grouped = getStandardExamNames();
    foreach ($grouped as $category => $names) {
        echo '<optgroup label="' . htmlspecialchars($category) . '">';
        foreach ($names as $name) {
            $is_selected = ($selected == $name) ? 'selected' : '';
            echo '<option value="' . htmlspecialchars($name) . '" ' . $is_selected . '>' . htmlspecialchars($name) . '</option>';
        }
        echo '</optgroup>';
    }
}

/**
 * Get exam types with descriptions
 * @return array Exam types
 */
function getExamTypes() {
    return [
        'test' => 'Regular Test',
        'midterm' => 'Midterm Exam',
        'endterm' => 'End of Term Exam',
        'assignment' => 'Assignment',
        'practical' => 'Practical/Lab Work',
    ];
}

/**
 * Render exam type dropdown options
 * @param string $selected Currently selected type
 * @param bool $include_blank Include blank option
 */
function renderExamTypeOptions($selected = '', $include_blank = true) {
    if ($include_blank) {
        echo '<option value="">-- Select Type --</option>';
    }
    
    $types = getExamTypes();
    foreach ($types as $value => $label) {
        $is_selected = ($selected == $value) ? 'selected' : '';
        echo '<option value="' . htmlspecialchars($value) . '" ' . $is_selected . '>' . htmlspecialchars($label) . '</option>';
    }
}

/**
 * Normalize exam name (add year if missing)
 * @param string $exam_name Input exam name
 * @return string Normalized exam name with year
 */
function normalizeExamName($exam_name) {
    $exam_name = trim($exam_name);
    $current_year = date('Y');
    
    // Add year if not present
    if (strpos($exam_name, $current_year) === false && strpos($exam_name, (string)($current_year - 1)) === false) {
        $exam_name = $exam_name . ' ' . $current_year;
    }
    
    return $exam_name;
}
?>
