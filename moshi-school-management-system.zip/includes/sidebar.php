<?php
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$role = isset($_SESSION['role']) ? $_SESSION['role'] : null;

// Helper function to determine if a link is active
function isActive($page, $dir = null) {
    global $current_page, $current_dir;
    if ($dir !== null) {
        return ($current_page == $page && $current_dir == $dir);
    }
    return $current_page == $page;
}
?>
<style>
    .sidebar-nav ul li a {
        display: flex;
        align-items: center;
        padding: 12px 25px;
        color: var(--primary-text);
        text-decoration: none;
        transition: all 0.3s ease;
        border-left: 4px solid transparent;
        margin: 2px 0;
        font-weight: 600;
        font-size: 0.95rem;
    }

    .sidebar-nav ul li a:hover {
        background: var(--accent-soft-red);
        color: var(--corporate-red);
        border-left: 4px solid var(--corporate-red);
        padding-left: 30px; /* Subtle slide effect */
    }

    .sidebar-nav ul li a.active {
        background: #FFF5F5;
        color: #940000;
        border-left: 4px solid #940000;
        font-weight: 700;
    }

    .sidebar-nav ul li a i {
        width: 30px;
        font-size: 1.1rem;
    }

    .sidebar-section-title {
        padding: 20px 25px 8px;
        color: var(--secondary-text);
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        font-weight: 700;
    }

    /* Dropdown Styles */
    .has-dropdown {
        position: relative;
    }
    .submenu {
        display: none;
        background: #fdfdfd;
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .submenu li a {
        padding-left: 55px !important;
        font-size: 0.85rem !important;
        border-left: none !important;
    }
    .submenu li a:hover {
        padding-left: 60px !important;
    }
    .submenu.show {
        display: block;
    }
    .dropdown-arrow {
        margin-left: auto;
        font-size: 0.7rem !important;
        transition: transform 0.3s;
    }
    .has-dropdown.active-parent .dropdown-arrow {
        transform: rotate(180deg);
    }
    
    /* Headmaster Approvals Pulse */
    @keyframes pulse-gold {
        0% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0.7); }
        70% { box-shadow: 0 0 0 12px rgba(212, 175, 55, 0); }
        100% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0); }
    }
    .btn-approval {
        background: linear-gradient(135deg, #d4af37, #aa8222) !important;
        color: #fff !important;
        border-radius: 8px;
        margin: 10px 15px !important;
        padding: 12px 20px !important;
        font-weight: 700 !important;
        border-left: none !important;
        box-shadow: 0 4px 15px rgba(212, 175, 55, 0.3);
        transition: all 0.3s ease;
    }
    .btn-approval i {
        color: #fff !important;
    }
    .btn-approval:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(212, 175, 55, 0.5);
    }
    .btn-approval.pulse-effect {
        animation: pulse-gold 2s infinite;
    }
    .badge-count {
        background: #222;
        color: #d4af37;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        margin-left: auto;
        font-weight: 800;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    .badge-notification {
        background: var(--corporate-red, #940000);
        color: white;
        padding: 2px 6px;
        border-radius: 10px;
        font-size: 0.7rem;
        margin-left: auto;
        font-weight: 600;
    }
</style>

<aside class="sidebar" style="width: <?php echo $role === 'student' ? '280px' : '260px'; ?>; background: var(--primary-white); border-right: 2px solid #940000; color: var(--primary-text); height: 100vh; padding-top: 20px; box-shadow: 2px 0 20px rgba(148,0,0,0.05); position: fixed; left: 0; top: 0; z-index: 1000; display: flex; flex-direction: column;">
    <div class="sidebar-logo" style="text-align: center; margin-bottom: 20px; padding: 20px 20px; border-bottom: 1px solid #FFF5F5; padding-bottom: 20px;">
        <div style="width: 70px; height: 70px; border-radius: 50%; margin: 0 auto 12px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(148,0,0,0.15); overflow: hidden; border: 3px solid #940000; background: white;">
            <img src="<?php echo BASE_URL; ?>assets/images/logo.png" alt="School Logo" style="width: 90%; height: 90%; object-fit: contain;">
        </div>
        <h4 style="color: #940000; margin: 0; font-size: 0.9rem; font-weight: 900; letter-spacing: 0.5px; line-height: 1.2; text-transform: uppercase;"><?php echo APP_NAME; ?></h4>
    </div>

    <nav class="sidebar-nav" style="flex: 1; overflow-y: auto; padding-bottom: 15px;">
        <ul style="list-style: none; padding: 0;">
            <!-- COMMON FOR ALL -->
            <?php if ($role !== 'headteacher'): ?>
            <li style="margin-bottom: 5px;">
                <a href="<?php echo BASE_URL; ?><?php echo $role; ?>/dashboard.php" class="<?php echo isActive('dashboard.php') ? 'active' : ''; ?>">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </li>
            <?php endif; ?>

            <!-- NEW: Communication for leadership roles -->
            <?php if (in_array($role, ['dos', 'discipline'])): ?>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/communication/index.php" class="<?php echo isActive('index.php', 'communication') ? 'active' : ''; ?>">
                        <i class="fas fa-sms"></i> Communication Hub
                    </a>
                </li>
            <?php endif; ?>

            <?php if ($role == 'headteacher'): ?>
                <li class="sidebar-section-title">Headmaster Panel</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>headteacher/dashboard.php" class="<?php echo isActive('dashboard.php', 'headteacher') ? 'active' : ''; ?>">
                        <i class="fas fa-chart-bar"></i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/results/school-stats.php" class="<?php echo isActive('school-stats.php', 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-school"></i> School Statistics
                    </a>
                </li>
                
                <li class="has-dropdown <?php echo ($current_dir == 'results') ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo ($current_dir == 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-book"></i> Academic Overview <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo ($current_dir == 'results') ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>admin/results/index.php" class="<?php echo isActive('index.php', 'results') ? 'active' : ''; ?>">Exam Results</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/school-stats.php" class="<?php echo isActive('school-stats.php', 'results') ? 'active' : ''; ?>">Performance Analytics</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/class-stats.php" class="<?php echo isActive('class-stats.php', 'results') ? 'active' : ''; ?>">Class Performance</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/subject-stats.php" class="<?php echo isActive('subject-stats.php', 'results') ? 'active' : ''; ?>">Subject Ranking</a></li>
                    </ul>
                </li>

                
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/attendance/class-report.php" class="<?php echo isActive('class-report.php', 'attendance') ? 'active' : ''; ?>">
                        <i class="fas fa-clipboard-check"></i> Attendance Reports
                    </a>
                </li>

                
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/communication/index.php" class="<?php echo isActive('index.php', 'communication') ? 'active' : ''; ?>">
                        <i class="fas fa-bullhorn"></i> Communication
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>headteacher/report-center.php" class="<?php echo isActive('report-center.php', 'headteacher') ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Reports Center
                    </a>
                </li>


                
                <li style="margin-top: 10px;">
                    <a href="<?php echo BASE_URL; ?>profile.php" class="<?php echo isActive('profile.php') ? 'active' : ''; ?>">
                        <i class="fas fa-cog"></i> Settings
                    </a>
                </li>
            <?php endif; ?>

            <?php if ($role == 'dos'): ?>
                <li class="sidebar-section-title">📚 Academic Core</li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/dashboard.php" class="<?php echo isActive('dashboard.php', 'dos') ? 'active' : ''; ?>">
                        <i class="fas fa-th-large"></i> Dashboard
                    </a>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>admin/subjects/index.php" class="<?php echo isActive('index.php', 'subjects') ? 'active' : ''; ?>">
                        <i class="fas fa-book"></i> Subject Management
                    </a>
                </li>

                 <li>
                    <a href="<?php echo BASE_URL; ?>dos/subjects/allocate.php" class="<?php echo isActive('allocate.php', 'subjects') ? 'active' : ''; ?>">
                        <i class="fas fa-user-tag"></i> Teacher Allocation
                    </a>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/classes/allocate.php" class="<?php echo isActive('allocate.php', 'classes') ? 'active' : ''; ?>">
                        <i class="fas fa-chalkboard-teacher"></i> Class Teacher Allocation
                    </a>
                </li>

                <li class="has-dropdown <?php echo (in_array($current_page, ['index.php']) && $current_dir == 'timetable') ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo ($current_dir == 'timetable') ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Timetable <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo ($current_dir == 'timetable') ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>admin/timetable/index.php">Master Timetable</a></li>
                        <li><a href="<?php echo BASE_URL; ?>dos/examination/index.php">Exam Timetable</a></li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/examination/index.php" class="<?php echo isActive('index.php', 'examination') ? 'active' : ''; ?>">
                        <i class="fas fa-file-signature"></i> Examination
                    </a>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/period-log/index.php" class="<?php echo isActive('index.php', 'period-log') ? 'active' : ''; ?>">
                        <i class="fas fa-clipboard-check"></i> Period Logbook
                    </a>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/lesson-plans/index.php" class="<?php echo isActive('index.php', 'lesson-plans') ? 'active' : ''; ?>">
                        <i class="fas fa-folder-open"></i> Lesson Plans
                    </a>
                </li>

                <li class="sidebar-section-title">📈 Results & Reporting</li>

                <li class="has-dropdown <?php echo ($current_dir == 'results') ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo ($current_dir == 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-poll"></i> Results Management <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo ($current_dir == 'results') ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>admin/results/index.php">Overview</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/review.php">Mark Entry Monitor</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/compile.php">Publish Results</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/results/class-stats.php">Class Statistics</a></li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/analytics/index.php" class="<?php echo isActive('index.php', 'analytics') ? 'active' : ''; ?>">
                        <i class="fas fa-chart-line"></i> Academic Analytics
                    </a>
                </li>

                <li>
                    <a href="<?php echo BASE_URL; ?>dos/reports/index.php" class="<?php echo isActive('index.php', 'reports') ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Reports Center
                    </a>
                </li>

                <li class="sidebar-section-title">⚙ Account</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>profile.php" class="<?php echo isActive('profile.php') ? 'active' : ''; ?>">
                        <i class="fas fa-user-cog"></i> Settings
                    </a>
                </li>
            <?php endif; ?>
            <?php if ($role == 'discipline'): ?>
                <li class="sidebar-section-title">Discipline Management</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>discipline/dashboard.php" class="<?php echo isActive('dashboard.php') ? 'active' : ''; ?>">
                        <i class="fas fa-th-large"></i> Discipline Overview
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>discipline/records/index.php" class="<?php echo isActive('index.php', 'records') ? 'active' : ''; ?>">
                        <i class="fas fa-clipboard-list"></i> Incident Records
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>discipline/records/create.php" class="<?php echo isActive('create.php', 'records') ? 'active' : ''; ?>">
                        <i class="fas fa-plus-circle"></i> Log Incident
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>discipline/records/behavior.php" class="<?php echo isActive('behavior.php', 'records') ? 'active' : ''; ?>">
                        <i class="fas fa-star"></i> Behavior Reports
                    </a>
                </li>
                <li class="sidebar-section-title">Attendance Monitoring</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/attendance/class-report.php" class="<?php echo isActive('class-report.php', 'attendance') ? 'active' : ''; ?>">
                        <i class="fas fa-user-clock"></i> Truancy Monitor
                    </a>
                </li>
            <?php endif; ?>

            <?php if ($role == 'admin'): ?>
                <li class="sidebar-section-title">Registration</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/users/index.php" class="<?php echo isActive('index.php', 'users') ? 'active' : ''; ?>">
                        <i class="fas fa-users-cog"></i> User Management
                    </a>
                </li>
                <li class="sidebar-section-title">System Management</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/roles/index.php" class="<?php echo isActive('index.php', 'roles') ? 'active' : ''; ?>">
                        <i class="fas fa-user-shield"></i> Roles & Permissions
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/security/index.php" class="<?php echo isActive('index.php', 'security') ? 'active' : ''; ?>">
                        <i class="fas fa-shield-alt"></i> Security & Logs
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/backup/index.php" class="<?php echo isActive('index.php', 'backup') ? 'active' : ''; ?>">
                        <i class="fas fa-database"></i> Backup & Recovery
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/database/index.php" class="<?php echo isActive('index.php', 'database') ? 'active' : ''; ?>">
                        <i class="fas fa-server"></i> Database Admin
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>admin/settings/general.php" class="<?php echo isActive('general.php', 'settings') ? 'active' : ''; ?>">
                        <i class="fas fa-cogs"></i> System Settings
                    </a>
                </li>
            <?php endif; ?>

            <?php if ($role == 'teacher'): ?>
                <li class="sidebar-section-title">Teaching Hub</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/classes/index.php" class="<?php echo isActive('index.php', 'classes') ? 'active' : ''; ?>">
                        <i class="fas fa-chalkboard-teacher"></i> My Classes
                    </a>
                </li>
                <li class="has-dropdown <?php echo ($current_dir == 'attendance') ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo ($current_dir == 'attendance') ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-check"></i> Attendance <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo ($current_dir == 'attendance') ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>teacher/attendance/mark.php" class="<?php echo isActive('mark.php', 'attendance') ? 'active' : ''; ?>">Mark Attendance</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/attendance/class-report.php" class="<?php echo isActive('class-report.php', 'attendance') ? 'active' : ''; ?>">Class Report</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/attendance/student-report.php" class="<?php echo isActive('student-report.php', 'attendance') ? 'active' : ''; ?>">Student Report</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/results/exams.php" class="<?php echo isActive('exams.php', 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-poll"></i> Results / Exams
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/period-sign.php" class="<?php echo isActive('period-sign.php', 'teacher') ? 'active' : ''; ?>">
                        <i class="fas fa-clipboard-check"></i> Sign Period
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/lesson-plans/index.php" class="<?php echo isActive('index.php', 'lesson-plans') ? 'active' : ''; ?>">
                        <i class="fas fa-folder-open"></i> Lesson Plans
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/students/index.php" class="<?php echo isActive('index.php', 'students') ? 'active' : ''; ?>">
                        <i class="fas fa-user-graduate"></i> Students
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/studies/index.php" class="<?php echo isActive('index.php', 'studies') ? 'active' : ''; ?>">
                        <i class="fas fa-book-open"></i> Study Materials
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/timetable.php" class="<?php echo isActive('timetable.php') ? 'active' : ''; ?>">
                        <i class="fas fa-clock"></i> Timetable
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/results/parent-messages.php" class="<?php echo isActive('parent-messages.php', 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-sms"></i> Parent Comm.
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/results/reports.php" class="<?php echo isActive('reports.php', 'results') ? 'active' : ''; ?>">
                        <i class="fas fa-file-invoice"></i> Reports
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>teacher/messages/index.php" class="<?php echo isActive('index.php', 'messages') ? 'active' : ''; ?>">
                        <i class="fas fa-bullhorn"></i> Announcements
                    </a>
                </li>
                <li class="sidebar-section-title">Account</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>profile.php" class="<?php echo isActive('profile.php') ? 'active' : ''; ?>">
                        <i class="fas fa-user-cog"></i> Settings
                    </a>
                </li>
            <?php endif; ?>

            <?php if ($role == 'student'): ?>
                <li class="sidebar-section-title">🎓 Student Portal</li>
                <li>
                    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="<?php echo isActive('dashboard.php', 'student') ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                </li>
                <li class="has-dropdown <?php echo (isActive('timetable.php', 'student') || isActive('studies.php', 'student') || isActive('quizzes.php', 'student')) ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo (isActive('timetable.php', 'student') || isActive('studies.php', 'student') || isActive('quizzes.php', 'student')) ? 'active' : ''; ?>">
                        <i class="fas fa-graduation-cap"></i> Academics <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo (isActive('timetable.php', 'student') || isActive('studies.php', 'student') || isActive('quizzes.php', 'student')) ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>student/timetable.php" class="<?php echo isActive('timetable.php', 'student') ? 'active' : ''; ?>">Academic Calendar</a></li>
                        <li><a href="<?php echo BASE_URL; ?>student/studies.php" class="<?php echo isActive('studies.php', 'student') ? 'active' : ''; ?>">Learning Materials</a></li>
                        <li><a href="<?php echo BASE_URL; ?>student/quizzes.php" class="<?php echo isActive('quizzes.php', 'student') ? 'active' : ''; ?>">Online Quizzes</a></li>
                    </ul>
                </li>
                <li class="has-dropdown <?php echo (isActive('results.php', 'student') || isActive('report-forms.php', 'student') || isActive('analytics.php', 'student')) ? 'active-parent' : ''; ?>">
                    <a href="javascript:void(0)" onclick="toggleDropdown(this)" class="<?php echo (isActive('results.php', 'student') || isActive('report-forms.php', 'student') || isActive('analytics.php', 'student')) ? 'active' : ''; ?>">
                        <i class="fas fa-chart-bar"></i> Performance <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo (isActive('results.php', 'student') || isActive('report-forms.php', 'student') || isActive('analytics.php', 'student')) ? 'show' : ''; ?>">
                        <li><a href="<?php echo BASE_URL; ?>student/results.php" class="<?php echo isActive('results.php', 'student') ? 'active' : ''; ?>">My Grades</a></li>
                        <li><a href="<?php echo BASE_URL; ?>student/report-forms.php" class="<?php echo isActive('report-forms.php', 'student') ? 'active' : ''; ?>">Report Forms</a></li>
                        <li><a href="<?php echo BASE_URL; ?>student/analytics.php" class="<?php echo isActive('analytics.php', 'student') ? 'active' : ''; ?>">Analytics</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>student/assignments.php" class="<?php echo isActive('assignments.php', 'student') ? 'active' : ''; ?>">
                        <i class="fas fa-file-signature"></i> Assignments
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>student/announcements.php" class="<?php echo isActive('announcements.php', 'student') ? 'active' : ''; ?>">
                        <i class="fas fa-bullhorn"></i> Announcements
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>student/calendar.php" class="<?php echo isActive('calendar.php', 'student') ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Calendar
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>profile.php" class="<?php echo (isActive('profile.php') && !isset($_GET['tab'])) ? 'active' : ''; ?>">
                        <i class="fas fa-user"></i> Profile
                    </a>
                </li>
                <li>
                    <a href="<?php echo BASE_URL; ?>profile.php?tab=password" class="<?php echo (isActive('profile.php') && isset($_GET['tab']) && $_GET['tab'] === 'password') ? 'active' : ''; ?>">
                        <i class="fas fa-cog"></i> Settings
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
    <script>
        function toggleDropdown(el) {
            const parent = el.closest('.has-dropdown');
            const submenu = parent.querySelector('.submenu');
            
            // Close all other submenus first (Optional)
            // document.querySelectorAll('.submenu').forEach(s => {
            //     if(s !== submenu) s.classList.remove('show');
            // });
            // document.querySelectorAll('.has-dropdown').forEach(p => {
            //     if(p !== parent) p.classList.remove('active-parent');
            // });

            submenu.classList.toggle('show');
            parent.classList.toggle('active-parent');
        }
    </script>
    <div style="border-top: 1px solid var(--accent-soft-red); background: transparent; flex-shrink: 0; width: 100%;">
        <a href="<?php echo BASE_URL; ?>logout.php" style="display: flex; align-items: center; padding: 15px 25px; color: #e74c3c; text-decoration: none; font-weight: 600; font-size: 0.95rem; transition: all 0.3s ease;" onmouseover="this.style.background='rgba(231, 76, 60, 0.1)'" onmouseout="this.style.background='transparent'">
            <i class="fas fa-sign-out-alt" style="width: 30px; font-size: 1.1rem;"></i> Logout
        </a>
    </div>
</aside>
