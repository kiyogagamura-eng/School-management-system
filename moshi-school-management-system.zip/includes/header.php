<?php
/**
 * Global Header
 */
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'User';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'guest';
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . " | " . APP_NAME : APP_NAME; ?></title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main.css?v=<?php echo time(); ?>">
    <?php if ($role === 'student'): ?>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/student_dashboard.css?v=<?php echo time(); ?>">
    <?php endif; ?>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .wrapper {
            display: flex;
            min-height: 100vh;
        }
        .main-content {
            flex: 1;
            background-color: #ffffff;
            /* Offset for the fixed sidebar */
            <?php if ($role === 'student'): ?>
                margin-left: 280px;
                padding: 0;
            <?php else: ?>
                margin-left: 260px;
                padding: 20px;
            <?php endif; ?>
        }
        .top-nav {
            background: #FFFFFF !important;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.03);
        }
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid var(--corporate-red);
        }
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }
        .badge-red {
            background: var(--accent-soft-red);
            color: var(--corporate-red);
        }
    </style>

    <!-- SYSTEM-WIDE FONT ENFORCEMENT (Safe Version) -->
    <style>
        html, body, p, div, span, td, th, a, input, select, textarea {
            font-family: 'Inter', sans-serif !important;
        }
        h1, h2, h3, h4, h5, h6, .page-header h2, .card-header {
            font-family: 'Inter', sans-serif !important;
            font-weight: 800 !important;
        }
        /* Ensure Font Awesome is NEVER touched */
        .fas, .fab, .far, .fa-solid, .fa-brands, .fa-regular, i {
            font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands", sans-serif !important;
            font-weight: 900 !important; /* Font Awesome needs this weight for solid icons */
        }
    </style>
    <script>
        // Force page reload if loaded from browser back-forward cache (bfcache)
        window.addEventListener('pageshow', function (event) {
            if (event.persisted) {
                window.location.reload();
            }
        });
    </script>
</head>
<body class="<?php echo $role === 'student' ? 'student-portal-body' : ''; ?>">
    <div class="wrapper">
        <?php include __DIR__ . '/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="top-nav">
                <div class="header-left">
                    <button id="sidebarCollapse" onclick="toggleSidebar()" class="btn" style="background: transparent; color: #940000; font-size: 1.5rem; padding: 0; margin-right: 20px;">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2 style="margin: 0; font-size: 1.4rem; font-weight: 800; color: #940000; letter-spacing: -0.5px;"><?php echo h($page_title ?? 'Dashboard'); ?></h2>
                </div>

                <div class="header-right" style="display: flex; align-items: center; gap: 20px;">
                    <!-- Notification UI -->
                    <div class="notification-container" style="position: relative;">
                        <button id="notif-btn" onclick="toggleNotifDropdown()" style="background: none; border: none; font-size: 1.3rem; color: #64748b; cursor: pointer; position: relative; padding: 5px;">
                            <i class="fas fa-bell"></i>
                            <span id="notif-badge" style="display: none; position: absolute; top: 0; right: 0; background: #ef4444; color: white; font-size: 0.6rem; font-weight: 800; padding: 2px 5px; border-radius: 10px; border: 2px solid #fff;">0</span>
                        </button>
                        
                        <div id="notif-dropdown" style="display: none; position: absolute; right: 0; top: 100%; width: 320px; background: white; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; z-index: 1000; overflow: hidden; margin-top: 10px;">
                            <div style="padding: 15px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; background: #FFF5F5;">
                                <h4 style="margin: 0; font-size: 0.9rem; color: #8b0000;"><i class="fas fa-bell" style="margin-right: 5px;"></i> Notifications</h4>
                                <button onclick="markAllRead()" style="background: none; border: none; font-size: 0.75rem; color: #3b82f6; font-weight: 700; cursor: pointer;">Mark all read</button>
                            </div>
                            <div id="notif-list" style="max-height: 350px; overflow-y: auto;">
                                <div style="padding: 20px; text-align: center; color: #94a3b8; font-size: 0.85rem;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>
                            </div>
                        </div>
                    </div>

                    <div class="user-meta" style="text-align: right; line-height: 1.2;">
                        <span class="role-badge" style="background: var(--corporate-red); color: #fff; padding: 3px 12px; border-radius: 4px; font-size: 0.6rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 4px; box-shadow: 0 2px 5px rgba(148,0,0,0.2);">
                            <?php echo h(strtoupper($role)); ?>
                        </span>
                        <?php if (strtolower($username) !== strtolower($role)): ?>
                            <div style="font-weight: 700; color: #333; font-size: 0.9rem;"><?php echo h($username); ?></div>
                        <?php endif; ?>
                    </div>
                    <?php 
                    $profile_pic = 'default.png';
                    try {
                        $st_h = $pdo->prepare("SELECT profile_pic FROM users WHERE user_id = ?");
                        $st_h->execute([$_SESSION['user_id']]);
                        $u_h = $st_h->fetch();
                        $profile_pic = $u_h['profile_pic'] ?? 'default.png';
                    } catch(Exception $e) {}
                    ?>
                    <div class="user-profile-img" style="width: 40px; height: 40px; border-radius: 50%; overflow: hidden; border: 2px solid #FFF5F5;">
                        <img src="<?php echo BASE_URL; ?>assets/uploads/profiles/<?php echo h($profile_pic); ?>" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($username); ?>&background=940000&color=fff'">
                    </div>
                </div>
            </header>

            <script>
                function toggleSidebar() {
                    const sidebar = document.querySelector('.sidebar');
                    const mainContent = document.querySelector('.main-content');
                    
                    if (window.innerWidth > 991) {
                        sidebar.classList.toggle('closed');
                        if(mainContent) mainContent.classList.toggle('expanded');
                    } else {
                        sidebar.classList.toggle('open');
                    }
                }
                
                // Close sidebar when clicking outside on mobile
                document.addEventListener('click', function(event) {
                    const sidebar = document.querySelector('.sidebar');
                    const toggle = document.querySelector('.mobile-toggle');
                    
                    if (window.innerWidth <= 991 && 
                        sidebar && toggle &&
                        !sidebar.contains(event.target) && 
                        !toggle.contains(event.target) && 
                        sidebar.classList.contains('open')) {
                        sidebar.classList.remove('open');
                    }
                });
            </script>

            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="fade-in" style="background: <?php echo $_SESSION['flash_type'] == 'success' ? '#fff' : '#fff'; ?>; border-left: 5px solid <?php echo $_SESSION['flash_type'] == 'success' ? '#2ecc71' : 'var(--corporate-red)'; ?>; padding: 15px; margin-bottom: 20px; border-radius: 4px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <?php 
                        echo $_SESSION['flash_message']; 
                        unset($_SESSION['flash_message']);
                        unset($_SESSION['flash_type']);
                    ?>
                </div>
            <?php endif; ?>

            <script>
                // Notification Logic
                const notifBtn = document.getElementById('notif-btn');
                const notifDropdown = document.getElementById('notif-dropdown');
                const notifList = document.getElementById('notif-list');
                const notifBadge = document.getElementById('notif-badge');

                function toggleNotifDropdown() {
                    if (notifDropdown.style.display === 'none') {
                        notifDropdown.style.display = 'block';
                    } else {
                        notifDropdown.style.display = 'none';
                    }
                }

                document.addEventListener('click', function(event) {
                    if (notifBtn && notifDropdown && !notifBtn.contains(event.target) && !notifDropdown.contains(event.target)) {
                        notifDropdown.style.display = 'none';
                    }
                });

                function fetchNotifications() {
                    fetch('<?php echo BASE_URL; ?>api/fetch_notifications.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Update badge
                            if (data.unread_count > 0) {
                                notifBadge.style.display = 'block';
                                notifBadge.innerText = data.unread_count > 9 ? '9+' : data.unread_count;
                            } else {
                                notifBadge.style.display = 'none';
                            }

                            // Update list
                            if (data.data.length === 0) {
                                notifList.innerHTML = '<div style="padding: 20px; text-align: center; color: #94a3b8; font-size: 0.85rem;">No new notifications.</div>';
                            } else {
                                let html = '';
                                data.data.forEach(item => {
                                    let bg = item.is_read == 1 ? '#ffffff' : '#f8fafc';
                                    let fw = item.is_read == 1 ? '500' : '700';
                                    let link = item.link ? 'href="' + item.link + '"' : 'href="#"';
                                    html += `
                                        <a ${link} onclick="markAsRead(${item.notification_id})" style="display: block; padding: 12px 15px; border-bottom: 1px solid #e2e8f0; text-decoration: none; background: ${bg}; transition: 0.2s;">
                                            <div style="font-size: 0.8rem; color: #334155; font-weight: ${fw}; margin-bottom: 5px;">${item.message}</div>
                                            <div style="font-size: 0.65rem; color: #94a3b8;"><i class="far fa-clock"></i> ${new Date(item.created_at).toLocaleString()}</div>
                                        </a>
                                    `;
                                });
                                notifList.innerHTML = html;
                            }
                        }
                    })
                    .catch(err => console.error('Notification error:', err));
                }

                function markAsRead(id) {
                    let fd = new FormData();
                    fd.append('notification_id', id);
                    fetch('<?php echo BASE_URL; ?>api/mark_notification_read.php', { method: 'POST', body: fd })
                    .then(() => fetchNotifications());
                }

                function markAllRead() {
                    let fd = new FormData();
                    fd.append('mark_all', 1);
                    fetch('<?php echo BASE_URL; ?>api/mark_notification_read.php', { method: 'POST', body: fd })
                    .then(() => fetchNotifications());
                }

                // Initial fetch and interval
                fetchNotifications();
                setInterval(fetchNotifications, 30000); // 30 seconds
            </script>
