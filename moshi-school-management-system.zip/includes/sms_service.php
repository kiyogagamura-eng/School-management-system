/**
 * SMS Integration Service
 * Handles triggering SMS for results and attendance
 */

function triggerResultSMS($student_id, $exam_id) {
    global $pdo;
    try {
        // Fetch student and parent info
        $stmt = $pdo->prepare("
            SELECT s.first_name, s.last_name, s.parent_phone, s.parent_name, e.exam_name
            FROM students s
            JOIN exams e ON e.exam_id = ?
            WHERE s.student_id = ?
        ");
        $stmt->execute([$exam_id, $student_id]);
        $data = $stmt->fetch();
        
        if (!$data) return false;

        // Fetch results for calculated average
        $stmt = $pdo->prepare("SELECT AVG(marks_obtained) as average FROM results WHERE student_id = ? AND exam_id = ?");
        $stmt->execute([$student_id, $exam_id]);
        $avg = round($stmt->fetchColumn(), 1);

        $phone = $data['parent_phone'];
        $message = "Hello {$data['parent_name']}. The results for {$data['first_name']} {$data['last_name']} for the exam {$data['exam_name']} are out. The average is {$avg}%. Please log in to the school system to view full results. - MPS";

        return sendSMS($phone, $message);
    } catch (PDOException $e) {
        return false;
    }
}

function triggerAttendanceSMS($student_id, $date, $period) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT first_name, last_name, parent_phone, parent_name FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
        
        if (!$student) return false;

        $phone = $student['parent_phone'];
        $message = "Hello {$student['parent_name']}. {$student['first_name']} was marked absent today {$date} during period {$period}. Please contact the school for further details. - MPS";

        return sendSMS($phone, $message);
    } catch (PDOException $e) {
        return false;
    }
}
