<?php
// Africa's Talking USSD Endpoint
// Flow: Admission No → Year → Exam → Results
header('Content-Type: text/plain');

// Receive POST data
$sessionId   = $_POST["sessionId"] ?? "";
$serviceCode = $_POST["serviceCode"] ?? "";
$phoneNumber = $_POST["phoneNumber"] ?? "";
$text        = $_POST["text"] ?? "";

// DB Connection
require_once '../includes/config.php';
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    echo "END System is offline. Please try again later.";
    exit;
}

// Require helper functions (for division calculation)
require_once '../includes/functions.php';

// Parse input: "STD-2026-001*1*2" → ['STD-2026-001','1','2']
$parts = array_map('trim', explode("*", $text));
$level = empty($text) ? 0 : count($parts);

// ── HELPERS ──────────────────────────────────
function getYears($pdo, $sid) {
    // Use academic_year from academic_terms (same as website)
    // exam_date may be NULL but academic_year is always set
    $stmt = $pdo->prepare("
        SELECT DISTINCT t.academic_year AS yr
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        JOIN academic_terms t ON e.term_id = t.term_id
        WHERE r.student_id = ?
          AND r.status = 'published'
          AND t.academic_year IS NOT NULL
        ORDER BY yr DESC LIMIT 6
    ");
    $stmt->execute([$sid]);
    $years = $stmt->fetchAll(PDO::FETCH_COLUMN);
    return array_filter($years, fn($y) => !empty($y));
}


function getExams($pdo, $sid, $year) {
    // Fetch unique exam names (groups subjects of the same exam together)
    $stmt = $pdo->prepare("
        SELECT MIN(e.exam_id) as exam_id, e.exam_name, e.exam_type, t.term_name, t.academic_year
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        JOIN academic_terms t ON e.term_id = t.term_id
        WHERE r.student_id = ?
          AND r.status = 'published'
          AND t.academic_year = ?
        GROUP BY e.exam_name, e.exam_type
        ORDER BY exam_id ASC LIMIT 8
    ");
    $stmt->execute([$sid, $year]);
    return $stmt->fetchAll();
}

function shortName($name, $type = '') {
    // Create a short readable label based on exam_type
    $typeLabels = [
        'midterm'    => 'Mid',
        'endterm'    => 'EoT',
        'test'       => 'Test',
        'assignment' => 'Asgn',
        'practical'  => 'Prac',
    ];
    $name = preg_replace('/\b20\d{2}\b/', '', $name);
    $name = preg_replace('/examination/i', 'Exam', $name);
    $name = preg_replace('/End of Term/i', 'EoT', $name);
    $name = preg_replace('/Annual/i', 'Annual', $name);
    $name = trim($name);
    // Prefix with type label if available
    if ($type && isset($typeLabels[$type])) {
        $prefix = $typeLabels[$type];
        // Avoid double prefix
        if (stripos($name, $prefix) === false) {
            $name = "[$prefix] " . $name;
        }
    }
    if (strlen($name) > 22) $name = substr($name, 0, 22) . "..";
    return $name;
}

function getStudent($pdo, $adm) {
    $stmt = $pdo->prepare(
        "SELECT student_id, first_name, last_name FROM students WHERE admission_number = ? LIMIT 1"
    );
    $stmt->execute([$adm]);
    return $stmt->fetch();
}

// ── LEVEL 0: Welcome ──────────────────────────
if ($level === 0) {
    echo "CON Welcome to Moshi School Portal\nEnter Admission Number:";
    exit;
}

// ── LEVEL 1: Validate student → Show years ────
if ($level === 1) {
    $student = getStudent($pdo, $parts[0]);

    if (!$student) {
        echo "END Admission Number '" . $parts[0] . "' not found.\nVerify the number and try again.";
        exit;
    }

    $years = array_values(getYears($pdo, $student['student_id']));

    if (empty($years)) {
        echo "END " . $student['first_name'] . " " . $student['last_name'] . "\nHas no results in the system yet.";
        exit;
    }

    $resp  = "CON " . $student['first_name'] . " " . $student['last_name'] . "\n";
    $resp .= "Select Year:\n";
    foreach ($years as $i => $yr) {
        $resp .= ($i + 1) . ". " . $yr . "\n";
    }
    echo rtrim($resp);
    exit;
}

// ── LEVEL 2: Got year → Show exams ───────────
if ($level === 2) {
    $student     = getStudent($pdo, $parts[0]);
    $year_choice = (int)$parts[1];

    if (!$student) { echo "END Error. Please try again."; exit; }

    $years = array_values(getYears($pdo, $student['student_id']));

    if ($year_choice < 1 || $year_choice > count($years)) {
        echo "END Choice '$year_choice' is invalid. Please dial again.";
        exit;
    }

    $selected_year = $years[$year_choice - 1];
    $exams = getExams($pdo, $student['student_id'], $selected_year);

    if (empty($exams)) {
        echo "END No results found for year $selected_year.";
        exit;
    }

    $resp  = "CON Year: $selected_year\nSelect Exam:\n";
    foreach ($exams as $i => $exam) {
        $type = $exam['exam_type'] ?? '';
        $resp .= ($i + 1) . ". " . shortName($exam['exam_name'], $type) . "\n";
    }
    echo rtrim($resp);
    exit;
}

// ── LEVEL 3: Got exam → Show results ─────────
if ($level === 3) {
    $student     = getStudent($pdo, $parts[0]);
    $year_choice = (int)$parts[1];
    $exam_choice = (int)$parts[2];

    if (!$student) { echo "END Error. Please try again."; exit; }

    $years = array_values(getYears($pdo, $student['student_id']));
    if ($year_choice < 1 || $year_choice > count($years)) {
        echo "END Selected year is invalid. Please dial again.";
        exit;
    }
    $selected_year = $years[$year_choice - 1];

    $exams = getExams($pdo, $student['student_id'], $selected_year);
    if ($exam_choice < 1 || $exam_choice > count($exams)) {
        echo "END Selected exam is invalid. Please dial again.";
        exit;
    }
    $selected_exam = $exams[$exam_choice - 1];

    // Fetch grades
    $stmt = $pdo->prepare("
        SELECT s.subject_code, r.grade, r.marks_obtained, gs.point_value
        FROM results r
        JOIN subjects s ON r.subject_id = s.subject_id
        JOIN exams e ON r.exam_id = e.exam_id
        JOIN academic_terms t ON e.term_id = t.term_id
        LEFT JOIN grading_scale gs ON r.grade = gs.grade
        WHERE r.student_id = ? 
          AND e.exam_name = ?
          AND t.academic_year = ?
          AND r.status = 'published'
        GROUP BY s.subject_code
        ORDER BY s.subject_code ASC
    ");
    $stmt->execute([$student['student_id'], $selected_exam['exam_name'], $selected_year]);
    $results = $stmt->fetchAll();

    if (empty($results)) {
        echo "END Results for this exam do not exist.";
        exit;
    }

    $exam_label = shortName($selected_exam['exam_name']);
    
    // Detailed Format matched to Screenshot/SMS
    $response = "END RESULTS FOR\n";
    $response .= mb_strtoupper($student['first_name'] . " " . $student['last_name']) . "\n";
    
    foreach ($results as $r) {
        // Find subject name (not just code)
        $stmt_s = $pdo->prepare("SELECT subject_name FROM subjects WHERE subject_code = ?");
        $stmt_s->execute([$r['subject_code']]);
        $s_name = $stmt_s->fetchColumn();
        
        $response .= $s_name . "--" . round($r['marks_obtained'] ?? 0) . "--(" . $r['grade'] . ")\n";
    }

    // Division & Summary
    $div_info = calculateOLevelDivision($results);
    $response .= "\nDiv: " . $div_info['division'] . " Pts: " . $div_info['total_points'];

    echo $response;
    exit;
}

// Fallback
echo "END An error occurred. Please dial again.";
?>
