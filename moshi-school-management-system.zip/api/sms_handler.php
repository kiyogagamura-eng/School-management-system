<?php
require_once '../includes/bootstrap.php';

$incoming_msg = $_POST['message'] ?? '';
$sender = $_POST['sender'] ?? '+255712000111';
$reply = "";

if (!empty($incoming_msg)) {
    $parts = explode(' ', trim($incoming_msg));
    $command = strtoupper($parts[0] ?? '');
    $admission_no = $parts[1] ?? '';

    if ($command == 'RESULT' && !empty($admission_no)) {
        // Fetch student
        $stmt = $pdo->prepare("SELECT student_id, first_name, last_name FROM students WHERE admission_number = ?");
        $stmt->execute([$admission_no]);
        $student = $stmt->fetch();

        if ($student) {
            // Get latest published results
            $stmt = $pdo->prepare("
                SELECT r.marks_obtained, r.grade, e.exam_name
                FROM results r
                JOIN exams e ON r.exam_id = e.exam_id
                WHERE r.student_id = ? AND r.status = 'published'
                ORDER BY e.created_at DESC
            ");
            $stmt->execute([$student['student_id']]);
            $results = $stmt->fetchAll();

            if (!empty($results)) {
                $exam_name = $results[0]['exam_name'];
                $total = 0;
                $count = count($results);
                foreach($results as $r) { $total += $r['marks_obtained']; }
                $avg = round($total / $count, 1);
                $grade = calculateGrade($avg);

                $reply = "Hello. Results for " . $student['first_name'] . " (" . $exam_name . "):\nAverage: " . $avg . "%\nGrade: " . $grade . "\nPosition: Available on portal.\nShuleXpert SMS.";
            } else {
                $reply = "Sorry, no results published yet for " . $admission_no;
            }
        } else {
            $reply = "Admission number " . $admission_no . " does not exist. Please check and try again.";
        }
    } else {
        $reply = "Format is wrong. Send: RESULT [AdmissionNo]\nExample: RESULT STD-2026-001";
    }

    // Log the reply in communications table
    $stmt = $pdo->prepare("INSERT INTO communications (comm_type, recipient, message, status) VALUES ('sms', ?, ?, 'sent')");
    $stmt->execute([$sender, $reply]);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>SMS Result Simulator</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f7f6; padding: 40px; display: flex; flex-direction: column; align-items: center; }
        .sms-app { width: 350px; background: white; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); overflow: hidden; border: 10px solid #fff; }
        .sms-header { background: #007bff; color: white; padding: 20px; text-align: center; font-weight: 700; }
        .sms-body { height: 450px; padding: 15px; display: flex; flex-direction: column; gap: 10px; overflow-y: auto; background: #e5ddd5; }
        .message { max-width: 80%; padding: 10px 15px; border-radius: 15px; font-size: 14px; line-height: 1.4; position: relative; }
        .sent { align-self: flex-end; background: #dcf8c6; border-bottom-right-radius: 0; }
        .received { align-self: flex-start; background: white; border-bottom-left-radius: 0; }
        .sms-footer { padding: 15px; background: #f0f0f0; display: flex; gap: 10px; }
        input { flex: 1; border: none; padding: 10px; border-radius: 20px; outline: none; }
        button { background: #007bff; color: white; border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; }
        .meta { font-size: 10px; color: #999; margin-top: 5px; display: block; text-align: right; }
    </style>
</head>
<body>

    <h2 style="color: #940000; font-weight: 900; margin-bottom: 30px;">SMS RESULTS SYSTEM SIMULATOR</h2>

    <div class="sms-app">
        <div class="sms-header">
            15555 - School Portal
        </div>
        <div class="sms-body" id="chat">
            <div class="message received">
                Welcome to ShuleXpert SMS. Send RESULT [Admission No] to get results.
                <span class="meta">Just now</span>
            </div>
            
            <?php if (!empty($incoming_msg)): ?>
                <div class="message sent">
                    <?php echo h($incoming_msg); ?>
                    <span class="meta"><?php echo date('H:i'); ?></span>
                </div>
                <div class="message received">
                    <?php echo nl2br(h($reply)); ?>
                    <span class="meta"><?php echo date('H:i'); ?></span>
                </div>
            <?php endif; ?>
        </div>
        <form class="sms-footer" method="POST">
            <input type="text" name="message" placeholder="Type RESULT [No]..." required autocomplete="off">
            <button type="submit"><i class="fas fa-paper-plane"></i></button>
        </form>
    </div>

    <div style="margin-top: 30px; color: #666; font-size: 13px; text-align: center;">
        <b>Instruction:</b> Enter an admission number (e.g., <b>STD-Form4A-002</b>) to test.<br>
        This simulates the parent sending an SMS to the shortcode <b>15555</b>.
    </div>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
