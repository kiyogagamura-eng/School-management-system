<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$notification_id = isset($_POST['notification_id']) ? (int)$_POST['notification_id'] : null;
$mark_all = isset($_POST['mark_all']) ? (bool)$_POST['mark_all'] : false;

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

if ($mark_all) {
    if (markNotificationRead(null, $user_id, $user_role)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to mark all as read']);
    }
} elseif ($notification_id) {
    // Optionally verify ownership 
    if (markNotificationRead($notification_id)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to mark notification']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
