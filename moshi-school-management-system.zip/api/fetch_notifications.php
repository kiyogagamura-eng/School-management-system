<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

try {
    // Fetch notifications either directed to the user OR their role
    $stmt = $pdo->prepare("
        SELECT * FROM system_notifications 
        WHERE (recipient_id = ? OR recipient_role = ?) 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute([$user_id, $user_role]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get unread count
    $stmtCount = $pdo->prepare("
        SELECT COUNT(*) FROM system_notifications 
        WHERE (recipient_id = ? OR recipient_role = ?) AND is_read = 0
    ");
    $stmtCount->execute([$user_id, $user_role]);
    $unreadCount = $stmtCount->fetchColumn();

    echo json_encode([
        'status' => 'success', 
        'data' => $notifications,
        'unread_count' => (int)$unreadCount
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
