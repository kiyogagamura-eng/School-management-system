-- MOSHI PUBLIC SECONDARY SCHOOLS MANAGEMENT SYSTEM
-- DATABASE SCHEMA

CREATE DATABASE IF NOT EXISTS moshi_sms;
USE moshi_sms;

-- Users Table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    role ENUM('admin', 'headteacher', 'dos', 'teacher', 'student', 'parent') NOT NULL,
    status ENUM('active', 'inactive', 'locked') DEFAULT 'active',
    last_login DATETIME,
    last_login_ip VARCHAR(45),
    failed_attempts INT DEFAULT 0,
    locked_until DATETIME,
    remember_token VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Teachers Table
CREATE TABLE teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    date_of_birth DATE,
    phone VARCHAR(20),
    email VARCHAR(100),
    qualification TEXT,
    specialization TEXT,
    position ENUM('Teacher', 'Class Teacher', 'Subject Head', 'Assistant Head (Admin)', 'Assistant Head (Academic)', 'DOS', 'Deputy Headteacher', 'Headteacher') DEFAULT 'Teacher',
    department VARCHAR(100),
    hire_date DATE,
    address TEXT,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Classes Table
CREATE TABLE classes (
    class_id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(50) NOT NULL,
    form_level INT NOT NULL,
    stream VARCHAR(10) NOT NULL,
    academic_year VARCHAR(10) NOT NULL,
    class_teacher_id INT,
    capacity INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
);

-- Students Table
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    admission_number VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    date_of_birth DATE,
    class_id INT,
    parent_name VARCHAR(100),
    parent_phone VARCHAR(20),
    parent_email VARCHAR(100),
    parent_alternative_phone VARCHAR(20),
    address TEXT,
    enrollment_date DATE,
    status ENUM('Active', 'Inactive', 'Transferred', 'Graduated') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE SET NULL
);

-- Parents Table
CREATE TABLE parents (
    parent_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    parent_name VARCHAR(100) NOT NULL,
    parent_phone VARCHAR(20) NOT NULL,
    parent_email VARCHAR(100),
    alternative_phone VARCHAR(20),
    verified BOOLEAN DEFAULT FALSE,
    sms_enabled BOOLEAN DEFAULT TRUE,
    last_otp VARCHAR(6),
    otp_expires_at DATETIME,
    otp_attempts INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Subjects Table
CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    is_compulsory BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Class Subjects Table
CREATE TABLE class_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT,
    subject_id INT,
    teacher_id INT,
    academic_term VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
);

-- Academic Terms Table
CREATE TABLE academic_terms (
    term_id INT AUTO_INCREMENT PRIMARY KEY,
    term_name VARCHAR(50) NOT NULL,
    academic_year VARCHAR(10) NOT NULL,
    start_date DATE,
    end_date DATE,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Table
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    class_id INT,
    subject_id INT,
    teacher_id INT,
    attendance_date DATE NOT NULL,
    period INT NOT NULL,
    status ENUM('present', 'absent', 'late') NOT NULL,
    remarks TEXT,
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
);

-- Study Materials Table
CREATE TABLE study_materials (
    material_id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT,
    subject_id INT,
    teacher_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(50),
    material_type ENUM('notes', 'assignment', 'reference', 'video') NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATE,
    downloads INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
);

-- Exams Table
CREATE TABLE exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(100) NOT NULL,
    exam_type ENUM('midterm', 'endterm', 'test', 'assignment', 'practical') NOT NULL,
    class_id INT,
    subject_id INT,
    teacher_id INT,
    exam_date DATE,
    max_marks INT DEFAULT 100,
    pass_marks INT DEFAULT 40,
    weightage DECIMAL(5,2),
    term_id INT,
    is_published BOOLEAN DEFAULT FALSE,
    publish_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL,
    FOREIGN KEY (term_id) REFERENCES academic_terms(term_id) ON DELETE SET NULL
);

-- Results Table
CREATE TABLE results (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT,
    student_id INT,
    subject_id INT,
    class_id INT,
    marks_obtained DECIMAL(5,2),
    grade VARCHAR(2),
    remarks TEXT,
    teacher_comments TEXT,
    status ENUM('draft', 'submitted', 'published') DEFAULT 'draft',
    entered_by INT,
    entered_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exams(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (entered_by) REFERENCES teachers(teacher_id) ON DELETE SET NULL,
    UNIQUE KEY unique_student_exam (student_id, exam_id)
);

CREATE TABLE announcements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    priority ENUM('normal', 'high') DEFAULT 'normal',
    target_role VARCHAR(50) NOT NULL,
    target_id INT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    read_count INT DEFAULT 0,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Communications Table
CREATE TABLE communications (
    comm_id INT AUTO_INCREMENT PRIMARY KEY,
    comm_type ENUM('announcement', 'sms', 'alert') NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    sender_id INT,
    sent_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scheduled_date DATETIME,
    status ENUM('draft', 'scheduled', 'sent', 'partial', 'failed') DEFAULT 'sent',
    character_count INT,
    sms_count INT,
    FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Communication Recipients Table
CREATE TABLE communication_recipients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    comm_id INT,
    recipient_type ENUM('parent', 'teacher', 'student', 'class') NOT NULL,
    recipient_id INT,
    phone_number VARCHAR(20),
    status ENUM('pending', 'sent', 'delivered', 'failed') DEFAULT 'pending',
    sent_at DATETIME,
    delivered_at DATETIME,
    error_message TEXT,
    FOREIGN KEY (comm_id) REFERENCES communications(comm_id) ON DELETE CASCADE
);

-- Message Templates Table
CREATE TABLE message_templates (
    template_id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100),
    template_category VARCHAR(50),
    subject VARCHAR(255),
    message TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- SMS Settings Table
CREATE TABLE sms_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    provider VARCHAR(50),
    api_key VARCHAR(255),
    api_secret VARCHAR(255),
    sender_id VARCHAR(50),
    credit_balance DECIMAL(10,2),
    low_balance_threshold DECIMAL(10,2),
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- SMS Logs Table
CREATE TABLE sms_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    comm_id INT,
    recipient_phone VARCHAR(20),
    message TEXT,
    status VARCHAR(50),
    provider_response TEXT,
    cost DECIMAL(10,4),
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivered_at DATETIME,
    FOREIGN KEY (comm_id) REFERENCES communications(comm_id) ON DELETE SET NULL
);

-- Activity Logs Table
CREATE TABLE activity_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255),
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- System Settings Table
CREATE TABLE system_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Grading Scale Table (Added for proper grading calculation)
CREATE TABLE grading_scale (
    grade_id INT AUTO_INCREMENT PRIMARY KEY,
    grade VARCHAR(2) NOT NULL UNIQUE,
    min_marks INT NOT NULL,
    max_marks INT NOT NULL,
    grade_point DECIMAL(3,1),
    division INT,
    label VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Timetables Table (Added for schedule management)
CREATE TABLE timetables (
    timetable_id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT NOT NULL,
    subject_id INT NOT NULL,
    teacher_id INT NOT NULL,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    period_number INT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room_number VARCHAR(20),
    academic_term VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE CASCADE,
    UNIQUE KEY unique_slot (class_id, day_of_week, period_number, academic_term)
);

-- School Events Table (Added for holidays and special events)
CREATE TABLE school_events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_type ENUM('holiday', 'exam', 'sports_day', 'parents_meeting', 'other') NOT NULL,
    event_date DATE NOT NULL,
    end_date DATE,
    description TEXT,
    is_attendance_exempt BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Parent Portal Sessions Table (For OTP-based parent access)
CREATE TABLE parent_sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    parent_phone VARCHAR(20) NOT NULL,
    student_id INT NOT NULL,
    session_token VARCHAR(100) NOT NULL UNIQUE,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    last_activity DATETIME,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    INDEX idx_token (session_token),
    INDEX idx_expires (expires_at)
);

-- INSERT DEFAULT GRADING SCALE (Tanzania O-Level System)
INSERT INTO grading_scale (grade, min_marks, max_marks, grade_point, division, label) VALUES
('A', 80, 100, 5.0, 1, 'Excellent'),
('B+', 75, 79, 4.5, 1, 'Very Good'),
('B', 70, 74, 4.0, 2, 'Good'),
('C+', 65, 69, 3.5, 2, 'Good'),
('C', 60, 64, 3.0, 3, 'Satisfactory'),
('D+', 55, 59, 2.5, 3, 'Pass'),
('D', 50, 54, 2.0, 4, 'Pass'),
('E', 40, 49, 1.0, 4, 'Pass'),
('F', 0, 39, 0.0, 0, 'Fail');

-- System Notifications Table
CREATE TABLE system_notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_id INT NULL,
    recipient_role VARCHAR(50) NULL,
    message TEXT NOT NULL,
    link VARCHAR(255) NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipient_id) REFERENCES users(user_id) ON DELETE CASCADE
);
