# Moshi Public Secondary Schools Management System

A web-based school management system built as a final-year diploma project for a government secondary school in Moshi Municipal Council, Tanzania. The system digitises student records, attendance, results, timetabling, and school-to-parent communication for a public school setting.

> Final Year Project — Diploma in Business Information and Communication Technology, Moshi Co-operative University.
>
> This is an academic prototype, not a finished production system — it was built to demonstrate the design and functionality of a school management solution.

## About

This system was designed to address real administrative challenges observed during field research at a government school in Moshi: paper-based student records, manual attendance tracking, and slow communication between the school and parents. It provides role-based dashboards for administrators, the Director of Studies (DoS), the headteacher, teachers, and students.

## Features

- **User & role management** — admin, headteacher, DoS, teachers, students, and parents, each with scoped access
- **Student records** — admission, profiles, and class allocation
- **Attendance tracking** — daily attendance capture with class and student-level reports
- **Timetable management** — subject/teacher assignment with conflict checking
- **Examinations & results** — grading scale, results compilation, and printable report cards
- **School communication** — announcements and SMS notifications to parents (via NextSMS gateway)
- **Discipline records** — logging and tracking of student discipline cases
- **Reports & analytics** — attendance, performance, and activity reports for school leadership
- **System administration** — settings, academic terms, role permissions, and activity/security logs

## Tech Stack

- **Backend:** PHP (procedural, no framework)
- **Database:** MySQL
- **Frontend:** HTML, CSS, JavaScript
- **Notifications:** NextSMS API (SMS to parents/teachers)

## Project Structure

```
├── admin/           # Admin dashboards: users, classes, subjects, results, timetable, reports, settings
├── dos/             # Director of Studies dashboards: examinations, lesson plans, analytics
├── headteacher/     # Headteacher dashboard and report center
├── teacher/         # Teacher-facing pages
├── student/         # Student-facing pages
├── discipline/      # Discipline records module
├── api/             # SMS handler, notifications, USSD endpoint
├── ajax/            # AJAX endpoints
├── includes/        # Shared config, auth, DB connection, helper functions
├── assets/          # CSS, JS, images
├── schema.sql       # Full database schema (structure only, no student data)
└── index.php        # Login entry point
```

## Note on Data

This repository ships with the **database structure only** (`schema.sql`). No real student, parent, or teacher data is included, in line with basic data-protection practice for information involving minors.

## Authors

Developed by a three-member student team at Moshi Co-operative University as part of the final-year ICT project, supervised by university lecturers.

## License

Academic project — shared for portfolio purposes.
