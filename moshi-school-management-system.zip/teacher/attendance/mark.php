<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Mark Attendance";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];

$selected_class   = $_GET['class_id'] ?? null;
$selected_subject = $_GET['subject_id'] ?? null;
$selected_date    = $_GET['date'] ?? date('Y-m-d');

// Validation for year limit
$selected_year = (int)date('Y', strtotime($selected_date));
$current_year  = (int)date('Y');

if ($selected_year > $current_year) {
    $error = "The selected year has not arrived yet (You cannot choose a future year like $selected_year).";
    $selected_class = null;
    $selected_subject = null;
} elseif ($selected_year < 2024) {
    $error = "The selected year is in the past (You cannot choose a year before 2024).";
    $selected_class = null;
    $selected_subject = null;
}

// Fetch assigned subjects for this teacher
try {
    $stmt = $pdo->prepare("
        SELECT cs.class_id, cs.subject_id, c.class_name, s.subject_name 
        FROM class_subjects cs
        JOIN classes c ON cs.class_id = c.class_id
        JOIN subjects s ON cs.subject_id = s.subject_id
        WHERE cs.teacher_id = ?
        
        UNION
        
        SELECT c.class_id, 0 as subject_id, c.class_name, 'GENERAL ATTENDANCE' as subject_name
        FROM classes c
        WHERE c.class_teacher_id = ?
    ");
    $stmt->execute([$teacher_id, $teacher_id]);
    $my_subjects = $stmt->fetchAll();
} catch (PDOException $e) {
    $my_subjects = [];
}

$students = [];
$actual_subject_id = null;
if ($selected_class && ($selected_subject !== null)) {
    $actual_subject_id = ($selected_subject == 0) ? null : $selected_subject;
    $stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
    $stmt->execute([$selected_class]);
    $students = $stmt->fetchAll();
}

// Handle Attendance Submission
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_attendance'])) {
    $attendance_data = $_POST['attendance'] ?? [];
    $submit_class    = $_POST['submit_class_id'];
    $submit_subject  = $_POST['submit_subject_id'] ?: null;
    $submit_date     = $_POST['submit_date'];
    $all_ids         = $_POST['all_student_ids'] ?? [];

    try {
        $pdo->beginTransaction();

        // Delete any existing attendance for this class/subject/date to avoid duplicates
        $del = $pdo->prepare("DELETE FROM attendance WHERE class_id = ? AND subject_id " . ($submit_subject ? "= ?" : "IS NULL") . " AND attendance_date = ? AND teacher_id = ?");
        if ($submit_subject) {
            $del->execute([$submit_class, $submit_subject, $submit_date, $teacher_id]);
        } else {
            $del->execute([$submit_class, $submit_date, $teacher_id]);
        }

        $ins = $pdo->prepare("INSERT INTO attendance (student_id, class_id, subject_id, teacher_id, attendance_date, period, status, remarks) VALUES (?, ?, ?, ?, ?, 1, ?, '')");

        foreach ($all_ids as $sid) {
            // Default is 'present'; if student_id is in absent array → absent
            $status = isset($attendance_data[$sid]) ? $attendance_data[$sid] : 'present';
            $ins->execute([$sid, $submit_class, $submit_subject, $teacher_id, $submit_date, $status]);
        }

        $pdo->commit();
        $success = "Attendance saved successfully! (" . date('d/m/Y', strtotime($submit_date)) . ")";

        // Reload students list after save
        $stmt2 = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
        $stmt2->execute([$selected_class]);
        $students = $stmt2->fetchAll();

    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch already-saved attendance for today (to pre-fill)
$saved_attendance = [];
if ($selected_class && $selected_date) {
    $q = $pdo->prepare("SELECT student_id, status FROM attendance WHERE class_id = ? AND attendance_date = ? AND teacher_id = ? AND subject_id " . ($actual_subject_id ? "= ?" : "IS NULL"));
    if ($actual_subject_id) {
        $q->execute([$selected_class, $selected_date, $teacher_id, $actual_subject_id]);
    } else {
        $q->execute([$selected_class, $selected_date, $teacher_id]);
    }
    foreach ($q->fetchAll() as $row) {
        $saved_attendance[$row['student_id']] = $row['status'];
    }
}

require_once '../../includes/header.php';
?>
<style>
    .att-container { padding: 20px 30px; max-width: 900px; margin: 0 auto; }

    /* ── Top toolbar ─────────────────────────────── */
    .att-toolbar { display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; background: white; border: 1px solid #f0f0f0; border-radius: 14px; padding: 18px 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.04); }
    .att-toolbar .form-group { margin: 0; flex: 1; min-width: 180px; }
    .att-toolbar select, .att-toolbar input[type=date] { padding: 10px 13px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 0.88rem; width: 100%; }
    .att-toolbar .btn-load { background: #940000; color: white; border: none; padding: 10px 22px; border-radius: 8px; font-weight: 700; font-size: 0.88rem; cursor: pointer; white-space: nowrap; }
    .att-toolbar .btn-load:hover { background: #7a0000; }

    /* ── Counter bar ─────────────────────────────── */
    .counter-bar { display: flex; gap: 12px; margin-bottom: 18px; }
    .counter-pill { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 14px 10px; border-radius: 12px; font-weight: 800; }
    .counter-pill.total  { background: #f1f5f9; color: #475569; }
    .counter-pill.pres   { background: #fff5f5; color: #940000; border: 1.5px solid #fca5a5; }
    .counter-pill.abs    { background: #fefce8; color: #92400e; border: 1.5px solid #fcd34d; }
    .counter-pill .cnt   { font-size: 2rem; line-height: 1; }
    .counter-pill .lbl   { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.75; }

    /* ── Action bar ─────────────────────────────── */
    .action-bar { display: flex; gap: 10px; align-items: center; margin-bottom: 15px; }
    .btn-all-present { background: #940000; color: white; border: none; padding: 9px 20px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; cursor: pointer; }
    .btn-all-absent { background: #fff; color: #92400e; border: 2px solid #fcd34d; padding: 9px 20px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; cursor: pointer; }
    .search-att { margin-left: auto; position: relative; }
    .search-att input { padding: 9px 14px 9px 36px; border: 1px solid #e0e0e0; border-radius: 20px; font-size: 0.85rem; width: 220px; }
    .search-att i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #aaa; }

    /* ── Student list ────────────────────────────── */
    .student-grid { background: white; border-radius: 14px; border: 1px solid #f0f0f0; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.04); }
    .student-row {
        display: flex; align-items: center; gap: 14px;
        padding: 10px 18px; border-bottom: 1px solid #f8f8f8;
        cursor: pointer; user-select: none; transition: background 0.15s;
    }
    .student-row:last-child { border-bottom: none; }
    .student-row:hover { background: #fafafa; }

    /* Status states */
    .student-row.is-present { background: white; }
    .student-row.is-absent  { background: #fefce8; }
    .student-row.is-late    { background: #fff5f5; }

    .row-num { width: 26px; font-size: 0.75rem; color: #bbb; font-weight: 700; text-align: right; flex-shrink: 0; }
    .row-avatar { width: 34px; height: 34px; border-radius: 50%; background: #f5f5f5; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 800; color: #940000; flex-shrink: 0; }
    .row-name   { flex: 1; font-size: 0.9rem; font-weight: 700; color: #1e293b; }
    .row-adm    { font-size: 0.72rem; color: #94a3b8; font-weight: 600; }

    /* Big status toggle button */
    .row-toggle { flex-shrink: 0; display: flex; gap: 6px; }
    .tgl-btn { padding: 6px 14px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; border: none; cursor: pointer; letter-spacing: 0.3px; transition: all 0.15s; }
    .tgl-p { background: #940000; color: white; }
    .tgl-a { background: #fef3c7; color: #92400e; border: 2px solid #fcd34d; }
    .tgl-l { background: #fff5f5; color: #940000; border: 2px solid #fca5a5; }
    .tgl-btn.inactive { background: #f1f5f9; color: #cbd5e1; border: 1.5px solid #e2e8f0; }

    /* Save button */
    .save-bar { margin-top: 20px; text-align: right; }
    .btn-save { background: #940000; color: white; border: none; padding: 14px 45px; border-radius: 50px; font-size: 0.95rem; font-weight: 800; cursor: pointer; box-shadow: 0 8px 20px rgba(148,0,0,0.2); transition: all 0.2s; }
    .btn-save:hover { background: #7a0000; transform: translateY(-1px); box-shadow: 0 12px 25px rgba(148,0,0,0.25); }

    .alert-success { background: #fff5f5; color: #940000; border: 1px solid #fca5a5; padding: 12px 16px; border-radius: 10px; font-weight: 700; margin-bottom: 15px; }
    .alert-error   { background: #fefce8; color: #92400e; border: 1px solid #fcd34d; padding: 12px 16px; border-radius: 10px; font-weight: 700; margin-bottom: 15px; }
</style>

<div class="att-container">
    <div style="margin-bottom: 20px;">
        <h2 style="margin: 0; color: #940000; font-weight: 900; font-size: 1.4rem;">
            <i class="fas fa-calendar-check"></i> Student Attendance
        </h2>
        <p style="color: #64748b; margin: 4px 0 0; font-size: 0.85rem;">
            Select Class → Set all Present → Click on those who are Absent
        </p>
    </div>

    <!-- ── Toolbar ── -->
    <form method="GET" class="att-toolbar">
        <div class="form-group">
            <label style="font-size:0.78rem;font-weight:700;color:#64748b;display:block;margin-bottom:5px;">CLASS / SUBJECT</label>
            <select name="subject_class" onchange="const p=this.value.split('|'); this.form.elements['class_id'].value=p[0]; this.form.elements['subject_id'].value=p[1]; this.form.submit();">
                <option value="|">-- Select --</option>
                <?php foreach ($my_subjects as $s): ?>
                    <option value="<?= $s['class_id'].'|'.$s['subject_id'] ?>"
                        <?= ($selected_class==$s['class_id'] && $selected_subject==$s['subject_id']) ? 'selected' : '' ?>>
                        <?= h($s['class_name'].' — '.$s['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="class_id"   value="<?= h($selected_class) ?>">
            <input type="hidden" name="subject_id" value="<?= h($selected_subject) ?>">
        </div>
        <div class="form-group">
            <label style="font-size:0.78rem;font-weight:700;color:#64748b;display:block;margin-bottom:5px;">DATE</label>
            <input type="date" name="date" value="<?= h($selected_date) ?>" onchange="this.form.submit()">
        </div>
        <button type="submit" class="btn-load"><i class="fas fa-list"></i> LOAD LIST</button>
    </form>

    <?php if ($success): ?><div class="alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert-error"><i class="fas fa-exclamation-triangle"></i> <?= $error ?></div><?php endif; ?>

    <?php if (!empty($students)): ?>
    <form method="POST" id="attForm">
        <input type="hidden" name="submit_class_id"   value="<?= h($selected_class) ?>">
        <input type="hidden" name="submit_subject_id" value="<?= h($actual_subject_id) ?>">
        <input type="hidden" name="submit_date"       value="<?= h($selected_date) ?>">
        <?php foreach ($students as $s): ?>
            <input type="hidden" name="all_student_ids[]" value="<?= $s['student_id'] ?>">
        <?php endforeach; ?>

        <!-- ── Counters ── -->
        <div class="counter-bar">
            <div class="counter-pill total">
                <span class="cnt"><?= count($students) ?></span>
                <span class="lbl">Total</span>
            </div>
            <div class="counter-pill pres">
                <span class="cnt" id="cnt-present">0</span>
                <span class="lbl">✓ Present</span>
            </div>
            <div class="counter-pill abs">
                <span class="cnt" id="cnt-absent">0</span>
                <span class="lbl">✗ Absent</span>
            </div>
        </div>

        <!-- ── Quick action bar ── -->
        <div class="action-bar">
            <button type="button" class="btn-all-present" onclick="markAll('present')">
                <i class="fas fa-check-double"></i> Set All PRESENT
            </button>
            <button type="button" class="btn-all-absent" onclick="markAll('absent')">
                <i class="fas fa-times"></i> Set All ABSENT
            </button>
            <div class="search-att">
                <i class="fas fa-search"></i>
                <input type="text" id="searchBox" placeholder="Search name..." onkeyup="filterStudents(this.value)">
            </div>
        </div>

        <!-- ── Student list ── -->
        <div class="student-grid">
            <?php foreach ($students as $i => $student):
                $sid        = $student['student_id'];
                $initials   = strtoupper(substr($student['first_name'],0,1) . substr($student['last_name'],0,1));
                $savedStatus= $saved_attendance[$sid] ?? 'present';
            ?>
            <div class="student-row is-<?= $savedStatus ?>"
                 id="row-<?= $sid ?>"
                 data-id="<?= $sid ?>"
                 data-name="<?= strtolower($student['first_name'].' '.$student['last_name']) ?>"
                 onclick="cycleStatus(<?= $sid ?>)">

                <span class="row-num"><?= $i+1 ?></span>
                <div class="row-avatar" id="av-<?= $sid ?>"><?= $initials ?></div>
                <div style="flex:1;">
                    <div class="row-name"><?= h($student['first_name'].' '.$student['last_name']) ?></div>
                    <div class="row-adm"><?= h($student['admission_number']) ?></div>
                </div>

                <!-- Hidden radio buttons submitted with form -->
                <input type="radio" name="attendance[<?= $sid ?>]" value="present" id="r-p-<?= $sid ?>"
                    <?= ($savedStatus === 'present' ? 'checked' : '') ?> style="display:none">
                <input type="radio" name="attendance[<?= $sid ?>]" value="absent"  id="r-a-<?= $sid ?>"
                    <?= ($savedStatus === 'absent'  ? 'checked' : '') ?> style="display:none">
                <input type="radio" name="attendance[<?= $sid ?>]" value="late"    id="r-l-<?= $sid ?>"
                    <?= ($savedStatus === 'late'    ? 'checked' : '') ?> style="display:none">

                <!-- Visual toggle buttons (stop click from bubbling to row) -->
                <div class="row-toggle" onclick="event.stopPropagation()">
                    <button type="button" class="tgl-btn tgl-p <?= $savedStatus !== 'present' ? 'inactive' : '' ?>"
                        id="bp-<?= $sid ?>" onclick="setStatus(<?= $sid ?>,'present')">P</button>
                    <button type="button" class="tgl-btn tgl-a <?= $savedStatus !== 'absent'  ? 'inactive' : '' ?>"
                        id="ba-<?= $sid ?>" onclick="setStatus(<?= $sid ?>,'absent')">A</button>
                    <button type="button" class="tgl-btn tgl-l <?= $savedStatus !== 'late'    ? 'inactive' : '' ?>"
                        id="bl-<?= $sid ?>" onclick="setStatus(<?= $sid ?>,'late')">L</button>
                </div>
            </div>

            <?php endforeach; ?>
        </div>

        <div class="save-bar">
            <button type="submit" name="save_attendance" class="btn-save">
                <i class="fas fa-save"></i> SAVE ATTENDANCE
            </button>
        </div>
    </form>

    <?php elseif ($selected_class !== null): ?>
        <div style="text-align:center;padding:50px;background:white;border-radius:14px;border:1px solid #f0f0f0;">
            <i class="fas fa-info-circle" style="font-size:3rem;color:#ddd;margin-bottom:15px;display:block;"></i>
            <p style="color:#64748b;">No active students found in this class.</p>
        </div>
    <?php endif; ?>
</div>

<script>
// ── Determine initial status for each student ──────
const statuses = {};
<?php foreach ($students as $s):
    $sid = $s['student_id'];
    $st  = $saved_attendance[$sid] ?? 'present';
?>
    statuses[<?= $sid ?>] = '<?= $st ?>';
<?php endforeach; ?>

// ── Set status for one student ──────────────────────
function setStatus(sid, status) {
    statuses[sid] = status;

    // Check the right radio
    document.getElementById('r-p-' + sid).checked = (status === 'present');
    document.getElementById('r-a-' + sid).checked = (status === 'absent');
    document.getElementById('r-l-' + sid).checked = (status === 'late');

    // Update row background
    const row = document.getElementById('row-' + sid);
    row.className = row.className.replace(/is-\w+/, '');
    row.classList.add('is-' + status);

    // Update toggle buttons
    const activeClasses = { present: 'tgl-p', absent: 'tgl-a', late: 'tgl-l' };
    ['present','absent','late'].forEach(s => {
        const btn = document.getElementById('b' + s[0] + '-' + sid);
        btn.className = 'tgl-btn ' + activeClasses[s] + (s === status ? '' : ' inactive');
    });

    updateCounters();
}

// ── Cycle status on row click (P → A → L → P) ──────
function cycleStatus(sid) {
    const order = ['present','absent','late'];
    const current = statuses[sid] || 'present';
    const next = order[(order.indexOf(current) + 1) % order.length];
    setStatus(sid, next);
}

// ── Mark ALL students at once ───────────────────────
function markAll(status) {
    Object.keys(statuses).forEach(sid => setStatus(parseInt(sid), status));
}

// ── Live counter ────────────────────────────────────
function updateCounters() {
    let pres = 0, abs = 0;
    Object.values(statuses).forEach(s => {
        if (s === 'present' || s === 'late') pres++;
        else abs++;
    });
    document.getElementById('cnt-present').textContent = pres;
    document.getElementById('cnt-absent').textContent  = abs;
}

// ── Search / filter ─────────────────────────────────
function filterStudents(q) {
    q = q.toLowerCase();
    document.querySelectorAll('.student-row').forEach(row => {
        const name = row.dataset.name || '';
        row.style.display = name.includes(q) ? '' : 'none';
    });
}

// Init counters on load
updateCounters();
</script>

<?php require_once '../../includes/footer.php'; ?>
