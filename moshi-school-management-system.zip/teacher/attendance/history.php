<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Attendance History";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];

// Filter parameters
$selected_class = $_GET['class_id'] ?? null;
$selected_date = $_GET['date'] ?? date('Y-m-d');

// Fetch teacher's assigned classes for the filter dropdown
$stmt = $pdo->prepare("
    SELECT DISTINCT c.class_id, c.class_name 
    FROM classes c
    LEFT JOIN class_subjects cs ON c.class_id = cs.class_id
    WHERE cs.teacher_id = ? OR c.class_teacher_id = ?
    ORDER BY c.class_name ASC
");
$stmt->execute([$teacher_id, $teacher_id]);
$my_classes = $stmt->fetchAll();

// Fetch attendance history
$query = "
    SELECT a.*, s.first_name, s.last_name, c.class_name, sub.subject_name
    FROM attendance a
    JOIN students s ON a.student_id = s.student_id
    JOIN classes c ON a.class_id = c.class_id
    LEFT JOIN subjects sub ON a.subject_id = sub.subject_id
    WHERE a.teacher_id = ?
";
$params = [$teacher_id];

if ($selected_class) {
    $query .= " AND a.class_id = ?";
    $params[] = $selected_class;
}
if ($selected_date) {
    $query .= " AND a.attendance_date = ?";
    $params[] = $selected_date;
}

$query .= " ORDER BY a.attendance_date DESC, a.period ASC, s.first_name ASC LIMIT 200";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$history = $stmt->fetchAll();

?>
<?php require_once '../../includes/header.php'; ?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <div class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-history"></i> Attendance History</h2>
                <p style="color: var(--secondary-text); margin-top: 5px;">Review recently marked attendance records.</p>
            </div>
            <a href="mark.php" class="btn btn-primary"><i class="fas fa-plus"></i> Mark New Attendance</a>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-body">
            <form action="" method="GET" style="display: flex; gap: 20px; align-items: flex-end; flex-wrap: wrap;">
                <div class="form-group" style="margin: 0; min-width: 200px;">
                    <label>Filter by Class</label>
                    <select name="class_id" class="form-control">
                        <option value="">-- All My Classes --</option>
                        <?php foreach ($my_classes as $c): ?>
                            <option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class == $c['class_id'] ? 'selected' : ''; ?>>
                                <?php echo h($c['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin: 0; min-width: 150px;">
                    <label>Filter by Date</label>
                    <input type="date" name="date" class="form-control" value="<?php echo $selected_date; ?>">
                </div>
                <button type="submit" class="btn btn-primary" style="background: #940000; border-color: #940000; font-weight: 700;">FILTER RECORDS</button>
                <a href="history.php" class="btn btn-outline" style="text-decoration: none; color: #666;">CLEAR</a>
            </form>
        </div>
    </div>

    <!-- History Table -->
    <div class="card">
        <div class="card-header">Attendance Logs (<?php echo count($history); ?> records)</div>
        <div class="card-body">
            <?php if (empty($history)): ?>
                <div style="text-align: center; padding: 40px; color: var(--secondary-text);">
                    <i class="fas fa-search fa-3x" style="margin-bottom: 15px; opacity: 0.3;"></i>
                    <p>No attendance records found for the selected criteria.</p>
                </div>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Period</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Student</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $row): ?>
                            <tr>
                                <td><?php echo formatDate($row['attendance_date']); ?></td>
                                <td style="text-align: center;"><b>P<?php echo $row['period']; ?></b></td>
                                <td><?php echo h($row['class_name']); ?></td>
                                <td style="font-size: 0.85rem; color: #666;"><?php echo h($row['subject_name'] ?? 'GENERAL'); ?></td>
                                <td style="font-weight: 700;"><?php echo h($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                <td>
                                    <?php if ($row['status'] == 'present'): ?>
                                        <span style="color: #940000; font-weight: 700; background: #fff5f5; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;">PRESENT</span>
                                    <?php elseif ($row['status'] == 'absent'): ?>
                                        <span style="color: #64748b; font-weight: 700; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;">ABSENT</span>
                                    <?php else: ?>
                                        <span style="color: #475569; font-weight: 700; background: #f8fafc; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; border: 1px solid #e2e8f0;">LATE</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
