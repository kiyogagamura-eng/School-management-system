<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$subject_id = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;

if (!$class_id || !$subject_id) {
    echo json_encode([]);
    exit;
}

try {
    // 1. Fetch form_level for the given class_id
    $stmt_class = $pdo->prepare("SELECT form_level FROM classes WHERE class_id = ?");
    $stmt_class->execute([$class_id]);
    $form_level = $stmt_class->fetchColumn();

    if (!$form_level) {
        echo json_encode([]);
        exit;
    }

    // 2. Fetch topics matching this subject_id and form_level
    $stmt_topics = $pdo->prepare("
        SELECT topic_id, topic_name 
        FROM syllabus_topics 
        WHERE subject_id = ? AND form_level = ? 
        ORDER BY topic_name ASC
    ");
    $stmt_topics->execute([$subject_id, $form_level]);
    $topics = $stmt_topics->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($topics);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
