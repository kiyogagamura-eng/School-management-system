<?php
require_once '../includes/bootstrap.php';
requireRole(['teacher']);

$page_title = "Sign Period — Daily Lesson Logbook";

// Resolve teacher_id from DB
$stmt_t = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt_t->execute([$_SESSION['user_id']]);
$teacher_row = $stmt_t->fetch();
$teacher_id  = $teacher_row ? (int)$teacher_row['teacher_id'] : 0;

// Get teacher's assigned classes & subjects
$assigned = $pdo->prepare("
    SELECT cs.class_id, cs.subject_id, c.class_name, s.subject_name
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.teacher_id = ?
    ORDER BY c.class_name, s.subject_name
");
$assigned->execute([$teacher_id]);
$assignments = $assigned->fetchAll();

$success = '';
$error = '';

// Handle submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_id = (int)$_POST['class_id'];
    $subject_id = (int)$_POST['subject_id'];
    $log_date = $_POST['log_date'];
    $period_number = (int)$_POST['period_number'];
    $status = $_POST['status'];
    
    // Evaluate topic covered
    $topic_covered = trim($_POST['topic_covered'] ?? '');
    if ($topic_covered === '__custom__') {
        $topic_covered = trim($_POST['custom_topic'] ?? '');
    }
    
    $remarks = trim($_POST['remarks'] ?? '');

    if (!$class_id || !$subject_id || empty($topic_covered)) {
        $error = "Tafadhali chagua mada na ujaze taarifa zote.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO period_logs (teacher_id, class_id, subject_id, log_date, period_number, status, topic_covered, remarks)
                VALUES (?,?,?,?,?,?,?,?)
            ");
            $stmt->execute([
                $teacher_id,
                $class_id,
                $subject_id,
                $log_date,
                $period_number,
                $status,
                $topic_covered,
                $remarks
            ]);
            $success = "Kipindi kimesainiwa rasmi kikamilifu!";
            
            // Log Activity
            logActivity($_SESSION['user_id'], 'Signed Period', "Logged Period $period_number for Class $class_id - status $status");
        } catch(Exception $e) {
            $error = "Hitilafu: " . $e->getMessage();
        }
    }
}

// Today's signed periods
$today_logs = $pdo->prepare("
    SELECT pl.*, c.class_name, s.subject_name
    FROM period_logs pl
    JOIN classes c ON pl.class_id = c.class_id
    JOIN subjects s ON pl.subject_id = s.subject_id
    WHERE pl.teacher_id = ? AND pl.log_date = CURDATE()
    ORDER BY pl.signed_at DESC
");
$today_logs->execute([$teacher_id]);
$today = $today_logs->fetchAll();

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/teacher_dashboard.css?v=<?php echo time(); ?>">
<style>
.sign-container { padding: 20px; max-width: 1200px; margin: 0 auto; min-height: 100vh; }
.premium-gradient-card { 
    background: linear-gradient(135deg, #a00000 0%, #c20000 100%); 
    color: #fff; 
    padding: 24px 28px; 
    border-radius: 16px; 
    margin-bottom: 25px; 
    display: flex; 
    align-items: center; 
    box-shadow: 0 6px 22px rgba(160,0,0,0.25);
    position: relative;
    overflow: hidden;
}
.premium-gradient-card::after {
    content: '';
    position: absolute;
    right: -5%;
    top: -30%;
    width: 260px;
    height: 260px;
    background: radial-gradient(circle, rgba(255,255,255,0.07) 0%, transparent 60%);
    border-radius: 50%;
}
.sign-icon { 
    background: rgba(255,255,255,0.15); 
    width: 55px; 
    height: 55px; 
    border-radius: 12px; 
    display: flex; 
    align-items: center; 
    justify-content: center; 
    font-size: 1.6rem; 
    color: #fff; 
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}
.sign-header-title { flex: 1; margin-left: 18px; }
.card-box { 
    background: #fff; 
    border-radius: 15px; 
    padding: 25px; 
    box-shadow: var(--shadow-sm); 
    border: 1px solid rgba(139, 0, 0, 0.08); 
    margin-bottom: 20px; 
}
.card-sec-title { 
    font-size: 0.8rem; 
    font-weight: 800; 
    color: #8b0000; 
    text-transform: uppercase; 
    letter-spacing: 1px; 
    margin-bottom: 20px; 
    display: flex; 
    align-items: center; 
    gap: 8px; 
}
.large-form .form-group { margin-bottom: 20px; }
.large-form label { 
    display: block; 
    font-size: 0.78rem; 
    font-weight: 800; 
    color: #475569; 
    text-transform: uppercase; 
    margin-bottom: 8px; 
    letter-spacing: 0.5px;
}
.large-form select, .large-form input, .large-form textarea { 
    width: 100%; 
    padding: 12px 16px; 
    border: 1px solid #cbd5e1; 
    border-radius: 10px; 
    font-size: 0.95rem; 
    outline: none; 
    background: #f8fafc; 
    transition: all 0.2s;
    font-weight: 600;
    color: #1e293b;
}
.large-form select:focus, .large-form input:focus, .large-form textarea:focus { 
    border-color: #8b0000; 
    background: #fff; 
    box-shadow: 0 0 0 3px rgba(139,0,0,0.1);
}
.btn-large-submit { 
    background: linear-gradient(135deg, #8b0000 0%, #b30000 100%); 
    color: #fff; 
    border: none; 
    padding: 15px; 
    border-radius: 10px; 
    font-weight: 700; 
    cursor: pointer; 
    width: 100%; 
    font-size: 1rem; 
    display: flex; 
    align-items: center; 
    justify-content: center; 
    gap: 10px;
    box-shadow: 0 4px 15px rgba(139, 0, 0, 0.25);
    transition: all 0.25s;
}
.btn-large-submit:hover { 
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(139, 0, 0, 0.35);
}
.log-row { 
    display: flex; 
    align-items: center; 
    justify-content: space-between; 
    padding: 16px 20px; 
    border-radius: 12px; 
    background: #f8fafc; 
    margin-bottom: 12px; 
    border: 1px solid #f1f5f9;
    transition: var(--transition-smooth);
}
.log-row:hover {
    background: #fff5f5;
    border-color: rgba(139,0,0,0.1);
}
.badge-status { 
    padding: 5px 12px; 
    border-radius: 20px; 
    font-size: 0.72rem; 
    font-weight: 800; 
    text-transform: uppercase; 
    letter-spacing: 0.5px;
}
.badge-status.taught { background: #f0fdf4; color: #166534; }
.badge-status.missed { background: #fff5f5; color: #940000; }
.badge-status.covered { background: #f0f9ff; color: #075985; }

/* Grid Responsive */
.main-grid { display: grid; grid-template-columns: 1.2fr 1.8fr; gap: 25px; }

@media (max-width: 991px) {
    .main-grid { grid-template-columns: 1fr; }
    .sign-container { padding: 15px 10px; }
}
</style>

<div class="sign-container">
    <!-- Header Banner -->
    <div class="premium-gradient-card">
        <div class="sign-icon"><i class="fas fa-clipboard-check"></i></div>
        <div class="sign-header-title">
            <h4 style="margin:0; font-weight:900; font-size: 1.3rem;">Record Your Teaching Period</h4>
            <p style="margin:4px 0 0; color:#ffc1c1; font-size:0.88rem; font-weight:500;">Log topics taught each lesson. The Director of Studies monitors your syllabus coverage.</p>
        </div>
        <div style="text-align:right;">
            <div style="font-size:2rem; font-weight:900; color:#fff; line-height: 1;"><?php echo count($today); ?></div>
            <div style="font-size:0.75rem; color:#ffc1c1; font-weight: 700; text-transform: uppercase; margin-top:2px;">Signed Today</div>
        </div>
    </div>

    <?php if(!empty($success)): ?>
        <div style="background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:15px 20px; border-radius:10px; margin-bottom:20px; font-weight:700;">
            <i class="fas fa-check-circle me-2" style="font-size: 1.1rem;"></i><?php echo $success; ?>
        </div>
    <?php endif; ?>
    <?php if(!empty($error)): ?>
        <div style="background:#fff5f5; color:#940000; border:1px solid #fecaca; padding:15px 20px; border-radius:10px; margin-bottom:20px; font-weight:700;">
            <i class="fas fa-exclamation-circle me-2" style="font-size: 1.1rem;"></i><?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div class="main-grid">
        <!-- Form Section -->
        <div class="card-box">
            <div class="card-sec-title">
                <i class="fas fa-pen-fancy"></i> Record a Teaching Period
            </div>
            
            <form method="POST" class="large-form">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="log_date" value="<?php echo date('Y-m-d'); ?>" required max="<?php echo date('Y-m-d'); ?>">
                </div>

                <div class="form-group">
                    <label>Class</label>
                    <select name="class_id" id="classSelect" required onchange="handleClassChange()">
                        <option value="">-- Select Class --</option>
                        <?php
                        $seen_classes = [];
                        foreach($assignments as $a):
                            if(!in_array($a['class_id'], $seen_classes)):
                                $seen_classes[] = $a['class_id'];
                        ?>
                        <option value="<?php echo $a['class_id']; ?>"><?php echo h($a['class_name']); ?></option>
                        <?php endif; endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Subject</label>
                    <select name="subject_id" id="subjectSelect" required onchange="loadSyllabusTopics()">
                        <option value="">Select class first...</option>
                        <?php foreach($assignments as $a): ?>
                            <option value="<?php echo $a['subject_id']; ?>" data-class="<?php echo $a['class_id']; ?>" style="display:none;">
                                <?php echo h($a['subject_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Period Number</label>
                        <select name="period_number" required>
                            <?php for($i=1;$i<=8;$i++): ?>
                                <option value="<?php echo $i; ?>">Period <?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" required>
                            <option value="taught">✅ Period Taught</option>
                            <option value="missed">❌ Period Missed</option>
                            <option value="covered_by_other">🔄 Covered by Colleague</option>
                        </select>
                    </div>
                </div>

                <!-- Topic field dynamically populated from TET Syllabus set by DOS -->
                <div class="form-group">
                    <label>Topic Taught (TET Syllabus) *</label>
                    <select name="topic_covered" id="topicSelect" required onchange="handleTopicChange()">
                        <option value="">Select class and subject first...</option>
                    </select>
                </div>

                <!-- Fallback free-text input when topic not in TET list -->
                <div class="form-group" id="customTopicGroup" style="display:none; transition: all 0.3s;">
                    <label style="color: #a00000;">Enter Topic Manually</label>
                    <input type="text" name="custom_topic" id="customTopicInput" placeholder="Type a topic not found in the syllabus list...">
                </div>

                <div class="form-group">
                    <label>Remarks / Challenges (Optional)</label>
                    <textarea name="remarks" rows="2" placeholder="Any notes or classroom challenges..."></textarea>
                </div>

                <button type="submit" class="btn-large-submit">
                    <i class="fas fa-signature"></i> Sign Period Now
                </button>
            </form>
        </div>

        <!-- Today's Signed Logs -->
        <div class="card-box">
            <div class="card-sec-title">
                <i class="fas fa-history"></i> Periods Signed Today — <?php echo date('d M Y'); ?>
            </div>
            
            <?php if(empty($today)): ?>
                <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                    <i class="fas fa-hourglass-start" style="font-size:3rem; opacity:0.15; display:block; margin-bottom:15px; color:#a00000;"></i>
                    <p style="margin: 0; font-weight:600; font-size: 0.95rem;">No periods signed today yet.</p>
                    <p style="margin: 5px 0 0; font-size:0.8rem; color:#aaa;">Use the form on the left to record your first period.</p>
                </div>
            <?php else: ?>
                <?php foreach($today as $log): 
                    $status_badge = 'badge-status ' . ($log['status'] === 'taught' ? 'taught' : ($log['status'] === 'missed' ? 'missed' : 'covered'));
                    $status_text = $log['status'] === 'taught' ? 'Taught' : ($log['status'] === 'missed' ? 'Missed' : 'Covered by Colleague');
                ?>
                <div class="log-row">
                    <div>
                        <div style="font-weight:800; color:#1e293b; font-size: 0.95rem;"><?php echo h($log['class_name']); ?> — <?php echo h($log['subject_name']); ?></div>
                        <div style="font-size:0.8rem; color:#475569; margin-top:5px; font-weight:500;">
                            Signed at: <strong style="color:#1e293b;"><?php echo date('H:i', strtotime($log['signed_at'])); ?></strong> &nbsp;·&nbsp; Period <strong><?php echo $log['period_number']; ?></strong>
                        </div>
                        <div style="font-size:0.82rem; color:#64748b; margin-top:6px; background:#f1f5f9; padding:4px 8px; border-radius:4px; display:inline-block;">
                            <i class="fas fa-bookmark me-1" style="color:#a00000;"></i> Topic: <strong><?php echo h($log['topic_covered']); ?></strong>
                        </div>
                        <?php if(!empty($log['remarks'])): ?>
                            <div style="font-size:0.78rem; color:#a00000; margin-top:6px; font-style:italic;">
                                ✍️ Remarks: "<?php echo h($log['remarks']); ?>"
                            </div>
                        <?php endif; ?>
                    </div>
                    <div style="text-align: right; flex-shrink: 0;">
                        <span class="<?php echo $status_badge; ?>"><?php echo $status_text; ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function handleClassChange() {
    const classId = document.getElementById('classSelect').value;
    const subjectSelect = document.getElementById('subjectSelect');
    
    // reset options
    const options = subjectSelect.querySelectorAll('option');
    options.forEach(opt => {
        if (opt.value === '') {
            opt.style.display = '';
            return;
        }
        opt.style.display = opt.getAttribute('data-class') === classId ? '' : 'none';
    });
    
    subjectSelect.value = '';
    
    // Reset topics too
    document.getElementById('topicSelect').innerHTML = '<option value="">-- Chagua Darasa na Somo kwanza --</option>';
    document.getElementById('customTopicGroup').style.display = 'none';
    document.getElementById('customTopicInput').required = false;
}

function loadSyllabusTopics() {
    const classId = document.getElementById('classSelect').value;
    const subjectId = document.getElementById('subjectSelect').value;
    const topicSelect = document.getElementById('topicSelect');
    const customTopicGroup = document.getElementById('customTopicGroup');
    const customTopicInput = document.getElementById('customTopicInput');

    // Reset topic select
    topicSelect.innerHTML = '<option value="">Loading topics...</option>';
    customTopicGroup.style.display = 'none';
    customTopicInput.value = '';
    customTopicInput.required = false;

    if (!classId || !subjectId) {
        topicSelect.innerHTML = '<option value="">-- Select class and subject first --</option>';
        return;
    }

    fetch(`get-syllabus-topics.php?class_id=${classId}&subject_id=${subjectId}`)
        .then(response => {
            if (!response.ok) throw new Error('HTTP error ' + response.status);
            return response.json();
        })
        .then(data => {
            topicSelect.innerHTML = '<option value="">-- Select a TET Syllabus Topic --</option>';
            if (!data || data.length === 0) {
                topicSelect.innerHTML += '<option value="__custom__" selected>No topics set — enter manually</option>';
                customTopicGroup.style.display = 'block';
                customTopicInput.required = true;
            } else {
                data.forEach(topic => {
                    const opt = document.createElement('option');
                    opt.value = topic.topic_name;
                    opt.textContent = topic.topic_name;
                    topicSelect.appendChild(opt);
                });
                topicSelect.innerHTML += '<option value="__custom__">🔍 Topic not listed? Enter manually...</option>';
            }
        })
        .catch(err => {
            console.error('Error loading topics:', err);
            topicSelect.innerHTML = '<option value="__custom__" selected>Error loading — type topic manually</option>';
            customTopicGroup.style.display = 'block';
            customTopicInput.required = true;
        });
}

function handleTopicChange() {
    const topicSelect = document.getElementById('topicSelect');
    const customTopicGroup = document.getElementById('customTopicGroup');
    const customTopicInput = document.getElementById('customTopicInput');

    if (topicSelect.value === '__custom__') {
        customTopicGroup.style.display = 'block';
        customTopicInput.required = true;
        customTopicInput.focus();
    } else {
        customTopicGroup.style.display = 'none';
        customTopicInput.required = false;
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>
