<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "My Classes";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];
$employee_id = $teacher['employee_id'];

// Get classes assigned to this teacher
// Get classes assigned to this teacher (Subjects taught OR Class Teacher role)
$stmt = $pdo->prepare("
    SELECT c.class_name, c.class_id, s.subject_name,
    (SELECT COUNT(*) FROM students WHERE class_id = c.class_id AND status = 'Active') as student_count
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.teacher_id = ?
    ORDER BY class_name ASC
");
$stmt->execute([$teacher_id]);
$my_classes = $stmt->fetchAll();
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <div class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <h1 style="color: var(--corporate-red);"><i class="fas fa-chalkboard-teacher"></i> My Classes Overview</h1>
        <p style="color: var(--secondary-text); margin-top: 5px;">View and manage the classes assigned to you this term.</p>
    </div>

            <div>
                <?php if ($my_classes): ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px; margin-top: 20px;">
                        <?php foreach($my_classes as $cls): ?>
                        <div class="card shadow-premium hover-scale" style="padding: 0; overflow: hidden; border: 2px solid var(--corporate-red); border-radius: 15px; transition: transform 0.3s; margin-bottom: 0;">
                            <div style="background: var(--premium-gradient); color: var(--primary-text); padding: 20px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(148,0,0,0.1);">
                                <div>
                                    <div style="font-weight: 900; font-size: 1.6rem; letter-spacing: 0.5px; color: var(--corporate-red);"><?php echo h($cls['class_name']); ?></div>
                                    <div style="font-size: 13px; color: var(--secondary-text); margin-top: 5px; font-weight: 600;"><i class="fas fa-book-open"></i> <?php echo h($cls['subject_name']); ?></div>
                                </div>
                                <div style="background: rgba(148,0,0,0.07); color: var(--corporate-red); padding: 8px 14px; border-radius: 20px; font-size: 12px; font-weight: 800; border: 1px solid rgba(148,0,0,0.1); text-align: center;">
                                    <i class="fas fa-users" style="font-size: 16px; margin-bottom: 4px; display: block;"></i> <?php echo h($cls['student_count'] ?? '0'); ?>
                                </div>
                            </div>
                            <div class="card-body" style="background: #fafafa; padding: 20px;">
                                <div style="display: flex; gap: 10px; justify-content: space-between;">
                                    <a href="../students/index.php?class_id=<?php echo $cls['class_id']; ?>" class="btn-mini hover-scale" style="flex: 1; text-align: center; background: white; border: 1px solid #e0e0e0; padding: 15px 5px; font-size: 13px; font-weight: 700; border-radius: 8px; color: var(--primary-text); text-decoration: none;">
                                        <i class="fas fa-user-graduate" style="display: block; font-size: 22px; margin-bottom: 8px; color: var(--corporate-red);"></i> Students
                                    </a>
                                    <a href="../attendance/mark.php?class_id=<?php echo $cls['class_id']; ?>" class="btn-mini hover-scale" style="flex: 1; text-align: center; background: white; border: 1px solid #e0e0e0; padding: 15px 5px; font-size: 13px; font-weight: 700; border-radius: 8px; color: var(--primary-text); text-decoration: none;">
                                        <i class="fas fa-calendar-check" style="display: block; font-size: 22px; margin-bottom: 8px; color: var(--corporate-red);"></i> Attendance
                                    </a>
                                    <a href="../results/exams.php?class_id=<?php echo $cls['class_id']; ?>" class="btn-mini hover-scale" style="flex: 1; text-align: center; background: white; border: 1px solid #e0e0e0; padding: 15px 5px; font-size: 13px; font-weight: 700; border-radius: 8px; color: var(--primary-text); text-decoration: none;">
                                        <i class="fas fa-poll" style="display: block; font-size: 22px; margin-bottom: 8px; color: var(--corporate-red);"></i> Exams
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="background: var(--primary-white); padding: 40px; text-align: center; border-radius: 10px; border: 1px solid rgba(148,0,0,0.1);">
                        <i class="fas fa-chalkboard fa-4x" style="color: #ccc; margin-bottom: 20px;"></i>
                        <p style="color: var(--secondary-text); font-size: 16px;">No classes assigned to you yet for this term.</p>
                    </div>
                <?php endif; ?>
            </div>
</div> <!-- End dashboard-container -->
<?php require_once '../../includes/footer.php'; ?>
