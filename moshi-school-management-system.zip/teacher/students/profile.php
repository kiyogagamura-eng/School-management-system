<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

if (!isset($_GET['id'])) {
    redirect('index.php', 'No student selected.', 'error');
}
$student_id = (int)$_GET['id'];

// Get teacher context
$teacher_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$teacher_id]);
$t_id = $stmt->fetchColumn();

// Fetch student info
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, c.stream, c.form_level 
    FROM students s
    JOIN classes c ON s.class_id = c.class_id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    redirect('index.php', 'Student not found.', 'error');
}

// Security: Check if teacher teaches this student's class
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM (
        SELECT 1 FROM class_subjects WHERE teacher_id = ? AND class_id = ?
        UNION
        SELECT 1 FROM classes WHERE class_teacher_id = ? AND class_id = ?
    ) auth_check
");
$stmt->execute([$t_id, $student['class_id'], $t_id, $student['class_id']]);
if ($stmt->fetchColumn() == 0) {
    redirect('index.php', 'You are not authorized to view this student\'s profile.', 'error');
}

$page_title = "Student Profile - " . $student['first_name'];

// Fetch Attendance Overview
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_days,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_days,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_days
    FROM attendance 
    WHERE student_id = ?
");
$stmt->execute([$student_id]);
$attendance = $stmt->fetch();
$attendance_pct = $attendance['total_days'] > 0 ? round(($attendance['present_days'] / $attendance['total_days']) * 100, 1) : 0;

// Fetch Recent Exam Results
$stmt = $pdo->prepare("
    SELECT r.*, e.exam_name, e.exam_date, s.subject_name
    FROM results r
    JOIN exams e ON r.exam_id = e.exam_id
    JOIN subjects s ON r.subject_id = s.subject_id
    WHERE r.student_id = ? AND r.status = 'published'
    ORDER BY e.exam_date DESC LIMIT 5
");
$stmt->execute([$student_id]);
$recent_results = $stmt->fetchAll();

?>
<?php require_once '../../includes/header.php'; ?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<style>
    .profile-header-card {
        background: var(--premium-gradient);
        border: 2px solid var(--corporate-red);
        border-radius: 16px;
        padding: 40px;
        color: var(--primary-text);
        display: flex;
        gap: 30px;
        align-items: center;
        box-shadow: var(--shadow-md);
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
    }
    .profile-header-card::after {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        background: rgba(255,255,255,0.05);
        border-radius: 50%;
    }
    .profile-avatar-large {
        width: 120px;
        height: 120px;
        background: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        color: var(--corporate-red);
        border: 4px solid rgba(148,0,0,0.1);
        flex-shrink: 0;
        z-index: 1;
    }
    .profile-info {
        z-index: 1;
        flex: 1;
    }
    .profile-info h1 {
        margin: 0 0 5px 0;
        font-size: 2.2rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        color: var(--corporate-red);
    }
    .profile-info .adm-badge {
        background: var(--corporate-red);
        color: white;
        padding: 5px 15px;
        border-radius: 20px;
        font-family: monospace;
        font-weight: 700;
        font-size: 0.9rem;
        display: inline-block;
        margin-bottom: 15px;
        backdrop-filter: blur(5px);
    }
    .profile-meta {
        display: flex;
        gap: 20px;
        font-size: 0.95rem;
        color: var(--secondary-text);
    }
    .profile-meta div { display: flex; align-items: center; gap: 8px; }
    .profile-meta i { color: var(--corporate-red); }
    
    .grid-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
    }
    
    .info-card {
        background: white;
        border-radius: 14px;
        padding: 25px;
        border: 1px solid rgba(148,0,0,0.08);
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }
    .info-card h3 {
        color: var(--corporate-red);
        margin: 0 0 20px 0;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
        gap: 10px;
        border-bottom: 1px solid #f0f0f0;
        padding-bottom: 10px;
    }
    .info-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .info-list li {
        padding: 12px 0;
        border-bottom: 1px dashed #f0f0f0;
        display: flex;
        justify-content: space-between;
    }
    .info-list li:last-child { border-bottom: none; }
    .info-label { color: var(--secondary-text); font-size: 0.9rem; }
    .info-val { font-weight: 700; color: var(--primary-text); }
    
    .att-stats {
        display: flex;
        justify-content: space-around;
        text-align: center;
        margin-top: 15px;
    }
    .att-stat-box .val { font-size: 1.8rem; font-weight: 800; line-height: 1; margin-bottom: 5px; }
    .att-stat-box .lbl { font-size: 0.75rem; color: var(--secondary-text); text-transform: uppercase; letter-spacing: 0.5px; }
    
    .result-badge {
        padding: 5px 12px;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    .grade-A { background: #fff5f5; color: #940000; }
    .grade-B { background: #fff5f5; color: #940000; }
    .grade-C { background: #f8fafc; color: #475569; }
    .grade-D { background: #f1f5f9; color: #64748b; }
    .grade-F { background: #f8fafc; color: #94a3b8; border: 1px solid #e2e8f0; }
</style>

<div class="dashboard-container">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700; text-decoration: none;"><i class="fas fa-arrow-left"></i> Back to Students List</a>
    </div>

    <!-- Header Card -->
    <div class="profile-header-card">
        <div class="profile-avatar-large">
            <?php if (strtolower($student['gender']) == 'male'): ?>
                <i class="fas fa-user-tie"></i>
            <?php else: ?>
                <i class="fas fa-user-graduate"></i>
            <?php endif; ?>
        </div>
        <div class="profile-info">
            <div class="adm-badge"><?php echo h($student['admission_number']); ?></div>
            <h1><?php echo h($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']); ?></h1>
            <div class="profile-meta">
                <div><i class="fas fa-school"></i> <?php echo h($student['class_name']); ?></div>
                <div><i class="fas fa-venus-mars"></i> <?php echo ucfirst(h($student['gender'])); ?></div>
                <div><i class="fas fa-calendar-alt"></i> Enrolled: <?php echo date('Y', strtotime($student['enrollment_date'])); ?></div>
            </div>
        </div>
    </div>

    <div class="grid-2">
        <!-- Personal Info -->
        <div class="info-card">
            <h3><i class="fas fa-address-card"></i> Personal Information</h3>
            <ul class="info-list">
                <li><span class="info-label">Date of Birth</span> <span class="info-val"><?php echo formatDate($student['date_of_birth']); ?></span></li>
                <li><span class="info-label">Address</span> <span class="info-val"><?php echo h($student['address']); ?></span></li>
                <li><span class="info-label">Parent/Guardian</span> <span class="info-val"><?php echo h($student['parent_name'] ?: 'N/A'); ?></span></li>
                <li><span class="info-label">Parent Phone</span> <span class="info-val"><?php echo h($student['parent_phone'] ?: 'N/A'); ?></span></li>
                <li><span class="info-label">Parent Email</span> <span class="info-val"><?php echo h($student['parent_email'] ?: 'N/A'); ?></span></li>
            </ul>
            <div style="margin-top: 20px;">
                <a href="../messages/index.php?to=<?php echo $student['student_id']; ?>" class="btn-quick-action" style="background: var(--corporate-red); color: white; border: none; padding: 12px; width: 100%; text-align: center; border-radius: 8px;">
                    <i class="fas fa-comment-dots"></i> Message Parent
                </a>
            </div>
        </div>

        <!-- Academic & Attendance -->
        <div style="display: flex; flex-direction: column; gap: 30px;">
            <div class="info-card">
                <h3><i class="fas fa-calendar-check"></i> Attendance Summary (Overall)</h3>
                <div class="att-stats">
                    <div class="att-stat-box">
                        <div class="val" style="color: #940000;"><?php echo $attendance_pct; ?>%</div>
                        <div class="lbl">Attendance Rate</div>
                    </div>
                    <div class="att-stat-box">
                        <div class="val" style="color: #1e293b;"><?php echo $attendance['present_days']; ?></div>
                        <div class="lbl">Days Present</div>
                    </div>
                    <div class="att-stat-box">
                        <div class="val" style="color: #64748b;"><?php echo $attendance['absent_days']; ?></div>
                        <div class="lbl">Days Absent</div>
                    </div>
                </div>
            </div>
            
            <div class="info-card">
                <h3><i class="fas fa-chart-line"></i> Recent Exam Results (Published)</h3>
                <?php if ($recent_results): ?>
                <table style="width: 100%; border-collapse: collapse;">
                    <?php foreach ($recent_results as $res): ?>
                    <tr style="border-bottom: 1px dashed #f0f0f0;">
                        <td style="padding: 10px 0;">
                            <div style="font-weight: 700; color: var(--primary-text); font-size: 0.9rem;"><?php echo h($res['exam_name']); ?></div>
                            <div style="font-size: 0.75rem; color: var(--secondary-text);"><?php echo h($res['subject_name']); ?> | <?php echo formatDate($res['exam_date']); ?></div>
                        </td>
                        <td style="text-align: right; font-weight: 800; font-size: 1.1rem; color: var(--corporate-red);">
                            <?php echo $res['marks_obtained']; ?>%
                        </td>
                        <td style="text-align: right; width: 50px;">
                            <span class="result-badge grade-<?php echo substr($res['grade'], 0, 1); ?>"><?php echo $res['grade']; ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php else: ?>
                <div style="text-align: center; color: var(--secondary-text); padding: 20px 0; font-size: 0.9rem;">
                    No published results available for this student yet.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
