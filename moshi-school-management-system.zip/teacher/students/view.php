<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

if (!isset($_GET['class_id'])) {
    redirect('index.php', 'No class selected.', 'error');
}
$class_id = $_GET['class_id'];

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];

// Ensure teacher is assigned to this class (via subjects OR as Class Teacher)
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM (
        SELECT 1 FROM class_subjects WHERE teacher_id = ? AND class_id = ?
        UNION
        SELECT 1 FROM classes WHERE class_teacher_id = ? AND class_id = ?
    ) auth_check
");
$stmt->execute([$teacher_id, $class_id, $teacher_id, $class_id]);
if ($stmt->fetchColumn() == 0) {
    redirect('index.php', 'Unauthorized to view this class.', 'error');
}

// Get class info
$stmt = $pdo->prepare("SELECT * FROM classes WHERE class_id = ?");
$stmt->execute([$class_id]);
$class_info = $stmt->fetch();
$page_title = "Students - " . $class_info['class_name'];

// Get students
$stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name, last_name");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll();
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<main class="dashboard-container">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700; text-decoration: none;"><i class="fas fa-arrow-left"></i> Back to Classes</a>
    </div>

    <div class="page-header">
        <div>
            <h1 style="color: var(--corporate-red);"><i class="fas fa-users"></i> Class Roster: <?php echo h($class_info['class_name']); ?></h1>
            <p style="color: var(--secondary-text); margin-top: 5px;">View and manage students in this class. Total: <?php echo count($students); ?> Students.</p>
        </div>
        <div>
            <a href="../attendance/mark.php?class_id=<?php echo $class_info['class_id']; ?>" class="btn-quick-action" style="padding: 12px 25px; background: var(--corporate-red); color: white; display: inline-flex; border-radius: 8px;"><i class="fas fa-calendar-check" style="margin-bottom: 0; margin-right: 8px; font-size: 16px;"></i> Mark Attendance</a>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-body" style="padding: 0;">
            <?php if ($students): ?>
            <table class="premium-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Adm. Number</th>
                        <th>Student Name</th>
                        <th>Gender</th>
                        <th>Parent Name</th>
                        <th>Parent Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($students as $s): ?>
                    <tr>
                        <td style="text-align: center; color: var(--secondary-text); font-weight: 700;"><?php echo $i++; ?></td>
                        <td style="font-weight: 700; color: var(--corporate-red);"><?php echo h($s['admission_number']); ?></td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 35px; height: 35px; background: var(--accent-soft-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--corporate-red);">
                                    <i class="fas fa-user-graduate"></i>
                                </div>
                                <b><?php echo h($s['first_name'] . ' ' . $s['middle_name'] . ' ' . $s['last_name']); ?></b>
                            </div>
                        </td>
                        <td>
                            <?php if (strtolower($s['gender']) == 'male'): ?>
                                <i class="fas fa-mars" style="color: #3498db;"></i> Male
                            <?php else: ?>
                                <i class="fas fa-venus" style="color: #e91e63;"></i> Female
                            <?php endif; ?>
                        </td>
                        <td><i class="fas fa-user-tie" style="color: var(--secondary-text); margin-right: 5px;"></i> <?php echo h($s['parent_name'] ?: 'N/A'); ?></td>
                        <td style="font-family: monospace; font-weight: 700; color: var(--secondary-text);"><i class="fas fa-phone-alt" style="color: #27ae60; margin-right: 5px;"></i> <?php echo h($s['parent_phone'] ?: 'N/A'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div style="padding: 40px; text-align: center;">
                <i class="fas fa-info-circle fa-3x" style="color: #ccc; margin-bottom: 15px;"></i>
                <p style="color: var(--secondary-text);">No active students found in this class yet.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php require_once '../../includes/footer.php'; ?>

