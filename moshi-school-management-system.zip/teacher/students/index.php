<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "My Students";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];

// Get distinct classes assigned to this teacher (Subjects taught OR Class Teacher role)
$stmt = $pdo->prepare("
    SELECT DISTINCT c.class_name, c.class_id, c.stream, c.form_level, c.capacity, c.class_teacher_id,
    (SELECT COUNT(*) FROM students WHERE class_id = c.class_id AND status = 'Active') as student_count
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    WHERE cs.teacher_id = ?
    
    UNION
    
    SELECT DISTINCT c.class_name, c.class_id, c.stream, c.form_level, c.capacity, c.class_teacher_id,
    (SELECT COUNT(*) FROM students WHERE class_id = c.class_id AND status = 'Active') as student_count
    FROM classes c
    WHERE c.class_teacher_id = ?
    
    ORDER BY class_name ASC
");
$stmt->execute([$teacher_id, $teacher_id]);
$my_classes = $stmt->fetchAll();

// Calculate totals
$total_classes = count($my_classes);
$total_students = array_sum(array_column($my_classes, 'student_count'));

// Pre-fetch all students for each class
$students_by_class = [];
foreach ($my_classes as $cls) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name, last_name");
    $stmt->execute([$cls['class_id']]);
    $students_by_class[$cls['class_id']] = $stmt->fetchAll();
}
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css?v=<?php echo time(); ?>">

<style>
    /* Stats Row */
    .students-stats-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    .students-stat-card {
        background: var(--primary-white);
        border-radius: 12px;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        gap: 18px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.04);
        border: 1px solid rgba(148,0,0,0.06);
        transition: transform 0.2s ease;
    }
    .students-stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(148,0,0,0.08);
    }
    .stat-icon-circle {
        width: 52px;
        height: 52px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
        flex-shrink: 0;
    }
    .stat-icon-circle.red {
        background: var(--accent-soft-red);
        color: var(--corporate-red);
    }
    .stat-icon-circle.green {
        background: #f1f5f9;
        color: #64748b;
    }
    .stat-info .stat-value {
        font-size: 1.8rem;
        font-weight: 800;
        color: var(--primary-text);
        line-height: 1;
    }
    .stat-info .stat-label {
        font-size: 0.8rem;
        color: var(--secondary-text);
        font-weight: 500;
        margin-top: 4px;
    }

    /* Class Overview Cards */
    .classes-overview-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 20px;
        margin-bottom: 35px;
    }
    .class-overview-card {
        background: var(--primary-white);
        border-radius: 14px;
        border: 2px solid rgba(148,0,0,0.1);
        overflow: hidden;
        transition: all 0.3s ease;
        box-shadow: 0 2px 12px rgba(0,0,0,0.03);
    }
    .class-overview-card:hover {
        border-color: var(--corporate-red);
        box-shadow: 0 8px 30px rgba(148,0,0,0.1);
    }
    .class-card-header {
        padding: 18px 22px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid rgba(148,0,0,0.06);
    }
    .class-card-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .class-avatar {
        width: 45px;
        height: 45px;
        background: var(--accent-soft-red);
        color: var(--corporate-red);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }
    .class-card-title {
        font-weight: 800;
        font-size: 1.15rem;
        color: var(--corporate-red);
    }
    .class-card-role {
        font-size: 0.75rem;
        color: var(--secondary-text);
        margin-top: 2px;
    }
    .student-count-badge {
        background: var(--accent-soft-red);
        color: var(--corporate-red);
        padding: 5px 14px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
        border: 1px solid rgba(148,0,0,0.1);
    }
    .class-card-details {
        padding: 15px 22px;
    }
    .class-detail-row {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #f5f5f5;
        font-size: 0.88rem;
    }
    .class-detail-row:last-child { border-bottom: none; }
    .class-detail-label { color: var(--secondary-text); font-weight: 500; }
    .class-detail-value { color: var(--primary-text); font-weight: 700; }
    .class-card-actions {
        padding: 15px 22px;
        border-top: 1px solid rgba(148,0,0,0.06);
        display: flex;
        gap: 10px;
    }
    .btn-class-action {
        flex: 1;
        padding: 10px 15px;
        border-radius: 8px;
        font-size: 0.82rem;
        font-weight: 700;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    .btn-class-action.outline {
        background: var(--primary-white);
        border: 1.5px solid var(--corporate-red);
        color: var(--corporate-red);
    }
    .btn-class-action.outline:hover {
        background: var(--accent-soft-red);
    }
    .btn-class-action.filled {
        background: var(--corporate-red);
        border: 1.5px solid var(--corporate-red);
        color: var(--primary-white);
    }
    .btn-class-action.filled:hover {
        background: #7a0000;
    }

    /* Students Section */
    .students-section {
        background: var(--primary-white);
        border-radius: 14px;
        border: 1px solid rgba(148,0,0,0.08);
        box-shadow: 0 2px 12px rgba(0,0,0,0.03);
        overflow: hidden;
    }
    .students-section-header {
        padding: 20px 25px;
        border-bottom: 1px solid rgba(148,0,0,0.06);
    }
    .students-section-header h2 {
        font-size: 1.1rem;
        color: var(--corporate-red);
        font-weight: 800;
        margin: 0;
    }
    
    /* Class Tabs */
    .class-tabs {
        display: flex;
        gap: 0;
        border-bottom: 2px solid #f0f0f0;
        padding: 0 25px;
    }
    .class-tab {
        padding: 12px 22px;
        font-size: 0.88rem;
        font-weight: 700;
        color: var(--secondary-text);
        cursor: pointer;
        border-bottom: 3px solid transparent;
        margin-bottom: -2px;
        transition: all 0.2s ease;
        background: none;
        border-top: none;
        border-left: none;
        border-right: none;
    }
    .class-tab:hover {
        color: var(--corporate-red);
    }
    .class-tab.active {
        color: var(--corporate-red);
        border-bottom-color: var(--corporate-red);
    }

    /* Student Table */
    .student-class-group {
        display: none;
    }
    .student-class-group.active {
        display: block;
    }
    .student-class-group-title {
        padding: 18px 25px 10px;
        font-size: 0.95rem;
        font-weight: 800;
        color: var(--corporate-red);
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .student-class-group-title .count {
        background: var(--accent-soft-red);
        color: var(--corporate-red);
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .students-table-container {
        padding: 0 25px 25px;
    }
    .students-clean-table {
        width: 100%;
        border-collapse: collapse;
    }
    .students-clean-table th {
        text-align: left;
        padding: 12px 15px;
        font-size: 0.75rem;
        font-weight: 700;
        color: var(--secondary-text);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 2px solid #f0f0f0;
        background: transparent;
    }
    .students-clean-table td {
        padding: 14px 15px;
        font-size: 0.88rem;
        border-bottom: 1px solid #f5f5f5;
        color: var(--primary-text);
    }
    .students-clean-table tr:hover td {
        background: var(--accent-soft-red);
    }
    .students-clean-table tr:last-child td {
        border-bottom: none;
    }
    .view-profile-btn {
        color: var(--secondary-text);
        font-size: 1rem;
        cursor: pointer;
        transition: color 0.2s;
        text-decoration: none;
    }
    .view-profile-btn:hover {
        color: var(--corporate-red);
    }
    .gender-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        font-size: 0.85rem;
    }

    @media (max-width: 768px) {
        .classes-overview-grid {
            grid-template-columns: 1fr;
        }
        .students-stats-row {
            grid-template-columns: 1fr 1fr;
        }
        .class-tabs {
            overflow-x: auto;
            padding: 0 15px;
        }
        .students-table-container {
            padding: 0 15px 15px;
            overflow-x: auto;
        }
    }
</style>

<main class="dashboard-container">
    <!-- Page Header -->
    <div class="page-header" style="border-radius: 12px; margin-bottom: 25px;">
        <h1 style="color: var(--corporate-red);"><i class="fas fa-users"></i> My Students</h1>
        <p style="color: var(--secondary-text); margin-top: 5px;">Manage classes and students you teach</p>
    </div>

    <!-- Stats Row -->
    <div class="students-stats-row">
        <div class="students-stat-card">
            <div class="stat-icon-circle red">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $total_classes; ?></div>
                <div class="stat-label">Classes assigned</div>
            </div>
        </div>
        <div class="students-stat-card">
            <div class="stat-icon-circle green">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $total_students; ?></div>
                <div class="stat-label">Students across all classes</div>
            </div>
        </div>
    </div>

    <?php if ($my_classes): ?>

    <!-- My Classes Overview -->
    <h2 style="font-size: 1.1rem; color: var(--corporate-red); font-weight: 800; margin-bottom: 18px;">
        <i class="fas fa-th-large" style="margin-right: 6px;"></i> My Classes Overview
    </h2>
    <div class="classes-overview-grid">
        <?php foreach ($my_classes as $cls): 
            $is_class_teacher = ($cls['class_teacher_id'] == $teacher_id);
        ?>
        <div class="class-overview-card" style="<?php echo $is_class_teacher ? 'border: 3px solid var(--corporate-red); transform: scale(1.02);' : ''; ?>">
            <div class="class-card-header">
                <div class="class-card-header-left">
                    <div class="class-avatar"><i class="fas fa-school"></i></div>
                    <div>
                        <div class="class-card-title" style="font-weight: 900; font-family: 'Inter', sans-serif !important;"><?php echo h($cls['class_name']); ?></div>
                        <div class="class-card-role" style="font-family: 'Inter', sans-serif !important;">
                            <?php if ($cls['class_teacher_id'] == $teacher_id): ?>
                                <span style="background: #fff5f5; color: #940000; font-size: 10px; font-weight: 800; padding: 3px 12px; border-radius: 6px; border: 1px solid #940000; display: inline-flex; align-items: center; gap: 4px; text-transform: uppercase;">
                                    <i class="fas fa-star"></i> Class Teacher
                                </span>
                            <?php else: ?>
                                <span style="color: #64748b; font-weight: 700; font-size: 11px;">Subject Teacher</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <span class="student-count-badge"><?php echo h($cls['student_count']); ?> Students</span>
            </div>
            <div class="class-card-details">
                <div class="class-detail-row">
                    <span class="class-detail-label">Stream</span>
                    <span class="class-detail-value"><?php echo h($cls['stream'] ?: 'N/A'); ?></span>
                </div>
                <div class="class-detail-row">
                    <span class="class-detail-label">Form Level</span>
                    <span class="class-detail-value">Form <?php echo h($cls['form_level']); ?></span>
                </div>
                <div class="class-detail-row">
                    <span class="class-detail-label">Capacity</span>
                    <span class="class-detail-value"><?php echo h($cls['capacity'] ?: 'N/A'); ?></span>
                </div>
            </div>
            <div class="class-card-actions">
                <a href="view.php?class_id=<?php echo $cls['class_id']; ?>" class="btn-class-action outline">
                    <i class="fas fa-users"></i> View Students
                </a>
                <a href="../attendance/mark.php?class_id=<?php echo $cls['class_id']; ?>" class="btn-class-action filled">
                    <i class="fas fa-calendar-check"></i> Mark Attendance
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Students in My Classes -->
    <div class="students-section">
        <div class="students-section-header">
            <h2><i class="fas fa-user-graduate" style="margin-right: 8px;"></i> Students in My Classes</h2>
        </div>

        <!-- Tabs -->
        <div class="class-tabs">
            <?php foreach ($my_classes as $idx => $cls): ?>
            <button class="class-tab <?php echo ($idx === 0) ? 'active' : ''; ?>" 
                    onclick="switchTab(this, 'class-group-<?php echo $cls['class_id']; ?>')">
                <?php echo h($cls['class_name']); ?> (<?php echo $cls['student_count']; ?>)
            </button>
            <?php endforeach; ?>
        </div>

        <!-- Student Tables per Class -->
        <?php foreach ($my_classes as $idx => $cls): ?>
        <div class="student-class-group <?php echo ($idx === 0) ? 'active' : ''; ?>" id="class-group-<?php echo $cls['class_id']; ?>">
            <div class="student-class-group-title">
                <?php echo h($cls['class_name']); ?>
                <span class="count"><?php echo $cls['student_count']; ?></span>
            </div>
            <div class="students-table-container">
                <?php $students = $students_by_class[$cls['class_id']]; ?>
                <?php if ($students): ?>
                <table class="students-clean-table">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Student Name</th>
                            <th>Admission No.</th>
                            <th>Gender</th>
                            <th>Parent / Guardian</th>
                            <th style="text-align: center;">View Profile</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($students as $s): ?>
                        <tr>
                            <td style="font-weight: 700; color: var(--secondary-text);"><?php echo $i++; ?></td>
                            <td style="font-weight: 600;"><?php echo h($s['first_name'] . ' ' . $s['middle_name'] . ' ' . $s['last_name']); ?></td>
                            <td style="font-family: 'Courier New', monospace; font-weight: 600; color: var(--corporate-red);"><?php echo h($s['admission_number']); ?></td>
                            <td>
                                <span class="gender-badge">
                                    <?php if (strtolower($s['gender']) == 'male'): ?>
                                        <i class="fas fa-mars" style="color: #940000;"></i> Male
                                    <?php else: ?>
                                        <i class="fas fa-venus" style="color: #64748b;"></i> Female
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td style="color: var(--secondary-text);"><?php echo h($s['parent_name'] ?: 'N/A'); ?></td>
                            <td style="text-align: center;">
                                <a href="profile.php?id=<?php echo $s['student_id']; ?>" class="view-profile-btn" title="View Profile">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div style="padding: 30px; text-align: center; color: var(--secondary-text);">
                    <i class="fas fa-info-circle" style="font-size: 1.5rem; margin-bottom: 10px; display: block; opacity: 0.5;"></i>
                    No active students enrolled in this class.
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php else: ?>
    <!-- Empty State -->
    <div style="background: var(--primary-white); padding: 60px 40px; text-align: center; border-radius: 14px; border: 1px solid rgba(148,0,0,0.08);">
        <i class="fas fa-user-graduate fa-4x" style="color: #ddd; margin-bottom: 20px;"></i>
        <h3 style="color: var(--secondary-text); font-weight: 600; margin-bottom: 8px;">No Classes Assigned</h3>
        <p style="color: var(--secondary-text); font-size: 0.95rem;">You don't have any classes assigned yet. Contact the administrator.</p>
    </div>
    <?php endif; ?>
</main>

<script>
function switchTab(tabEl, groupId) {
    // Deactivate all tabs
    document.querySelectorAll('.class-tab').forEach(t => t.classList.remove('active'));
    // Hide all groups
    document.querySelectorAll('.student-class-group').forEach(g => g.classList.remove('active'));
    // Activate clicked tab and group
    tabEl.classList.add('active');
    document.getElementById(groupId).classList.add('active');
}
</script>

<?php require_once '../../includes/footer.php'; ?>
