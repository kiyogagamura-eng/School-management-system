<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Class Statistics";

$teacher_id = 0;
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher_id = $stmt->fetchColumn();

// Fetch exams that have results for this teacher
$stmt = $pdo->prepare("
    SELECT e.exam_id, e.exam_name, c.class_name, s.subject_name 
    FROM exams e
    JOIN classes c ON e.class_id = c.class_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.teacher_id = ? AND EXISTS (SELECT 1 FROM results r WHERE r.exam_id = e.exam_id)
    ORDER BY e.created_at DESC
");
$stmt->execute([$teacher_id]);
$exams_with_results = $stmt->fetchAll();

$exam_id = $_GET['exam_id'] ?? ($exams_with_results[0]['exam_id'] ?? 0);

$stats = null;
$grade_distribution = [];
$top_students = [];
$bottom_students = [];
$exam_details = null;
$trend_data = [];

if ($exam_id) {
    // Fetch exam details
    $stmt = $pdo->prepare("
        SELECT e.*, c.class_name, s.subject_name 
        FROM exams e
        JOIN classes c ON e.class_id = c.class_id
        JOIN subjects s ON e.subject_id = s.subject_id
        WHERE e.exam_id = ? AND e.teacher_id = ?
    ");
    $stmt->execute([$exam_id, $teacher_id]);
    $exam_details = $stmt->fetch();

    if ($exam_details) {
        $stmt = $pdo->prepare("
            SELECT r.*, s.first_name, s.last_name, s.admission_number 
            FROM results r
            JOIN students s ON r.student_id = s.student_id
            WHERE r.exam_id = ?
            ORDER BY r.marks_obtained DESC
        ");
        $stmt->execute([$exam_id]);
        $results = $stmt->fetchAll();

        if (!empty($results)) {
            $marks_arr = array_column($results, 'marks_obtained');
            $pass_marks = $exam_details['pass_marks'];

            $stats = [
                'total' => count($results),
                'average' => round(array_sum($marks_arr) / count($marks_arr), 1),
                'highest' => max($marks_arr),
                'lowest' => min($marks_arr),
                'passed' => count(array_filter($marks_arr, function($m) use ($pass_marks) { return $m >= $pass_marks; })),
                'failed' => count(array_filter($marks_arr, function($m) use ($pass_marks) { return $m < $pass_marks; })),
            ];

            // Grade distribution
            $grades = array_column($results, 'grade');
            $grade_counts = array_count_values($grades);
            $all_grades = ['A', 'B', 'C', 'D', 'E', 'F'];
            foreach ($all_grades as $g) {
                $grade_distribution[$g] = $grade_counts[$g] ?? 0;
            }

            // Top and Bottom 5
            $top_students = array_slice($results, 0, 5);
            $bottom_students = array_slice(array_reverse($results), 0, 5);
            
            // Re-reverse bottom students so the absolute lowest is at the bottom of the list visually if we want, 
            // but usually we just list them. We'll leave them as lowest first.
        }

        // Trend Analysis (Previous exams for the same class and subject)
        $stmt = $pdo->prepare("
            SELECT e.exam_name, e.exam_date, AVG(r.marks_obtained) as avg_marks
            FROM exams e
            JOIN results r ON e.exam_id = r.exam_id
            WHERE e.class_id = ? AND e.subject_id = ? AND e.exam_date <= ?
            GROUP BY e.exam_id
            ORDER BY e.exam_date ASC
            LIMIT 5
        ");
        $stmt->execute([$exam_details['class_id'], $exam_details['subject_id'], $exam_details['exam_date']]);
        $trend_data = $stmt->fetchAll();
    }
}
?>
<?php require_once '../../includes/header.php'; ?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="dashboard-container">
    <header class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-chart-pie"></i> <?php echo $page_title; ?></h2>
                <p style="color: var(--secondary-text); margin-top: 5px;">Analysis of your class results.</p>
            </div>
            
            <form action="" method="GET" style="display: flex; gap: 10px; align-items: center;">
                <label style="font-weight: 700; color: white;">Select Exam:</label>
                <select name="exam_id" class="form-control" onchange="this.form.submit()" style="min-width: 250px;">
                    <option value="">-- Choose Exam --</option>
                    <?php 
                    // Group exams using standard categories from helper
                    $standard_groups = getStandardExamNames();
                    $grouped_stats_exams = [];
                    
                    // Categorize exams based on keywords in their names
                    foreach ($exams_with_results as $e) {
                        $exam_name_lower = strtolower($e['exam_name']);
                        $categorized = false;
                        
                        foreach ($standard_groups as $category => $keywords) {
                            foreach ($keywords as $keyword) {
                                if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                    $grouped_stats_exams[$category][] = $e;
                                    $categorized = true;
                                    break 2;
                                }
                            }
                        }
                        
                        // If not categorized, put in "Other Assessments"
                        if (!$categorized) {
                            $grouped_stats_exams['Other Assessments'][] = $e;
                        }
                    }
                    
                    // Display grouped options
                    foreach ($grouped_stats_exams as $label => $group): ?>
                        <optgroup label="<?php echo $label; ?>">
                            <?php foreach ($group as $e): ?>
                                <option value="<?php echo $e['exam_id']; ?>" <?php echo $e['exam_id'] == $exam_id ? 'selected' : ''; ?>>
                                    <?php echo h($e['exam_name'] . ' (' . $e['class_name'] . ' - ' . $e['subject_name'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
    </header>

    <?php if (!$exam_id): ?>
        <div class="card" style="text-align: center; padding: 50px;">
            <i class="fas fa-chart-bar" style="font-size: 4rem; color: #ccc; margin-bottom: 20px;"></i>
            <h3>No Exam Selected</h3>
            <p style="color: var(--secondary-text);">Please select an exam from the dropdown above to view its statistics.</p>
        </div>
    <?php elseif (!$stats): ?>
        <div class="card" style="text-align: center; padding: 50px;">
            <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: #f39c12; margin-bottom: 20px;"></i>
            <h3>No Results Found</h3>
            <p style="color: var(--secondary-text);">No marks have been entered for this exam yet.</p>
            <a href="enter-marks.php?id=<?php echo $exam_id; ?>" class="btn btn-primary" style="margin-top: 15px;">Enter Marks Now</a>
        </div>
    <?php else: ?>

        <!-- Summary Cards -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 25px;">
            <div class="card" style="text-align: center; padding: 20px; border-bottom: 4px solid #64748b;">
                <div style="font-size: 2rem; font-weight: 900; color: #64748b;"><?php echo $stats['total']; ?></div>
                <div style="color: var(--secondary-text); font-weight: 700; font-size: 0.8rem;">TOTAL STUDENTS</div>
            </div>
            <div class="card" style="text-align: center; padding: 20px; border-bottom: 4px solid #940000;">
                <div style="font-size: 2rem; font-weight: 900; color: #940000;"><?php echo $stats['average']; ?>%</div>
                <div style="color: var(--secondary-text); font-weight: 700; font-size: 0.8rem;">CLASS AVERAGE</div>
            </div>
            <div class="card" style="text-align: center; padding: 20px; border-bottom: 4px solid #940000;">
                <div style="font-size: 2rem; font-weight: 900; color: #940000;"><?php echo $stats['highest']; ?>%</div>
                <div style="color: var(--secondary-text); font-weight: 700; font-size: 0.8rem;">HIGHEST MARK</div>
            </div>
            <div class="card" style="text-align: center; padding: 20px; border-bottom: 4px solid #64748b;">
                <div style="font-size: 2rem; font-weight: 900; color: #64748b;"><?php echo $stats['lowest']; ?>%</div>
                <div style="color: var(--secondary-text); font-weight: 700; font-size: 0.8rem;">LOWEST MARK</div>
            </div>
            <div class="card" style="text-align: center; padding: 20px; border-bottom: 4px solid #940000;">
                <div style="font-size: 2rem; font-weight: 900; color: #940000;"><?php echo round(($stats['passed']/$stats['total'])*100); ?>%</div>
                <div style="color: var(--secondary-text); font-weight: 700; font-size: 0.8rem;">PASS RATE (<?php echo $stats['passed']; ?> Passed)</div>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
            <!-- Grade Distribution Chart -->
            <div class="card">
                <div class="card-header"><i class="fas fa-chart-pie"></i> Grade Distribution</div>
                <div class="card-body" style="position: relative; height: 300px; display: flex; justify-content: center;">
                    <canvas id="gradeChart"></canvas>
                </div>
            </div>

            <!-- Trend Chart -->
            <div class="card">
                <div class="card-header"><i class="fas class="fas fa-line-chart"></i> Performance Trend (<?php echo h($exam_details['subject_name']); ?>)</div>
                <div class="card-body" style="position: relative; height: 300px;">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Top Students -->
            <div class="card">
                <div class="card-header" style="background: #940000; color: white;">
                    <i class="fas fa-trophy"></i> Top 5 Students
                </div>
                <div class="card-body" style="padding: 0;">
                    <table class="table" style="margin: 0;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Marks</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_students as $s): ?>
                                <tr>
                                    <td style="font-weight: 700;"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?></td>
                                    <td style="font-weight: 900; color: #940000;"><?php echo $s['marks_obtained']; ?></td>
                                    <td><span class="badge" style="background: #fff5f5; color: #940000;"><?php echo $s['grade']; ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Bottom Students -->
            <div class="card">
                <div class="card-header" style="background: #475569; color: white;">
                    <i class="fas fa-exclamation-circle"></i> Students Needing Attention (Bottom 5)
                </div>
                <div class="card-body" style="padding: 0;">
                    <table class="table" style="margin: 0;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Marks</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bottom_students as $s): ?>
                                <tr>
                                    <td style="font-weight: 700;"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?></td>
                                    <td style="font-weight: 900; color: #64748b;"><?php echo $s['marks_obtained']; ?></td>
                                    <td><span class="badge" style="background: #f1f5f9; color: #475569;"><?php echo $s['grade']; ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div style="padding: 15px; text-align: center; background: #f9f9f9; border-top: 1px solid #eee;">
                        <a href="parent-messages.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-primary" style="font-size: 0.8rem; background: #940000; border-color: #940000;">
                            <i class="fas fa-sms"></i> Message Parents
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Grade Distribution Chart
            const ctxGrade = document.getElementById('gradeChart').getContext('2d');
            new Chart(ctxGrade, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_keys($grade_distribution)); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_values($grade_distribution)); ?>,
                        backgroundColor: ['#940000', '#c0392b', '#64748b', '#94a3b8', '#cbd5e1', '#f1f5f9'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'right' }
                    }
                }
            });

            // Trend Chart
            const trendData = <?php echo json_encode($trend_data); ?>;
            if (trendData.length > 0) {
                const ctxTrend = document.getElementById('trendChart').getContext('2d');
                new Chart(ctxTrend, {
                    type: 'line',
                    data: {
                        labels: trendData.map(d => d.exam_name),
                        datasets: [{
                            label: 'Class Average',
                            data: trendData.map(d => d.avg_marks),
                            borderColor: '#940000',
                            backgroundColor: 'rgba(148, 0, 0, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, max: 100 }
                        }
                    }
                });
            }
        });
        </script>

    <?php endif; ?>
</div>

<?php require_once '../../includes/footer.php'; ?>
