<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Results Reports";

$teacher_id = 0;
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher_id = $stmt->fetchColumn();

// Fetch classes assigned to this teacher for filtering
$stmt = $pdo->prepare("SELECT DISTINCT c.class_id, c.class_name FROM classes c JOIN class_subjects cs ON c.class_id = cs.class_id WHERE cs.teacher_id = ? ORDER BY c.class_name");
$stmt->execute([$teacher_id]);
$filter_classes = $stmt->fetchAll();

// Fetch academic years (Dynamic up to current year)
$current_year = (int)date('Y');
$filter_years = range(2024, $current_year);
rsort($filter_years);

// Get selected filters
$sel_class_id = $_GET['filter_class_id'] ?? '';
$sel_year = $_GET['filter_year'] ?? $current_year;

$error_msg = "";
if ((int)$sel_year > $current_year) {
    $error_msg = "The selected academic year has not arrived yet (You cannot choose a future year like $sel_year).";
    $sel_year = $current_year;
} elseif ((int)$sel_year < 2024) {
    $error_msg = "The selected academic year is in the past (You cannot choose a year before 2024).";
    $sel_year = $current_year;
}

// Fetch exams filtered by class and year (using COALESCE to handle NULL dates)
$query = "
    SELECT e.exam_id, e.exam_name, e.exam_date, e.exam_type, c.class_name, s.subject_name 
    FROM exams e
    JOIN classes c ON e.class_id = c.class_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.teacher_id = ?
";
$params = [$teacher_id];

if ($sel_class_id) {
    $query .= " AND e.class_id = ?";
    $params[] = $sel_class_id;
}

// Filter by year - if exam_date is null, use created_at year
$query .= " AND COALESCE(YEAR(e.exam_date), YEAR(e.created_at)) = ?";
$params[] = $sel_year;

$query .= " ORDER BY COALESCE(e.exam_date, e.created_at) DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$exams = $stmt->fetchAll();

// Group exams by type for the dropdown
$grouped_exams = [];
foreach ($exams as $e) {
    $type_label = '';
    switch($e['exam_type']) {
        case 'midterm': $type_label = 'Midterm Exams'; break;
        case 'endterm': $type_label = 'End of Term Exams'; break;
        case 'test': 
        case 'practical':
            $type_label = 'Weekly / Monthly Tests'; break;
        default: $type_label = 'Other Assessments'; break;
    }
    $grouped_exams[$type_label][] = $e;
}

// Handle Report Downloads
if (isset($_GET['download']) && isset($_GET['exam_id'])) {
    $type = $_GET['download'];
    $exam_id = (int)$_GET['exam_id'];
    
    // Verify exam belongs to teacher
    $stmt = $pdo->prepare("SELECT e.*, c.class_name, s.subject_name FROM exams e JOIN classes c ON e.class_id = c.class_id JOIN subjects s ON e.subject_id = s.subject_id WHERE e.exam_id = ? AND e.teacher_id = ?");
    $stmt->execute([$exam_id, $teacher_id]);
    $exam = $stmt->fetch();
    
    if ($exam) {
        $stmt = $pdo->prepare("
            SELECT r.*, st.first_name, st.last_name, st.admission_number, st.parent_phone 
            FROM results r
            JOIN students st ON r.student_id = st.student_id
            WHERE r.exam_id = ?
            ORDER BY r.marks_obtained DESC
        ");
        $stmt->execute([$exam_id]);
        $results = $stmt->fetchAll();
        
        $filename = "report_" . safeFilename($exam['exam_name'] . "_" . $exam['class_name']) . "_" . date('Ymd') . ".csv";
        
        // Clean output buffer before sending actual file
        if (ob_get_length()) ob_clean();
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $out = fopen('php://output', 'w');
        // Add BOM for Excel UTF-8 display
        fputs($out, $bom =(chr(0xEF) . chr(0xBB) . chr(0xBF)));
        
        // CSV Metadata Header
        fputcsv($out, ['Exam:', $exam['exam_name'], 'Class:', $exam['class_name'], 'Subject:', $exam['subject_name'], 'Date:', date('Y-m-d')]);
        fputcsv($out, []); // Blank line
        
        if ($type === 'full') {
            fputcsv($out, ['Rank', 'Admission No', 'Student Name', 'Marks (' . $exam['max_marks'] . ')', 'Grade', 'Remarks']);
            $rank = 1;
            foreach ($results as $r) {
                fputcsv($out, [$rank++, $r['admission_number'], $r['first_name'].' '.$r['last_name'], $r['marks_obtained'], $r['grade'], $r['remarks']]);
            }
        } elseif ($type === 'pass') {
            fputcsv($out, ['Rank', 'Admission No', 'Student Name', 'Marks (' . $exam['max_marks'] . ')', 'Grade']);
            $rank = 1;
            foreach ($results as $r) {
                if ($r['marks_obtained'] >= $exam['pass_marks']) {
                    fputcsv($out, [$rank++, $r['admission_number'], $r['first_name'].' '.$r['last_name'], $r['marks_obtained'], $r['grade']]);
                }
            }
        } elseif ($type === 'fail') {
            fputcsv($out, ['Admission No', 'Student Name', 'Marks (' . $exam['max_marks'] . ')', 'Grade', 'Parent Phone']);
            foreach ($results as $r) {
                if ($r['marks_obtained'] < $exam['pass_marks']) {
                    fputcsv($out, [$r['admission_number'], $r['first_name'].' '.$r['last_name'], $r['marks_obtained'], $r['grade'], $r['parent_phone']]);
                }
            }
        } elseif ($type === 'trend') {
            // Compare with previous exam of same class/subj
            $stmt = $pdo->prepare("SELECT exam_id, exam_name FROM exams WHERE class_id = ? AND subject_id = ? AND exam_date < ? ORDER BY exam_date DESC LIMIT 1");
            $stmt->execute([$exam['class_id'], $exam['subject_id'], $exam['exam_date']]);
            $prev_exam = $stmt->fetch();
            
            fputcsv($out, ['Admission No', 'Student Name', 'Current Marks', 'Previous Marks', 'Trend']);
            
            $prev_marks = [];
            if ($prev_exam) {
                $stmt = $pdo->prepare("SELECT student_id, marks_obtained FROM results WHERE exam_id = ?");
                $stmt->execute([$prev_exam['exam_id']]);
                $prev_marks = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
            }
            
            foreach ($results as $r) {
                $p_mark = isset($prev_marks[$r['student_id']]) ? $prev_marks[$r['student_id']] : 'N/A';
                $trend = 'N/A';
                if ($p_mark !== 'N/A') {
                    $diff = $r['marks_obtained'] - $p_mark;
                    $trend = $diff > 0 ? "+$diff (Improved)" : ($diff < 0 ? "$diff (Declined)" : "No Change");
                }
                fputcsv($out, [$r['admission_number'], $r['first_name'].' '.$r['last_name'], $r['marks_obtained'], $p_mark, $trend]);
            }
        }
        
        fclose($out);
        exit();
    } else {
        die("Error: Exam not found or you don't have permission to download this report.");
    }
}

// Fetch report data if exam is selected for preview
$preview_exam_id = $_GET['exam_id'] ?? null;
$preview_results = [];
$preview_exam = null;
$stats = ['pass' => 0, 'fail' => 0, 'avg' => 0, 'total' => 0];

if ($preview_exam_id) {
    $stmt = $pdo->prepare("SELECT e.*, c.class_name, s.subject_name FROM exams e JOIN classes c ON e.class_id = c.class_id JOIN subjects s ON e.subject_id = s.subject_id WHERE e.exam_id = ? AND e.teacher_id = ?");
    $stmt->execute([$preview_exam_id, $teacher_id]);
    $preview_exam = $stmt->fetch();

    if ($preview_exam) {
        $stmt = $pdo->prepare("SELECT r.*, st.first_name, st.last_name, st.admission_number FROM results r JOIN students st ON r.student_id = st.student_id WHERE r.exam_id = ? ORDER BY r.marks_obtained DESC");
        $stmt->execute([$preview_exam_id]);
        $preview_results = $stmt->fetchAll();

        if (!empty($preview_results)) {
            $stats['total'] = count($preview_results);
            $sum = 0;
            foreach ($preview_results as $r) {
                $sum += $r['marks_obtained'];
                if ($r['marks_obtained'] >= $preview_exam['pass_marks']) $stats['pass']++;
                else $stats['fail']++;
            }
            $stats['avg'] = round($sum / $stats['total'], 1);
        }
    }
}
?>
<?php require_once '../../includes/header.php'; ?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css?v=<?php echo time(); ?>">
<style>
    /* Absolute Force for Reports Page */
    body, h1, h2, h3, h4, h5, h6, .card-header, .btn, .form-control {
        font-family: 'Inter', sans-serif !important;
    }
</style>

<div class="dashboard-container">
    <header class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <h2 style="margin: 0;"><i class="fas fa-file-excel"></i> <?php echo $page_title; ?></h2>
        <p style="color: var(--secondary-text); margin-top: 5px;">Download various student results reports in CSV format.</p>
    </header>

    <?php if (!empty($error_msg)): ?>
        <div style="background: #fef2f2; border-left: 5px solid #ef4444; color: #991b1b; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-exclamation-circle" style="font-size: 1.2rem;"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <div class="card shadow-premium">
        <div class="card-header"><i class="fas fa-download"></i> Select Report to Download</div>
        <div class="card-body">
            
            <!-- Filters (Always Visible) -->
            <div style="background: #fdfdfd; padding: 25px; border-radius: 15px; margin-bottom: 25px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <form action="" method="GET" id="filterForm" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; align-items: flex-end;">
                    <div>
                        <label style="font-weight: 800; display: block; margin-bottom: 8px; color: #1e293b; font-size: 0.8rem;">CHOOSE CLASS</label>
                        <select name="filter_class_id" class="form-control" style="height: 45px; border-radius: 8px;" onchange="this.form.submit()">
                            <option value="">-- All My Classes --</option>
                            <?php foreach ($filter_classes as $fc): ?>
                                <option value="<?php echo $fc['class_id']; ?>" <?php echo ($sel_class_id == $fc['class_id']) ? 'selected' : ''; ?>><?php echo h($fc['class_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                        <div>
                            <label style="font-weight: 800; display: block; margin-bottom: 8px; color: #1e293b; font-size: 0.8rem;">ACADEMIC YEAR</label>
                            <select name="filter_year" class="form-control" style="height: 45px; border-radius: 8px;" onchange="this.form.submit()">
                                <?php foreach ($filter_years as $year): ?>
                                    <option value="<?php echo $year; ?>" <?php echo ($sel_year == $year) ? 'selected' : ''; ?>><?php echo $year; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <div>
                        <label style="font-weight: 800; display: block; margin-bottom: 8px; color: #1e293b; font-size: 0.8rem;">SELECT EXAM</label>
                        <select name="exam_id" id="exam_select" class="form-control" style="height: 45px; border-radius: 8px; border: 2px solid var(--corporate-red);" onchange="this.form.submit()">
                            <option value="">-- Select Exam --</option>
                            <?php 
                            // Group exams using standard categories from helper
                            $standard_groups = getStandardExamNames();
                            $grouped_by_standard = [];
                            
                            // Categorize exams based on keywords in their names
                            foreach ($exams as $e) {
                                $exam_name_lower = strtolower($e['exam_name']);
                                $categorized = false;
                                
                                foreach ($standard_groups as $category => $keywords) {
                                    foreach ($keywords as $keyword) {
                                        if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                            $grouped_by_standard[$category][] = $e;
                                            $categorized = true;
                                            break 2;
                                        }
                                    }
                                }
                                
                                // If not categorized, put in "Other Assessments"
                                if (!$categorized) {
                                    $grouped_by_standard['Other Assessments'][] = $e;
                                }
                            }
                            
                            // Display grouped options
                            foreach ($grouped_by_standard as $label => $group): ?>
                                <optgroup label="<?php echo $label; ?>">
                                    <?php foreach ($group as $e): ?>
                                        <option value="<?php echo $e['exam_id']; ?>" <?php echo ($preview_exam_id == $e['exam_id']) ? 'selected' : ''; ?>>
                                            <?php 
                                                $display_name = h($e['exam_name']);
                                                if (stripos($display_name, $e['subject_name']) === false) {
                                                    $display_name .= ' (' . h($e['subject_name']) . ')';
                                                }
                                                echo $display_name;
                                            ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php if ($preview_exam): ?>
                        <div>
                            <button type="button" onclick="downloadReport('full')" class="btn btn-primary" style="background: #1e293b; border: none; padding: 12px 20px; width: 100%; height: 45px;"><i class="fas fa-file-csv"></i> Download CSV</button>
                        </div>
                    <?php endif; ?>
                </form>
            </div>

            <?php if (empty($exams)): ?>
                <div style="text-align: center; padding: 60px 40px; background: white; border-radius: 15px; border: 2px dashed #e2e8f0;">
                    <i class="fas fa-folder-open" style="font-size: 3rem; margin-bottom: 15px; color: #ccc;"></i>
                    <h3 style="color: #64748b; font-weight: 700;">No exams found</h3>
                    <p style="color: #94a3b8;">Try changing the class or academic year filters above.</p>
                </div>
            <?php else: ?>

                <?php if ($preview_exam): ?>
                    <!-- Quick Stats -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 30px;">
                        <div class="card" style="text-align: center; border-left: 4px solid #940000; padding: 20px;">
                            <div style="font-size: 1.8rem; font-weight: 900; color: #1e293b;"><?php echo $stats['total']; ?></div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Students</div>
                        </div>
                        <div class="card" style="text-align: center; border-left: 4px solid #940000; padding: 20px;">
                            <div style="font-size: 1.8rem; font-weight: 900; color: #940000;"><?php echo $stats['pass']; ?></div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Passed</div>
                        </div>
                        <div class="card" style="text-align: center; border-left: 4px solid #64748b; padding: 20px;">
                            <div style="font-size: 1.8rem; font-weight: 900; color: #64748b;"><?php echo $stats['fail']; ?></div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Failed</div>
                        </div>
                        <div class="card" style="text-align: center; border-left: 4px solid #475569; padding: 20px;">
                            <div style="font-size: 1.8rem; font-weight: 900; color: #475569;"><?php echo $stats['avg']; ?>%</div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Class Avg</div>
                        </div>
                    </div>

                    <!-- Table Preview -->
                    <div class="card shadow-premium" style="border-radius: 15px; overflow: hidden;">
                        <div class="card-header" style="background: #fff5f5; color: #940000; border-bottom: 1px solid #fecaca; font-weight: 800; padding: 15px 20px;">
                            <i class="fas fa-eye"></i> REPORT PREVIEW: <?php echo h($preview_exam['exam_name']); ?>
                        </div>
                        <div class="card-body" style="padding: 0;">
                            <table class="premium-table">
                                <thead>
                                    <tr>
                                        <th style="width: 80px;">Rank</th>
                                        <th>Student Name</th>
                                        <th style="text-align: center;">Marks / <?php echo $preview_exam['max_marks']; ?></th>
                                        <th style="text-align: center;">Grade</th>
                                        <th style="text-align: center;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $rank = 1; foreach ($preview_results as $res): 
                                        $is_pass = ($res['marks_obtained'] >= $preview_exam['pass_marks']);
                                    ?>
                                        <tr>
                                            <td style="font-weight: 800; color: #64748b; text-align: center;"><?php echo $rank++; ?></td>
                                            <td style="font-weight: 700;"><?php echo h($res['first_name'] . ' ' . $res['last_name']); ?></td>
                                            <td style="text-align: center; font-weight: 800;"><?php echo $res['marks_obtained']; ?></td>
                                            <td style="text-align: center;"><span style="font-weight: 900; color: var(--corporate-red);"><?php echo $res['grade']; ?></span></td>
                                            <td style="text-align: center;">
                                                <span style="background: <?php echo $is_pass ? '#fff5f5' : '#f1f5f9'; ?>; color: <?php echo $is_pass ? '#940000' : '#64748b'; ?>; padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; border: 1px solid <?php echo $is_pass ? '#fecaca' : '#e2e8f0'; ?>;">
                                                    <?php echo $is_pass ? 'PASS' : 'FAIL'; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Welcome Placeholder -->
                    <div style="text-align: center; padding: 80px 40px; background: white; border-radius: 15px; border: 2px dashed #e2e8f0;">
                        <i class="fas fa-chart-bar" style="font-size: 4rem; color: #e2e8f0; margin-bottom: 20px;"></i>
                        <h3 style="color: #64748b; font-weight: 700;">Please select an exam to view the report</h3>
                        <p style="color: #94a3b8;">Choose an exam from the dropdown above to see detailed student performance.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function downloadReport(type) {
    const examId = document.getElementById('exam_select').value;
    if (!examId) {
        alert('Please select an exam first.');
        return;
    }
    window.location.href = `?download=${type}&exam_id=${examId}`;
}
</script>

<?php require_once '../../includes/footer.php'; ?>
