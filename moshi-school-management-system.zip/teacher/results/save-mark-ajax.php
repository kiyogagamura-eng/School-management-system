<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

// Set JSON response header
header('Content-Type: application/json');

// Fetch teacher profile
$teacher_stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$teacher_stmt->execute([$_SESSION['user_id']]);
$teacher_profile = $teacher_stmt->fetch();
$current_teacher_id = $teacher_profile ? $teacher_profile['teacher_id'] : null;

if (!$current_teacher_id) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid teacher profile.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exam_id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
    $student_id = isset($_POST['student_id']) ? (int)$_POST['student_id'] : 0;
    $marks = isset($_POST['marks']) ? $_POST['marks'] : '';

    if (!$exam_id || !$student_id) {
        echo json_encode(['success' => false, 'message' => 'Missing exam_id or student_id.']);
        exit();
    }

    // Fetch exam details
    $stmt = $pdo->prepare("SELECT * FROM exams WHERE exam_id = ?");
    $stmt->execute([$exam_id]);
    $exam = $stmt->fetch();

    if (!$exam) {
        echo json_encode(['success' => false, 'message' => 'Exam not found.']);
        exit();
    }

    // Security check
    if ($exam['teacher_id'] != $current_teacher_id) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized subject teacher.']);
        exit();
    }

    // Check status
    $stmt_status = $pdo->prepare("SELECT status FROM results WHERE exam_id = ? LIMIT 1");
    $stmt_status->execute([$exam_id]);
    $current_status = $stmt_status->fetchColumn() ?: 'draft';

    if ($current_status === 'published' || $current_status === 'submitted') {
        echo json_encode(['success' => false, 'message' => 'Results are locked and cannot be updated.']);
        exit();
    }

    if ($marks === '') {
        // Empty value means not entered yet or deleted
        echo json_encode(['success' => true, 'message' => 'Marks ignored (empty value).']);
        exit();
    }

    $marks = (float)$marks;
    if ($marks < 0) {
        $marks = 0;
    }
    if ($marks > $exam['max_marks']) {
        $marks = $exam['max_marks'];
    }

    // Calculate percentage, grade, and remark
    $percentage = ($exam['max_marks'] > 0) ? ($marks / $exam['max_marks']) * 100 : 0;
    $grade = calculateGrade($percentage);

    // Fetch grading scale mapping to get remark
    $grading_stmt = $pdo->query("SELECT * FROM grading_scale ORDER BY min_marks DESC");
    $grading_scale = $grading_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $grade_to_remark = [];
    foreach ($grading_scale as $g) {
        $grade_to_remark[$g['grade']] = $g['remarks'] ?? ($g['label'] ?? '');
    }
    $remark = $grade_to_remark[$grade] ?? '';

    try {
        $stmt_insert = $pdo->prepare("
            INSERT INTO results (student_id, exam_id, subject_id, class_id, marks_obtained, grade, remarks, status, entered_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', ?)
            ON DUPLICATE KEY UPDATE 
                marks_obtained = VALUES(marks_obtained), 
                grade = VALUES(grade), 
                remarks = VALUES(remarks),
                last_updated = CURRENT_TIMESTAMP
        ");
        $stmt_insert->execute([
            $student_id, $exam_id, $exam['subject_id'], 
            $exam['class_id'], $marks, $grade, $remark, $current_teacher_id
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Auto-saved successfully.',
            'grade' => $grade,
            'remark' => $remark,
            'percentage' => $percentage
        ]);
        exit();
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}
