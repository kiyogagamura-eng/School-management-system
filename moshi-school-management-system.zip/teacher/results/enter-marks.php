<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Teacher Marks Entry";

// Fetch teacher_id for the current logged-in user
$teacher_stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$teacher_stmt->execute([$_SESSION['user_id']]);
$teacher_profile = $teacher_stmt->fetch();
$current_teacher_id = $teacher_profile ? $teacher_profile['teacher_id'] : null;

if (!$current_teacher_id) {
    die("Invalid Identification: You do not have a teacher profile associated with your account.");
}

$exam_id = $_GET['id'] ?? 0;
if (!$exam_id) redirect('exams.php');

// Fetch exam details
$stmt = $pdo->prepare("
    SELECT e.*, c.class_name, s.subject_name 
    FROM exams e
    JOIN classes c ON e.class_id = c.class_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.exam_id = ?
");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch();

if (!$exam) redirect('exams.php');

// Security check: Ensure this teacher is assigned to this exam
if ($exam['teacher_id'] != $current_teacher_id) {
    die("Unauthorized access. Only the subject teacher is allowed to enter marks for this exam.");
}

// Fetch students in this class
$stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$stmt->execute([$exam['class_id']]);
$students = $stmt->fetchAll();

// Fetch existing marks
$stmt = $pdo->prepare("SELECT student_id, results.* FROM results WHERE exam_id = ?");
$stmt->execute([$exam_id]);
$existing_marks = $stmt->fetchAll(PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);

// Determine overall status for this exam set
$current_status = 'draft';
if (!empty($existing_marks)) {
    $first_res = reset($existing_marks);
    $current_status = $first_res['status'] ?? 'draft';
}

$error = '';
$success = '';

// Handle Template Export in CSV
if (isset($_GET['export_template'])) {
    if (ob_get_length()) ob_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="marks_template_' . safeFilename($exam['exam_name']) . '.csv"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    fputs($output, $bom =(chr(0xEF) . chr(0xBB) . chr(0xBF))); // UTF-8 BOM
    
    fputcsv($output, ['Admission No', 'Student Name', 'Marks']);
    foreach ($students as $s) {
        $marks = isset($existing_marks[$s['student_id']]) ? $existing_marks[$s['student_id']]['marks_obtained'] : '';
        fputcsv($output, [$s['admission_number'], $s['first_name'] . ' ' . $s['last_name'], $marks]);
    }
    fclose($output);
    exit();
}

// Handle CSV Import
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['import_csv'])) {
    if ($_FILES['csv_file']['error'] == 0) {
        $file = $_FILES['csv_file']['tmp_name'];
        $filename = $_FILES['csv_file']['name'];
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($extension !== 'csv') {
            $error = "Invalid file type. Please save as (.CSV) before importing.";
        } else {
            $content = file_get_contents($file);
            $bom = pack('H*','EFBBBF');
            $content = preg_replace("/^$bom/", '', $content);
            $content = str_replace(["\r\n", "\r"], "\n", $content);
            
            $handle = fopen('php://temp', 'r+');
            fwrite($handle, $content);
            rewind($handle);
            
            $firstLine = fgets($handle);
            rewind($handle);
            $commaCount = substr_count($firstLine, ',');
            $semiCount = substr_count($firstLine, ';');
            $tabCount = substr_count($firstLine, "\t");
            
            $delimiter = ',';
            if ($semiCount > $commaCount && $semiCount > $tabCount) $delimiter = ';';
            elseif ($tabCount > $commaCount && $tabCount > $semiCount) $delimiter = "\t";
            
            $headerRow = fgetcsv($handle, 1000, $delimiter);
            $colMap = ['adm' => 0, 'marks' => 2]; 
            
            if ($headerRow) {
                foreach ($headerRow as $idx => $h) {
                    $h = strtolower(trim($h));
                    if (strpos($h, 'adm') !== false || strpos($h, 'reg') !== false || strpos($h, 'namba') !== false || strpos($h, 'no') !== false) {
                        $colMap['adm'] = $idx;
                    }
                    if ((strpos($h, 'mark') !== false && strpos($h, 'remark') === false) || strpos($h, 'score') !== false || strpos($h, 'alam') !== false || strpos($h, 'matokeo') !== false) {
                        $colMap['marks'] = $idx;
                    }
                }
            }

            $imported_count = 0;
            $skipped_count = 0;
            $student_map = [];
            foreach ($students as $s) {
                $student_map[strtolower(trim($s['admission_number']))] = $s['student_id'];
            }

            while (($data = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
                if (empty($data) || !isset($data[$colMap['adm']])) continue;
                
                $adm_no = strtolower(trim($data[$colMap['adm']]));
                if (isset($student_map[$adm_no])) {
                    $s_id = $student_map[$adm_no];
                    $raw_marks = isset($data[$colMap['marks']]) ? trim($data[$colMap['marks']]) : '0';
                    $marks = 0;
                    if (preg_match('/[0-9]+(?:[\.,][0-9]+)?/', $raw_marks, $matches)) {
                        $marks = (float)str_replace(',', '.', $matches[0]);
                    }
                    
                    if ($marks > $exam['max_marks']) $marks = $exam['max_marks'];
                    
                    $percentage = ($exam['max_marks'] > 0) ? ($marks / $exam['max_marks']) * 100 : 0;
                    $grade = calculateGrade($percentage);
                    
                    $existing_marks[$s_id] = [
                        'marks_obtained' => $marks,
                        'grade' => $grade,
                        'remarks' => $grade_to_remark[$grade] ?? '',
                        'status' => 'draft'
                    ];
                    $imported_count++;
                } else {
                    if ($adm_no !== '') $skipped_count++;
                }
            }
            
            if ($imported_count > 0) {
                $success = "Successfully imported marks for $imported_count students into the temporary review table. Scroll down to save draft or submit.";
                if ($skipped_count > 0) {
                    $success .= " ($skipped_count rows were not recognized).";
                }
            } else {
                $error = "No marks uploaded. Make sure the file matches the Admission Numbers in the system.";
            }
            fclose($handle);
        }
    } else {
        $error = "Hitilafu katika kupakia faili. Tafadhali jaribu tena.";
    }
}

// Handle Manual Save Draft / Submit to Admin
if ($_SERVER['REQUEST_METHOD'] == 'POST' && (isset($_POST['save_marks']) || isset($_POST['submit_to_admin']))) {
    if ($current_status === 'published') {
        $error = "Results are already published, you cannot edit them.";
    } else {
        $marks_data = $_POST['marks'] ?? [];
        $new_status = isset($_POST['submit_to_admin']) ? 'submitted' : 'draft';

        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("
                INSERT INTO results (student_id, exam_id, subject_id, class_id, marks_obtained, grade, remarks, status, entered_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    marks_obtained = VALUES(marks_obtained), 
                    grade = VALUES(grade), 
                    remarks = VALUES(remarks),
                    status = VALUES(status),
                    last_updated = CURRENT_TIMESTAMP
            ");
            
            foreach ($marks_data as $student_id => $marks) {
                if ($marks === '' && !isset($existing_marks[$student_id])) continue;
                
                $marks = ($marks === '') ? 0 : (float)$marks;
                if ($marks > $exam['max_marks']) {
                    $marks = $exam['max_marks'];
                }
                
                $percentage = ($exam['max_marks'] > 0) ? ($marks / $exam['max_marks']) * 100 : 0;
                $grade = calculateGrade($percentage);
                $remark = $grade_to_remark[$grade] ?? '';
                
                $stmt->execute([
                    $student_id, $exam_id, $exam['subject_id'], 
                    $exam['class_id'], $marks, $grade, $remark, $new_status, $current_teacher_id
                ]);
            }
            // Do NOT update exams.is_published to 1 here.
            // DOS will publish/compile, and Headmaster will approve.
            
            $pdo->commit();
            $action_type = ($new_status === 'submitted') ? 'Submitted Marks' : 'Saved Draft Marks';
            logActivity($_SESSION['user_id'], $action_type, "$action_type for Exam ID {$exam_id}");
            $success = $new_status === 'submitted' ? "Marks successfully submitted to DOS/Academic office." : "Draft marks saved successfully.";
            
            // Refresh data
            $stmt = $pdo->prepare("SELECT student_id, results.* FROM results WHERE exam_id = ?");
            $stmt->execute([$exam_id]);
            $existing_marks = $stmt->fetchAll(PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);
            $current_status = $new_status;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Hitilafu: " . $e->getMessage();
        }
    }
}

// Stats Calculation
$class_stats = null;
if (!empty($existing_marks)) {
    $marks_arr = array_map(function($r) { return (float)$r['marks_obtained']; }, $existing_marks);
    $class_stats = [
        'total' => count($marks_arr),
        'average' => round(array_sum($marks_arr) / count($marks_arr), 1),
        'highest' => max($marks_arr),
        'lowest' => min($marks_arr),
        'passed' => count(array_filter($marks_arr, function($m) use ($exam) { return $m >= $exam['pass_marks']; })),
        'failed' => count(array_filter($marks_arr, function($m) use ($exam) { return $m < $exam['pass_marks']; })),
    ];
}

// Fetch grading scale for JavaScript
try {
    $grading_stmt = $pdo->query("SELECT * FROM grading_scale ORDER BY min_marks DESC");
    $grading_scale_js = $grading_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $grading_scale_js = [
        ['grade' => 'A', 'min_marks' => 80, 'max_marks' => 100, 'remarks' => 'Excellent'],
        ['grade' => 'B', 'min_marks' => 70, 'max_marks' => 79, 'remarks' => 'Very Good'],
        ['grade' => 'C', 'min_marks' => 60, 'max_marks' => 69, 'remarks' => 'Good'],
        ['grade' => 'D', 'min_marks' => 50, 'max_marks' => 59, 'remarks' => 'Satisfactory'],
        ['grade' => 'E', 'min_marks' => 40, 'max_marks' => 49, 'remarks' => 'Pass'],
        ['grade' => 'F', 'min_marks' => 0, 'max_marks' => 39, 'remarks' => 'Fail'],
    ];
}

$grade_to_remark = [];
foreach ($grading_scale_js as $g) {
    $grade_to_remark[$g['grade']] = $g['remarks'] ?? ($g['label'] ?? '');
}

require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css?v=<?php echo time(); ?>">
<style>
.marks-container { padding: 20px; max-width: 900px; margin: 0 auto; min-height: 100vh; }
.marks-header-card {
    background: #fff;
    border-radius: 12px;
    border: 1px solid rgba(139, 0, 0, 0.12);
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
}
.marks-input {
    width: 90px;
    padding: 10px;
    font-size: 1.1rem;
    font-weight: 800 !important;
    text-align: center;
    border: 2px solid #cbd5e1;
    border-radius: 10px;
    background: #f8fafc;
    transition: all 0.2s;
    display: inline-block;
}
.marks-input:focus {
    border-color: #8b0000;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(139,0,0,0.15);
    outline: none;
}
.marks-input:disabled {
    background: #e2e8f0;
    color: #64748b;
    border-color: #cbd5e1;
}

/* Responsive Table to Cards on Small screen (Mobile first optimized) */
@media (max-width: 768px) {
    .premium-table thead { display: none; }
    .premium-table tr { 
        display: block; 
        background: #ffffff; 
        border: 1px solid rgba(139,0,0,0.08); 
        border-radius: 12px; 
        margin-bottom: 15px; 
        padding: 14px; 
        box-shadow: 0 2px 8px rgba(0,0,0,0.02);
    }
    .premium-table tr td { 
        display: flex; 
        justify-content: space-between; 
        align-items: center; 
        border: none !important; 
        padding: 8px 0 !important; 
        text-align: right !important; 
        font-size: 0.92rem !important;
    }
    .premium-table tr td::before { 
        content: attr(data-label); 
        font-weight: 800; 
        color: #64748b; 
        font-size: 0.72rem; 
        text-transform: uppercase; 
        text-align: left; 
        flex: 1;
    }
    .premium-table tr td:first-child { border-radius: 0; }
    .premium-table tr td:last-child { border-radius: 0; }
    .marks-input { width: 100px; }
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
    gap: 12px;
    margin-bottom: 25px;
}
.stat-card-small {
    background: #fff;
    padding: 15px;
    border-radius: 12px;
    text-align: center;
    border-top: 4px solid #8b0000;
    box-shadow: 0 4px 10px rgba(0,0,0,0.02);
}
.stat-card-small .num {
    font-size: 1.4rem;
    font-weight: 900;
    color: #8b0000;
}
.stat-card-small .lbl {
    font-size: 0.7rem;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    margin-top: 4px;
}
.floating-footer-actions {
    background: #fff;
    border-top: 2px solid #e2e8f0;
    padding: 15px 20px;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 25px;
    border-radius: 12px;
    box-shadow: var(--shadow-sm);
    flex-wrap: wrap;
}
.btn-premium-action {
    padding: 14px 28px;
    border-radius: 10px;
    font-weight: 800;
    font-size: 0.95rem;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
}
.btn-premium-action.draft {
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #cbd5e1;
}
.btn-premium-action.submit {
    background: linear-gradient(135deg, #8b0000 0%, #b30000 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(139,0,0,0.25);
}
.btn-premium-action:hover {
    transform: translateY(-2px);
}
</style>

<div class="marks-container">
    <!-- Navigation header -->
    <div style="margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between;">
        <a href="../dashboard.php?tab=marks" class="btn-mini" style="background:#f1f5f9; border-color:#cbd5e1; color:#475569; padding: 8px 16px; border-radius: 8px; text-decoration:none; font-weight:700;"><i class="fas fa-chevron-left me-1"></i> Back to Exams</a>
        
        <div style="background: white; border: 1px solid rgba(139,0,0,0.1); padding: 6px 15px; border-radius: 20px; font-weight: 800; color: #8b0000; font-size:0.85rem;">
            Exam: <?php echo h($exam['exam_name']); ?>
        </div>
    </div>

    <!-- Exam Profile Banner -->
    <div class="marks-header-card">
        <h3 style="margin: 0; font-weight: 900; color:#1e293b; font-size:1.15rem;"><?php echo h($exam['class_name'] . ' — ' . $exam['subject_name']); ?></h3>
        <div style="font-size: 0.85rem; color:#64748b; margin-top: 5px; font-weight: 600;">
            Exam Type: <span style="text-transform: capitalize; color:#8b0000;"><?php echo h($exam['exam_type']); ?></span> &nbsp;·&nbsp; Max Marks: <strong><?php echo $exam['max_marks']; ?></strong> &nbsp;·&nbsp; Pass Marks: <strong><?php echo $exam['pass_marks']; ?></strong>
        </div>
    </div>

    <?php if ($success): ?>
        <div style="background: #f0fdf4; color: #166534; border:1px solid #bbf7d0; padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight:700;"><i class="fas fa-check-circle me-1"></i> <?php echo $success; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div style="background: #fff5f5; color: #940000; border:1px solid #fecaca; padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight:700;"><i class="fas fa-exclamation-circle me-1"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Class Stats Mini -->
    <?php if ($class_stats): ?>
    <div class="stats-grid">
        <div class="stat-card-small">
            <div class="num"><?php echo $class_stats['average']; ?>%</div>
            <div class="lbl">Class Avg</div>
        </div>
        <div class="stat-card-small">
            <div class="num"><?php echo $class_stats['highest']; ?>%</div>
            <div class="lbl">Highest Mark</div>
        </div>
        <div class="stat-card-small" style="border-top-color:#64748b;">
            <div class="num"><?php echo $class_stats['lowest']; ?>%</div>
            <div class="lbl">Lowest Mark</div>
        </div>
        <div class="stat-card-small">
            <div class="num"><?php echo $class_stats['passed']; ?>/<?php echo $class_stats['total']; ?></div>
            <div class="lbl">Passed</div>
        </div>
        <div class="stat-card-small" style="border-top-color:#64748b;">
            <div class="num"><?php echo $class_stats['failed']; ?>/<?php echo $class_stats['total']; ?></div>
            <div class="lbl">Failed</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Main Entry Panel -->
    <div class="card shadow-premium" style="background:#fff; border-radius:15px; border:1px solid rgba(139,0,0,0.08); overflow:hidden;">
        
        <!-- Offline import drawer -->
        <?php if ($current_status === 'draft'): ?>
        <div style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 18px 22px;">
            <div style="font-size:0.75rem; font-weight:800; color:#475569; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:12px;"><i class="fas fa-file-csv me-1"></i> IMPORT VIA CSV / EXCEL TEMPLATE</div>
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <a href="?id=<?php echo $exam_id; ?>&export_template=1" style="background:#fff; border:1px solid #cbd5e1; color:#475569; padding:8px 12px; border-radius:8px; text-decoration:none; font-size:0.8rem; font-weight:700;">
                    <i class="fas fa-cloud-download-alt me-1"></i> Download Template (CSV)
                </a>
                <form action="" method="POST" enctype="multipart/form-data" style="display:flex; gap:8px; align-items:center;">
                    <div style="position:relative; overflow:hidden;">
                        <input type="file" name="csv_file" accept=".csv" required id="csv_file_input" style="position:absolute; left:0; top:0; opacity:0; width:100%; height:100%; cursor:pointer;">
                        <label for="csv_file_input" id="file_label" style="background:#fff; border: 1.5px dashed #cbd5e1; color:#475569; padding:8px 12px; border-radius:8px; font-size:0.8rem; font-weight:700; cursor:pointer; display:block;">
                            <i class="fas fa-file-import me-1"></i> Select File
                        </label>
                    </div>
                    <button type="submit" name="import_csv" style="background:#a00000; color:white; border:none; padding:8px 15px; border-radius:8px; font-size:0.8rem; font-weight:700; cursor:pointer;">
                        <i class="fas fa-sync me-1"></i> Upload & Sync
                    </button>
                </form>
            </div>
            <script>
                document.getElementById('csv_file_input').onchange = function() {
                    const fName = this.value.split('\\').pop();
                    const label = document.getElementById('file_label');
                    label.innerHTML = '<i class="fas fa-check"></i> ' + (fName.length > 15 ? fName.substring(0, 12) + '...' : fName);
                    label.style.borderColor = '#8b0000';
                    label.style.color = '#8b0000';
                };
            </script>
        </div>
        <?php endif; ?>

        <div class="card-body" style="padding: 20px;">
            <div style="margin-bottom: 20px; display: flex; align-items: center; gap: 15px; flex-wrap:wrap;">
                <span style="font-weight: 800; color: #475569; font-size:0.85rem;">Current Status:</span>
                <?php if ($current_status == 'draft'): ?>
                    <span class="badge-status missed" style="background:#fff5f5; color:#940000; border:1px solid #fecaca;"><i class="fas fa-edit me-1"></i> DRAFT (EDIT MARKS)</span>
                <?php elseif ($current_status == 'submitted'): ?>
                    <span class="badge-status covered" style="background:#f0faf6; color:#0f766e; border:1px solid #ccfbf1;"><i class="fas fa-clock me-1"></i> AWAITING ACADEMIC REVIEW</span>
                <?php else: ?>
                    <span class="badge-status taught" style="background:#f0fdf4; color:#166534; border:1px solid #bbf7d0;"><i class="fas fa-check-double me-1"></i> PUBLISHED (APPROVED)</span>
                <?php endif; ?>
                <span style="color:#64748b; font-size:0.85rem; font-weight:600; margin-left:auto;">Total Students: <?php echo count($students); ?></span>
            </div>

            <form action="" method="POST" id="marksForm" onsubmit="return handleFormSubmit(event)">
                <table class="premium-table" style="width:100%;">
                    <thead>
                        <tr style="background:#f8fafc; border-bottom:1px solid #e2e8f0;">
                            <th style="padding:15px 10px; font-size:0.75rem; text-transform:uppercase; font-weight:800; color:#8b0000; width:50px;">#</th>
                            <th style="padding:15px; font-size:0.75rem; text-transform:uppercase; font-weight:800; color:#8b0000;">Adm No</th>
                            <th style="padding:15px; font-size:0.75rem; text-transform:uppercase; font-weight:800; color:#8b0000;">Student Name</th>
                            <th style="padding:15px; font-size:0.75rem; text-transform:uppercase; font-weight:800; color:#8b0000; width:140px; text-align:center;">Marks Obtained (Max: <?php echo $exam['max_marks']; ?>)</th>
                            <th style="padding:15px; font-size:0.75rem; text-transform:uppercase; font-weight:800; color:#8b0000; width:80px; text-align:center;">Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($students as $student): 
                            $s_id = $student['student_id'];
                            $marks = isset($existing_marks[$s_id]) ? $existing_marks[$s_id]['marks_obtained'] : '';
                            $grade = isset($existing_marks[$s_id]) ? $existing_marks[$s_id]['grade'] : '-';
                            $is_locked = ($current_status === 'published' || $current_status === 'submitted');
                        ?>
                            <tr>
                                <td data-label="#"><?php echo $i++; ?></td>
                                <td data-label="Adm No" style="font-family: monospace; font-weight:600; color:#475569;"><?php echo h($student['admission_number']); ?></td>
                                <td data-label="Student" style="font-weight: 800; color:#1e293b;"><?php echo h($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                <td data-label="Marks" style="text-align: center;">
                                    <input type="number" step="0.1" min="0" max="<?php echo $exam['max_marks']; ?>" 
                                        name="marks[<?php echo $s_id; ?>]" class="marks-input" 
                                        data-student="<?php echo $s_id; ?>"
                                        value="<?php echo $marks; ?>" 
                                        <?php echo $is_locked ? 'disabled' : ''; ?>
                                        oninput="updateGrade(this, <?php echo $s_id; ?>)">
                                </td>
                                <td data-label="Grade" style="text-align: center;">
                                    <span id="grade_<?php echo $s_id; ?>" style="font-weight: 900; color: #8b0000; font-size: 1.15rem;"><?php echo $grade; ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="floating-footer-actions">
                    <?php if ($current_status === 'draft'): ?>
                        <button type="submit" name="save_marks" class="btn-premium-action draft">
                            <i class="fas fa-save"></i> SAVE AS DRAFT
                        </button>
                        <button type="submit" name="submit_to_admin" class="btn-premium-action submit">
                                    <i class="fas fa-paper-plane"></i> SUBMIT TO ACADEMIC
                                </button>
                    <?php elseif ($current_status === 'submitted'): ?>
                        <div style="color: #0f766e; font-weight: 700; display:flex; align-items:center; gap:8px;">
                            <i class="fas fa-spinner fa-spin"></i> Results submitted. Awaiting DOS approval.
                        </div>
                    <?php else: ?>
                        <div style="color: #166534; font-weight: 700; display:flex; align-items:center; gap:8px; margin-right:auto;">
                            <i class="fas fa-check-circle"></i> Results published.
                        </div>
                        <a href="statistics.php?exam_id=<?php echo $exam_id; ?>" class="btn-premium-action submit" style="text-decoration:none;">
                            <i class="fas fa-chart-pie"></i> View Class Report
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const gradingScale = <?php echo json_encode($grading_scale_js); ?>;
const examId = <?php echo $exam_id; ?>;
const maxMarks = <?php echo $exam['max_marks']; ?>;

// Create Toast status indicator
const toastNode = document.createElement('div');
toastNode.style.position = 'fixed';
toastNode.style.bottom = '20px';
toastNode.style.right = '20px';
toastNode.style.padding = '12px 24px';
toastNode.style.background = '#1e293b';
toastNode.style.color = '#fff';
toastNode.style.borderRadius = '30px';
toastNode.style.boxShadow = '0 10px 25px rgba(0,0,0,0.25)';
toastNode.style.zIndex = '9999';
toastNode.style.fontSize = '0.9rem';
toastNode.style.fontWeight = 'bold';
toastNode.style.display = 'none';
toastNode.style.alignItems = 'center';
toastNode.style.gap = '10px';
toastNode.style.transition = 'all 0.3s ease';
document.body.appendChild(toastNode);

function showSaveStatus(text, type='info') {
    toastNode.style.display = 'flex';
    if (type === 'saving') {
        toastNode.innerHTML = '<i class="fas fa-circle-notch fa-spin" style="color:#0ea5e9;"></i> <span>' + text + '</span>';
        toastNode.style.background = '#0f172a';
    } else if (type === 'success') {
        toastNode.innerHTML = '<i class="fas fa-check-circle" style="color:#22c55e;"></i> <span>' + text + '</span>';
        toastNode.style.background = '#064e3b';
        setTimeout(() => {
            toastNode.style.display = 'none';
        }, 2200);
    } else {
        toastNode.innerHTML = '<i class="fas fa-exclamation-triangle" style="color:#ef4444;"></i> <span>' + text + '</span>';
        toastNode.style.background = '#7f1d1d';
    }
}

function updateGrade(input, studentId) {
    const marks = parseFloat(input.value);
    let grade = 'F';
    
    if (isNaN(marks)) {
        document.getElementById('grade_' + studentId).textContent = '-';
        return;
    }

    const percentage = (maxMarks > 0) ? (marks / maxMarks) * 100 : 0;

    for (const g of gradingScale) {
        if (percentage >= g.min_marks && percentage <= g.max_marks) {
            grade = g.grade;
            break;
        }
    }
    
    const gradeEl = document.getElementById('grade_' + studentId);
    if (gradeEl) {
        gradeEl.textContent = grade;
        const colors = {'A': '#166534', 'B': '#15803d', 'C': '#b45309', 'D': '#c2410c', 'E': '#b91c1c', 'F': '#991b1b'};
        gradeEl.style.color = colors[grade] || '#8b0000';
    }
}

// Auto-save listeners
document.querySelectorAll('.marks-input').forEach(input => {
    let timeout = null;
    
    input.addEventListener('input', function() {
        const studentId = this.dataset.student;
        updateGrade(this, studentId);
        
        // Debounce auto-save
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            autoSaveMark(studentId, this.value);
        }, 1200);
    });

    input.addEventListener('blur', function() {
        const studentId = this.dataset.student;
        autoSaveMark(studentId, this.value);
    });
});

function autoSaveMark(studentId, marks) {
    if (marks === '') return;
    
    showSaveStatus('Auto-saving...', 'saving');
    
    const formData = new FormData();
    formData.append('exam_id', examId);
    formData.append('student_id', studentId);
    formData.append('marks', marks);
    
    fetch('save-mark-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showSaveStatus('Mark saved!', 'success');
        } else {
            showSaveStatus('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        showSaveStatus('Network error — mark not saved.', 'error');
    });
}

function handleFormSubmit(event) {
    const submitBtn = event.submitter;
    if (submitBtn && submitBtn.name === 'submit_to_admin') {
        const confirmResult = confirm('Are you sure you want to submit these results to the Director of Studies? You will not be able to edit marks until DOS approves.');
        if (!confirmResult) {
            event.preventDefault();
            return false;
        }
    }
    return true;
}
</script>

<?php require_once '../../includes/footer.php'; ?>
