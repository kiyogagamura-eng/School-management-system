<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Parent Communication";

$teacher_id = 0;
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher_id = $stmt->fetchColumn();

// Fetch published exams for this teacher
$stmt = $pdo->prepare("
    SELECT e.exam_id, e.exam_name, c.class_name, s.subject_name 
    FROM exams e
    JOIN classes c ON e.class_id = c.class_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.teacher_id = ? AND e.is_published = 1
    ORDER BY e.created_at DESC
");
$stmt->execute([$teacher_id]);
$published_exams = $stmt->fetchAll();

$exam_id = $_GET['exam_id'] ?? ($published_exams[0]['exam_id'] ?? 0);

$struggling_students = [];
$exam_details = null;
$success = '';
$error = '';

if ($exam_id) {
    // Fetch exam details to verify ownership and get pass marks
    $stmt = $pdo->prepare("SELECT e.*, c.class_name, s.subject_name FROM exams e JOIN classes c ON e.class_id = c.class_id JOIN subjects s ON e.subject_id = s.subject_id WHERE e.exam_id = ? AND e.teacher_id = ?");
    $stmt->execute([$exam_id, $teacher_id]);
    $exam_details = $stmt->fetch();

    if ($exam_details) {
        // Fetch students who failed or whose marks are below a certain threshold
        $stmt = $pdo->prepare("
            SELECT r.*, st.first_name, st.last_name, st.admission_number, st.parent_name, st.parent_phone 
            FROM results r
            JOIN students st ON r.student_id = st.student_id
            WHERE r.exam_id = ? AND r.marks_obtained < ?
            ORDER BY r.marks_obtained ASC
        ");
        $stmt->execute([$exam_id, $exam_details['pass_marks']]);
        $struggling_students = $stmt->fetchAll();
    }
}

// Handle Single SMS
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_single_sms'])) {
    $student_id = (int)$_POST['student_id'];
    $phone = $_POST['parent_phone'];
    $message = trim($_POST['message']);

    if (empty($phone)) {
        $error = "This student does not have a parent phone number registered.";
    } elseif (empty($message)) {
        $error = "Message cannot be empty.";
    } else {
        if (sendSMS($phone, $message)) {
            // Log message
            $stmt = $pdo->prepare("INSERT INTO teacher_parent_messages (teacher_id, student_id, parent_phone, message, message_type, status) VALUES (?, ?, ?, ?, 'sms', 'sent')");
            $stmt->execute([$teacher_id, $student_id, $phone, $message]);
            $success = "Message sent successfully!";
        } else {
            $error = "Failed to send message. Please check the SMS gateway connection.";
        }
    }
}

// Handle Bulk SMS to all struggling students
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_bulk_sms'])) {
    $template = trim($_POST['bulk_message']);
    
    if (empty($template)) {
        $error = "Message template cannot be empty.";
    } elseif (empty($struggling_students)) {
        $error = "No students in the challenge list to send messages to.";
    } else {
        $sent_count = 0;
        $failed_count = 0;
        
        $log_stmt = $pdo->prepare("INSERT INTO teacher_parent_messages (teacher_id, student_id, parent_phone, message, message_type, status) VALUES (?, ?, ?, ?, 'sms', 'sent')");
        
        foreach ($struggling_students as $s) {
            if (empty($s['parent_phone'])) {
                $failed_count++;
                continue;
            }
            
            // Render template variables
            $msg = str_replace('[NAME]', $s['first_name'], $template);
            $msg = str_replace('[MARKS]', $s['marks_obtained'], $msg);
            $msg = str_replace('[GRADE]', $s['grade'], $msg);
            
            if (sendSMS($s['parent_phone'], $msg)) {
                $log_stmt->execute([$teacher_id, $s['student_id'], $s['parent_phone'], $msg]);
                $sent_count++;
            } else {
                $failed_count++;
            }
        }
        
        if ($sent_count > 0) {
            $success = "Successfully sent messages to $sent_count parents.";
            if ($failed_count > 0) $success .= " ($failed_count failed/missing numbers).";
        } else {
            $error = "Failed to send any messages. Make sure numbers are valid.";
        }
    }
}

// Fetch message history for this teacher
$stmt = $pdo->prepare("
    SELECT m.*, s.first_name, s.last_name, s.admission_number 
    FROM teacher_parent_messages m
    JOIN students s ON m.student_id = s.student_id
    WHERE m.teacher_id = ?
    ORDER BY m.created_at DESC
    LIMIT 20
");
$stmt->execute([$teacher_id]);
$message_history = $stmt->fetchAll();
?>
<?php require_once '../../includes/header.php'; ?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <header class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-comments"></i> <?php echo $page_title; ?></h2>
                <p style="color: var(--secondary-text); margin-top: 5px;">Communicate with your students' parents via SMS.</p>
            </div>
            
            <form action="" method="GET" style="display: flex; gap: 10px; align-items: center;">
                <label style="font-weight: 700; color: white;">Select Exam:</label>
                <select name="exam_id" class="form-control" onchange="this.form.submit()" style="min-width: 250px;">
                    <option value="">-- Choose Exam --</option>
                    <?php 
                    // Group exams using standard categories from helper
                    $standard_groups = getStandardExamNames();
                    $grouped_parent_exams = [];
                    
                    // Categorize exams based on keywords in their names
                    foreach ($published_exams as $e) {
                        $exam_name_lower = strtolower($e['exam_name']);
                        $categorized = false;
                        
                        foreach ($standard_groups as $category => $keywords) {
                            foreach ($keywords as $keyword) {
                                if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                    $grouped_parent_exams[$category][] = $e;
                                    $categorized = true;
                                    break 2;
                                }
                            }
                        }
                        
                        // If not categorized, put in "Other Assessments"
                        if (!$categorized) {
                            $grouped_parent_exams['Other Assessments'][] = $e;
                        }
                    }
                    
                    // Display grouped options
                    foreach ($grouped_parent_exams as $label => $group): ?>
                        <optgroup label="<?php echo $label; ?>">
                            <?php foreach ($group as $e): ?>
                                <option value="<?php echo $e['exam_id']; ?>" <?php echo $e['exam_id'] == $exam_id ? 'selected' : ''; ?>>
                                    <?php echo h($e['exam_name'] . ' (' . $e['class_name'] . ' - ' . $e['subject_name'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
    </header>

    <?php if ($success): ?>
        <div style="background: #fff5f5; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000; font-weight: 700;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div style="background: #f8fafc; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000; font-weight: 700;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <?php if (!$exam_id): ?>
        <div class="card" style="text-align: center; padding: 50px;">
            <i class="fas fa-envelope-open-text" style="font-size: 4rem; color: #ccc; margin-bottom: 20px;"></i>
            <h3>No Exam Selected</h3>
            <p style="color: var(--secondary-text);">Please select a published exam to see the list of students who need academic attention.</p>
        </div>
    <?php else: ?>

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 30px;">
            
            <!-- Struggling Students List -->
            <div class="card shadow-premium">
                <div class="card-header" style="background: #940000; color: white; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px;">
                    <span style="font-weight: 800;"><i class="fas fa-exclamation-triangle"></i> Students Needing Attention (Below <?php echo $exam_details['pass_marks']; ?>)</span>
                    <span class="badge" style="background: white; color: #940000; font-weight: 900;"><?php echo count($struggling_students); ?></span>
                </div>
                <div class="card-body" style="padding: 0;">
                    <?php if (empty($struggling_students)): ?>
                        <div style="padding: 30px; text-align: center; color: #940000; font-weight: 700;">
                            <i class="fas fa-check-circle" style="font-size: 2rem; margin-bottom: 10px;"></i><br>
                            EXCELLENT! No students failed this exam.
                        </div>
                    <?php else: ?>
                        <table class="table" style="margin: 0;">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Marks</th>
                                    <th>Parent Contact</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($struggling_students as $s): ?>
                                    <tr>
                                        <td>
                                            <div style="font-weight: 700;"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?></div>
                                            <div style="font-size: 0.8rem; color: #888;"><?php echo h($s['admission_number']); ?></div>
                                        </td>
                                        <td>
                                            <span style="font-weight: 900; color: #940000;"><?php echo $s['marks_obtained']; ?></span>
                                            <span style="font-size: 0.8rem; color: #64748b; font-weight: 700;">(<?php echo $s['grade']; ?>)</span>
                                        </td>
                                        <td>
                                            <?php if ($s['parent_phone']): ?>
                                                <div><?php echo h($s['parent_name'] ?: 'Parent'); ?></div>
                                                <div style="font-size: 0.85rem; color: #2980b9; font-family: monospace;"><?php echo h($s['parent_phone']); ?></div>
                                            <?php else: ?>
                                                <span class="badge" style="background: #f1f2f6; color: #a4b0be;">No Contact</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($s['parent_phone']): ?>
                                                <button class="btn btn-outline" style="border-color: #940000; color: #940000; padding: 4px 10px; font-size: 0.8rem; font-weight: 800;" 
                                                    onclick="openSingleSmsModal(<?php echo htmlspecialchars(json_encode($s)); ?>)">
                                                    <i class="fas fa-paper-plane"></i> MESSAGE
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-outline" disabled style="padding: 4px 10px; font-size: 0.8rem; opacity: 0.5;">Message</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Bulk SMS Form -->
            <div class="card shadow-premium" style="align-self: start;">
                <div class="card-header"><i class="fas fa-bullhorn"></i> Send Bulk Message</div>
                <div class="card-body">
                    <p style="font-size: 0.85rem; color: #666; margin-bottom: 15px;">
                        Send a single message to all parents of students in the list. Use placeholders to personalize:
                    </p>
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 5px; font-size: 0.8rem; font-family: monospace; margin-bottom: 15px;">
                        [NAME] = Student's First Name<br>
                        [MARKS] = Student's Marks<br>
                        [GRADE] = Student's Grade
                    </div>
                    <form action="" method="POST" onsubmit="return confirm('Are you sure you want to send this message to all <?php echo count($struggling_students); ?> parents? This will consume SMS credits.')">
                        <div class="form-group">
                            <label>Message Content:</label>
                            <textarea name="bulk_message" class="form-control" rows="5" required placeholder="e.g., Hello Parent. We want to inform you that [NAME] got [MARKS] marks in the exam..."></textarea>
                            <small style="color: #999;" id="bulkCharCount">160 chars = 1 SMS</small>
                        </div>
                        <button type="submit" name="send_bulk_sms" class="btn btn-primary" style="width: 100%; background: #940000; border: none; padding: 12px; font-weight: 800; border-radius: 50px; box-shadow: 0 5px 15px rgba(148,0,0,0.2);" <?php echo empty($struggling_students) ? 'disabled' : ''; ?>>
                            <i class="fas fa-paper-plane"></i> SEND TO ALL PARENTS
                        </button>
                    </form>
                </div>
            </div>
        </div>

    <?php endif; ?>

    <!-- Message History -->
    <div class="card">
        <div class="card-header"><i class="fas fa-history"></i> Recent Messages Sent</div>
        <div class="card-body" style="padding: 0;">
            <table class="table" style="margin: 0;">
                <thead>
                    <tr>
                        <th style="width: 150px;">Date & Time</th>
                        <th style="width: 150px;">Student</th>
                        <th style="width: 120px;">Phone</th>
                        <th>Message Content</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($message_history)): ?>
                        <tr><td colspan="4" style="text-align: center; color: #999; padding: 20px;">No messages sent recently.</td></tr>
                    <?php else: ?>
                        <?php foreach ($message_history as $msg): ?>
                            <tr>
                                <td style="font-size: 0.85rem; color: #666;"><?php echo date('d M Y, H:i', strtotime($msg['created_at'])); ?></td>
                                <td><?php echo h($msg['first_name'] . ' ' . $msg['last_name']); ?></td>
                                <td style="font-family: monospace; font-size: 0.85rem;"><?php echo h($msg['parent_phone']); ?></td>
                                <td style="font-size: 0.9rem; color: #444;"><?php echo nl2br(h($msg['message'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Single SMS Modal -->
<div id="singleSmsModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
    <div class="card" style="width: 400px; margin: 100px auto; animation: fadeIn 0.3s;">
        <div class="card-header" style="display: flex; justify-content: space-between;">
            <span><i class="fas fa-envelope"></i> Message Parent</span>
            <span style="cursor: pointer;" onclick="document.getElementById('singleSmsModal').style.display='none'">&times;</span>
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <input type="hidden" name="student_id" id="sms_student_id">
                <input type="hidden" name="parent_phone" id="sms_parent_phone">
                
                <div style="margin-bottom: 15px; background: #f8f9fa; padding: 10px; border-radius: 5px;">
                    <div style="font-size: 0.8rem; color: #666;">To: <strong id="sms_parent_name"></strong></div>
                    <div style="font-size: 0.8rem; color: #666;">Student: <strong id="sms_student_name"></strong></div>
                    <div style="font-size: 0.8rem; color: #666;">Phone: <strong id="sms_phone_display" style="font-family: monospace;"></strong></div>
                </div>
                
                <div class="form-group">
                    <label>Message Content:</label>
                    <textarea name="message" id="single_message" class="form-control" rows="4" required></textarea>
                </div>
                
                <button type="submit" name="send_single_sms" class="btn btn-primary" style="width: 100%;">
                    <i class="fas fa-paper-plane"></i> SEND MESSAGE
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function openSingleSmsModal(student) {
    document.getElementById('sms_student_id').value = student.student_id;
    document.getElementById('sms_parent_phone').value = student.parent_phone;
    document.getElementById('sms_parent_name').textContent = student.parent_name || 'Parent';
    document.getElementById('sms_student_name').textContent = student.first_name + ' ' + student.last_name;
    document.getElementById('sms_phone_display').textContent = student.parent_phone;
    
    // Auto populate template
    const marks = student.marks_obtained;
    const grade = student.grade;
    const subj = '<?php echo $exam_details ? addslashes($exam_details['subject_name']) : ''; ?>';
    
    const defaultMsg = `Hello. Student ${student.first_name} scored ${marks} (${grade}) in ${subj}. More effort is needed. Please follow up.`;
    document.getElementById('single_message').value = defaultMsg;
    
    document.getElementById('singleSmsModal').style.display = 'block';
}

// Character counter for bulk
document.querySelector('textarea[name="bulk_message"]').addEventListener('input', function(e) {
    const len = e.target.value.length;
    let smsCount = Math.ceil(len / 160);
    if(smsCount === 0) smsCount = 1;
    document.getElementById('bulkCharCount').textContent = `${len} chars = ${smsCount} SMS`;
});
</script>

<?php require_once '../../includes/footer.php'; ?>
