<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');
require_once '../../includes/exam_names_helper.php'; // Added for exam name dropdown

$page_title = "Manage Exams";

$teacher_id = 0;
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher_id = $stmt->fetchColumn();

// Fetch active term
$term = getCurrentTerm();

$success = '';
$error = '';

// Handle Exam Creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_exam'])) {
    // Get exam name - use custom if provided, otherwise use dropdown
    $exam_name_dropdown = trim($_POST['exam_name']);
    $exam_name_custom = trim($_POST['exam_name_custom']);
    $exam_name = !empty($exam_name_custom) ? $exam_name_custom : $exam_name_dropdown;
    
    $exam_type = $_POST['exam_type'];
    if (isset($_POST['subject_class'])) {
        list($class_id, $subject_id) = explode('|', $_POST['subject_class']);
    } else {
        $class_id = $_POST['class_id'];
        $subject_id = $_POST['subject_id'];
    }
    $exam_date = $_POST['exam_date'];
    $max_marks = $_POST['max_marks'];
    $pass_marks = $_POST['pass_marks'];
    $weightage = $_POST['weightage'] ?? 100;
    $description = trim($_POST['exam_description']);
    
    // Add current year to exam name if not already present
    $current_year = date('Y');
    if (strpos($exam_name, $current_year) === false) {
        $exam_name = $exam_name . ' ' . $current_year;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO exams (exam_name, exam_type, class_id, subject_id, teacher_id, exam_date, max_marks, pass_marks, weightage, exam_description, term_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$exam_name, $exam_type, $class_id, $subject_id, $teacher_id, $exam_date, $max_marks, $pass_marks, $weightage, $description, $term['term_id']]);
        $success = "Exam created successfully. You can now enter marks.";
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Handle Exam Edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_exam'])) {
    $edit_id = (int)$_POST['edit_exam_id'];
    $exam_name = trim($_POST['edit_exam_name']); // Takes value from input (which can be from dropdown or custom)
    $exam_type = $_POST['edit_exam_type'];
    $exam_date = $_POST['edit_exam_date'];
    $max_marks = $_POST['edit_max_marks'];
    $pass_marks = $_POST['edit_pass_marks'];
    $weightage = $_POST['edit_weightage'];
    $description = trim($_POST['edit_exam_description']);

    try {
        // Only allow editing unpublished exams
        $stmt = $pdo->prepare("UPDATE exams SET exam_name = ?, exam_type = ?, exam_date = ?, max_marks = ?, pass_marks = ?, weightage = ?, exam_description = ? WHERE exam_id = ? AND teacher_id = ? AND is_published = 0");
        $stmt->execute([$exam_name, $exam_type, $exam_date, $max_marks, $pass_marks, $weightage, $description, $edit_id, $teacher_id]);
        $success = "Exam updated successfully!";
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Handle Exam Delete
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_exam'])) {
    $del_id = (int)$_POST['delete_exam_id'];
    
    // Check if exam has results
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM results WHERE exam_id = ?");
    $stmt->execute([$del_id]);
    $has_results = $stmt->fetchColumn() > 0;
    
    if ($has_results) {
        $error = "You cannot delete an exam that has marks entered. Please delete the marks first.";
    } else {
        try {
            $stmt = $pdo->prepare("DELETE FROM exams WHERE exam_id = ? AND teacher_id = ?");
            $stmt->execute([$del_id, $teacher_id]);
            $success = "Exam deleted successfully.";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Handle Submit to Admin
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['publish_exam'])) {
    $pub_id = (int)$_POST['publish_exam_id'];
    
    try {
        $pdo->beginTransaction();
        
        // Update results status to submitted
        $stmt = $pdo->prepare("UPDATE results SET status = 'submitted' WHERE exam_id = ? AND status = 'draft'");
        $stmt->execute([$pub_id]);
        
        // Mark exam as submitted (using is_published=1 to indicate teacher submission)
        $stmt = $pdo->prepare("UPDATE exams SET is_published = 1, publish_date = NOW() WHERE exam_id = ?");
        $stmt->execute([$pub_id]);
        
        $pdo->commit();
        $success = "Results submitted to administration successfully!";
        
        logActivity($_SESSION['user_id'], 'Submitted Results', "Teacher submitted exam ID $pub_id to Admin.");
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch existing exams for this teacher with result counts
try {
    $stmt = $pdo->prepare("
        SELECT e.*, c.class_name, s.subject_name,
            (SELECT COUNT(*) FROM results r WHERE r.exam_id = e.exam_id) as result_count,
            (SELECT AVG(r.marks_obtained) FROM results r WHERE r.exam_id = e.exam_id) as avg_marks,
            (SELECT COUNT(*) FROM students st WHERE st.class_id = e.class_id AND st.status = 'Active') as total_students
        FROM exams e
        JOIN classes c ON e.class_id = c.class_id
        JOIN subjects s ON e.subject_id = s.subject_id
        WHERE e.teacher_id = ? 
          AND EXISTS (
              SELECT 1 FROM class_subjects cs 
              WHERE cs.teacher_id = e.teacher_id 
                AND cs.class_id = e.class_id 
                AND cs.subject_id = e.subject_id
          )
        ORDER BY c.form_level ASC, c.stream ASC, e.created_at DESC
    ");
    $stmt->execute([$teacher_id]);
    $exams = $stmt->fetchAll();
} catch (PDOException $e) {
    $exams = [];
}

// Group exams by class
$exams_by_class = [];
foreach ($exams as $e) {
    $exams_by_class[$e['class_name']][] = $e;
}

// Fetch assigned subjects
$stmt = $pdo->prepare("SELECT cs.*, c.class_name, s.subject_name FROM class_subjects cs JOIN classes c ON cs.class_id = c.class_id JOIN subjects s ON cs.subject_id = s.subject_id WHERE cs.teacher_id = ?");
$stmt->execute([$teacher_id]);
$my_subjects = $stmt->fetchAll();

// Group subjects by class for dynamic select dropdowns
$class_to_subjects = [];
$my_classes = [];
foreach ($my_subjects as $s) {
    $my_classes[$s['class_id']] = $s['class_name'];
    $class_to_subjects[$s['class_id']][] = [
        'subject_id' => $s['subject_id'],
        'subject_name' => $s['subject_name']
    ];
}

// Summary counts
$total_exams = count($exams);
$published_count = 0; // mapped to 'submitted' for teacher
$draft_count = 0;
foreach ($exams as $e) {
    if ($e['is_published']) $published_count++;
    else $draft_count++;
}
?>
<?php
require_once '../../includes/header.php';
?>
<style>
    /* Premium Exam Dashboard Styles */
    .dashboard-container { padding: 25px 35px; background: #fdfdfd; min-height: 100vh; }
    
    /* Header */
    .exam-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    .exam-header-title h1 { font-size: 1.4rem; color: var(--corporate-red); font-weight: 800; margin: 0 0 5px 0; }
    .exam-header-title p { font-size: 0.85rem; color: var(--secondary-text); margin: 0; }
    .btn-new-exam { background: var(--corporate-red); color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 700; font-size: 0.85rem; cursor: pointer; transition: background 0.2s; }
    .btn-new-exam:hover { background: #7a0000; }

    /* Stats Cards */
    .stats-row { display: flex; gap: 15px; margin-bottom: 30px; }
    .stat-card-premium { flex: 1; background: white; border: 1px solid rgba(0,0,0,0.05); border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); }
    .stat-icon { width: 45px; height: 45px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; }
    .stat-icon.red { background: #fff5f5; color: #940000; }
    .stat-icon.orange { background: #f8fafc; color: #64748b; }
    .stat-icon.blue { background: #f8fafc; color: #64748b; }
    .stat-icon.green { background: #940000; color: #fff; }
    .stat-icon.purple { background: #f1f5f9; color: #475569; }
    .stat-details .stat-num { font-size: 1.6rem; font-weight: 800; color: var(--primary-text); line-height: 1; }
    .stat-details .stat-label { font-size: 0.75rem; color: var(--secondary-text); font-weight: 600; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }

    /* Filters */
    .filters-row { display: flex; gap: 15px; margin-bottom: 30px; align-items: center; }
    .filter-group { display: flex; flex-direction: column; gap: 5px; flex: 1; max-width: 200px; }
    .filter-group label { font-size: 0.75rem; color: var(--secondary-text); font-weight: 600; }
    .filter-group select { padding: 8px 12px; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 0.85rem; color: var(--primary-text); outline: none; }
    .search-box { margin-left: auto; position: relative; }
    .search-box input { padding: 8px 15px 8px 35px; border: 1px solid #e0e0e0; border-radius: 20px; font-size: 0.85rem; width: 250px; outline: none; }
    .search-box i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #aaa; font-size: 0.85rem; }

    /* Class Grouping */
    .class-exam-group { margin-bottom: 35px; }
    .class-group-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; margin-bottom: 15px; }
    .class-group-title { font-size: 1.1rem; font-weight: 800; color: var(--corporate-red); display: flex; align-items: center; gap: 10px; }
    .class-group-title span { font-size: 0.75rem; background: #f5f5f5; color: var(--secondary-text); padding: 3px 8px; border-radius: 12px; font-weight: 600; }
    .class-group-students { font-size: 0.85rem; color: #1976d2; font-weight: 600; }

    /* Exam Table */
    .exam-table { width: 100%; border-collapse: collapse; }
    .exam-table th { text-align: left; padding: 12px 15px; font-size: 0.75rem; color: var(--corporate-red); font-weight: 700; background: #fffafaf0; border-bottom: 1px solid rgba(148,0,0,0.1); text-transform: none; }
    .exam-table td { padding: 15px; font-size: 0.85rem; border-bottom: 1px solid #f5f5f5; vertical-align: middle; color: var(--primary-text); }
    .exam-table tr:hover td { background: #fdfdfd; }
    
    .exam-name { font-weight: 700; color: var(--primary-text); }
    
    /* Progress Bar */
    .progress-cell { width: 120px; }
    .progress-text { display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 4px; font-weight: 600; color: var(--secondary-text); }
    .progress-bar-bg { width: 100%; height: 6px; background: #eee; border-radius: 3px; overflow: hidden; }
    .progress-bar-fill { height: 100%; background: #64748b; border-radius: 3px; }
    .progress-bar-fill.complete { background: #940000; }

    /* Badges */
    .status-badge { padding: 4px 10px; border-radius: 4px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; border: 1px solid; }
    .status-badge.draft { color: #64748b; border-color: #cbd5e1; background: #f8fafc; }
    .status-badge.submitted { color: #940000; border-color: #fecaca; background: #fff5f5; }

    /* Action Buttons */
    .action-cell { display: flex; gap: 8px; align-items: center; justify-content: flex-end; }
    .btn-action-enter { border: 1px solid #940000; color: #940000; background: transparent; padding: 6px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; text-decoration: none; transition: all 0.2s; }
    .btn-action-enter:hover { background: #fff5f5; }
    .btn-action-menu { border: 1px solid #e0e0e0; color: var(--secondary-text); background: transparent; padding: 6px 10px; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
    .btn-action-menu:hover { background: #f5f5f5; color: var(--primary-text); }

    /* Workflow Diagram */
    .workflow-section { background: white; border: 1px solid #f0f0f0; border-radius: 12px; padding: 25px; margin-top: 40px; display: flex; justify-content: space-between; align-items: center; }
    .workflow-title { font-size: 0.75rem; color: var(--secondary-text); font-weight: 800; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; }
    .workflow-steps { display: flex; align-items: center; gap: 15px; }
    .w-step { display: flex; align-items: center; gap: 10px; }
    .w-icon { width: 35px; height: 35px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1rem; }
    .w-icon.draft { background: #f8fafc; color: #64748b; }
    .w-icon.submitted { background: #fff5f5; color: #940000; }
    .w-icon.approved { background: #940000; color: #fff; }
    .w-icon.published { background: #475569; color: #fff; }
    .w-text h4 { margin: 0; font-size: 0.85rem; color: var(--primary-text); font-weight: 700; }
    .w-text p { margin: 2px 0 0 0; font-size: 0.7rem; color: var(--secondary-text); max-width: 120px; line-height: 1.3; }
    .w-arrow { color: #ccc; font-size: 1rem; margin: 0 10px; }
    
    .help-box { background: #fff5f5; border: 1px solid #ffebee; padding: 15px 20px; border-radius: 8px; display: flex; align-items: center; gap: 15px; max-width: 250px; }
    .help-box i { color: #d32f2f; font-size: 1.5rem; }
    .help-box h4 { margin: 0; font-size: 0.85rem; color: #d32f2f; font-weight: 700; }
    .help-box p { margin: 2px 0 0 0; font-size: 0.7rem; color: #d32f2f; opacity: 0.8; line-height: 1.3; }

    /* Dropdown Menu for Actions */
    .dropdown-content { display: none; position: absolute; right: 0; background-color: #fff; min-width: 150px; box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.1); z-index: 1; border-radius: 8px; border: 1px solid #f0f0f0; overflow: hidden; }
    .dropdown-content a, .dropdown-content button { color: var(--primary-text); padding: 10px 15px; text-decoration: none; display: block; font-size: 0.8rem; border: none; background: none; width: 100%; text-align: left; cursor: pointer; font-family: inherit; }
    .dropdown-content a:hover, .dropdown-content button:hover { background-color: #f5f5f5; }
    .dropdown-content .text-red { color: #d32f2f; }
    .action-dropdown { position: relative; display: inline-block; }
</style>

<div class="dashboard-container">
    <!-- Header -->
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <div class="exam-header-title">
            <h1><i class="fas fa-clipboard-list"></i> Manage Exams</h1>
            <p style="color: var(--secondary-text); margin-top: 5px;">Create, manage, and publish exams and student results.</p>
        </div>
        <button class="btn-new-exam" onclick="document.getElementById('addExamModal').style.display='block'">
            <i class="fas fa-plus"></i> New Exam
        </button>
    </div>

    <?php if ($success): ?>
        <div style="background: #fff5f5; color: #940000; padding: 12px 15px; border-radius: 8px; margin-bottom: 20px; font-size: 0.85rem; font-weight: 600;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div style="background: #f8fafc; color: #940000; padding: 12px 15px; border-radius: 8px; margin-bottom: 20px; font-size: 0.85rem; font-weight: 600;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Stats Row -->
    <div class="stats-row">
        <div class="stat-card-premium">
            <div class="stat-icon red"><i class="fas fa-clipboard-list"></i></div>
            <div class="stat-details">
                <div class="stat-num"><?php echo $total_exams; ?></div>
                <div class="stat-label">Total Exams</div>
            </div>
        </div>
        <div class="stat-card-premium">
            <div class="stat-icon orange"><i class="fas fa-file-alt"></i></div>
            <div class="stat-details">
                <div class="stat-num"><?php echo $draft_count; ?></div>
                <div class="stat-label">Drafts</div>
            </div>
        </div>
        <div class="stat-card-premium">
            <div class="stat-icon blue"><i class="fas fa-paper-plane"></i></div>
            <div class="stat-details">
                <div class="stat-num"><?php echo $published_count; ?></div>
                <div class="stat-label">Submitted</div>
            </div>
        </div>
        <div class="stat-card-premium">
            <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
            <div class="stat-details">
                <div class="stat-num">0</div>
                <div class="stat-label">Approved</div>
            </div>
        </div>
        <div class="stat-card-premium">
            <div class="stat-icon purple"><i class="fas fa-globe"></i></div>
            <div class="stat-details">
                <div class="stat-num">0</div>
                <div class="stat-label">Published</div>
            </div>
        </div>
    </div>

    <?php
    $filter_classes = [];
    $filter_subjects = [];
    foreach ($my_subjects as $s) {
        if (!in_array($s['class_name'], $filter_classes)) $filter_classes[] = $s['class_name'];
        if (!in_array($s['subject_name'], $filter_subjects)) $filter_subjects[] = $s['subject_name'];
    }
    sort($filter_classes);
    sort($filter_subjects);
    ?>
    <!-- Filters -->
    <div class="filters-row">
        <div class="filter-group">
            <label>Filter by Class</label>
            <select id="filter_class" onchange="filterExams()">
                <option value="">All Classes</option>
                <?php foreach($filter_classes as $fc): ?>
                    <option value="<?php echo h($fc); ?>"><?php echo h($fc); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Filter by Subject</label>
            <select id="filter_subject" onchange="filterExams()">
                <option value="">All Subjects</option>
                <?php foreach($filter_subjects as $fs): ?>
                    <option value="<?php echo h($fs); ?>"><?php echo h($fs); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Filter by Status</label>
            <select id="filter_status" onchange="filterExams()">
                <option value="">All Statuses</option>
                <option value="draft">Draft</option>
                <option value="submitted">Submitted</option>
            </select>
        </div>
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="filter_search" placeholder="Search exam..." onkeyup="filterExams()">
        </div>
    </div>

    <!-- Exam Lists Grouped By Class -->
    <?php if (empty($exams_by_class)): ?>
        <div style="text-align: center; padding: 50px; background: white; border-radius: 12px; border: 1px solid #f0f0f0;">
            <i class="fas fa-clipboard" style="font-size: 3rem; color: #ddd; margin-bottom: 15px;"></i>
            <h3 style="color: var(--secondary-text); margin: 0;">No exams created yet.</h3>
            <p style="color: #aaa; font-size: 0.85rem; margin-top: 5px;">Click "New Exam" to get started.</p>
        </div>
    <?php else: ?>
        <?php foreach ($exams_by_class as $class_name => $class_exams): ?>
            <?php $first_exam = $class_exams[0]; // To get total students ?>
            <div class="class-exam-group">
                <div class="class-group-header">
                    <div class="class-group-title">
                        <?php echo h($class_name); ?> <span><?php echo count($class_exams); ?> Exams</span>
                    </div>
                    <div class="class-group-students"><?php echo $first_exam['total_students']; ?> Students</div>
                </div>
                
                <table class="exam-table">
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th style="width: 200px;">Exam Name</th>
                            <th>Subject</th>
                            <th>Type</th>
                            <th>Max Marks</th>
                            <th style="text-align: center;">Students</th>
                            <th>Progress</th>
                            <th>Status</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($class_exams as $e): ?>
                            <?php 
                                $total = $e['total_students'];
                                $entered = $e['result_count'];
                                $percent = $total > 0 ? round(($entered / $total) * 100) : 0;
                            ?>
                            <tr>
                                <td style="color: var(--secondary-text);"><?php echo $i++; ?></td>
                                <td class="exam-name"><?php echo h($e['exam_name']); ?></td>
                                <td><?php echo h($e['subject_name']); ?></td>
                                <td style="text-transform: capitalize;"><?php echo h($e['exam_type']); ?></td>
                                <td><?php echo $e['max_marks']; ?></td>
                                <td style="text-align: center; font-weight: 600;"><?php echo $total; ?></td>
                                <td class="progress-cell">
                                    <div class="progress-text">
                                        <span style="color: <?php echo $entered == $total && $total > 0 ? '#940000' : '#64748b'; ?>"><?php echo $entered; ?>/<?php echo $total; ?></span>
                                        <span><?php echo $percent; ?>%</span>
                                    </div>
                                    <div class="progress-bar-bg">
                                        <div class="progress-bar-fill <?php echo $percent == 100 ? 'complete' : ''; ?>" style="width: <?php echo $percent; ?>%;"></div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($e['is_published']): ?>
                                        <span class="status-badge submitted">SUBMITTED</span>
                                    <?php else: ?>
                                        <span class="status-badge draft">DRAFT</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-cell">
                                        <?php if ($e['is_published']): ?>
                                            <a href="enter-marks.php?id=<?php echo $e['exam_id']; ?>" class="btn-action-enter" style="border-color: #64748b; color: #64748b;">
                                                <i class="fas fa-eye"></i> View Marks
                                            </a>
                                        <?php else: ?>
                                            <a href="enter-marks.php?id=<?php echo $e['exam_id']; ?>" class="btn-action-enter">
                                                <i class="fas fa-edit"></i> Enter Marks
                                            </a>
                                        <?php endif; ?>
                                        <div class="action-dropdown">
                                            <button class="btn-action-menu" onclick="toggleDropdown('dropdown-<?php echo $e['exam_id']; ?>')"><i class="fas fa-ellipsis-h"></i></button>
                                            <div id="dropdown-<?php echo $e['exam_id']; ?>" class="dropdown-content">
                                                <?php if ($e['result_count'] > 0): ?>
                                                    <a href="statistics.php?exam_id=<?php echo $e['exam_id']; ?>"><i class="fas fa-chart-bar"></i> View Statistics</a>
                                                <?php endif; ?>
                                                <?php if (!$e['is_published']): ?>
                                                    <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($e)); ?>)"><i class="fas fa-pen"></i> Edit Exam</button>
                                                    <?php if ($e['result_count'] > 0 && $percent == 100): ?>
                                                        <button onclick="openPublishModal(<?php echo $e['exam_id']; ?>, '<?php echo h(addslashes($e['exam_name'])); ?>')"><i class="fas fa-paper-plane"></i> Submit to Admin</button>
                                                    <?php endif; ?>
                                                    <?php if ($e['result_count'] == 0): ?>
                                                        <form method="POST" onsubmit="return confirm('Delete this exam?')">
                                                            <input type="hidden" name="delete_exam_id" value="<?php echo $e['exam_id']; ?>">
                                                            <button type="submit" name="delete_exam" class="text-red"><i class="fas fa-trash"></i> Delete Exam</button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Workflow Diagram -->
    <div class="workflow-section">
        <div>
            <div class="workflow-title">Exam Workflow</div>
            <div class="workflow-steps">
                <div class="w-step">
                    <div class="w-icon draft"><i class="fas fa-file-alt"></i></div>
                    <div class="w-text">
                        <h4>Draft</h4>
                        <p>Enter marks and save as draft</p>
                    </div>
                </div>
                <i class="fas fa-arrow-right w-arrow"></i>
                <div class="w-step">
                    <div class="w-icon submitted"><i class="fas fa-paper-plane"></i></div>
                    <div class="w-text">
                        <h4>Submitted</h4>
                        <p>Submit results to admin</p>
                    </div>
                </div>
                <i class="fas fa-arrow-right w-arrow"></i>
                <div class="w-step">
                    <div class="w-icon approved"><i class="fas fa-check-circle"></i></div>
                    <div class="w-text">
                        <h4>Approved</h4>
                        <p>Admin reviews and approves</p>
                    </div>
                </div>
                <i class="fas fa-arrow-right w-arrow"></i>
                <div class="w-step">
                    <div class="w-icon published"><i class="fas fa-globe"></i></div>
                    <div class="w-text">
                        <h4>Published</h4>
                        <p>Results visible to students</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="help-box">
            <i class="fas fa-question-circle"></i>
            <div>
                <h4>Need Help?</h4>
                <p>Make sure to submit results after entering all marks.</p>
            </div>
        </div>
    </div>
</div>

<script>
// Filter Exams Function
function filterExams() {
    let fClass = document.getElementById('filter_class').value.toLowerCase();
    let fSubject = document.getElementById('filter_subject').value.toLowerCase();
    let fStatus = document.getElementById('filter_status').value.toLowerCase();
    let fSearch = document.getElementById('filter_search').value.toLowerCase();

    let groups = document.querySelectorAll('.class-exam-group');
    
    groups.forEach(group => {
        let groupClass = group.querySelector('.class-group-title').textContent.split(' ')[0].concat(' ', group.querySelector('.class-group-title').textContent.split(' ')[1]).trim().toLowerCase(); // e.g. "form 2a"
        
        let shouldShowGroup = false;
        
        // If class filter is active and doesn't match this group, hide the whole group
        if (fClass && !groupClass.includes(fClass)) {
            group.style.display = 'none';
            return;
        }

        let rows = group.querySelectorAll('.exam-table tbody tr');
        rows.forEach(row => {
            let examName = row.querySelector('.exam-name').textContent.toLowerCase();
            let subject = row.cells[2].textContent.toLowerCase();
            let statusBadge = row.querySelector('.status-badge').textContent.toLowerCase();
            let status = statusBadge.includes('submitted') ? 'submitted' : 'draft';
            
            let matchSearch = examName.includes(fSearch) || subject.includes(fSearch);
            let matchSubject = fSubject === '' || subject === fSubject;
            let matchStatus = fStatus === '' || status === fStatus;

            if (matchSearch && matchSubject && matchStatus) {
                row.style.display = '';
                shouldShowGroup = true;
            } else {
                row.style.display = 'none';
            }
        });

        group.style.display = shouldShowGroup ? '' : 'none';
    });
}

// Close dropdowns when clicking outside
window.onclick = function(event) {
    if (!event.target.matches('.btn-action-menu') && !event.target.matches('.btn-action-menu i')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.style.display === 'block') {
                openDropdown.style.display = 'none';
            }
        }
    }
}

function toggleDropdown(id) {
    var dropdown = document.getElementById(id);
    var isDisplayed = dropdown.style.display === 'block';
    
    // Hide all
    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var i = 0; i < dropdowns.length; i++) {
        dropdowns[i].style.display = 'none';
    }
    
    // Toggle current
    if (!isDisplayed) {
        dropdown.style.display = 'block';
    }
    event.stopPropagation();
}

// Ensure old script functions exist
function openEditModal(exam) {
    document.getElementById('edit_exam_id').value = exam.exam_id;
    document.getElementById('edit_exam_name').value = exam.exam_name;
    document.getElementById('edit_exam_type').value = exam.exam_type;
    document.getElementById('edit_max_marks').value = exam.max_marks;
    document.getElementById('edit_pass_marks').value = exam.pass_marks;
    document.getElementById('edit_exam_date').value = exam.exam_date;
    document.getElementById('edit_weightage').value = exam.weightage;
    document.getElementById('edit_exam_description').value = exam.exam_description || '';
    document.getElementById('editExamModal').style.display = 'block';
}

// Update exam name when dropdown changes (for edit modal)
function updateEditExamName() {
    var dropdown = document.getElementById('edit_exam_name_dropdown');
    var input = document.getElementById('edit_exam_name');
    if (dropdown.value) {
        input.value = dropdown.value;
    }
}

function openPublishModal(examId, examName) {
    document.getElementById('publish_exam_id').value = examId;
    document.getElementById('publish_exam_name_display').textContent = examName;
    document.getElementById('publishModal').style.display = 'block';
}
</script>

    <!-- Create Exam Modal -->
    <div id="addExamModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
        <div class="card" style="width: 520px; margin: 80px auto; animation: fadeIn 0.3s; max-height: 90vh; overflow-y: auto;">
            <div class="card-header" style="display: flex; justify-content: space-between;">
                <span><i class="fas fa-plus-circle"></i> Create New Exam</span>
                <span style="cursor: pointer;" onclick="document.getElementById('addExamModal').style.display='none'">&times;</span>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label>Exam Name <span class="text-red">*</span></label>
                        <select name="exam_name" class="form-control" required>
                            <?php renderExamNameOptions(); ?>
                        </select>
                        <small style="color: var(--secondary-text); font-size: 0.75rem;">Or type custom name below</small>
                        <input type="text" name="exam_name_custom" class="form-control" style="margin-top: 8px;" placeholder="Custom exam name (optional)">
                    </div>
                    <div class="form-group">
                        <label>Exam Type <span class="text-red">*</span></label>
                        <select name="exam_type" class="form-control" required>
                            <?php renderExamTypeOptions(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Class <span class="text-red">*</span></label>
                        <select name="class_id" id="exam_class_select" class="form-control" required onchange="updateExamSubjects()">
                            <option value="">-- Choose Class --</option>
                            <?php foreach ($my_classes as $cid => $cname): ?>
                                <option value="<?php echo $cid; ?>"><?php echo h($cname); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Subject <span class="text-red">*</span></label>
                        <select name="subject_id" id="exam_subject_select" class="form-control" required>
                            <option value="">-- Choose Subject --</option>
                        </select>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label>Maximum Marks</label>
                            <input type="number" name="max_marks" class="form-control" value="100">
                        </div>
                        <div class="form-group">
                            <label>Pass Marks</label>
                            <input type="number" name="pass_marks" class="form-control" value="40">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Exam Date</label>
                        <input type="date" name="exam_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Weightage (%)</label>
                        <input type="number" name="weightage" class="form-control" value="100" min="1" max="100">
                        <small style="color: var(--secondary-text);">Impact of this exam on the final grade.</small>
                    </div>
                    <div class="form-group">
                        <label>Description (Optional)</label>
                        <textarea name="exam_description" class="form-control" rows="2" placeholder="e.g. Topics 1-5"></textarea>
                    </div>
                    <button type="submit" name="create_exam" class="btn btn-primary" style="width: 100%;"><i class="fas fa-plus"></i> CREATE EXAM</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Exam Modal -->
    <div id="editExamModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
        <div class="card" style="width: 520px; margin: 80px auto; animation: fadeIn 0.3s; max-height: 90vh; overflow-y: auto;">
            <div class="card-header" style="display: flex; justify-content: space-between;">
                <span><i class="fas fa-edit"></i> Edit Exam</span>
                <span style="cursor: pointer;" onclick="document.getElementById('editExamModal').style.display='none'">&times;</span>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <input type="hidden" name="edit_exam_id" id="edit_exam_id">
                    <div class="form-group">
                        <label>Exam Name <span class="text-red">*</span></label>
                        <select name="edit_exam_name_dropdown" id="edit_exam_name_dropdown" class="form-control" onchange="updateEditExamName()">
                            <?php renderExamNameOptions(); ?>
                        </select>
                        <small style="color: var(--secondary-text); font-size: 0.75rem;">Or type custom name below</small>
                        <input type="text" name="edit_exam_name" id="edit_exam_name" class="form-control" style="margin-top: 8px;" placeholder="Custom exam name" required>
                    </div>
                    <div class="form-group">
                        <label>Exam Type <span class="text-red">*</span></label>
                        <select name="edit_exam_type" id="edit_exam_type" class="form-control" required>
                            <?php renderExamTypeOptions(); ?>
                        </select>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label>Maximum Marks</label>
                            <input type="number" name="edit_max_marks" id="edit_max_marks" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Pass Marks</label>
                            <input type="number" name="edit_pass_marks" id="edit_pass_marks" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Exam Date</label>
                        <input type="date" name="edit_exam_date" id="edit_exam_date" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Weightage (%)</label>
                        <input type="number" name="edit_weightage" id="edit_weightage" class="form-control" min="1" max="100">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="edit_exam_description" id="edit_exam_description" class="form-control" rows="2"></textarea>
                    </div>
                    <button type="submit" name="edit_exam" class="btn btn-primary" style="width: 100%;"><i class="fas fa-save"></i> SAVE CHANGES</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Submit Modal -->
    <div id="publishModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
        <div class="card" style="width: 500px; margin: 100px auto; animation: fadeIn 0.3s;">
            <div class="card-header" style="background: #940000; color: white; display: flex; justify-content: space-between;">
                <span><i class="fas fa-paper-plane"></i> Submit Results to Admin</span>
                <span style="cursor: pointer; color: white;" onclick="document.getElementById('publishModal').style.display='none'">&times;</span>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <input type="hidden" name="publish_exam_id" id="publish_exam_id">
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                        <h4 style="margin: 0 0 15px; color: var(--corporate-red);"><i class="fas fa-clipboard-check"></i> Confirmation Checklist</h4>
                        <div id="publish_exam_name_display" style="font-weight: 900; font-size: 1.1rem; margin-bottom: 15px;"></div>
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                            <input type="checkbox" required> All marks have been entered correctly
                        </label>
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                            <input type="checkbox" required> I am ready to submit these results to the administration
                        </label>
                        <p style="font-size: 0.8rem; color: #7f8c8d; margin-top: 15px;">
                            <i class="fas fa-info-circle"></i> Once submitted, the admin will review and compile these marks into the final student report card.
                        </p>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button type="button" class="btn btn-outline" style="flex: 1;" onclick="document.getElementById('publishModal').style.display='none'"><i class="fas fa-times"></i> Cancel</button>
                        <button type="submit" name="publish_exam" class="btn btn-primary" style="flex: 2; background: #940000; border-color: #940000;"><i class="fas fa-paper-plane"></i> SUBMIT TO ADMIN</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<script>
// JSON map of class_id to assigned subjects
const classToSubjects = <?php echo json_encode($class_to_subjects); ?>;

function updateExamSubjects() {
    const classId = document.getElementById('exam_class_select').value;
    const subjectSelect = document.getElementById('exam_subject_select');
    
    // Clear current options
    subjectSelect.innerHTML = '<option value="">-- Choose Subject --</option>';
    
    if (classId && classToSubjects[classId]) {
        classToSubjects[classId].forEach(sub => {
            const opt = document.createElement('option');
            opt.value = sub.subject_id;
            opt.textContent = sub.subject_name;
            subjectSelect.appendChild(opt);
        });
        
        // Auto-select subject if teacher only teaches 1 subject in this class
        if (classToSubjects[classId].length === 1) {
            subjectSelect.value = classToSubjects[classId][0].subject_id;
        }
    }
}

function openEditModal(exam) {
    document.getElementById('edit_exam_id').value = exam.exam_id;
    document.getElementById('edit_exam_name').value = exam.exam_name;
    document.getElementById('edit_exam_type').value = exam.exam_type;
    document.getElementById('edit_max_marks').value = exam.max_marks;
    document.getElementById('edit_pass_marks').value = exam.pass_marks;
    document.getElementById('edit_exam_date').value = exam.exam_date;
    document.getElementById('edit_weightage').value = exam.weightage;
    document.getElementById('edit_exam_description').value = exam.exam_description || '';
    document.getElementById('editExamModal').style.display = 'block';
}

function openPublishModal(examId, examName) {
    document.getElementById('publish_exam_id').value = examId;
    document.getElementById('publish_exam_name_display').textContent = examName;
    document.getElementById('publishModal').style.display = 'block';
}
</script>

<?php require_once '../../includes/footer.php'; ?>
