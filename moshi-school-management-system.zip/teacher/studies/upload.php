<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Upload Study Materials";

$teacher_id = 0;
$stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher_id = $stmt->fetchColumn();

// Fetch assigned classes/subjects
$stmt = $pdo->prepare("
    SELECT cs.*, c.class_name, s.subject_name 
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.teacher_id = ?
");
$stmt->execute([$teacher_id]);
$my_subjects = $stmt->fetchAll();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $subject_class = $_POST['subject_class']; // format: class_id|subject_id
    $material_type = $_POST['material_type'];
    
    if (empty($title) || empty($subject_class) || empty($_FILES['material_file']['name'])) {
        $error = "All required fields must be filled.";
    } else {
        list($class_id, $subject_id) = explode('|', $subject_class);
        
        $file = $_FILES['material_file'];
        $file_name = time() . '_' . basename($file['name']);
        $target_path = "../../assets/uploads/materials/" . $file_name;
        $file_type = strtolower(pathinfo($target_path, PATHINFO_EXTENSION));

        $allowed_types = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'mp4', 'jpg', 'jpeg', 'png'];

        if (!in_array($file_type, $allowed_types)) {
            $error = "Invalid file type. Only documents, images, and videos are allowed.";
        } else {
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                try {
                    $stmt = $pdo->prepare("INSERT INTO study_materials (class_id, subject_id, teacher_id, title, description, file_path, file_type, material_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$class_id, $subject_id, $teacher_id, $title, $description, $file_name, $file_type, $material_type]);
                    $success = "Material uploaded successfully!";
                } catch (PDOException $e) {
                    $error = "Database error: " . $e->getMessage();
                }
            } else {
                $error = "Failed to upload file.";
            }
        }
    }
}
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <div style="margin-bottom: 20px;">
        <a href="index.php" class="btn btn-outline" style="font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Materials</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red); max-width: 800px; margin: 0 auto;">
        <div class="card-header" style="background: var(--header-gradient);">
            <h3 style="margin: 0;"><i class="fas fa-file-upload"></i> <?php echo $page_title; ?></h3>
        </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div style="background: #fff5f5; color: #940000; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #940000;"><?php echo $success; ?></div>
                <?php endif; ?>

                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Material Title <span class="text-red">*</span></label>
                        <input type="text" name="title" class="form-control" required placeholder="e.g. Form 1 Biology - Cell Structure">
                    </div>
                    
                    <div class="form-group">
                        <label>Select Subject/Class <span class="text-red">*</span></label>
                        <select name="subject_class" class="form-control" required>
                            <option value="">-- Choose Target --</option>
                            <?php foreach ($my_subjects as $s): ?>
                                <option value="<?php echo $s['class_id'] . '|' . $s['subject_id']; ?>">
                                    <?php echo h($s['class_name'] . ' - ' . $s['subject_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Material Type <span class="text-red">*</span></label>
                        <select name="material_type" class="form-control" required>
                            <option value="notes">Lecture Notes</option>
                            <option value="assignment">Assignment / HW</option>
                            <option value="reference">Reference Material</option>
                            <option value="video">Video Link/Resource</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>File Upload (PDF, DOC, etc.) <span class="text-red">*</span></label>
                        <input type="file" name="material_file" class="form-control" required style="padding: 10px;">
                        <small style="color: var(--secondary-text);">Max file size: 20MB</small>
                    </div>

                    <div class="form-group">
                        <label>Short Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Explain what this material contains..."></textarea>
                    </div>

                    <div style="margin-top: 30px; display: flex; gap: 15px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1;">UPLOAD MATERIAL</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> <!-- End dashboard-container -->
<?php require_once '../../includes/footer.php'; ?>
