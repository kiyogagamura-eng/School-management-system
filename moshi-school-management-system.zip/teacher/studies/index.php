<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Study Materials";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];

// Recent Materials
$stmt = $pdo->prepare("
    SELECT sm.*, c.class_name, s.subject_name 
    FROM study_materials sm
    JOIN classes c ON sm.class_id = c.class_id
    JOIN subjects s ON sm.subject_id = s.subject_id
    WHERE sm.teacher_id = ? 
    ORDER BY sm.upload_date DESC LIMIT 10
");
$stmt->execute([$teacher_id]);
$recent_materials = $stmt->fetchAll();
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <div class="page-header">
        <div>
            <h1 style="color: var(--corporate-red);"><i class="fas fa-book"></i> Study Materials</h1>
            <p style="color: var(--secondary-text); margin-top: 5px;">Manage resources and notes for your classes.</p>
        </div>
        <a href="upload.php" class="btn btn-primary"><i class="fas fa-upload"></i> Upload Material</a>
    </div>

            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Your Uploaded Materials</h3>
                </div>
                <div class="card-body">
                    <?php if ($recent_materials): ?>
                        <table class="premium-table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Type</th>
                                    <th>Upload Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_materials as $mat): ?>
                                <tr>
                                    <td><b><?php echo h($mat['title']); ?></b></td>
                                    <td><?php echo h($mat['class_name']); ?></td>
                                    <td><?php echo h($mat['subject_name']); ?></td>
                                    <td><?php echo ucfirst($mat['material_type']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($mat['upload_date'])); ?></td>
                                    <td>
                                        <a href="../../<?php echo h($mat['file_path']); ?>" target="_blank" class="btn-mini">Download</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div style="text-align: center; padding: 40px; color: var(--secondary-text);">
                            <i class="fas fa-folder-open fa-3x" style="margin-bottom: 15px; color: #ccc;"></i>
                            <p>You haven't uploaded any study materials yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
    </div> <!-- End dashboard-container -->
<?php require_once '../../includes/footer.php'; ?>
