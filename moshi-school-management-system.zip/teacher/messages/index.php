<?php
require_once '../../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Messages";

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];
?>
<?php
require_once '../../includes/header.php';
?>
<link rel="stylesheet" href="../../assets/css/teacher_dashboard.css">

<div class="dashboard-container">
    <div class="page-header">
        <h1 style="color: var(--corporate-red);"><i class="fas fa-envelope"></i> Messages & Announcements</h1>
        <p style="color: var(--secondary-text); margin-top: 5px;">Communicate with administration and view important notices.</p>
    </div>

            <div class="dashboard-card">
                <div class="card-body" style="text-align: center; padding: 60px 20px;">
                    <i class="fas fa-comments fa-5x" style="color: #e3e3e0; margin-bottom: 20px;"></i>
                    <h2 style="color: var(--primary-text); margin-bottom: 10px;">Messaging Module in Development</h2>
                    <p style="color: var(--secondary-text); max-width: 500px; margin: 0 auto;">The internal messaging system is currently being built. You will soon be able to message parents, students, and administration directly from this panel.</p>
                </div>
            </div>
</div> <!-- End dashboard-container -->
<?php require_once '../../includes/footer.php'; ?>
