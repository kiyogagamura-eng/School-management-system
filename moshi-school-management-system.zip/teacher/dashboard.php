<?php
require_once '../includes/bootstrap.php';
requireRole('teacher');

$page_title = "Teacher Dashboard";

// 1. Fetch Teacher Profile
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];
$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];
$employee_id = $teacher['employee_id'];

// 2. Fetch My Classes (Assigned class-subject combinations + student counts)
$stmt = $pdo->prepare("
    SELECT c.class_name, c.class_id, s.subject_name, s.subject_id,
    (SELECT COUNT(*) FROM students WHERE class_id = c.class_id AND status = 'Active') as student_count
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.teacher_id = ?
    ORDER BY class_name ASC, subject_name ASC
");
$stmt->execute([$teacher_id]);
$my_classes = $stmt->fetchAll();

// 3. Analytics filter (class + subject)
$selected_class_id  = 0;
$selected_subject_id = 0;
if (!empty($_GET['analytics_filter'])) {
    [$selected_class_id, $selected_subject_id] = explode('|', $_GET['analytics_filter']);
    $selected_class_id  = (int)$selected_class_id;
    $selected_subject_id = (int)$selected_subject_id;
} elseif (!empty($my_classes)) {
    $selected_class_id  = (int)$my_classes[0]['class_id'];
    $selected_subject_id = (int)$my_classes[0]['subject_id'];
}

// 4. Open exams for marks entry
$stmt_exams = $pdo->prepare("
    SELECT e.exam_id, e.exam_name, c.class_name, s.subject_name, e.max_marks, e.exam_date,
    (SELECT COUNT(*) FROM results WHERE exam_id = e.exam_id) as entered_count,
    (SELECT COUNT(*) FROM students WHERE class_id = e.class_id AND status = 'Active') as total_students
    FROM exams e
    JOIN classes c ON e.class_id = c.class_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.teacher_id = ?
    ORDER BY e.exam_date DESC LIMIT 10
");
$stmt_exams->execute([$teacher_id]);
$my_exams = $stmt_exams->fetchAll();

// 5. Grade distribution for selected class/subject
$grades_summary    = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'E' => 0, 'F' => 0];
$total_grades_count = 0;
if ($selected_class_id && $selected_subject_id) {
    $stmt_grades = $pdo->prepare("
        SELECT r.grade, COUNT(*) as cnt
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        WHERE e.teacher_id = ? AND e.class_id = ? AND e.subject_id = ? AND r.status = 'published'
        GROUP BY r.grade
    ");
    $stmt_grades->execute([$teacher_id, $selected_class_id, $selected_subject_id]);
    foreach ($stmt_grades->fetchAll() as $gd) {
        if (isset($grades_summary[$gd['grade']])) {
            $grades_summary[$gd['grade']] = (int)$gd['cnt'];
            $total_grades_count += (int)$gd['cnt'];
        }
    }
}

// 6. Bottom 5 students for selected filter
$bottom_students = [];
if ($selected_class_id && $selected_subject_id) {
    $stmt_bottom = $pdo->prepare("
        SELECT s.first_name, s.last_name, c.class_name, ROUND(AVG(r.marks_obtained),1) as avg_score
        FROM results r
        JOIN students s ON r.student_id = s.student_id
        JOIN classes c ON s.class_id = c.class_id
        JOIN exams e ON r.exam_id = e.exam_id
        WHERE e.teacher_id = ? AND e.class_id = ? AND e.subject_id = ?
        GROUP BY s.student_id, s.first_name, s.last_name, c.class_name
        ORDER BY avg_score ASC
        LIMIT 5
    ");
    $stmt_bottom->execute([$teacher_id, $selected_class_id, $selected_subject_id]);
    $bottom_students = $stmt_bottom->fetchAll();
}

// 7. Current filter label
$filtered_name = "All Classes";
foreach ($my_classes as $cls) {
    if ($cls['class_id'] == $selected_class_id && $cls['subject_id'] == $selected_subject_id) {
        $filtered_name = $cls['class_name'] . " — " . $cls['subject_name'];
        break;
    }
}

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/teacher_dashboard.css?v=<?php echo time(); ?>">
<style>
/* ─── Page wrapper ─────────────────────────────────────────── */
.mobile-hub {
    display: flex;
    flex-direction: column;
    gap: 20px;
    padding: 18px 22px;
    width: 100%;
    min-height: 100vh;
    box-sizing: border-box;
}

/* ─── Welcome header (simple: icon + title + subtitle) ──────── */
.welcome-card {
    background: #fff;
    border-radius: 14px;
    padding: 24px 26px;
    border: 1px solid #f0f2f5;
    box-shadow: 0 2px 12px rgba(0,0,0,0.04);
    display: flex;
    align-items: center;
    gap: 14px;
}
.welcome-card .wc-icon {
    font-size: 1.6rem;
    color: #8b0000;
    line-height: 1;
    flex-shrink: 0;
}
.welcome-card h2 {
    margin: 0 0 4px;
    font-size: 1.35rem;
    font-weight: 800;
    color: #8b0000;
    line-height: 1.2;
}
.welcome-card .sub {
    margin: 0;
    font-size: 0.84rem;
    color: #94a3b8;
    font-weight: 400;
    line-height: 1.4;
}

/* ─── Tab nav ──────────────────────────────────────────────── */
.quick-tabs {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}
.tab-btn {
    background: #fff;
    border: 1.5px solid rgba(160, 0, 0, 0.12);
    border-radius: 14px;
    padding: 16px 8px;
    font-size: 0.78rem;
    font-weight: 800;
    text-align: center;
    color: #5a5a6e;
    cursor: pointer;
    transition: all 0.25s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.tab-btn i { font-size: 1.35rem; color: #a00000; transition: transform 0.2s; }
.tab-btn:hover { transform: translateY(-2px); border-color: #a00000; box-shadow: 0 6px 16px rgba(160,0,0,0.1); }
.tab-btn:hover i { transform: scale(1.12); }
.tab-btn.active { background: linear-gradient(135deg, #a00000 0%, #c20000 100%); color: #fff; border-color: #a00000; box-shadow: 0 6px 20px rgba(160,0,0,0.25); }
.tab-btn.active i { color: #fff; }

/* ─── Class cards ──────────────────────────────────────────── */
.class-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px; }
.class-card {
    background: #fff;
    border: 1.5px solid rgba(160, 0, 0, 0.08);
    border-left: 6px solid #a00000;
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.03);
    transition: all 0.25s ease;
}
.class-card:hover { box-shadow: 0 8px 24px rgba(160,0,0,0.1); transform: translateY(-3px); }
.class-card-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.class-card-head h3 { margin: 0; font-size: 1.15rem; color: #1e293b; font-weight: 900; }
.badge-assigned {
    font-size: 0.7rem; font-weight: 800; letter-spacing: 0.4px;
    background: #fff0f0; color: #a00000;
    padding: 3px 10px; border-radius: 20px;
    border: 1px solid rgba(160,0,0,0.2);
}
.class-card-meta { font-size: 0.85rem; color: #64748b; font-weight: 500; margin-bottom: 14px; }
.class-card-meta strong { color: #1e293b; }

/* ─── Always-visible action buttons ─────────────────────────── */
.class-card-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    border-top: 1px solid #f1f5f9;
    padding-top: 14px;
}
.action-link {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    text-align: center;
    padding: 10px 6px;
    font-size: 0.72rem;
    font-weight: 700;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    color: #475569;
    text-decoration: none;
    transition: all 0.2s ease;
    line-height: 1.3;
}
.action-link i { font-size: 1.2rem; color: #a00000; transition: transform 0.2s; }
.action-link:hover {
    background: #a00000;
    color: #fff;
    border-color: #a00000;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(160,0,0,0.2);
}
.action-link:hover i { color: #fff; transform: scale(1.1); }

/* ─── Tab content ───────────────────────────────────────────── */
.tab-content { display: none; }
.tab-content.active { display: block; animation: fadeInUp 0.35s ease-out; }

/* ─── Analytics ─────────────────────────────────────────────── */
.analytics-card {
    background: #fff; border-radius: 14px; padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.04);
    border: 1.5px solid rgba(160,0,0,0.08);
    margin-bottom: 18px;
}
.analytics-card h5 {
    margin: 0 0 14px; font-weight: 800; font-size: 0.9rem;
    color: #1e293b; border-left: 3px solid #a00000; padding-left: 8px;
}
.remedial-box {
    background: #fff5f5; border-left: 4px solid #a00000;
    padding: 13px 15px; margin-bottom: 10px; border-radius: 8px;
    display: flex; justify-content: space-between; align-items: center;
    transition: transform 0.2s;
}
.remedial-box:hover { transform: translateX(3px); }
.remedial-box strong { color: #1e293b; font-size: 0.93rem; }
.remedial-box .cls { font-size: 0.78rem; color: #64748b; font-weight: 600; margin-top: 2px; }

/* ─── Filter select ─────────────────────────────────────────── */
.filter-select {
    width: 100%; padding: 11px 14px; border-radius: 10px;
    border: 1.5px solid #cbd5e1; font-weight: 700; font-size: 0.9rem;
    background: #f8fafc; color: #1e293b; outline: none; margin-bottom: 18px;
}
.filter-select:focus { border-color: #a00000; }

/* ─── Section heading ────────────────────────────────────────── */
.sec-head {
    display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;
}
.sec-head h4 { margin: 0; font-weight: 800; color: #a00000; font-size: 0.98rem; }
.count-pill { font-size: 0.72rem; font-weight: 800; background: #fff0f0; color: #a00000; padding: 3px 10px; border-radius: 20px; border: 1px solid rgba(160,0,0,0.18); }

/* ─── Exam list item ─────────────────────────────────────────── */
.exam-row {
    background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
    padding: 14px 16px; margin-bottom: 12px;
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 10px;
}
.exam-row strong { color: #1e293b; font-size: 0.93rem; }
.exam-row .sub-meta { font-size: 0.78rem; color: #64748b; font-weight: 500; margin-top: 3px; }
.btn-enter-marks {
    padding: 8px 16px; background: #a00000; color: #fff;
    border-radius: 8px; font-weight: 700; font-size: 0.82rem;
    text-decoration: none; white-space: nowrap;
    border: none; display: inline-block;
    transition: all 0.2s;
}
.btn-enter-marks:hover { background: #c20000; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(160,0,0,0.25); }

/* ─── Big link ───────────────────────────────────────────────── */
.btn-big-red {
    display: flex; align-items: center; justify-content: center; gap: 10px;
    padding: 15px; background: linear-gradient(135deg, #a00000 0%, #c20000 100%);
    color: #fff; font-weight: 800; font-size: 0.97rem;
    border-radius: 12px; text-decoration: none;
    box-shadow: 0 6px 18px rgba(160,0,0,0.2);
    transition: all 0.25s;
}
.btn-big-red:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(160,0,0,0.3); }

/* ─── Responsive ─────────────────────────────────────────────── */
@media (max-width: 600px) {
    .mobile-hub { padding: 12px 8px; }
    .quick-tabs { gap: 7px; }
    .tab-btn { padding: 12px 5px; font-size: 0.72rem; }
}
</style>

<div class="mobile-hub">

    <!-- Welcome Header — Simple style -->
    <div class="welcome-card">
        <span class="wc-icon"><i class="fas fa-chalkboard-teacher"></i></span>
        <div>
            <h2>Welcome, <?php echo h($teacher_name); ?></h2>
            <p class="sub"><?php echo date('l, d F Y'); ?> &mdash; Moshi Public Secondary School &mdash; Staff ID: <?php echo h($employee_id); ?></p>
        </div>
    </div>

    <!-- Tab Navigation -->
    <div class="quick-tabs">
        <div class="tab-btn active" id="tabbtn-classes"  onclick="switchTab('classes',this)"><i class="fas fa-th-large"></i><span>My Classes</span></div>
        <div class="tab-btn"        id="tabbtn-marks"    onclick="switchTab('marks',this)">  <i class="fas fa-edit"></i><span>Mark Entry</span></div>
        <div class="tab-btn"        id="tabbtn-analytics"onclick="switchTab('analytics',this)"><i class="fas fa-chart-bar"></i><span>Analytics</span></div>
        <div class="tab-btn"        id="tabbtn-period"   onclick="switchTab('period',this)"> <i class="fas fa-signature"></i><span>Sign Period</span></div>
    </div>

    <!-- ══ TAB 1 — My Classes ══════════════════════════════════ -->
    <div id="tab-classes" class="tab-content active">
        <div class="sec-head">
            <h4><i class="fas fa-book-reader" style="margin-right:6px;"></i>MY ASSIGNED CLASSES</h4>
            <span class="count-pill"><?php echo count($my_classes); ?> Classes</span>
        </div>

        <?php if (empty($my_classes)): ?>
            <div style="background:#fff;text-align:center;padding:50px 20px;border-radius:14px;color:#94a3b8;border:1px solid #f0f0f0;">
                <i class="fas fa-graduation-cap" style="font-size:2.8rem;opacity:.18;display:block;margin-bottom:12px;color:#a00000;"></i>
                You have not been assigned any classes by the Director of Studies yet.
            </div>
        <?php else: ?>
            <div class="class-grid">
                <?php foreach ($my_classes as $cls): ?>
                <div class="class-card">
                    <div class="class-card-head">
                        <h3><?php echo h($cls['class_name']); ?></h3>
                        <span class="badge-assigned">Active</span>
                    </div>
                    <div class="class-card-meta">
                        <i class="fas fa-book" style="color:#a00000; margin-right:5px;"></i>
                        Subject: <strong><?php echo h($cls['subject_name']); ?></strong><br>
                        <i class="fas fa-users" style="color:#a00000; margin-right:5px;"></i>
                        Students: <strong><?php echo $cls['student_count']; ?></strong>
                    </div>
                    <div class="class-card-actions">
                        <a href="attendance/mark.php?class_id=<?php echo $cls['class_id']; ?>" class="action-link">
                            <i class="fas fa-calendar-check"></i>
                            Attendance
                        </a>
                        <a href="results/exams.php?class_id=<?php echo $cls['class_id']; ?>" class="action-link">
                            <i class="fas fa-edit"></i>
                            Enter Marks
                        </a>
                        <a href="period-sign.php?class_id=<?php echo $cls['class_id']; ?>&subject_id=<?php echo $cls['subject_id']; ?>" class="action-link">
                            <i class="fas fa-signature"></i>
                            Sign Period
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- ══ TAB 2 — Mark Entry ═══════════════════════════════════ -->
    <div id="tab-marks" class="tab-content">
        <div class="sec-head">
            <h4><i class="fas fa-edit" style="margin-right:6px;"></i>EXAM MARKS ENTRY</h4>
        </div>
        <div style="background:#fff;padding:20px;border-radius:14px;border:1.5px solid rgba(160,0,0,0.08);box-shadow:0 2px 10px rgba(0,0,0,0.03);">
            <p style="font-size:.85rem;color:#64748b;margin-bottom:16px;font-weight:500;">Select from the exams prepared for your classes to enter student marks:</p>

            <?php if (empty($my_exams)): ?>
                <div style="text-align:center;padding:30px;color:#94a3b8;font-weight:600;">
                    <i class="fas fa-file-excel d-block mb-2" style="font-size:2rem;color:#a00000;opacity:.25;"></i>
                    No exams have been set for your classes yet.
                </div>
            <?php else: ?>
                <?php foreach ($my_exams as $exam):
                    $pct = $exam['total_students'] > 0 ? round(($exam['entered_count']/$exam['total_students'])*100) : 0;
                ?>
                <div class="exam-row">
                    <div>
                        <strong><?php echo h($exam['class_name'] . ' — ' . $exam['exam_name']); ?></strong>
                        <div class="sub-meta">
                            Subject: <strong style="color:#1e293b;"><?php echo h($exam['subject_name']); ?></strong>
                            &nbsp;·&nbsp; Entered: <?php echo $exam['entered_count']; ?>/<?php echo $exam['total_students']; ?> (<?php echo $pct; ?>%)
                        </div>
                    </div>
                    <a href="results/enter-marks.php?id=<?php echo $exam['exam_id']; ?>" class="btn-enter-marks">
                        Enter Marks &rarr;
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div style="margin-top:16px;">
                <a href="results/exams.php" class="btn-big-red">
                    <i class="fas fa-plus-circle"></i> Set Up / View All Exams
                </a>
            </div>
        </div>
    </div>

    <!-- ══ TAB 3 — Analytics ════════════════════════════════════ -->
    <div id="tab-analytics" class="tab-content">
        <div class="sec-head">
            <h4><i class="fas fa-chart-line" style="margin-right:6px;"></i>CLASS PERFORMANCE ANALYTICS</h4>
        </div>

        <!-- Class/Subject filter -->
        <label style="display:block;font-size:.74rem;font-weight:800;color:#64748b;text-transform:uppercase;margin-bottom:7px;">Filter by Class</label>
        <select class="filter-select" onchange="window.location.href='dashboard.php?analytics_filter='+this.value+'&tab=analytics'">
            <?php foreach ($my_classes as $cls):
                $val = $cls['class_id'].'|'.$cls['subject_id'];
                $sel = ($selected_class_id==$cls['class_id'] && $selected_subject_id==$cls['subject_id']) ? 'selected' : '';
            ?>
                <option value="<?php echo $val; ?>" <?php echo $sel; ?>><?php echo h($cls['class_name']); ?> — <?php echo h($cls['subject_name']); ?></option>
            <?php endforeach; ?>
        </select>

        <div style="background:#fff5f5;padding:8px 14px;border-radius:8px;color:#a00000;font-weight:700;font-size:.84rem;margin-bottom:16px;border:1px solid rgba(160,0,0,0.1);">
            Showing: <strong><?php echo $filtered_name; ?></strong>
        </div>

        <!-- Grade Distribution -->
        <div class="analytics-card">
            <h5>GRADE DISTRIBUTION</h5>
            <?php if ($total_grades_count == 0): ?>
                <p style="font-size:.84rem;color:#94a3b8;text-align:center;padding:14px 0;">No published results for this class/subject yet.</p>
            <?php else: ?>
                <div style="display:flex;flex-direction:column;gap:10px;">
                    <?php foreach ($grades_summary as $gr => $cnt):
                        $pct = $total_grades_count > 0 ? round(($cnt/$total_grades_count)*100,1) : 0;
                    ?>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:22px;font-weight:800;font-size:.87rem;color:#1e293b;"><?php echo $gr; ?></span>
                        <div style="flex:1;background:#f1f5f9;height:20px;border-radius:10px;overflow:hidden;border:1px solid #e2e8f0;">
                            <div style="width:<?php echo $pct; ?>%;background:linear-gradient(90deg,#a00000,#c20000);height:100%;"></div>
                        </div>
                        <span style="font-size:.82rem;color:#475569;font-weight:700;width:60px;text-align:right;"><?php echo $cnt; ?> (<?php echo $pct; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Bottom 5 Students -->
        <div class="analytics-card">
            <h5>BOTTOM 5 STUDENTS — REMEDIAL FOCUS</h5>
            <p style="font-size:.8rem;color:#64748b;margin-bottom:14px;font-weight:500;">Students scoring lowest in the selected class/subject. Consider scheduling extra support sessions.</p>
            <?php if (empty($bottom_students)): ?>
                <p style="font-size:.84rem;color:#94a3b8;text-align:center;padding:14px 0;font-weight:500;">No performance data available yet for this class.</p>
            <?php else: ?>
                <?php foreach ($bottom_students as $bs): ?>
                <div class="remedial-box">
                    <div>
                        <strong><?php echo h($bs['first_name'].' '.$bs['last_name']); ?></strong>
                        <div class="cls">Class: <?php echo h($bs['class_name']); ?></div>
                    </div>
                    <span style="background:#e11d48;color:#fff;font-size:.8rem;font-weight:800;padding:5px 11px;border-radius:7px;box-shadow:0 2px 6px rgba(225,29,72,.2);">
                        <?php echo $bs['avg_score']; ?>% Avg
                    </span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- ══ TAB 4 — Sign Period ══════════════════════════════════ -->
    <div id="tab-period" class="tab-content">
        <div class="sec-head">
            <h4><i class="fas fa-clipboard-list" style="margin-right:6px;"></i>DAILY PERIOD LOGBOOK</h4>
        </div>
        <div style="background:#fff;padding:28px 20px;border-radius:14px;border:1.5px solid rgba(160,0,0,0.08);text-align:center;">
            <div style="background:#fff0f0;width:68px;height:68px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;">
                <i class="fas fa-signature" style="font-size:1.9rem;color:#a00000;"></i>
            </div>
            <p style="font-size:.88rem;color:#64748b;margin-bottom:20px;font-weight:500;">Your digital period logbook — record topics taught each lesson. The Director of Studies monitors your syllabus coverage in real-time.</p>
            <a href="period-sign.php" class="btn-big-red">
                <i class="fas fa-pen-nib"></i> Open Period Logbook
            </a>
        </div>
    </div>

</div><!-- end .mobile-hub -->

<script>
// Activate tab from URL
document.addEventListener("DOMContentLoaded", function() {
    const tab = new URLSearchParams(window.location.search).get('tab');
    if (tab) {
        const btn = document.getElementById('tabbtn-' + tab);
        if (btn) switchTab(tab, btn);
    }
});

function switchTab(tabId, element) {
    document.querySelectorAll('.tab-content').forEach(w => w.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + tabId).classList.add('active');
    element.classList.add('active');
}
</script>
<?php require_once '../includes/footer.php'; ?>
