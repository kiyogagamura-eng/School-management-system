<?php
require_once '../includes/bootstrap.php';
requireRole('teacher');

$page_title = "My Weekly Timetable";

// Fetch Teacher Context
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$user_id]);
$teacher = $stmt->fetch();
$teacher_id = $teacher['teacher_id'];

// Define working days and standard periods (for the grid)
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
// Fetch unique periods from the timetable to build the rows
$stmt = $pdo->prepare("SELECT DISTINCT period_number, start_time, end_time, is_break, break_name FROM timetables ORDER BY start_time ASC");
$stmt->execute();
$all_periods = $stmt->fetchAll();

// Fetch teacher's specific class/subject assignments for the timetable
$stmt = $pdo->prepare("
    SELECT t.*, c.class_name, s.subject_name, s.subject_code
    FROM timetables t
    LEFT JOIN classes c ON t.class_id = c.class_id
    LEFT JOIN subjects s ON t.subject_id = s.subject_id
    WHERE t.teacher_id = ? OR t.is_break = 1
    ORDER BY t.start_time ASC
");
$stmt->execute([$teacher_id]);
$timetable_entries = $stmt->fetchAll();

// Organize entries by [day][period_number]
$schedule = [];
foreach ($timetable_entries as $entry) {
    if ($entry['is_break']) {
        // Breaks apply to all days in our seed, but let's store them per day to be safe
        $schedule[$entry['day_of_week']][$entry['period_number']] = $entry;
    } else {
        $schedule[$entry['day_of_week']][$entry['period_number']] = $entry;
    }
}

// Current time info for highlighting
$current_day = date('l');
$current_time = date('H:i:s');

function isCurrentPeriod($start, $end, $day, $curr_day, $curr_time) {
    if ($day !== $curr_day) return false;
    return ($curr_time >= $start && $curr_time <= $end);
}

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/teacher_dashboard.css">
<style>
    .timetable-container {
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        overflow: hidden;
        margin-top: 20px;
    }

    .timetable-grid {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .timetable-grid th {
        background: #ffffff;
        color: var(--corporate-red);
        padding: 15px 10px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 1px;
        font-size: 12px;
        border-bottom: 3px solid var(--corporate-red);
        font-family: 'Inter', sans-serif !important;
    }

    .timetable-grid td {
        border: 1px solid #eee;
        padding: 8px;
        height: auto;
        min-height: 80px;
        vertical-align: top;
        transition: all 0.3s ease;
        position: relative;
    }

    .time-col {
        background: #fdfdfd;
        font-weight: 900;
        color: var(--corporate-red);
        text-align: center;
        width: 120px;
        vertical-align: middle !important;
        border-right: 3px solid var(--corporate-red) !important;
        font-size: 14px;
        text-transform: uppercase;
        font-family: 'Inter', sans-serif !important;
    }

    .period-box {
        display: flex;
        flex-direction: column;
        gap: 5px;
        height: 100%;
    }

    .entry-card {
        background: var(--accent-soft-red);
        border-left: 3px solid var(--corporate-red);
        padding: 8px;
        border-radius: 4px;
        font-size: 12px;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.03);
    }

    .entry-class {
        font-weight: 800;
        color: var(--corporate-red);
        font-size: 12px;
        margin-bottom: 1px;
    }

    .entry-subject {
        color: var(--primary-text);
        font-weight: 600;
    }

    .entry-code {
        font-size: 11px;
        color: var(--secondary-text);
        margin-top: 5px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .entry-room {
        background: var(--corporate-red);
        color: white;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: 800;
        font-size: 9px;
    }

    .break-row td {
        height: 60px;
        background: #f8fafc;
        text-align: center;
        vertical-align: middle;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 12px;
    }

    .current-session {
        background: #fff5f5 !important;
        outline: 2px solid #8b0000;
        outline-offset: -2px;
        z-index: 2;
    }

    .current-session::after {
        content: "NOW";
        position: absolute;
        top: 5px;
        right: 5px;
        background: var(--corporate-red);
        color: white;
        font-size: 9px;
        padding: 2px 5px;
        border-radius: 3px;
        font-weight: 800;
    }

    .empty-slot {
        color: #ddd;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        font-style: italic;
        font-size: 12px;
    }

    .legend {
        display: flex;
        gap: 20px;
        margin-top: 20px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
        font-size: 13px;
    }

    .legend-item {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .legend-box {
        width: 15px;
        height: 15px;
        border-radius: 3px;
    }

    @media (max-width: 992px) {
        .timetable-container {
            overflow-x: auto;
        }
        .timetable-grid {
            min-width: 900px;
        }
    }
</style>

<div class="container-fluid">
    <div class="welcome-banner">
        <h1>📅 ACADEMIC TIMETABLE</h1>
        <p>Full weekly schedule for <?php echo h($teacher['first_name'] . ' ' . $teacher['last_name']); ?></p>
        <div style="margin-top: 15px; display: flex; gap: 30px; font-size: 13px;">
            <span><i class="fas fa-calendar-alt" style="color: var(--corporate-red); margin-right: 5px;"></i> <b>Academic Year:</b> <?php echo date('Y') . '/' . (date('Y') + 1); ?></span>
            <span><i class="fas fa-clock" style="color: var(--corporate-red); margin-right: 5px;"></i> <b>Working Hours:</b> 08:00 AM - 04:30 PM</span>
        </div>
    </div>

    <div class="timetable-container fade-in">
        <table class="timetable-grid">
            <thead>
                <tr>
                    <th style="width: 150px;">Day / Time</th>
                    <?php foreach ($all_periods as $p): 
                        $start = date('H:i', strtotime($p['start_time']));
                        $end = date('H:i', strtotime($p['end_time']));
                        $is_break = $p['is_break'];
                    ?>
                        <th style="text-align: center;">
                            <div style="font-size: 13px;"><?php echo $start; ?> - <?php echo $end; ?></div>
                            <?php if (!$is_break): ?>
                                <div style="font-size: 10px; opacity: 0.8; font-weight: normal; margin-top: 3px;">Period <?php echo floor($p['period_number']); ?></div>
                            <?php else: ?>
                                <div style="font-size: 10px; opacity: 0.8; font-weight: normal; margin-top: 3px; color: #64748b;">Break</div>
                            <?php endif; ?>
                        </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($days as $day): ?>
                    <tr>
                        <td class="time-col" style="background: #f8f9fa; border-right: 2px solid var(--corporate-red);">
                            <div style="font-weight: 800; color: var(--corporate-red); font-size: 15px;"><?php echo strtoupper($day); ?></div>
                        </td>

                        <?php foreach ($all_periods as $p): 
                            $p_num = $p['period_number'];
                            $entry = $schedule[$day][$p_num] ?? null;
                            $is_now = isCurrentPeriod($p['start_time'], $p['end_time'], $day, $current_day, $current_time);
                            $is_break = $p['is_break'];
                        ?>
                            <td class="<?php echo $is_now ? 'current-session' : ''; ?> <?php echo $is_break ? 'break-row' : ''; ?>" style="<?php echo $is_break ? 'background: #f1f3f4; min-width: 80px;' : ''; ?>">
                                <?php if ($is_break): ?>
                                    <div style="font-size: 10px; font-weight: 800; color: #64748b; text-align: center;">☕ <?php echo strtoupper($p['break_name']); ?></div>
                                <?php elseif ($entry): ?>
                                    <div class="entry-card shadow-premium">
                                        <div class="entry-class">🏫 <?php echo h($entry['class_name']); ?></div>
                                        <div class="entry-subject"><?php echo h($entry['subject_name']); ?></div>
                                        <div class="entry-code">
                                            <span><?php echo h($entry['subject_code']); ?></span>
                                            <?php if($entry['room']): ?>
                                                <span class="entry-room"><?php echo h($entry['room']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="empty-slot">Free</div>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="legend">
        <div class="legend-item">
            <div class="legend-box" style="background: var(--accent-soft-red); border-left: 3px solid var(--corporate-red);"></div>
            <span>My Teaching Sessions</span>
        </div>
        <div class="legend-item">
            <div class="legend-box" style="background: #f8fafc; border: 1px solid #e2e8f0;"></div>
            <span>School Breaks</span>
        </div>
        <div class="legend-item">
            <div class="legend-box" style="background: white; border: 1px solid #e2e8f0;"></div>
            <span>Free / Preparation Periods</span>
        </div>
        <div class="legend-item" style="margin-left: auto;">
            <i class="fas fa-print" style="color: var(--corporate-red); cursor: pointer;" onclick="window.print()"></i>
            <span style="font-weight: 700; color: var(--corporate-red); cursor: pointer;" onclick="window.print()">Print Timetable</span>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
