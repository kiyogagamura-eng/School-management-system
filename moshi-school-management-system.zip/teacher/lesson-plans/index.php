<?php
require_once '../../includes/bootstrap.php';
requireRole(['teacher']);

$page_title = "My Lesson Plans";

// Resolve teacher_id from DB (session only stores user_id)
$stmt_t = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$stmt_t->execute([$_SESSION['user_id']]);
$teacher_row = $stmt_t->fetch();
$teacher_id  = $teacher_row ? (int)$teacher_row['teacher_id'] : 0;

// Handle new submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'submit') {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO lesson_plans (teacher_id, class_id, subject_id, term_id, plan_type, title, week_number, topic, objectives, methodology, resources)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([
            $teacher_id,
            $_POST['class_id'],
            $_POST['subject_id'],
            $_POST['term_id'] ?: null,
            $_POST['plan_type'],
            trim($_POST['title']),
            $_POST['week_number'] ?: null,
            trim($_POST['topic']),
            trim($_POST['objectives']),
            trim($_POST['methodology']),
            trim($_POST['resources'])
        ]);
        $success = "Lesson plan submitted successfully! DOS will review it.";
    } catch(Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Get teacher's assignments
$assignments = $pdo->prepare("
    SELECT cs.class_id, cs.subject_id, c.class_name, s.subject_name
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.class_id
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.teacher_id = ?
    ORDER BY c.class_name, s.subject_name
");
$assignments->execute([$teacher_id]);
$my_assignments = $assignments->fetchAll();

// Get current term
$current_term = getCurrentTerm();
$terms = $pdo->query("SELECT * FROM academic_terms ORDER BY academic_year DESC")->fetchAll();

// My submitted plans
$my_plans = $pdo->prepare("
    SELECT lp.*, c.class_name, s.subject_name, t.term_name
    FROM lesson_plans lp
    JOIN classes c ON lp.class_id = c.class_id
    JOIN subjects s ON lp.subject_id = s.subject_id
    LEFT JOIN academic_terms t ON lp.term_id = t.term_id
    WHERE lp.teacher_id = ?
    ORDER BY lp.created_at DESC
");
$my_plans->execute([$teacher_id]);
$plans = $my_plans->fetchAll();

$pending  = count(array_filter($plans, fn($p) => $p['status'] == 'pending'));
$approved = count(array_filter($plans, fn($p) => $p['status'] == 'approved'));
$rejected = count(array_filter($plans, fn($p) => $p['status'] == 'rejected'));

require_once '../../includes/header.php';
?>
<style>
.lp-teacher { padding: 25px; background: #f8fafc; min-height: 100vh; }

/* Header — Academic Card style (white bg with red accent) */
.lp-header {
    background: #fff;
    border: 1px solid #f1f5f9;
    color: #1e293b;
    padding: 22px 28px;
    border-radius: 14px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 18px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
}
.lp-header::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(160,0,0,0.03) 0%, transparent 60%);
    pointer-events: none;
}
.lp-icon {
    background: linear-gradient(135deg, #a00000, #c20000);
    width: 52px;
    height: 52px;
    min-width: 52px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: #fff;
    box-shadow: 0 4px 14px rgba(160,0,0,0.3);
}
.lp-header-label {
    font-size: 0.68rem;
    font-weight: 800;
    color: #a00000;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 3px;
}
.lp-header h4 { margin: 0 0 2px; font-weight: 800; color: #1e293b; font-size: 1.2rem; }
.lp-header p  { margin: 0; color: #64748b; font-size: 0.84rem; font-weight: 500; }
.lp-header-stat { text-align: right; margin-left: auto; }
.lp-header-stat .num { font-size: 1.5rem; font-weight: 900; color: #a00000; }
.lp-header-stat .lbl { font-size: 0.7rem; color: #94a3b8; font-weight: 700; text-transform: uppercase; }

.card-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 20px; border: 1px solid #f1f5f9; }
.stat-mini { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 22px; }
.sm-card { border-radius: 10px; padding: 15px; text-align: center; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; font-size: 0.78rem; font-weight: 700; color: #475569; text-transform: uppercase; margin-bottom: 6px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; outline: none; background: #f8fafc; box-sizing: border-box; color: #1e293b; }
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #a00000; background: #fff; }
.btn-submit { background: linear-gradient(135deg, #a00000, #c20000); color: #fff; border: none; padding: 12px 28px; border-radius: 9px; font-weight: 700; cursor: pointer; width: 100%; font-size: 0.95rem; box-shadow: 0 4px 14px rgba(160,0,0,0.25); transition: all 0.2s; }
.btn-submit:hover { background: linear-gradient(135deg, #c20000, #a00000); transform: translateY(-1px); box-shadow: 0 6px 18px rgba(160,0,0,0.3); }
.plan-card { border: 1px solid #f1f5f9; border-radius: 10px; margin-bottom: 12px; overflow: hidden; }
.plan-card-head { padding: 13px 18px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
.plan-card-body { padding: 14px 18px; font-size: 0.85rem; }
.badge-p { background: #fffbeb; color: #92400e; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; border: 1px solid #fde68a; }
.badge-a { background: #f0fdf4; color: #166534; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; border: 1px solid #bbf7d0; }
.badge-r { background: #fff0f0; color: #a00000; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; border: 1px solid rgba(160,0,0,0.2); }
.sec-title { font-size: 0.72rem; font-weight: 800; color: #a00000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; border-left: 3px solid #a00000; padding-left: 8px; }
</style>

<div class="lp-teacher">
    <div class="lp-header">
        <div class="lp-icon"><i class="fas fa-folder-open"></i></div>
        <div style="flex:1;">
            <div class="lp-header-label">Lesson Plans</div>
            <h4>Lesson Plans &amp; Schemes of Work</h4>
            <p>Submit your teaching plans for DOS review and approval</p>
        </div>
        <div class="lp-header-stat">
            <div class="num"><?php echo count($plans); ?></div>
            <div class="lbl">Total Submitted</div>
        </div>
    </div>

    <?php if(!empty($success)): ?>
        <div style="background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:12px 20px; border-radius:8px; margin-bottom:18px; font-weight:600;">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
        </div>
    <?php endif; ?>
    <?php if(!empty($error)): ?>
        <div style="background:#fff5f5; color:#940000; border:1px solid #fecaca; padding:12px 20px; border-radius:8px; margin-bottom:18px; font-weight:600;">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
        </div>
    <?php endif; ?>

    <!-- Status Summary -->
    <div class="stat-mini">
        <div class="sm-card" style="background:#fffbeb; border-left:4px solid #f59e0b;">
            <div style="font-size:1.8rem; font-weight:900; color:#f59e0b;"><?php echo $pending; ?></div>
            <div style="font-size:0.7rem; color:#92400e; font-weight:700; text-transform:uppercase;">Pending Review</div>
        </div>
        <div class="sm-card" style="background:#f0fdf4; border-left:4px solid #22c55e;">
            <div style="font-size:1.8rem; font-weight:900; color:#22c55e;"><?php echo $approved; ?></div>
            <div style="font-size:0.7rem; color:#166534; font-weight:700; text-transform:uppercase;">Approved</div>
        </div>
        <div class="sm-card" style="background:#fff5f5; border-left:4px solid #ef4444;">
            <div style="font-size:1.8rem; font-weight:900; color:#ef4444;"><?php echo $rejected; ?></div>
            <div style="font-size:0.7rem; color:#940000; font-weight:700; text-transform:uppercase;">Rejected</div>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1.6fr; gap:22px;">
        <!-- Submission Form -->
        <div class="card-box">
            <div class="sec-title"><i class="fas fa-plus-circle me-1"></i> Submit New Plan</div>
            <form method="POST">
                <input type="hidden" name="action" value="submit">
                <div class="form-group">
                    <label>Plan Type</label>
                    <select name="plan_type" required>
                        <option value="lesson_plan">📋 Lesson Plan</option>
                        <option value="scheme_of_work">📚 Scheme of Work</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Class</label>
                    <select name="class_id" id="classSelect" required onchange="filterSubjects()">
                        <option value="">Choose class...</option>
                        <?php
                        $seen = [];
                        foreach($my_assignments as $a):
                            if(!in_array($a['class_id'], $seen)): $seen[] = $a['class_id'];
                        ?>
                        <option value="<?php echo $a['class_id']; ?>"><?php echo h($a['class_name']); ?></option>
                        <?php endif; endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Subject</label>
                    <select name="subject_id" id="subjectSelect" required>
                        <option value="">Select class first...</option>
                        <?php foreach($my_assignments as $a): ?>
                        <option value="<?php echo $a['subject_id']; ?>" data-class="<?php echo $a['class_id']; ?>">
                            <?php echo h($a['subject_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div class="form-group">
                        <label>Term</label>
                        <select name="term_id">
                            <option value="<?php echo $current_term['term_id']; ?>"><?php echo h($current_term['term_name']); ?> (Current)</option>
                            <?php foreach($terms as $t): if($t['term_id']==$current_term['term_id']) continue; ?>
                            <option value="<?php echo $t['term_id']; ?>"><?php echo h($t['term_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Week No.</label>
                        <select name="week_number">
                            <option value="">Select...</option>
                            <?php for($w=1;$w<=16;$w++): ?>
                            <option value="<?php echo $w; ?>">Week <?php echo $w; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" required placeholder="e.g. Form 2 Mathematics Week 3 Lesson Plan">
                </div>
                <div class="form-group">
                    <label>Topic / Unit</label>
                    <input type="text" name="topic" required placeholder="e.g. Linear Equations and Inequalities">
                </div>
                <div class="form-group">
                    <label>Learning Objectives</label>
                    <textarea name="objectives" rows="2" required placeholder="By the end of the lesson, students should be able to..."></textarea>
                </div>
                <div class="form-group">
                    <label>Teaching Methodology</label>
                    <textarea name="methodology" rows="2" placeholder="e.g. Discussion, Group work, Q&A, Demonstration..."></textarea>
                </div>
                <div class="form-group">
                    <label>Resources / Materials</label>
                    <input type="text" name="resources" placeholder="e.g. Textbook p.45, Whiteboard, Ruler...">
                </div>
                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane me-2"></i> Submit for DOS Review
                </button>
            </form>
        </div>

        <!-- My Submitted Plans -->
        <div class="card-box">
            <div class="sec-title"><i class="fas fa-list me-1"></i> My Submitted Plans</div>
            <?php if(empty($plans)): ?>
                <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                    <i class="fas fa-folder-open" style="font-size:2.5rem; opacity:0.15; display:block; margin-bottom:15px;"></i>
                    <p style="margin:0;">No lesson plans submitted yet.<br><span style="font-size:0.82rem;">Use the form to submit your first plan for DOS review.</span></p>
                </div>
            <?php else: ?>
                <?php foreach($plans as $plan):
                    $cls = match($plan['status']) { 'approved'=>'badge-a', 'rejected'=>'badge-r', default=>'badge-p' };
                ?>
                <div class="plan-card">
                    <div class="plan-card-head">
                        <div>
                            <div style="font-weight:700; color:#1e293b; font-size:0.88rem;"><?php echo h($plan['title']); ?></div>
                            <div style="font-size:0.74rem; color:#64748b; margin-top:2px;">
                                <?php echo h($plan['class_name']); ?> · <?php echo h($plan['subject_name']); ?>
                                <?php if($plan['week_number']): ?> · Week <?php echo $plan['week_number']; ?><?php endif; ?>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
                            <span style="font-size:0.68rem; color:#94a3b8;"><?php echo date('d M Y', strtotime($plan['created_at'])); ?></span>
                            <span class="<?php echo $cls; ?>"><?php echo ucfirst($plan['status']); ?></span>
                        </div>
                    </div>
                    <?php if($plan['status'] == 'rejected' && $plan['dos_comment']): ?>
                    <div class="plan-card-body" style="background:#fff5f5; border-top:1px solid #fecaca;">
                        <div style="color:#940000; font-size:0.82rem;">
                            <strong><i class="fas fa-comment me-1"></i> DOS Comment:</strong> <?php echo h($plan['dos_comment']); ?>
                        </div>
                    </div>
                    <?php elseif($plan['status'] == 'approved' && $plan['dos_comment']): ?>
                    <div class="plan-card-body" style="background:#f0fdf4; border-top:1px solid #bbf7d0;">
                        <div style="color:#166534; font-size:0.82rem;">
                            <strong><i class="fas fa-comment me-1"></i> DOS Note:</strong> <?php echo h($plan['dos_comment']); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function filterSubjects() {
    const classId = document.getElementById('classSelect').value;
    const sel = document.getElementById('subjectSelect');
    sel.innerHTML = '<option value="">Choose subject...</option>';
    document.querySelectorAll('#subjectSelect option[data-class]').forEach(opt => {
        if(opt.dataset.class === classId) {
            const o = opt.cloneNode(true);
            sel.appendChild(o);
        }
    });
    // Rebuild hidden options pool
    sel.querySelectorAll('option[data-class]').forEach(o => sel.removeChild(o));
}
// Keep original option pool in hidden element
const _pool = document.createElement('select');
_pool.id = '_subPool';
_pool.style.display = 'none';
document.querySelectorAll('#subjectSelect option[data-class]').forEach(o => _pool.appendChild(o.cloneNode(true)));
document.body.appendChild(_pool);

function filterSubjects() {
    const classId = document.getElementById('classSelect').value;
    const sel = document.getElementById('subjectSelect');
    const pool = document.getElementById('_subPool');
    sel.innerHTML = '<option value="">Choose subject...</option>';
    pool.querySelectorAll('option').forEach(opt => {
        if(opt.dataset.class === classId) sel.appendChild(opt.cloneNode(true));
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
