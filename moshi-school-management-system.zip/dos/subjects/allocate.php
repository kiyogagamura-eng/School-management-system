<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);
$page_title = "Teacher Allocation";

$success = $error = '';

// ── Handle Actions ─────────────────────────────────────────────────────────

// ASSIGN (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] == 'assign') {
        $teacher_id  = (int) $_POST['teacher_id'];
        $class_id    = (int) $_POST['class_id'];
        $subject_id  = (int) $_POST['subject_id'];
        $academic_term = trim($_POST['academic_term'] ?? date('Y'));

        if (!$teacher_id || !$class_id || !$subject_id) {
            $error = "Please select Teacher, Class, and Subject.";
        } else {
            try {
                // Check if this class+subject combo already assigned
                $chk = $pdo->prepare("SELECT id, teacher_id FROM class_subjects WHERE class_id=? AND subject_id=?");
                $chk->execute([$class_id, $subject_id]);
                $existing = $chk->fetch();

                if ($existing) {
                    // Update existing allocation
                    $upd = $pdo->prepare("UPDATE class_subjects SET teacher_id=?, academic_term=? WHERE class_id=? AND subject_id=?");
                    $upd->execute([$teacher_id, $academic_term, $class_id, $subject_id]);
                    $success = "✅ Allocation updated successfully - Teacher changed for this class/subject combination.";
                } else {
                    // New allocation
                    $ins = $pdo->prepare("INSERT INTO class_subjects (class_id, subject_id, teacher_id, academic_term) VALUES (?,?,?,?)");
                    $ins->execute([$class_id, $subject_id, $teacher_id, $academic_term]);
                    $success = "✅ New allocation saved successfully!";
                }
                logActivity($_SESSION['user_id'], 'allocation', "Assigned teacher $teacher_id to class $class_id subject $subject_id");
            } catch (Exception $e) {
                $error = "Error: " . $e->getMessage();
            }
        }
    }

    if ($_POST['action'] == 'delete' && isset($_POST['alloc_id'])) {
        $pdo->prepare("DELETE FROM class_subjects WHERE id=?")->execute([(int)$_POST['alloc_id']]);
        $success = "🗑️ Allocation deleted successfully.";
    }

    if ($_POST['action'] == 'edit_save' && isset($_POST['alloc_id'])) {
        $pdo->prepare("UPDATE class_subjects SET teacher_id=?, academic_term=? WHERE id=?")
            ->execute([(int)$_POST['teacher_id'], trim($_POST['academic_term']), (int)$_POST['alloc_id']]);
        $success = "✅ Allocation updated successfully.";
    }
}

// ── Fetch data for dropdowns ────────────────────────────────────────────────
$teachers  = $pdo->query("SELECT teacher_id, CONCAT(first_name,' ',last_name) as name, specialization FROM teachers WHERE status='Active' ORDER BY first_name")->fetchAll();
$classes   = $pdo->query("SELECT class_id, class_name, form_level, stream, academic_year FROM classes ORDER BY form_level, stream")->fetchAll();
$subjects  = $pdo->query("SELECT subject_id, subject_name, subject_code FROM subjects ORDER BY subject_name")->fetchAll();

// ── Current Allocations ─────────────────────────────────────────────────────
$filter_class   = $_GET['class_id']   ?? '';
$filter_teacher = $_GET['teacher_id'] ?? '';

$where = "WHERE 1=1";
$params = [];
if ($filter_class)   { $where .= " AND cs.class_id=?";   $params[] = $filter_class; }
if ($filter_teacher) { $where .= " AND cs.teacher_id=?"; $params[] = $filter_teacher; }

$stmt = $pdo->prepare("
    SELECT cs.id, cs.academic_term,
           CONCAT(t.first_name,' ',t.last_name) as teacher_name,
           t.teacher_id,
           c.class_name, c.form_level, c.stream, c.class_id,
           s.subject_name, s.subject_code, s.subject_id
    FROM class_subjects cs
    JOIN teachers t  ON cs.teacher_id  = t.teacher_id
    JOIN classes  c  ON cs.class_id    = c.class_id
    JOIN subjects s  ON cs.subject_id  = s.subject_id
    $where
    ORDER BY c.form_level, c.stream, s.subject_name
");
$stmt->execute($params);
$allocations = $stmt->fetchAll();

// Stats
$total_alloc   = $pdo->query("SELECT COUNT(*) FROM class_subjects WHERE teacher_id IS NOT NULL")->fetchColumn();
$unassigned    = $pdo->query("SELECT COUNT(*) FROM class_subjects WHERE teacher_id IS NULL")->fetchColumn();
$total_classes = count($classes);
$total_teachers_active = count($teachers);

require_once '../../includes/header.php';
?>
<style>
/* ── Container ── */
.alloc-wrap { padding: 25px; background: #f8fafc; min-height: 100vh; }

/* ── Page Header (glassmorphism) ── */
.alloc-header {
    background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%);
    backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(148,0,0,0.15);
    box-shadow: 0 8px 32px rgba(148,0,0,0.08);
    border-radius: 14px; padding: 25px 30px; margin-bottom: 25px;
    display: flex; align-items: center; gap: 20px;
}
.alloc-header .icon {
    background: linear-gradient(135deg, #940000, #c0392b);
    width: 55px; height: 55px; border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem; color: #fff;
    box-shadow: 0 4px 15px rgba(148,0,0,0.3);
    flex-shrink: 0;
}

/* ── Stats Row ── */
.stat-row { display: grid; grid-template-columns: repeat(4,1fr); gap: 15px; margin-bottom: 25px; }
.stat-box {
    background: #fff; border-radius: 12px; padding: 18px 20px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.05);
    display: flex; align-items: center; gap: 14px;
    border-bottom: 4px solid transparent;
}
.stat-box .si { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
.stat-num  { font-size: 1.7rem; font-weight: 900; line-height: 1; color: #1e293b; }
.stat-lbl  { font-size: 0.65rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-top: 3px; }

/* ── Card Box ── */
.card-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
.sec-title { font-size: 0.72rem; font-weight: 800; color: #940000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }

/* ── Form ── */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.form-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; }
.fg { display: flex; flex-direction: column; gap: 5px; }
.fg label { font-size: 0.75rem; font-weight: 700; color: #475569; text-transform: uppercase; }
.fg select, .fg input {
    padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 8px;
    font-size: 0.9rem; outline: none; background: #f8fafc;
    transition: border 0.2s, background 0.2s;
}
.fg select:focus, .fg input:focus { border-color: #940000; background: #fff; box-shadow: 0 0 0 3px rgba(148,0,0,0.06); }

/* ── Buttons ── */
.btn-assign {
    background: linear-gradient(135deg, #940000, #c0392b);
    color: #fff; border: none; padding: 12px 28px; border-radius: 8px;
    font-weight: 700; font-size: 0.9rem; cursor: pointer;
    display: inline-flex; align-items: center; gap: 8px;
    box-shadow: 0 4px 15px rgba(148,0,0,0.3);
    transition: all 0.2s;
}
.btn-assign:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(148,0,0,0.4); }
.btn-del { background: none; border: none; color: #ef4444; cursor: pointer; padding: 5px 8px; border-radius: 6px; transition: 0.2s; }
.btn-del:hover { background: #fff5f5; }
.btn-edit-sm { background: #eff6ff; border: none; color: #1d4ed8; cursor: pointer; padding: 5px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 700; transition: 0.2s; }
.btn-edit-sm:hover { background: #dbeafe; }

/* ── Table ── */
.alloc-table { width: 100%; border-collapse: collapse; font-size: 0.87rem; }
.alloc-table th { background: #f8fafc; padding: 11px 14px; text-align: left; font-size: 0.68rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.alloc-table td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.alloc-table tr:hover td { background: #fafafa; }
.alloc-table tr:last-child td { border-bottom: none; }

/* ── Badges ── */
.badge-form { background: #fff5f5; color: #940000; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }
.badge-subj { background: #eff6ff; color: #1d4ed8; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }

/* ── Filter row ── */
.filter-row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 18px; }
.filter-row select { padding: 8px 12px; border: 1.5px solid #e2e8f0; border-radius: 8px; font-size: 0.83rem; outline: none; }
.filter-row select:focus { border-color: #940000; }

/* ── Alert / Success ── */
.alert-ok  { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; padding: 12px 18px; border-radius: 8px; font-weight: 600; margin-bottom: 18px; }
.alert-err { background: #fff5f5; color: #940000; border: 1px solid #fca5a5; padding: 12px 18px; border-radius: 8px; font-weight: 600; margin-bottom: 18px; }
</style>

<div class="alloc-wrap">

    <!-- Page Header -->
    <div class="alloc-header">
        <div class="icon"><i class="fas fa-user-tag"></i></div>
        <div>
            <div style="font-size:0.7rem; color:#940000; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:3px;">Academic Master &rsaquo; Teacher Allocation</div>
            <h3 style="margin:0; font-weight:900; color:#1e293b; font-size:1.3rem;">Subject & Teacher Allocation</h3>
            <p style="margin:3px 0 0; color:#64748b; font-size:0.85rem;">Assign teachers to specific subjects across classes - this affects the entire system</p>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($success): ?><div class="alert-ok"><i class="fas fa-check-circle me-1"></i><?php echo $success; ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert-err"><i class="fas fa-exclamation-circle me-1"></i><?php echo $error; ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stat-row">
        <div class="stat-box" style="border-bottom-color:#940000;">
            <div class="si" style="background:#fff5f5; color:#940000;"><i class="fas fa-link"></i></div>
            <div><div class="stat-num"><?php echo $total_alloc; ?></div><div class="stat-lbl">Allocations</div></div>
        </div>
        <div class="stat-box" style="border-bottom-color:#f59e0b;">
            <div class="si" style="background:#fffbeb; color:#f59e0b;"><i class="fas fa-exclamation-triangle"></i></div>
            <div><div class="stat-num"><?php echo $unassigned; ?></div><div class="stat-lbl">Unassigned</div></div>
        </div>
        <div class="stat-box" style="border-bottom-color:#940000;">
            <div class="si" style="background:#fff5f5; color:#940000;"><i class="fas fa-school"></i></div>
            <div><div class="stat-num"><?php echo $total_classes; ?></div><div class="stat-lbl">Classes</div></div>
        </div>
        <div class="stat-box" style="border-bottom-color:#940000;">
            <div class="si" style="background:#fff5f5; color:#940000;"><i class="fas fa-chalkboard-teacher"></i></div>
            <div><div class="stat-num"><?php echo $total_teachers_active; ?></div><div class="stat-lbl">Active Teachers</div></div>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:1fr 2.2fr; gap:22px; align-items:start;">

        <!-- ── LEFT: Assignment Form ── -->
        <div class="card-box">
            <div class="sec-title"><i class="fas fa-plus-circle"></i> Create New Allocation</div>
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                <div style="display:flex; flex-direction:column; gap:14px;">

                    <div class="fg">
                        <label><i class="fas fa-school"></i> Class &amp; Stream</label>
                        <select name="class_id" required>
                            <option value="">— Select Class —</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?php echo $c['class_id']; ?>">
                                    <?php echo h($c['class_name']); ?> (<?php echo h($c['academic_year']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="fg">
                        <label><i class="fas fa-book"></i> Subject</label>
                        <select name="subject_id" required>
                            <option value="">— Select Subject —</option>
                            <?php foreach ($subjects as $s): ?>
                                <option value="<?php echo $s['subject_id']; ?>">
                                    <?php echo h($s['subject_name']); ?> (<?php echo h($s['subject_code']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="fg">
                        <label><i class="fas fa-chalkboard-teacher"></i> Teacher</label>
                        <select name="teacher_id" required>
                            <option value="">— Select Teacher —</option>
                            <?php foreach ($teachers as $t): ?>
                                <option value="<?php echo $t['teacher_id']; ?>">
                                    Mwl. <?php echo h($t['name']); ?>
                                    <?php if ($t['specialization']): ?>(<?php echo h($t['specialization']); ?>)<?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="fg">
                        <label><i class="fas fa-calendar"></i> Academic Year</label>
                        <input type="text" name="academic_term" value="<?php echo date('Y'); ?>" placeholder="e.g. 2026">
                    </div>

                    <button type="submit" class="btn-assign">
                        <i class="fas fa-user-check"></i> Assign Teacher
                    </button>
                </div>
            </form>

            <!-- Info box -->
            <div style="margin-top:20px; padding:14px; background:#fff5f5; border-radius:8px; border-left:3px solid #940000; font-size:0.8rem; color:#64748b; line-height:1.6;">
                <strong style="color:#940000;"><i class="fas fa-info-circle"></i> Info:</strong><br>
                A class can have one teacher per subject. If you assign a new teacher to an already allocated class and subject, the previous assignment will be updated. Teachers can be assigned to multiple different subjects and classes.
            </div>
        </div>

        <!-- ── RIGHT: Allocations Table ── -->
        <div class="card-box">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
                <div class="sec-title" style="margin-bottom:0;"><i class="fas fa-table"></i> Current Allocations (<?php echo count($allocations); ?>)</div>
                <!-- Filters -->
                <form method="GET" class="filter-row" style="margin-bottom:0;">
                    <select name="class_id" onchange="this.form.submit()">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['class_id']; ?>" <?php echo $filter_class==$c['class_id']?'selected':''; ?>>
                                <?php echo h($c['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="teacher_id" onchange="this.form.submit()">
                        <option value="">All Teachers</option>
                        <?php foreach ($teachers as $t): ?>
                            <option value="<?php echo $t['teacher_id']; ?>" <?php echo $filter_teacher==$t['teacher_id']?'selected':''; ?>>
                                Mwl. <?php echo h($t['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($filter_class || $filter_teacher): ?>
                        <a href="allocate.php" style="color:#940000; font-size:0.8rem; font-weight:700; text-decoration:none;">✕ Clear Filter</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if (empty($allocations)): ?>
                <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                    <i class="fas fa-user-tag" style="font-size:3rem; opacity:0.12; display:block; margin-bottom:15px;"></i>
                    <p style="margin:0; font-size:0.9rem;">No allocations found.</p>
                    <p style="font-size:0.8rem; margin-top:5px;">Use the form on the left to start assigning.</p>
                </div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="alloc-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Teacher</th>
                                <th>Class</th>
                                <th>Subject</th>
                                <th>Year</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allocations as $i => $a): ?>
                            <tr id="row-<?php echo $a['id']; ?>">
                                <td style="color:#94a3b8; font-weight:700; font-size:0.75rem;"><?php echo $i+1; ?></td>
                                <td>
                                    <div style="font-weight:700; color:#1e293b;">Mwl. <?php echo h($a['teacher_name']); ?></div>
                                </td>
                                <td>
                                    <span class="badge-form">Form <?php echo $a['form_level']; ?><?php echo h($a['stream']); ?></span>
                                </td>
                                <td>
                                    <span class="badge-subj"><?php echo h($a['subject_code']); ?></span>
                                    <div style="font-size:0.78rem; color:#475569; margin-top:3px;"><?php echo h($a['subject_name']); ?></div>
                                </td>
                                <td style="color:#64748b; font-size:0.82rem;"><?php echo h($a['academic_term'] ?? '—'); ?></td>
                                <td>
                                    <div style="display:flex; gap:6px; align-items:center;">
                                        <!-- Quick Edit -->
                                        <button class="btn-edit-sm" onclick="openEdit(<?php echo $a['id']; ?>, <?php echo $a['teacher_id']; ?>, '<?php echo addslashes($a['teacher_name']); ?>', '<?php echo addslashes($a['academic_term']); ?>')">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <!-- Delete -->
                                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this allocation?\nMwl. <?php echo addslashes($a['teacher_name']); ?> — <?php echo addslashes($a['subject_name']); ?> (<?php echo addslashes($a['class_name']); ?>)')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="alloc_id" value="<?php echo $a['id']; ?>">
                                            <button type="submit" class="btn-del" title="Delete"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ── Edit Modal ── -->
<div id="edit-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:9999; display:none; align-items:center; justify-content:center;">
    <div style="background:#fff; border-radius:16px; padding:30px; width:400px; box-shadow:0 25px 60px rgba(0,0,0,0.2); position:relative;">
        <div style="font-size:0.7rem; color:#940000; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Edit Allocation</div>
        <h4 style="margin:0 0 20px; color:#1e293b; font-weight:900;" id="edit-title">—</h4>
        <form method="POST">
            <input type="hidden" name="action" value="edit_save">
            <input type="hidden" name="alloc_id" id="edit-alloc-id">
            <div class="fg" style="margin-bottom:14px;">
                <label>New Teacher</label>
                <select name="teacher_id" id="edit-teacher" required>
                    <?php foreach ($teachers as $t): ?>
                        <option value="<?php echo $t['teacher_id']; ?>">Mwl. <?php echo h($t['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="fg" style="margin-bottom:20px;">
                <label>Academic Year</label>
                <input type="text" name="academic_term" id="edit-term" placeholder="2026">
            </div>
            <div style="display:flex; gap:10px;">
                <button type="submit" class="btn-assign" style="flex:1; justify-content:center;">
                    <i class="fas fa-save"></i> Save
                </button>
                <button type="button" onclick="closeEdit()" style="flex:1; background:#f1f5f9; border:none; border-radius:8px; font-weight:700; cursor:pointer; color:#475569;">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(id, teacherId, teacherName, term) {
    document.getElementById('edit-modal').style.display = 'flex';
    document.getElementById('edit-alloc-id').value = id;
    document.getElementById('edit-teacher').value   = teacherId;
    document.getElementById('edit-term').value       = term;
    document.getElementById('edit-title').textContent = 'Mwl. ' + teacherName;
}
function closeEdit() {
    document.getElementById('edit-modal').style.display = 'none';
}
document.getElementById('edit-modal').addEventListener('click', function(e) {
    if (e.target === this) closeEdit();
});
</script>

<?php require_once '../../includes/footer.php'; ?>
