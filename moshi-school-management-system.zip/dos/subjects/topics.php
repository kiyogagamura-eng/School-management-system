<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);

$page_title = "TET Syllabus Topics Manager";

$success = '';
$error = '';

// Handle Adding a Topic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_topic'])) {
    $subject_id = (int)$_POST['subject_id'];
    $form_level = (int)$_POST['form_level'];
    $topic_name = trim($_POST['topic_name']);
    $description = trim($_POST['description'] ?? '');

    if (empty($topic_name) || !$subject_id || !$form_level) {
        $error = "Tafadhali jaza viwanja vyote vya lazima.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO syllabus_topics (subject_id, form_level, topic_name, description)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$subject_id, $form_level, $topic_name, $description]);
            $success = "Mada mpya imeongezwa kikamilifu kwenye muundo wa TET.";
            logActivity($_SESSION['user_id'], 'Added TET Topic', "Added topic '$topic_name' for Subject ID $subject_id Form $form_level");
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Mada hii tayari ipo kwenye somo na kidato hiki.";
            } else {
                $error = "Hitilafu: " . $e->getMessage();
            }
        }
    }
}

// Handle Deleting a Topic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_topic'])) {
    $topic_id = (int)$_POST['delete_topic_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM syllabus_topics WHERE topic_id = ?");
        $stmt->execute([$topic_id]);
        $success = "Mada imefutwa kikamilifu kwenye muundo wa TET.";
        logActivity($_SESSION['user_id'], 'Deleted TET Topic', "Deleted topic ID $topic_id");
    } catch (PDOException $e) {
        $error = "Hitilafu ya kufuta: " . $e->getMessage();
    }
}

// Fetch all subjects for the dropdowns
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY subject_name ASC")->fetchAll();

// Filters for topic viewing
$filter_subject = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : '';
$filter_form = isset($_GET['form_level']) ? (int)$_GET['form_level'] : '';

// Build queries based on filters
$where = "WHERE 1=1";
$params = [];
if ($filter_subject) {
    $where .= " AND st.subject_id = ?";
    $params[] = $filter_subject;
}
if ($filter_form) {
    $where .= " AND st.form_level = ?";
    $params[] = $filter_form;
}

$stmt_topics = $pdo->prepare("
    SELECT st.*, s.subject_name, s.subject_code 
    FROM syllabus_topics st
    JOIN subjects s ON st.subject_id = s.subject_id
    $where
    ORDER BY s.subject_name ASC, st.form_level ASC, st.topic_name ASC
");
$stmt_topics->execute($params);
$topics_list = $stmt_topics->fetchAll();

require_once '../../includes/header.php';
?>
<style>
.topics-container { padding: 25px; background: #f8fafc; min-height: 100vh; }
.header-banner { 
    background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%); 
    backdrop-filter: blur(12px); 
    border: 1px solid rgba(148,0,0,0.15);
    padding: 25px 30px; 
    border-radius: 14px; 
    margin-bottom: 25px; 
    display: flex; 
    align-items: center; 
    justify-content: space-between;
    box-shadow: 0 8px 32px rgba(148,0,0,0.08); 
}
.header-banner h3 { margin: 0; font-weight: 900; color: #1e293b; }
.header-banner p { margin: 4px 0 0; color: #64748b; font-size: 0.85rem; }
.btn-primary-red { background: #940000; color: #fff; padding: 10px 20px; border-radius: 8px; font-weight: 700; border: none; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: background 0.2s; }
.btn-primary-red:hover { background: #7a0000; }
.card-box { background: #fff; border-radius: 12px; padding: 22px; box-shadow: 0 2px 12px rgba(0,0,0,0.04); margin-bottom: 20px; }
.filter-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; margin-bottom: 20px; }
.filter-group { display: flex; flex-direction: column; gap: 5px; }
.filter-group label { font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase; }
.filter-group select, .filter-group input { padding: 9px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; outline: none; background: #fff; }
.topics-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
.topics-table th { background: #fff5f5; color: #940000; padding: 12px 15px; text-align: left; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; border-bottom: 1px solid rgba(148,0,0,0.1); }
.topics-table td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem; }
.badge-form { background: #f1f5f9; color: #475569; padding: 3px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 700; }
.btn-delete-mini { background: none; border: none; color: #ef4444; cursor: pointer; font-size: 0.9rem; transition: color 0.15s; }
.btn-delete-mini:hover { color: #b91c1c; }
.modal-overlay { display: none; position: fixed; z-index: 1000; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.4); backdrop-filter: blur(4px); }
.modal-box { width: 450px; background: #fff; border-radius: 12px; margin: 80px auto; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.15); animation: scaleUp 0.25s ease-out; }
.modal-header { background: #940000; color: #fff; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; font-weight: 800; }
.modal-body { padding: 20px; }
@keyframes scaleUp { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
</style>

<div class="topics-container">
    <div class="header-banner">
        <div>
            <h3><i class="fas fa-book-open"></i> Muundo wa Mada za TET (Syllabus Topics)</h3>
            <p>Sanidi na udhibiti orodha ya mada za masomo kulingana na muundo wa TET kwa ajili ya vipindi vya walimu.</p>
        </div>
        <button class="btn-primary-red" onclick="openAddModal()">
            <i class="fas fa-plus"></i> Weka Mada Mpya
        </button>
    </div>

    <?php if ($success): ?>
        <div style="background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 600;">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div style="background: #fff5f5; color: #940000; border: 1px solid #fecaca; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 600;">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
        </div>
    <?php endif; ?>

    <!-- Search / Filter Card -->
    <div class="card-box">
        <form method="GET" class="filter-row">
            <div class="filter-group" style="min-width: 200px;">
                <label for="subject_id">Somo (Subject)</label>
                <select name="subject_id" id="subject_id" onchange="this.form.submit()">
                    <option value="">-- Masomo Yote --</option>
                    <?php foreach ($subjects as $sub): ?>
                        <option value="<?php echo $sub['subject_id']; ?>" <?php echo $filter_subject == $sub['subject_id'] ? 'selected' : ''; ?>>
                            <?php echo h($sub['subject_name']); ?> (<?php echo h($sub['subject_code']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group" style="min-width: 150px;">
                <label for="form_level">Kidato (Form Level)</label>
                <select name="form_level" id="form_level" onchange="this.form.submit()">
                    <option value="">-- Vidato Vyote --</option>
                    <?php for ($f = 1; $f <= 6; $f++): ?>
                        <option value="<?php echo $f; ?>" <?php echo $filter_form == $f ? 'selected' : ''; ?>>
                            Kidato cha <?php echo $f; ?> (Form <?php echo $f; ?>)
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="filter-group">
                <?php if ($filter_subject || $filter_form): ?>
                    <a href="topics.php" style="background:#f1f5f9; color:#475569; padding: 10px 15px; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 700; border: 1px solid #cbd5e1; display: inline-block;">
                        ✕ Safisha Mchujo
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Topics List Card -->
    <div class="card-box table-responsive">
        <div style="font-size:0.75rem; font-weight:800; color:#940000; text-transform:uppercase; letter-spacing:1px; margin-bottom:15px;">
            <i class="fas fa-list me-1"></i> Orodha ya Mada (Zilizopatikana: <?php echo count($topics_list); ?>)
        </div>
        
        <?php if (empty($topics_list)): ?>
            <div style="text-align: center; padding: 50px 20px; color: #94a3b8;">
                <i class="fas fa-book" style="font-size: 3rem; opacity: 0.15; display: block; margin-bottom: 15px;"></i>
                Hakuna mada zozote zilizopatikana kulingana na mchujo huu.
            </div>
        <?php else: ?>
            <table class="topics-table">
                <thead>
                    <tr>
                        <th style="width: 250px;">Somo</th>
                        <th style="width: 120px;">Kidato</th>
                        <th>Jina la Mada (TET Topic)</th>
                        <th>Maelezo (Description)</th>
                        <th style="width: 80px; text-align: center;">Hatua</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topics_list as $tp): ?>
                        <tr>
                            <td><strong><?php echo h($tp['subject_name']); ?></strong> <span style="font-size: 0.75rem; color:#888;">(<?php echo h($tp['subject_code']); ?>)</span></td>
                            <td><span class="badge-form">Kidato cha <?php echo $tp['form_level']; ?></span></td>
                            <td style="font-weight: 700; color: #1e293b;"><?php echo h($tp['topic_name']); ?></td>
                            <td style="color:#64748b; font-size: 0.8rem;"><?php echo h($tp['description'] ?: '—'); ?></td>
                            <td style="text-align: center;">
                                <form method="POST" onsubmit="return confirm('Je, una uhakika unataka kufuta mada hii ya TET?');" style="display:inline;">
                                    <input type="hidden" name="delete_topic_id" value="<?php echo $tp['topic_id']; ?>">
                                    <button type="submit" name="delete_topic" class="btn-delete-mini" title="Futa Mada">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Add Topic Modal -->
<div id="addTopicModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <span><i class="fas fa-plus-circle me-1"></i> Weka Mada Mpya ya TET</span>
            <span style="cursor:pointer; font-size: 1.5rem;" onclick="closeAddModal()">&times;</span>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group" style="margin-bottom: 15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-size: 0.75rem; font-weight:700; color:#475569;">SOMO *</label>
                    <select name="subject_id" required style="padding:10px; border:1px solid #e2e8f0; border-radius:8px;">
                        <option value="">-- Chagua Somo --</option>
                        <?php foreach ($subjects as $sub): ?>
                            <option value="<?php echo $sub['subject_id']; ?>">
                                <?php echo h($sub['subject_name']); ?> (<?php echo h($sub['subject_code']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-size: 0.75rem; font-weight:700; color:#475569;">KIDATO (FORM LEVEL) *</label>
                    <select name="form_level" required style="padding:10px; border:1px solid #e2e8f0; border-radius:8px;">
                        <option value="">-- Chagua Kidato --</option>
                        <?php for ($f = 1; $f <= 6; $f++): ?>
                            <option value="<?php echo $f; ?>">Form <?php echo $f; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-size: 0.75rem; font-weight:700; color:#475569;">JINA LA MADA (TOPIC) *</label>
                    <input type="text" name="topic_name" placeholder="Mh. Linear Equations, Ufugaji, nk." required style="padding:10px; border:1px solid #e2e8f0; border-radius:8px;">
                </div>
                <div class="form-group" style="margin-bottom: 20px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-size: 0.75rem; font-weight:700; color:#475569;">MAELEZO YA NYongeza</label>
                    <textarea name="description" rows="3" placeholder="Maelezo fupi ya mada (hiari)" style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; resize:none;"></textarea>
                </div>
                <button type="submit" name="add_topic" class="btn-primary-red" style="width: 100%; justify-content: center; padding: 12px;">
                    <i class="fas fa-save me-1"></i> HIFADHI MADA
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('addTopicModal').style.display = 'block';
}
function closeAddModal() {
    document.getElementById('addTopicModal').style.display = 'none';
}
// Close modals on overlay click
window.addEventListener('click', function(event) {
    const modal = document.getElementById('addTopicModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});
</script>

<?php require_once '../../includes/footer.php'; ?>
