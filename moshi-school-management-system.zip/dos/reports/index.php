<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);
$page_title = "Reports Center";
require_once '../../includes/header.php';
?>
<style>
.reports-container { padding:30px; background:#f8fafc; min-height:100vh; }
.reports-header { background:#fff; color:#1e293b; padding:24px 26px; border-radius:14px; margin-bottom:30px; display:flex; align-items:center; gap:16px; border:1px solid #f0f2f5; box-shadow:0 2px 12px rgba(0,0,0,0.04); }
.rep-icon { color:#8b0000; font-size:1.6rem; display:flex; align-items:center; flex-shrink:0; }
.reports-header h3 { margin:0 0 4px; font-weight:800; font-size:1.35rem; color:#8b0000; line-height:1.2; }
.reports-header p { margin:0; color:#94a3b8; font-size:0.84rem; font-weight:400; line-height:1.4; }
.report-card { background:#fff; border-radius:12px; padding:25px; box-shadow:0 4px 15px rgba(0,0,0,0.05); display:flex; flex-direction:column; align-items:center; text-align:center; text-decoration:none; color:#1e293b; transition:all 0.3s; border-bottom:4px solid transparent; }
.report-card:hover { transform:translateY(-5px); box-shadow:0 8px 25px rgba(148,0,0,0.15); border-bottom-color:#940000; }
.rep-card-icon { width:70px; height:70px; background:#fff5f5; color:#940000; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.8rem; margin-bottom:18px; transition:all 0.3s; }
.report-card:hover .rep-card-icon { background:#940000; color:#fff; }
.rep-card-title { font-weight:800; font-size:1.1rem; margin-bottom:8px; }
.rep-card-desc { font-size:0.82rem; color:#64748b; line-height:1.5; }
.section-label { font-size:0.7rem; font-weight:800; color:#940000; text-transform:uppercase; letter-spacing:1.5px; margin:25px 0 15px; padding-left:5px; border-left:3px solid #940000; padding-left:10px; }
</style>

<div class="reports-container">
    <div class="reports-header">
        <span class="rep-icon"><i class="fas fa-chart-pie"></i></span>
        <div>
            <h3>DOS Reports Center</h3>
            <p>Access all academic reporting tools — class reports, subject analysis, teacher performance, and school-wide stats.</p>
        </div>
    </div>

    <div class="section-label">Academic Performance Reports</div>
    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:20px; margin-bottom:30px;">
        <a href="<?php echo BASE_URL; ?>admin/results/school-stats.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-school"></i></div>
            <div class="rep-card-title">School Overview</div>
            <div class="rep-card-desc">Overall division distribution, GPA trends, and pass rates for the entire school.</div>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/results/class-stats.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-users"></i></div>
            <div class="rep-card-title">Class Performance</div>
            <div class="rep-card-desc">Per-class academic breakdown with student rankings and averages by form/stream.</div>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/results/subject-stats.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-book-open"></i></div>
            <div class="rep-card-title">Subject Analytics</div>
            <div class="rep-card-desc">Subject-by-subject pass rate comparison and grade distribution analysis.</div>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/results/student-report.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-user-graduate"></i></div>
            <div class="rep-card-title">Student Report Cards</div>
            <div class="rep-card-desc">View individual terminal report cards for any student in the school.</div>
        </a>
    </div>

    <div class="section-label">Academic Supervision Reports</div>
    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:20px;">
        <a href="<?php echo BASE_URL; ?>dos/period-log/index.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-clipboard-check"></i></div>
            <div class="rep-card-title">Period Coverage</div>
            <div class="rep-card-desc">Daily period logbook — track taught, missed, and substituted periods by teacher.</div>
        </a>
        <a href="<?php echo BASE_URL; ?>dos/lesson-plans/index.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-folder-open"></i></div>
            <div class="rep-card-title">Lesson Plans Status</div>
            <div class="rep-card-desc">Overview of lesson plan submissions — pending, approved, and rejected counts.</div>
        </a>
        <a href="<?php echo BASE_URL; ?>dos/analytics/index.php" class="report-card">
            <div class="rep-card-icon"><i class="fas fa-chart-line"></i></div>
            <div class="rep-card-title">Academic Analytics</div>
            <div class="rep-card-desc">Teacher performance leaderboard, subject rankings, and grade distribution analysis.</div>
        </a>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
