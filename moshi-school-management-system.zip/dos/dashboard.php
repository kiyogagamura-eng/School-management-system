<?php
require_once '../includes/bootstrap.php';
requireRole(['dos', 'admin']);
$page_title = 'Academic Master Dashboard';

// ── Stats ──────────────────────────────────────────────────
try {
    $total_subjects  = $pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
    $total_teachers  = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status='Active'")->fetchColumn();
    $total_classes   = $pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
    $total_students  = $pdo->query("SELECT COUNT(*) FROM students WHERE status='Active'")->fetchColumn();

    $pending_plans   = $pdo->query("SELECT COUNT(*) FROM lesson_plans WHERE status='pending'")->fetchColumn();
    $pending_results = $pdo->query("SELECT COUNT(*) FROM results WHERE status='submitted'")->fetchColumn();
    $pending_results_approval = $pdo->query("SELECT COUNT(DISTINCT e.exam_id) FROM exams e JOIN results r ON r.exam_id=e.exam_id WHERE r.status='submitted'")->fetchColumn();

    // Today's period coverage
    $total_periods  = $pdo->query("SELECT COUNT(*) FROM period_logs WHERE log_date=CURDATE()")->fetchColumn();
    $taught_periods = $pdo->query("SELECT COUNT(*) FROM period_logs WHERE log_date=CURDATE() AND status='taught'")->fetchColumn();
    $missed_periods = $pdo->query("SELECT COUNT(*) FROM period_logs WHERE log_date=CURDATE() AND status='missed'")->fetchColumn();

    // Attendance today
    $att_today = $pdo->query("SELECT ROUND((SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END)/COUNT(*))*100) FROM attendance WHERE attendance_date=CURDATE()")->fetchColumn();

    // Recent lesson plan submissions
    $recent_plans = $pdo->query("
        SELECT lp.title, lp.status, lp.created_at, lp.plan_type,
               CONCAT(t.first_name,' ',t.last_name) as teacher_name,
               s.subject_name, c.class_name
        FROM lesson_plans lp
        JOIN teachers t ON lp.teacher_id=t.teacher_id
        JOIN subjects s ON lp.subject_id=s.subject_id
        JOIN classes c ON lp.class_id=c.class_id
        ORDER BY lp.created_at DESC LIMIT 5
    ")->fetchAll();

    // Upcoming exams (next 7 days)
    $upcoming_exams = $pdo->query("
        SELECT es.exam_name, es.exam_type, es.exam_date, es.start_time, es.venue,
               c.class_name, s.subject_name
        FROM exam_schedule es
        LEFT JOIN classes c ON es.class_id=c.class_id
        LEFT JOIN subjects s ON es.subject_id=s.subject_id
        WHERE es.exam_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
        ORDER BY es.exam_date ASC, es.start_time ASC
        LIMIT 6
    ")->fetchAll();

    // Subject pass rates (top 5)
    $sub_pass = $pdo->query("
        SELECT s.subject_name,
               COUNT(r.result_id) as total,
               SUM(CASE WHEN gs.point_value<=4 THEN 1 ELSE 0 END) as passed
        FROM results r
        JOIN exams e ON r.exam_id=e.exam_id
        JOIN subjects s ON r.subject_id=s.subject_id
        JOIN grading_scale gs ON r.grade=gs.grade
        WHERE r.status='published'
        GROUP BY r.subject_id
        ORDER BY SUM(CASE WHEN gs.point_value<=4 THEN 1 ELSE 0 END)/COUNT(r.result_id) DESC
        LIMIT 5
    ")->fetchAll();

} catch(Exception $e) {
    $total_subjects=$total_teachers=$total_classes=$total_students=0;
    $pending_plans=$pending_results=$total_periods=$taught_periods=$missed_periods=0;
    $att_today=0; $recent_plans=[]; $upcoming_exams=[]; $sub_pass=[];
}

// Fetch SMS Balance (from NextSMS)
$sms_balance = "0 TZS";
$credits_remaining = "0 SMS";
$sms_status = "OFFLINE";
$sms_status_color = "#ef4444";

try {
    $url = 'https://messaging-service.co.tz/api/sms/v1/balance';
    $credentials = base64_encode(NEXTSMS_USERNAME . ':' . NEXTSMS_PASSWORD);
        
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPGET        => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Basic ' . $credentials,
            'Accept: application/json'
        ],
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
    ]);
    $api_response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($api_response, true);
        if (isset($data['sms_balance'])) {
            $sms_balance = ($data['sms_balance'] * 16) . " TZS";
            $credits_remaining = $data['sms_balance'] . " SMS";
            $sms_status = "ONLINE";
            $sms_status_color = "#22c55e";
        } elseif (isset($data['balance'])) {
            $sms_balance = ($data['balance'] * 16) . " TZS";
            $credits_remaining = $data['balance'] . " SMS";
            $sms_status = "ONLINE";
            $sms_status_color = "#22c55e";
        }
    }
} catch (Exception $e) {}

$coverage_rate = $total_periods > 0 ? round(($taught_periods/$total_periods)*100) : 0;

require_once '../includes/header.php';
?>
<style>
.dos-dash { padding: 25px; background: #f8fafc; min-height: 100vh; }
.welcome-banner {
    background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    color: #1e293b; padding: 28px 30px; border-radius: 16px; margin-bottom: 28px;
    display: flex; align-items: center; gap: 20px;
    border: 1px solid rgba(148,0,0,0.15);
    box-shadow: 0 8px 32px rgba(148,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04);
}
.welcome-avatar {
    width: 60px; height: 60px; border-radius: 14px;
    background: linear-gradient(135deg, #940000, #c0392b);
    display: flex; align-items: center;
    justify-content: center; font-size: 1.8rem; color: #fff; flex-shrink: 0;
    box-shadow: 0 4px 15px rgba(148,0,0,0.3);
}
.stats-row { display: grid; grid-template-columns: repeat(5,1fr); gap: 15px; margin-bottom: 25px; }
.stat-card {
    background: #fff; border-radius: 12px; padding: 18px 20px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.05); display: flex; align-items: center;
    gap: 15px; border-bottom: 4px solid transparent; transition: all 0.2s;
}
.stat-card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,0.1); }
.stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; }
.stat-num { font-size: 1.6rem; font-weight: 900; line-height: 1; color: #1e293b; }
.stat-label { font-size: 0.68rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-top: 3px; }

.card-box { background: #fff; border-radius: 12px; padding: 22px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); margin-bottom: 20px; }
.sec-title { font-size: 0.72rem; font-weight: 800; color: #940000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }

.action-btn { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 18px 10px; border: 1px solid #f1f5f9; border-radius: 10px; text-decoration: none; color: #1e293b; transition: all 0.2s; text-align: center; gap: 8px; }
.action-btn:hover { border-color: #940000; background: #fff5f5; color: #940000; transform: translateY(-2px); }
.action-btn i { font-size: 1.4rem; }
.action-btn span { font-size: 0.75rem; font-weight: 700; line-height: 1.2; }

.plan-row { display: flex; align-items: center; justify-content: space-between; padding: 11px 15px; border-radius: 8px; background: #f8fafc; margin-bottom: 8px; }
.badge-pend  { background: #fffbeb; color: #92400e; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }
.badge-appr  { background: #f0fdf4; color: #166534; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }
.badge-rej   { background: #fff5f5; color: #940000; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }

.exam-row { display: flex; align-items: center; gap: 15px; padding: 12px 15px; border-radius: 8px; background: #f8fafc; margin-bottom: 8px; }
.exam-date-badge { min-width: 48px; text-align: center; background: #940000; color: #fff; border-radius: 8px; padding: 6px 8px; }
.exam-date-badge .day { font-size: 1.2rem; font-weight: 900; line-height: 1; }
.exam-date-badge .mon { font-size: 0.65rem; font-weight: 700; }

.progress-bg { background: #f1f5f9; border-radius: 10px; height: 9px; overflow: hidden; }
.progress-fill { height: 9px; border-radius: 10px; transition: width 1s ease; }
</style>

<div class="dos-dash">
    <!-- Welcome Banner -->
    <div class="welcome-banner">
        <div class="welcome-avatar"><i class="fas fa-user-tie"></i></div>
        <div style="flex:1;">
            <div style="font-size:0.75rem; color:#94a3b8; font-weight:700; text-transform:uppercase; letter-spacing:1px;">Academic Master Panel</div>
            <h3 style="margin:4px 0 2px; font-weight:900; font-size:1.4rem;">Welcome, <?php echo h($username); ?></h3>
            <p style="margin:0; color:#94a3b8; font-size:0.85rem;"><?php echo date('l, d F Y'); ?> — <?php echo h(APP_NAME); ?></p>
        </div>
        <div style="text-align:right;">
            <?php if($pending_plans > 0): ?>
            <a href="<?php echo BASE_URL; ?>dos/lesson-plans/index.php?status=pending" style="background:rgba(245,158,11,0.15); border:1px solid rgba(245,158,11,0.3); color:#fbbf24; padding:10px 18px; border-radius:8px; text-decoration:none; font-weight:700; font-size:0.85rem; display:inline-flex; align-items:center; gap:8px;">
                <i class="fas fa-folder-open"></i> <?php echo $pending_plans; ?> Plans Pending Review
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="stats-row">
        <div class="stat-card" style="border-bottom-color:#940000;">
            <div class="stat-icon" style="background:#fff5f5; color:#940000;"><i class="fas fa-book"></i></div>
            <div><div class="stat-num"><?php echo $total_subjects; ?></div><div class="stat-label">Subjects</div></div>
        </div>
        <div class="stat-card" style="border-bottom-color:#940000;">
            <div class="stat-icon" style="background:#fff5f5; color:#940000;"><i class="fas fa-chalkboard-teacher"></i></div>
            <div><div class="stat-num"><?php echo $total_teachers; ?></div><div class="stat-label">Teachers</div></div>
        </div>
        <div class="stat-card" style="border-bottom-color:#940000;">
            <div class="stat-icon" style="background:#fff5f5; color:#940000;"><i class="fas fa-school"></i></div>
            <div><div class="stat-num"><?php echo $total_classes; ?></div><div class="stat-label">Classes</div></div>
        </div>
        <div class="stat-card" style="border-bottom-color:#f59e0b;">
            <div class="stat-icon" style="background:#fffbeb; color:#f59e0b;"><i class="fas fa-folder-open"></i></div>
            <div><div class="stat-num"><?php echo $pending_plans; ?></div><div class="stat-label">Pending Plans</div></div>
        </div>
        <div class="stat-card" style="border-bottom-color:#f59e0b;">
            <div class="stat-icon" style="background:#fffbeb; color:#f59e0b;"><i class="fas fa-poll"></i></div>
            <div><div class="stat-num"><?php echo $pending_results; ?></div><div class="stat-label">Pending Results</div></div>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:2fr 1.1fr; gap:22px;">
        <!-- LEFT COLUMN -->
        <div>
            <!-- Quick Actions -->
            <div class="card-box">
                <div class="sec-title"><i class="fas fa-bolt"></i> Quick Actions</div>
                <div style="display:grid; grid-template-columns:repeat(6,1fr); gap:10px;">
                    <a href="<?php echo BASE_URL; ?>admin/subjects/index.php" class="action-btn">
                        <i class="fas fa-book" style="color:#940000;"></i><span>Subject Mgmt</span>
                    </a>
                    <a href="<?php echo BASE_URL; ?>dos/subjects/allocate.php" class="action-btn">
                        <i class="fas fa-user-tag" style="color:#3b82f6;"></i><span>Allocate Teachers</span>
                    </a>
                    <a href="<?php echo BASE_URL; ?>dos/subjects/topics.php" class="action-btn">
                        <i class="fas fa-book-open" style="color:#d946ef;"></i><span>TET Topics</span>
                    </a>
                    <a href="<?php echo BASE_URL; ?>dos/examination/index.php" class="action-btn">
                        <i class="fas fa-file-signature" style="color:#8b5cf6;"></i><span>Examinations</span>
                    </a>
                    <a href="<?php echo BASE_URL; ?>admin/results/compile.php" class="action-btn">
                        <i class="fas fa-check-double" style="color:#10b981;"></i><span>Publish Results</span>
                    </a>
                    <a href="<?php echo BASE_URL; ?>dos/analytics/index.php" class="action-btn">
                        <i class="fas fa-chart-line" style="color:#f59e0b;"></i><span>Analytics</span>
                    </a>
                </div>
            </div>

            <!-- Recent Lesson Plans -->
            <div class="card-box">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                    <div class="sec-title" style="margin-bottom:0;"><i class="fas fa-folder-open"></i> Recent Lesson Plan Submissions</div>
                    <a href="<?php echo BASE_URL; ?>dos/lesson-plans/index.php" style="font-size:0.78rem; color:#940000; font-weight:700; text-decoration:none;">View All →</a>
                </div>
                <?php if(empty($recent_plans)): ?>
                    <div style="text-align:center; padding:40px 20px; color:#94a3b8;">
                        <i class="fas fa-folder" style="font-size:2rem; opacity:0.15; display:block; margin-bottom:10px;"></i>
                        No lesson plans submitted yet.
                    </div>
                <?php else: ?>
                    <?php foreach($recent_plans as $plan):
                        $badge = match($plan['status']) { 'approved'=>'badge-appr','rejected'=>'badge-rej',default=>'badge-pend' };
                    ?>
                    <div class="plan-row">
                        <div style="flex:1;">
                            <div style="font-weight:700; color:#1e293b; font-size:0.88rem;"><?php echo h($plan['title']); ?></div>
                            <div style="font-size:0.75rem; color:#64748b; margin-top:2px;">
                                <?php echo h($plan['teacher_name']); ?> &nbsp;·&nbsp; <?php echo h($plan['class_name']); ?> &nbsp;·&nbsp; <?php echo h($plan['subject_name']); ?>
                            </div>
                        </div>
                        <div style="display:flex; flex-direction:column; align-items:flex-end; gap:4px; flex-shrink:0;">
                            <span class="<?php echo $badge; ?>"><?php echo ucfirst($plan['status']); ?></span>
                            <span style="font-size:0.68rem; color:#94a3b8;"><?php echo date('d M', strtotime($plan['created_at'])); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Subject Pass Rate Mini -->
            <div class="card-box">
                <div class="sec-title"><i class="fas fa-chart-bar"></i> Subject Pass Rate Overview</div>
                <?php if(empty($sub_pass)): ?>
                    <p style="color:#94a3b8; text-align:center; padding:20px 0;">No published results yet.</p>
                <?php else: ?>
                    <?php foreach($sub_pass as $sp):
                        $rate = $sp['total'] > 0 ? round(($sp['passed']/$sp['total'])*100) : 0;
                        $col = $rate>=70?'#22c55e':($rate>=40?'#f59e0b':'#ef4444');
                    ?>
                    <div style="margin-bottom:12px;">
                        <div style="display:flex; justify-content:space-between; font-size:0.82rem; font-weight:700; margin-bottom:5px;">
                            <span><?php echo h($sp['subject_name']); ?></span>
                            <span style="color:<?php echo $col; ?>"><?php echo $rate; ?>%</span>
                        </div>
                        <div class="progress-bg"><div class="progress-fill" style="width:<?php echo $rate; ?>%; background:<?php echo $col; ?>;"></div></div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div>
            <!-- Period Coverage Today -->
            <div class="card-box">
                <div class="sec-title"><i class="fas fa-clipboard-check"></i> Today's Period Coverage</div>
                <div style="text-align:center; margin-bottom:18px;">
                    <div style="font-size:3rem; font-weight:900; color:<?php echo $coverage_rate>=70?'#22c55e':($coverage_rate>=40?'#f59e0b':'#ef4444'); ?>;">
                        <?php echo $coverage_rate; ?>%
                    </div>
                    <div style="font-size:0.78rem; color:#64748b; font-weight:700; margin-top:4px;">Coverage Rate</div>
                    <div class="progress-bg" style="margin-top:12px;">
                        <div class="progress-fill" style="width:<?php echo $coverage_rate; ?>%; background:<?php echo $coverage_rate>=70?'#22c55e':($coverage_rate>=40?'#f59e0b':'#ef4444'); ?>;"></div>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; text-align:center;">
                    <div style="background:#f0fdf4; border-radius:8px; padding:10px;">
                        <div style="font-size:1.3rem; font-weight:900; color:#22c55e;"><?php echo $taught_periods; ?></div>
                        <div style="font-size:0.65rem; color:#64748b; font-weight:700;">Taught</div>
                    </div>
                    <div style="background:#fff5f5; border-radius:8px; padding:10px;">
                        <div style="font-size:1.3rem; font-weight:900; color:#ef4444;"><?php echo $missed_periods; ?></div>
                        <div style="font-size:0.65rem; color:#64748b; font-weight:700;">Missed</div>
                    </div>
                    <div style="background:#f8fafc; border-radius:8px; padding:10px;">
                        <div style="font-size:1.3rem; font-weight:900; color:#64748b;"><?php echo $total_periods; ?></div>
                        <div style="font-size:0.65rem; color:#64748b; font-weight:700;">Total</div>
                    </div>
                </div>
                <a href="<?php echo BASE_URL; ?>dos/period-log/index.php" style="display:block; text-align:center; margin-top:14px; color:#940000; font-size:0.8rem; font-weight:700; text-decoration:none;">View Full Logbook →</a>
            </div>

            <!-- Upcoming Exams -->
            <div class="card-box">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                    <div class="sec-title" style="margin-bottom:0;"><i class="fas fa-calendar-alt"></i> Upcoming Exams (7 days)</div>
                    <a href="<?php echo BASE_URL; ?>dos/examination/index.php" style="font-size:0.78rem; color:#940000; font-weight:700; text-decoration:none;">Manage →</a>
                </div>
                <?php if(empty($upcoming_exams)): ?>
                    <div style="text-align:center; padding:30px 20px; color:#94a3b8;">
                        <i class="fas fa-calendar-times" style="font-size:2rem; opacity:0.15; display:block; margin-bottom:10px;"></i>
                        No exams in the next 7 days.
                    </div>
                <?php else: ?>
                    <?php foreach($upcoming_exams as $ex): ?>
                    <div class="exam-row">
                        <div class="exam-date-badge">
                            <div class="day"><?php echo date('d', strtotime($ex['exam_date'])); ?></div>
                            <div class="mon"><?php echo strtoupper(date('M', strtotime($ex['exam_date']))); ?></div>
                        </div>
                        <div style="flex:1; min-width:0;">
                            <div style="font-weight:700; font-size:0.85rem; color:#1e293b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?php echo h($ex['exam_name']); ?></div>
                            <div style="font-size:0.73rem; color:#64748b; margin-top:2px;">
                                <?php echo h($ex['class_name'] ?? 'All'); ?> &nbsp;·&nbsp; <?php echo $ex['start_time'] ? date('H:i', strtotime($ex['start_time'])) : 'Time TBD'; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Attendance Today -->
            <div class="card-box" style="text-align:center; margin-bottom: 20px;">
                <div class="sec-title" style="justify-content:center;"><i class="fas fa-calendar-check"></i> Student Attendance Today</div>
                <div style="font-size:3.5rem; font-weight:900; color:<?php echo ($att_today>=80?'#22c55e':($att_today>=60?'#f59e0b':'#ef4444')); ?>;">
                    <?php echo $att_today ? $att_today.'%' : 'N/A'; ?>
                </div>
                <div style="font-size:0.78rem; color:#64748b; font-weight:700; margin-top:5px;"><?php echo date('d F Y'); ?></div>
            </div>

            <!-- SMS Gateway Balance Widget -->
            <div class="card-box">
                <div class="sec-title"><i class="fas fa-sms"></i> SMS Gateway Status</div>
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
                    <span style="font-size:0.82rem; color:#64748b; font-weight:700;">Gateway Connection</span>
                    <span style="background:<?php echo $sms_status_color; ?>15; color:<?php echo $sms_status_color; ?>; padding:3px 10px; border-radius:12px; font-size:0.75rem; font-weight:800; display:inline-flex; align-items:center; gap:5px;">
                        <span style="display:inline-block; width:6px; height:6px; background:<?php echo $sms_status_color; ?>; border-radius:50%;"></span>
                        <?php echo $sms_status; ?>
                    </span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:8px; border-bottom:1px solid #f1f5f9; padding-bottom:8px;">
                    <span style="font-size:0.82rem; color:#64748b; font-weight:700;">Remaining Balance</span>
                    <span style="font-size:1.15rem; font-weight:900; color:#8b0000;"><?php echo $sms_balance; ?></span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:baseline;">
                    <span style="font-size:0.78rem; color:#94a3b8;">SMS Remaining</span>
                    <span style="font-size:0.85rem; font-weight:700; color:#64748b;"><?php echo $credits_remaining; ?></span>
                </div>
                <div style="margin-top: 15px; border-top: 1px solid #f1f5f9; padding-top: 10px; text-align: center;">
                    <a href="<?php echo BASE_URL; ?>admin/communication/index.php" style="color: #940000; font-size:0.78rem; font-weight:700; text-decoration:none;"><i class="fas fa-paper-plane"></i> Send SMS Announcements</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
