<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);

$page_title = "Period Logbook";

// Filters
$filter_date    = $_GET['date']    ?? date('Y-m-d');
$filter_class   = $_GET['class_id'] ?? '';
$filter_teacher = $_GET['teacher_id'] ?? '';
$filter_status  = $_GET['status']  ?? '';

// Build query
$where = "WHERE pl.log_date = ?";
$params = [$filter_date];
if ($filter_class)   { $where .= " AND pl.class_id = ?";   $params[] = $filter_class; }
if ($filter_teacher) { $where .= " AND pl.teacher_id = ?"; $params[] = $filter_teacher; }
if ($filter_status)  { $where .= " AND pl.status = ?";     $params[] = $filter_status; }

$stmt = $pdo->prepare("
    SELECT pl.*, 
           CONCAT(t.first_name,' ',t.last_name) as teacher_name,
           c.class_name, s.subject_name
    FROM period_logs pl
    JOIN teachers t ON pl.teacher_id = t.teacher_id
    JOIN classes c ON pl.class_id = c.class_id
    JOIN subjects s ON pl.subject_id = s.subject_id
    $where
    ORDER BY pl.signed_at DESC
");
$stmt->execute($params);
$logs = $stmt->fetchAll();

// Daily summary stats
$total   = count($logs);
$taught  = count(array_filter($logs, fn($l) => $l['status'] == 'taught'));
$missed  = count(array_filter($logs, fn($l) => $l['status'] == 'missed'));
$covered = count(array_filter($logs, fn($l) => $l['status'] == 'covered_by_other'));
$rate    = $total > 0 ? round(($taught / $total) * 100) : 0;

// Weekly trends (last 7 days)
$weekly = $pdo->query("
    SELECT log_date, 
           SUM(status='taught') as taught,
           SUM(status='missed') as missed,
           COUNT(*) as total
    FROM period_logs
    WHERE log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY log_date ORDER BY log_date ASC
")->fetchAll();

// Dropdown data
$classes  = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream")->fetchAll();
$teachers = $pdo->query("SELECT * FROM teachers ORDER BY first_name")->fetchAll();

require_once '../../includes/header.php';
?>
<style>
.log-container { padding: 25px; background: #f8fafc; min-height: 100vh; }
.log-header { background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color: #1e293b; padding: 25px 30px; border-radius: 14px; margin-bottom: 25px; display: flex; align-items: center; gap: 20px; border: 1px solid rgba(148,0,0,0.15); box-shadow: 0 8px 32px rgba(148,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04); }
.log-header .icon { background: linear-gradient(135deg, #940000, #c0392b); width: 55px; height: 55px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; box-shadow: 0 4px 15px rgba(148,0,0,0.3); }
.card-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
.stat-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 15px; margin-bottom: 25px; }
.stat-card { border-radius: 12px; padding: 20px; text-align: center; }
.stat-card.taught  { background: #f0fdf4; border-left: 4px solid #22c55e; }
.stat-card.missed  { background: #fff5f5; border-left: 4px solid #ef4444; }
.stat-card.covered { background: #eff6ff; border-left: 4px solid #3b82f6; }
.stat-card.rate    { background: #fdf4ff; border-left: 4px solid #a855f7; }
.stat-num { font-size: 2rem; font-weight: 900; }
.stat-label { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin-top: 4px; }
.filter-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
.filter-row input, .filter-row select { padding: 9px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; outline: none; }
.log-table { width: 100%; border-collapse: collapse; }
.log-table th { background: #f8fafc; padding: 11px 15px; text-align: left; font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; }
.log-table td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.87rem; }
.badge-taught   { background: #f0fdf4; color: #166534; padding: 3px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; }
.badge-missed   { background: #fff5f5; color: #940000; padding: 3px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; }
.badge-covered  { background: #eff6ff; color: #1d4ed8; padding: 3px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; }
.section-title { font-size: 0.75rem; font-weight: 800; color: #940000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 18px; }
.progress-bar-bg { background: #f1f5f9; border-radius: 10px; height: 10px; overflow: hidden; }
.progress-bar-fill { background: linear-gradient(90deg, #22c55e, #16a34a); border-radius: 10px; height: 10px; transition: width 1s ease; }
</style>

<div class="log-container">
    <!-- Header -->
    <div class="log-header">
        <div class="icon"><i class="fas fa-clipboard-check"></i></div>
        <div style="flex:1;">
            <h3 style="margin:0; font-weight:900;">Period Logbook</h3>
            <p style="margin:4px 0 0; color:#94a3b8; font-size:0.9rem;">Monitor daily period coverage — taught, missed, and substituted periods</p>
        </div>
        <div style="text-align:right;">
            <div style="font-size:2rem; font-weight:900; color:#34d399;"><?php echo $rate; ?>%</div>
            <div style="font-size:0.75rem; color:#94a3b8;">Today's Coverage</div>
        </div>
    </div>

    <!-- Stats -->
    <div class="stat-grid">
        <div class="stat-card taught">
            <div class="stat-num" style="color:#22c55e;"><?php echo $taught; ?></div>
            <div class="stat-label">Periods Taught</div>
        </div>
        <div class="stat-card missed">
            <div class="stat-num" style="color:#ef4444;"><?php echo $missed; ?></div>
            <div class="stat-label">Periods Missed</div>
        </div>
        <div class="stat-card covered">
            <div class="stat-num" style="color:#3b82f6;"><?php echo $covered; ?></div>
            <div class="stat-label">Covered by Other</div>
        </div>
        <div class="stat-card rate">
            <div class="stat-num" style="color:#a855f7;"><?php echo $total; ?></div>
            <div class="stat-label">Total Logged</div>
        </div>
    </div>

    <!-- Progress Bar -->
    <?php if($total > 0): ?>
    <div class="card-box" style="padding: 20px 25px;">
        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:0.82rem; font-weight:700; color:#64748b;">
            <span>Period Coverage Rate for <?php echo date('d M Y', strtotime($filter_date)); ?></span>
            <span style="color:#22c55e;"><?php echo $taught; ?>/<?php echo $total; ?> periods</span>
        </div>
        <div class="progress-bar-bg">
            <div class="progress-bar-fill" style="width:<?php echo $rate; ?>%;"></div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filters + Table -->
    <div class="card-box">
        <form method="GET" class="filter-row" style="margin-bottom:20px;">
            <input type="date" name="date" value="<?php echo $filter_date; ?>" onchange="this.form.submit()">
            <select name="class_id" onchange="this.form.submit()">
                <option value="">All Classes</option>
                <?php foreach($classes as $c): ?>
                    <option value="<?php echo $c['class_id']; ?>" <?php echo $filter_class==$c['class_id']?'selected':''; ?>><?php echo h($c['class_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="teacher_id" onchange="this.form.submit()">
                <option value="">All Teachers</option>
                <?php foreach($teachers as $t): ?>
                    <option value="<?php echo $t['teacher_id']; ?>" <?php echo $filter_teacher==$t['teacher_id']?'selected':''; ?>><?php echo h($t['first_name'].' '.$t['last_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="status" onchange="this.form.submit()">
                <option value="">All Status</option>
                <option value="taught"            <?php echo $filter_status=='taught'?'selected':''; ?>>Taught</option>
                <option value="missed"            <?php echo $filter_status=='missed'?'selected':''; ?>>Missed</option>
                <option value="covered_by_other"  <?php echo $filter_status=='covered_by_other'?'selected':''; ?>>Covered by Other</option>
            </select>
            <?php if($filter_class||$filter_teacher||$filter_status): ?>
                <a href="?date=<?php echo $filter_date; ?>" style="color:#940000; font-weight:700; font-size:0.82rem; text-decoration:none;">✕ Clear</a>
            <?php endif; ?>
        </form>

        <?php if(empty($logs)): ?>
            <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                <i class="fas fa-clipboard-list" style="font-size:3rem; opacity:0.15; display:block; margin-bottom:15px;"></i>
                <p style="margin:0;">No periods logged for <strong><?php echo date('d M Y', strtotime($filter_date)); ?></strong></p>
                <p style="font-size:0.82rem; margin-top:5px;">Teachers sign their periods from the Teacher Portal.</p>
            </div>
        <?php else: ?>
            <table class="log-table">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Period</th>
                        <th>Topic Covered</th>
                        <th>Status</th>
                        <th>Signed At</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($logs as $l): ?>
                    <tr>
                        <td style="font-weight:700;"><?php echo h($l['teacher_name']); ?></td>
                        <td><?php echo h($l['class_name']); ?></td>
                        <td><?php echo h($l['subject_name']); ?></td>
                        <td style="text-align:center; color:#64748b; font-weight:700;"><?php echo $l['period_number']; ?></td>
                        <td style="font-size:0.82rem; color:#475569;"><?php echo h($l['topic_covered'] ?? '—'); ?></td>
                        <td>
                            <?php
                                $badge = match($l['status']) {
                                    'taught' => 'badge-taught',
                                    'missed' => 'badge-missed',
                                    default  => 'badge-covered'
                                };
                                $label = ucfirst(str_replace('_', ' ', $l['status']));
                            ?>
                            <span class="<?php echo $badge; ?>"><?php echo $label; ?></span>
                        </td>
                        <td style="font-size:0.78rem; color:#64748b;"><?php echo date('H:i', strtotime($l['signed_at'])); ?></td>
                        <td style="font-size:0.78rem; color:#64748b; font-style:italic;"><?php echo h($l['remarks'] ?? '—'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
