<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);
$page_title = "Academic Analytics";

// --- Data aggregation for charts ---

// 1. Division Distribution (pie chart)
$divisions_raw = $pdo->query("
    SELECT gs.point_value, COUNT(*) as cnt, r.student_id
    FROM results r
    JOIN grading_scale gs ON r.grade = gs.grade
    WHERE r.status = 'published'
    GROUP BY r.student_id
")->fetchAll();

// 2. Subject Pass Rate (bar chart) — % students who got grade D or better per subject
$subject_pass = $pdo->query("
    SELECT s.subject_name, 
           COUNT(r.result_id) as total,
           SUM(CASE WHEN gs.point_value <= 4 THEN 1 ELSE 0 END) as passed
    FROM results r
    JOIN subjects s ON r.subject_id = s.subject_id
    JOIN grading_scale gs ON r.grade = gs.grade
    WHERE r.status = 'published'
    GROUP BY r.subject_id
    ORDER BY (SUM(CASE WHEN gs.point_value <= 4 THEN 1 ELSE 0 END)/COUNT(r.result_id)) DESC
    LIMIT 10
")->fetchAll();

// 3. Class Average Score
$class_avg = $pdo->query("
    SELECT c.class_name, ROUND(AVG(r.marks_obtained),1) as avg_score, COUNT(DISTINCT r.student_id) as students
    FROM results r
    JOIN exams e ON r.exam_id = e.exam_id
    JOIN classes c ON e.class_id = c.class_id
    WHERE r.status = 'published'
    GROUP BY e.class_id
    ORDER BY avg_score DESC
")->fetchAll();

// 4. Top teacher performance (by % pass rate of their subjects)
$teacher_perf = $pdo->query("
    SELECT CONCAT(t.first_name,' ',t.last_name) as teacher_name,
           s.subject_name,
           COUNT(r.result_id) as total,
           SUM(CASE WHEN gs.point_value <= 4 THEN 1 ELSE 0 END) as passed,
           ROUND((SUM(CASE WHEN gs.point_value <= 4 THEN 1 ELSE 0 END)/COUNT(r.result_id))*100,1) as pass_rate
    FROM results r
    JOIN exams e ON r.exam_id = e.exam_id
    JOIN teachers t ON e.teacher_id = t.teacher_id
    JOIN subjects s ON e.subject_id = s.subject_id
    JOIN grading_scale gs ON r.grade = gs.grade
    WHERE r.status = 'published'
    GROUP BY e.teacher_id, e.subject_id
    HAVING total >= 3
    ORDER BY pass_rate DESC
    LIMIT 10
")->fetchAll();

// 5. Grade distribution overall
$grade_dist = $pdo->query("
    SELECT grade, COUNT(*) as cnt FROM results WHERE status='published' GROUP BY grade ORDER BY grade ASC
")->fetchAll();

$total_published = $pdo->query("SELECT COUNT(*) FROM results WHERE status='published'")->fetchColumn();

require_once '../../includes/header.php';
?>
<style>
.analytics-container { padding: 25px; background: #f8fafc; min-height: 100vh; }
.analytics-header { background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color:#1e293b; padding:25px 30px; border-radius:14px; margin-bottom:25px; display:flex; align-items:center; gap:20px; border: 1px solid rgba(148,0,0,0.15); box-shadow: 0 8px 32px rgba(148,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04); }
.analytics-header .icon { background:linear-gradient(135deg, #940000, #c0392b); width:55px; height:55px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.5rem; color:#fff; box-shadow: 0 4px 15px rgba(148,0,0,0.3); }
.card-box { background:#fff; border-radius:12px; padding:25px; box-shadow:0 4px 15px rgba(0,0,0,0.05); margin-bottom:20px; }
.section-title { font-size:0.75rem; font-weight:800; color:#940000; text-transform:uppercase; letter-spacing:1px; margin-bottom:18px; }
.chart-container { position:relative; }
table.rank-table { width:100%; border-collapse:collapse; }
table.rank-table th { background:#f8fafc; padding:10px 12px; font-size:0.7rem; font-weight:800; color:#64748b; text-transform:uppercase; }
table.rank-table td { padding:12px; border-bottom:1px solid #f1f5f9; font-size:0.85rem; }
.bar-bg { background:#f1f5f9; border-radius:6px; height:8px; overflow:hidden; }
.bar-fill { height:8px; border-radius:6px; background:linear-gradient(90deg,#940000,#c0392b); }
</style>

<div class="analytics-container">
    <div class="analytics-header">
        <div class="icon"><i class="fas fa-chart-line"></i></div>
        <div>
            <h3 style="margin:0;font-weight:900;">Academic Analytics</h3>
            <p style="margin:4px 0 0;color:#94a3b8;font-size:0.9rem;">Deep-dive insights into school academic performance — <?php echo number_format($total_published); ?> published results analyzed</p>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

        <!-- Subject Pass Rate -->
        <div class="card-box">
            <div class="section-title"><i class="fas fa-book me-1"></i> Subject Pass Rate Ranking</div>
            <?php if(empty($subject_pass)): ?>
                <p style="color:#94a3b8; text-align:center; padding:30px 0;">No published data yet.</p>
            <?php else: ?>
                <?php foreach($subject_pass as $i => $sub):
                    $rate = $sub['total'] > 0 ? round(($sub['passed']/$sub['total'])*100) : 0;
                    $color = $rate >= 70 ? '#22c55e' : ($rate >= 40 ? '#f59e0b' : '#ef4444');
                ?>
                <div style="margin-bottom:14px;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:0.83rem;">
                        <span style="font-weight:700; color:#1e293b;"><?php echo ($i+1).'. '.h($sub['subject_name']); ?></span>
                        <span style="font-weight:800; color:<?php echo $color; ?>;"><?php echo $rate; ?>%</span>
                    </div>
                    <div class="bar-bg">
                        <div class="bar-fill" style="width:<?php echo $rate; ?>%; background:<?php echo $color; ?>;"></div>
                    </div>
                    <div style="font-size:0.7rem; color:#94a3b8; margin-top:2px;"><?php echo $sub['passed']; ?>/<?php echo $sub['total']; ?> students passed</div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Class Average Scores -->
        <div class="card-box">
            <div class="section-title"><i class="fas fa-users me-1"></i> Class Average Performance</div>
            <?php if(empty($class_avg)): ?>
                <p style="color:#94a3b8; text-align:center; padding:30px 0;">No published data yet.</p>
            <?php else: ?>
                <table class="rank-table">
                    <thead><tr><th>#</th><th>Class</th><th>Students</th><th>Avg Score</th><th>Performance</th></tr></thead>
                    <tbody>
                    <?php foreach($class_avg as $i => $cls):
                        $p = round(($cls['avg_score']/100)*100);
                        $color = $p >= 60 ? '#22c55e' : ($p >= 40 ? '#f59e0b' : '#ef4444');
                    ?>
                    <tr>
                        <td style="font-weight:800; color:#94a3b8;"><?php echo $i+1; ?></td>
                        <td style="font-weight:700;"><?php echo h($cls['class_name']); ?></td>
                        <td><?php echo $cls['students']; ?></td>
                        <td style="font-weight:800; color:#1e293b;"><?php echo $cls['avg_score']; ?>%</td>
                        <td style="width:100px;">
                            <div class="bar-bg"><div class="bar-fill" style="width:<?php echo min($cls['avg_score'],100); ?>%; background:<?php echo $color; ?>;"></div></div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Grade Distribution -->
        <div class="card-box">
            <div class="section-title"><i class="fas fa-chart-pie me-1"></i> Overall Grade Distribution</div>
            <?php if(empty($grade_dist)): ?>
                <p style="color:#94a3b8; text-align:center; padding:30px 0;">No published data yet.</p>
            <?php else: ?>
                <div style="display:flex; flex-wrap:wrap; gap:12px; justify-content:center; padding:10px 0;">
                    <?php
                    $g_colors = ['A'=>'#22c55e','B'=>'#3b82f6','C'=>'#f59e0b','D'=>'#f97316','E'=>'#ef4444','F'=>'#94a3b8'];
                    $g_total = array_sum(array_column($grade_dist,'cnt'));
                    foreach($grade_dist as $g):
                        $pct = $g_total > 0 ? round(($g['cnt']/$g_total)*100) : 0;
                        $c = $g_colors[$g['grade']] ?? '#64748b';
                    ?>
                    <div style="text-align:center; background:#f8fafc; border-radius:10px; padding:15px 20px; min-width:80px; border-top:4px solid <?php echo $c; ?>;">
                        <div style="font-size:1.6rem; font-weight:900; color:<?php echo $c; ?>;"><?php echo $g['grade']; ?></div>
                        <div style="font-size:1.1rem; font-weight:800;"><?php echo $g['cnt']; ?></div>
                        <div style="font-size:0.7rem; color:#94a3b8;"><?php echo $pct; ?>%</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Teacher Performance -->
        <div class="card-box">
            <div class="section-title"><i class="fas fa-chalkboard-teacher me-1"></i> Teacher Performance Leaderboard</div>
            <?php if(empty($teacher_perf)): ?>
                <p style="color:#94a3b8; text-align:center; padding:30px 0;">No published data yet.</p>
            <?php else: ?>
                <table class="rank-table">
                    <thead><tr><th>#</th><th>Teacher</th><th>Subject</th><th>Pass Rate</th></tr></thead>
                    <tbody>
                    <?php foreach($teacher_perf as $i => $tp):
                        $c = $tp['pass_rate'] >= 70 ? '#22c55e' : ($tp['pass_rate'] >= 40 ? '#f59e0b' : '#ef4444');
                    ?>
                    <tr>
                        <td style="font-weight:800; color:<?php echo $i<3?'#ffd700':'#94a3b8'; ?>;"><?php echo $i<3?['🥇','🥈','🥉'][$i]:($i+1); ?></td>
                        <td style="font-weight:700;"><?php echo h($tp['teacher_name']); ?></td>
                        <td style="font-size:0.78rem; color:#64748b;"><?php echo h($tp['subject_name']); ?></td>
                        <td>
                            <span style="font-weight:800; color:<?php echo $c; ?>"><?php echo $tp['pass_rate']; ?>%</span>
                            <div class="bar-bg" style="margin-top:4px;"><div class="bar-fill" style="width:<?php echo $tp['pass_rate']; ?>%; background:<?php echo $c; ?>;"></div></div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
