<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);

$page_title = "Examination Management";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'create') {
        try {
            $stmt = $pdo->prepare("INSERT INTO exam_schedule (exam_name, exam_type, term_id, class_id, subject_id, exam_date, start_time, end_time, venue, max_marks, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $_POST['exam_name'], $_POST['exam_type'],
                $_POST['term_id'] ?: null, $_POST['class_id'] ?: null,
                $_POST['subject_id'] ?: null, $_POST['exam_date'],
                $_POST['start_time'] ?: null, $_POST['end_time'] ?: null,
                $_POST['venue'] ?: 'Main Hall', $_POST['max_marks'] ?: 100,
                $_POST['notes'] ?: null, $_SESSION['user_id']
            ]);
            $success = "Exam scheduled successfully!";
        } catch(Exception $e) { $error = "Error: " . $e->getMessage(); }
    } elseif ($_POST['action'] == 'delete' && isset($_POST['schedule_id'])) {
        $pdo->prepare("DELETE FROM exam_schedule WHERE schedule_id = ?")->execute([$_POST['schedule_id']]);
        $success = "Exam removed from schedule.";
    }
}

// Fetch data
$terms    = $pdo->query("SELECT * FROM academic_terms ORDER BY academic_year DESC")->fetchAll();
$classes  = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY subject_name")->fetchAll();
$filter_type = $_GET['type'] ?? '';
$filter_date = $_GET['date'] ?? '';

$where = "WHERE 1=1";
$params = [];
if ($filter_type) { $where .= " AND es.exam_type = ?"; $params[] = $filter_type; }
if ($filter_date) { $where .= " AND es.exam_date = ?"; $params[] = $filter_date; }

$stmt = $pdo->prepare("
    SELECT es.*, c.class_name, s.subject_name, t.term_name
    FROM exam_schedule es
    LEFT JOIN classes c ON es.class_id = c.class_id
    LEFT JOIN subjects s ON es.subject_id = s.subject_id
    LEFT JOIN academic_terms t ON es.term_id = t.term_id
    $where
    ORDER BY es.exam_date ASC, es.start_time ASC
");
$stmt->execute($params);
$exams = $stmt->fetchAll();

require_once '../../includes/header.php';
?>
<style>
.exam-container { padding: 25px; background: #f8fafc; min-height: 100vh; }
.exam-header { background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color: #1e293b; padding: 25px 30px; border-radius: 14px; margin-bottom: 25px; display: flex; align-items: center; gap: 20px; border: 1px solid rgba(148,0,0,0.15); box-shadow: 0 8px 32px rgba(148,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04); }
.exam-header .icon { background: linear-gradient(135deg, #940000, #c0392b); width: 55px; height: 55px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; box-shadow: 0 4px 15px rgba(148,0,0,0.3); }
.card-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
.section-title { font-size: 0.75rem; font-weight: 800; color: #940000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 20px; }
.form-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-group label { font-size: 0.78rem; font-weight: 700; color: #475569; text-transform: uppercase; }
.form-group input, .form-group select, .form-group textarea { padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; outline: none; background: #f8fafc; transition: border 0.2s; }
.form-group input:focus, .form-group select:focus { border-color: #940000; background: #fff; }
.btn-primary-red { background: #940000; color: #fff; border: none; padding: 12px 25px; border-radius: 8px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
.btn-primary-red:hover { background: #7d0000; }
.exam-table { width: 100%; border-collapse: collapse; }
.exam-table th { background: #f8fafc; padding: 12px 15px; text-align: left; font-size: 0.72rem; font-weight: 800; color: #64748b; text-transform: uppercase; }
.exam-table td { padding: 13px 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.88rem; }
.exam-table tr:hover td { background: #fafafa; }
.badge-type { padding: 4px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; text-transform: uppercase; }
.badge-terminal { background: #fff5f5; color: #940000; }
.badge-midterm { background: #eff6ff; color: #1d4ed8; }
.badge-weekly { background: #f0fdf4; color: #166534; }
.badge-mock { background: #fdf4ff; color: #7e22ce; }
.filters { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.filters select, .filters input { padding: 9px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; outline: none; }
</style>

<div class="exam-container">
    <!-- Header -->
    <div class="exam-header">
        <div class="icon"><i class="fas fa-file-signature"></i></div>
        <div>
            <h3 style="margin:0; font-weight:900;">Examination Management</h3>
            <p style="margin:4px 0 0; color:#94a3b8; font-size:0.9rem;">Schedule, configure and manage all school examinations</p>
        </div>
    </div>

    <?php if (!empty($success)): ?>
        <div style="background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:12px 20px; border-radius:8px; margin-bottom:20px; font-weight:600;"><i class="fas fa-check-circle me-2"></i><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <div style="background:#fff5f5; color:#940000; border:1px solid #fecaca; padding:12px 20px; border-radius:8px; margin-bottom:20px; font-weight:600;"><i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?></div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns: 1fr 2fr; gap:25px;">
        <!-- Create Form -->
        <div class="card-box">
            <div class="section-title"><i class="fas fa-plus-circle me-1"></i> Schedule New Exam</div>
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div style="display:flex; flex-direction:column; gap:14px;">
                    <div class="form-group">
                        <label>Exam Name</label>
                        <input type="text" name="exam_name" placeholder="e.g. Form 2 Mathematics Midterm" required>
                    </div>
                    <div class="form-group">
                        <label>Exam Type</label>
                        <select name="exam_type" required>
                            <option value="">Choose type...</option>
                            <option value="weekly_test">Weekly Test</option>
                            <option value="midterm">Midterm Exam</option>
                            <option value="terminal">Terminal Exam</option>
                            <option value="mock">Mock Exam</option>
                            <option value="special">Special Assessment</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Term</label>
                        <select name="term_id">
                            <option value="">All Terms</option>
                            <?php foreach($terms as $t): ?>
                                <option value="<?php echo $t['term_id']; ?>"><?php echo h($t['term_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Class (Optional)</label>
                        <select name="class_id">
                            <option value="">All Classes</option>
                            <?php foreach($classes as $c): ?>
                                <option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Subject (Optional)</label>
                        <select name="subject_id">
                            <option value="">All Subjects</option>
                            <?php foreach($subjects as $s): ?>
                                <option value="<?php echo $s['subject_id']; ?>"><?php echo h($s['subject_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Exam Date</label>
                        <input type="date" name="exam_date" required>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <div class="form-group">
                            <label>Start Time</label>
                            <input type="time" name="start_time">
                        </div>
                        <div class="form-group">
                            <label>End Time</label>
                            <input type="time" name="end_time">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Venue</label>
                        <input type="text" name="venue" value="Main Hall" placeholder="e.g. Main Hall, Form 3A Classroom">
                    </div>
                    <div class="form-group">
                        <label>Max Marks</label>
                        <input type="number" name="max_marks" value="100" min="1" max="200">
                    </div>
                    <div class="form-group">
                        <label>Notes</label>
                        <textarea name="notes" rows="2" placeholder="Any special instructions..."></textarea>
                    </div>
                    <button type="submit" class="btn-primary-red">
                        <i class="fas fa-calendar-plus"></i> Schedule Exam
                    </button>
                </div>
            </form>
        </div>

        <!-- Schedule Table -->
        <div class="card-box">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
                <div class="section-title" style="margin-bottom:0;"><i class="fas fa-calendar-check me-1"></i> Exam Schedule</div>
                <form method="GET" class="filters">
                    <select name="type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <option value="weekly_test" <?php echo $filter_type=='weekly_test'?'selected':''; ?>>Weekly Test</option>
                        <option value="midterm" <?php echo $filter_type=='midterm'?'selected':''; ?>>Midterm</option>
                        <option value="terminal" <?php echo $filter_type=='terminal'?'selected':''; ?>>Terminal</option>
                        <option value="mock" <?php echo $filter_type=='mock'?'selected':''; ?>>Mock</option>
                    </select>
                    <input type="date" name="date" value="<?php echo $filter_date; ?>" onchange="this.form.submit()">
                    <?php if($filter_type || $filter_date): ?>
                        <a href="index.php" style="color:#940000; font-size:0.8rem; font-weight:700; text-decoration:none;">✕ Clear</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if(empty($exams)): ?>
                <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                    <i class="fas fa-calendar-times" style="font-size:3rem; opacity:0.2; margin-bottom:15px; display:block;"></i>
                    <p style="margin:0; font-size:0.9rem;">No exams scheduled yet.</p>
                </div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="exam-table">
                        <thead>
                            <tr>
                                <th>Exam</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Class</th>
                                <th>Subject</th>
                                <th>Venue</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($exams as $ex): 
                                $badge = match($ex['exam_type']) {
                                    'terminal' => 'badge-terminal',
                                    'midterm'  => 'badge-midterm',
                                    'weekly_test' => 'badge-weekly',
                                    'mock'     => 'badge-mock',
                                    default    => 'badge-weekly'
                                };
                                $label = ucfirst(str_replace('_', ' ', $ex['exam_type']));
                            ?>
                            <tr>
                                <td style="font-weight:700; color:#1e293b;"><?php echo h($ex['exam_name']); ?></td>
                                <td><span class="badge-type <?php echo $badge; ?>"><?php echo $label; ?></span></td>
                                <td><?php echo date('d M Y', strtotime($ex['exam_date'])); ?></td>
                                <td style="font-size:0.8rem; color:#64748b;">
                                    <?php echo $ex['start_time'] ? date('H:i', strtotime($ex['start_time'])) . ' – ' . date('H:i', strtotime($ex['end_time'])) : '—'; ?>
                                </td>
                                <td><?php echo h($ex['class_name'] ?? 'All'); ?></td>
                                <td><?php echo h($ex['subject_name'] ?? 'All'); ?></td>
                                <td style="font-size:0.8rem;"><?php echo h($ex['venue']); ?></td>
                                <td>
                                    <form method="POST" onsubmit="return confirm('Delete this exam?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="schedule_id" value="<?php echo $ex['schedule_id']; ?>">
                                        <button type="submit" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.85rem;" title="Delete"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
