<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);

$page_title = "Lesson Plans";

// Handle approve/reject
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'], $_POST['plan_id'])) {
    $action = $_POST['action'];
    $plan_id = (int)$_POST['plan_id'];
    $comment = trim($_POST['dos_comment'] ?? '');
    $status = ($action == 'approve') ? 'approved' : 'rejected';
    $stmt = $pdo->prepare("UPDATE lesson_plans SET status=?, dos_comment=?, reviewed_by=?, reviewed_at=NOW() WHERE plan_id=?");
    $stmt->execute([$status, $comment, $_SESSION['user_id'], $plan_id]);
    $success = "Lesson plan " . $status . "!";
}

// Filters
$filter_status  = $_GET['status']     ?? '';
$filter_type    = $_GET['plan_type']  ?? '';
$filter_teacher = $_GET['teacher_id'] ?? '';

$where = "WHERE 1=1";
$params = [];
if ($filter_status)  { $where .= " AND lp.status = ?";      $params[] = $filter_status; }
if ($filter_type)    { $where .= " AND lp.plan_type = ?";   $params[] = $filter_type; }
if ($filter_teacher) { $where .= " AND lp.teacher_id = ?";  $params[] = $filter_teacher; }

$stmt = $pdo->prepare("
    SELECT lp.*,
           CONCAT(t.first_name,' ',t.last_name) as teacher_name,
           c.class_name, s.subject_name
    FROM lesson_plans lp
    JOIN teachers t ON lp.teacher_id = t.teacher_id
    JOIN classes  c ON lp.class_id   = c.class_id
    JOIN subjects s ON lp.subject_id = s.subject_id
    $where
    ORDER BY lp.created_at DESC
");
$stmt->execute($params);
$plans = $stmt->fetchAll();

$pending  = $pdo->query("SELECT COUNT(*) FROM lesson_plans WHERE status='pending'")->fetchColumn();
$approved = $pdo->query("SELECT COUNT(*) FROM lesson_plans WHERE status='approved'")->fetchColumn();
$rejected = $pdo->query("SELECT COUNT(*) FROM lesson_plans WHERE status='rejected'")->fetchColumn();
$teachers = $pdo->query("SELECT * FROM teachers ORDER BY first_name")->fetchAll();

require_once '../../includes/header.php';
?>
<style>
.lp-container { padding: 25px; background: #f8fafc; min-height: 100vh; }
.lp-header { background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color: #1e293b; padding:25px 30px; border-radius:14px; margin-bottom:25px; display:flex; align-items:center; gap:20px; border: 1px solid rgba(148,0,0,0.15); box-shadow: 0 8px 32px rgba(148,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04); }
.lp-icon { background: linear-gradient(135deg, #940000, #c0392b); width:55px; height:55px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.5rem; color:#fff; box-shadow: 0 4px 15px rgba(148,0,0,0.3); }
.card-box { background:#fff; border-radius:12px; padding:25px; box-shadow:0 4px 15px rgba(0,0,0,0.05); margin-bottom:20px; }
.stat-row { display:grid; grid-template-columns:repeat(3,1fr); gap:15px; margin-bottom:25px; }
.stat-tiny { border-radius:10px; padding:18px 20px; display:flex; align-items:center; gap:14px; }
.stat-tiny.pending  { background:#fffbeb; border-left:4px solid #f59e0b; }
.stat-tiny.approved { background:#f0fdf4; border-left:4px solid #22c55e; }
.stat-tiny.rejected { background:#fff5f5; border-left:4px solid #ef4444; }
.plan-card { border:1px solid #f1f5f9; border-radius:10px; margin-bottom:14px; overflow:hidden; }
.plan-card-header { padding:15px 20px; background:#f8fafc; display:flex; justify-content:space-between; align-items:flex-start; }
.plan-card-body { padding:15px 20px; }
.badge-pending  { background:#fffbeb; color:#92400e; padding:4px 12px; border-radius:20px; font-size:0.68rem; font-weight:700; text-transform:uppercase; }
.badge-approved { background:#f0fdf4; color:#166534; padding:4px 12px; border-radius:20px; font-size:0.68rem; font-weight:700; text-transform:uppercase; }
.badge-rejected { background:#fff5f5; color:#940000; padding:4px 12px; border-radius:20px; font-size:0.68rem; font-weight:700; text-transform:uppercase; }
.filter-row { display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin-bottom:20px; }
.filter-row select { padding:8px 14px; border:1px solid #e2e8f0; border-radius:8px; font-size:0.83rem; outline:none; }
.btn-approve { background:#22c55e; color:#fff; border:none; padding:8px 16px; border-radius:7px; font-weight:700; font-size:0.8rem; cursor:pointer; }
.btn-reject  { background:#ef4444; color:#fff; border:none; padding:8px 16px; border-radius:7px; font-weight:700; font-size:0.8rem; cursor:pointer; }
</style>

<div class="lp-container">
    <div class="lp-header">
        <div class="lp-icon"><i class="fas fa-folder-open"></i></div>
        <div>
            <h3 style="margin:0; font-weight:900;">Lesson Plans & Schemes of Work</h3>
            <p style="margin:4px 0 0; color:#94a3b8; font-size:0.9rem;">Review and approve/reject teaching plans submitted by teachers</p>
        </div>
    </div>

    <?php if(!empty($success)): ?>
        <div style="background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:12px 20px; border-radius:8px; margin-bottom:20px; font-weight:600;">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
        </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stat-row">
        <div class="stat-tiny pending">
            <div style="font-size:1.8rem; font-weight:900; color:#f59e0b;"><?php echo $pending; ?></div>
            <div>
                <div style="font-weight:700; color:#92400e;">Pending Review</div>
                <div style="font-size:0.75rem; color:#b45309;">Awaiting DOS action</div>
            </div>
        </div>
        <div class="stat-tiny approved">
            <div style="font-size:1.8rem; font-weight:900; color:#22c55e;"><?php echo $approved; ?></div>
            <div>
                <div style="font-weight:700; color:#166534;">Approved</div>
                <div style="font-size:0.75rem; color:#15803d;">Cleared for teaching</div>
            </div>
        </div>
        <div class="stat-tiny rejected">
            <div style="font-size:1.8rem; font-weight:900; color:#ef4444;"><?php echo $rejected; ?></div>
            <div>
                <div style="font-weight:700; color:#940000;">Rejected</div>
                <div style="font-size:0.75rem; color:#b91c1c;">Sent back for revision</div>
            </div>
        </div>
    </div>

    <!-- Plans List -->
    <div class="card-box">
        <!-- Filters -->
        <form method="GET" class="filter-row">
            <select name="status" onchange="this.form.submit()">
                <option value="">All Status</option>
                <option value="pending"  <?php echo $filter_status=='pending'?'selected':''; ?>>Pending</option>
                <option value="approved" <?php echo $filter_status=='approved'?'selected':''; ?>>Approved</option>
                <option value="rejected" <?php echo $filter_status=='rejected'?'selected':''; ?>>Rejected</option>
            </select>
            <select name="plan_type" onchange="this.form.submit()">
                <option value="">All Types</option>
                <option value="lesson_plan"    <?php echo $filter_type=='lesson_plan'?'selected':''; ?>>Lesson Plan</option>
                <option value="scheme_of_work" <?php echo $filter_type=='scheme_of_work'?'selected':''; ?>>Scheme of Work</option>
            </select>
            <select name="teacher_id" onchange="this.form.submit()">
                <option value="">All Teachers</option>
                <?php foreach($teachers as $t): ?>
                    <option value="<?php echo $t['teacher_id']; ?>" <?php echo $filter_teacher==$t['teacher_id']?'selected':''; ?>>
                        <?php echo h($t['first_name'].' '.$t['last_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php if($filter_status||$filter_type||$filter_teacher): ?>
                <a href="index.php" style="color:#940000; font-weight:700; font-size:0.82rem; text-decoration:none;">✕ Clear</a>
            <?php endif; ?>
        </form>

        <?php if(empty($plans)): ?>
            <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                <i class="fas fa-folder-open" style="font-size:3rem; opacity:0.15; display:block; margin-bottom:15px;"></i>
                <p style="margin:0;">No lesson plans submitted yet.</p>
                <p style="font-size:0.82rem; margin-top:5px;">Teachers submit plans from their Teaching Portal.</p>
            </div>
        <?php else: ?>
            <?php foreach($plans as $plan):
                $badge_class = match($plan['status']) {
                    'approved' => 'badge-approved',
                    'rejected' => 'badge-rejected',
                    default    => 'badge-pending'
                };
            ?>
            <div class="plan-card">
                <div class="plan-card-header">
                    <div>
                        <div style="font-weight:800; color:#1e293b; font-size:0.95rem;"><?php echo h($plan['title']); ?></div>
                        <div style="font-size:0.78rem; color:#64748b; margin-top:4px;">
                            <i class="fas fa-user me-1"></i><?php echo h($plan['teacher_name']); ?>
                            &nbsp;|&nbsp; <i class="fas fa-chalkboard me-1"></i><?php echo h($plan['class_name']); ?>
                            &nbsp;|&nbsp; <i class="fas fa-book me-1"></i><?php echo h($plan['subject_name']); ?>
                            <?php if($plan['week_number']): ?>
                            &nbsp;|&nbsp; Week <?php echo $plan['week_number']; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px; flex-shrink:0;">
                        <span style="font-size:0.72rem; color:#94a3b8;"><?php echo date('d M Y', strtotime($plan['created_at'])); ?></span>
                        <span class="<?php echo $badge_class; ?>"><?php echo ucfirst($plan['status']); ?></span>
                        <span style="background:#f1f5f9; color:#475569; padding:4px 10px; border-radius:20px; font-size:0.68rem; font-weight:700;">
                            <?php echo $plan['plan_type'] == 'scheme_of_work' ? 'Scheme of Work' : 'Lesson Plan'; ?>
                        </span>
                    </div>
                </div>
                <div class="plan-card-body">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:15px; font-size:0.82rem; color:#64748b; margin-bottom:15px;">
                        <div><strong style="color:#1e293b;">Topic:</strong> <?php echo h($plan['topic']); ?></div>
                        <div><strong style="color:#1e293b;">Objectives:</strong> <?php echo h(substr($plan['objectives'] ?? '—', 0, 80)); ?>...</div>
                        <div><strong style="color:#1e293b;">Resources:</strong> <?php echo h($plan['resources'] ?? '—'); ?></div>
                    </div>
                    <?php if($plan['dos_comment']): ?>
                        <div style="background:#f8fafc; border-left:3px solid #940000; padding:10px 15px; border-radius:0 8px 8px 0; font-size:0.82rem; margin-bottom:15px;">
                            <strong>DOS Comment:</strong> <?php echo h($plan['dos_comment']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if($plan['status'] == 'pending'): ?>
                    <form method="POST" style="display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap;">
                        <input type="hidden" name="plan_id" value="<?php echo $plan['plan_id']; ?>">
                        <div style="flex:1; min-width:220px;">
                            <input type="text" name="dos_comment" placeholder="Add comment (optional)..."
                                style="width:100%; padding:9px 14px; border:1px solid #e2e8f0; border-radius:8px; font-size:0.85rem; outline:none;">
                        </div>
                        <button type="submit" name="action" value="approve" class="btn-approve">
                            <i class="fas fa-check me-1"></i> Approve
                        </button>
                        <button type="submit" name="action" value="reject" class="btn-reject">
                            <i class="fas fa-times me-1"></i> Reject
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
