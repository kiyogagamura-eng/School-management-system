<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos', 'admin']);
$page_title = "Class Teacher Allocation";

$success = $error = '';

// ── Handle Action updates ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    
    // Assign or Update Class Teacher
    if ($_POST['action'] == 'assign') {
        $class_id = (int)$_POST['class_id'];
        $teacher_id = !empty($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : null;

        if (!$class_id) {
            $error = "Please select a class.";
        } else {
            try {
                // Update class_teacher_id in classes table
                $stmt = $pdo->prepare("UPDATE classes SET class_teacher_id = ? WHERE class_id = ?");
                $stmt->execute([$teacher_id, $class_id]);
                
                $success = "✅ Class Teacher assigned successfully!";
                logActivity($_SESSION['user_id'], 'class_allocation', "Assigned class teacher $teacher_id to class $class_id");
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }

    // Reset Class Teacher (Delete allocation)
    if ($_POST['action'] == 'delete' && isset($_POST['class_id'])) {
        $class_id = (int)$_POST['class_id'];
        try {
            $stmt = $pdo->prepare("UPDATE classes SET class_teacher_id = NULL WHERE class_id = ?");
            $stmt->execute([$class_id]);
            $success = "🗑️ Class Teacher assignment cleared.";
            logActivity($_SESSION['user_id'], 'class_allocation_delete', "Cleared class teacher for class $class_id");
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// ── Fetch Teachers and Classes ──────────────────────────────────────────────
try {
    $teachers = $pdo->query("SELECT teacher_id, CONCAT(first_name, ' ', last_name) as name, specialization FROM teachers WHERE status='Active' ORDER BY first_name")->fetchAll();
    
    // Fetch all classes with current teacher and student count
    $classes_stmt = $pdo->query("
        SELECT c.*, t.first_name, t.last_name, t.teacher_id,
        (SELECT COUNT(*) FROM students WHERE class_id = c.class_id) as student_count
        FROM classes c
        LEFT JOIN teachers t ON c.class_teacher_id = t.teacher_id
        ORDER BY c.form_level ASC, c.stream ASC
    ");
    $classes = $classes_stmt->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
    $classes = [];
    $error = "Error fetching data: " . $e->getMessage();
}

require_once '../../includes/header.php';
?>
<style>
/* ── Container ── */
.alloc-wrap { padding: 25px; background: #f8fafc; min-height: 100vh; }

/* ── Page Header (glassmorphism) ── */
.alloc-header {
    background: linear-gradient(135deg, rgba(255,255,255,0.85) 0%, rgba(255,245,245,0.9) 100%);
    backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(148,0,0,0.15);
    box-shadow: 0 8px 32px rgba(148,0,0,0.08);
    border-radius: 14px; padding: 25px 30px; margin-bottom: 25px;
    display: flex; align-items: center; gap: 20px;
}
.alloc-header .icon {
    background: linear-gradient(135deg, #940000, #c0392b);
    width: 55px; height: 55px; border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem; color: #fff;
    box-shadow: 0 4px 15px rgba(148,0,0,0.3);
    flex-shrink: 0;
}

/* ── Card Box ── */
.card-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
.sec-title { font-size: 0.72rem; font-weight: 800; color: #940000; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }

/* ── Form ── */
.fg { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; }
.fg label { font-size: 0.75rem; font-weight: 700; color: #475569; text-transform: uppercase; }
.fg select, .fg input {
    padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 8px;
    font-size: 0.9rem; outline: none; background: #f8fafc;
    transition: border 0.2s, background 0.2s;
}
.fg select:focus, .fg input:focus { border-color: #940000; background: #fff; box-shadow: 0 0 0 3px rgba(148,0,0,0.06); }

/* ── Buttons ── */
.btn-assign {
    background: linear-gradient(135deg, #940000, #c0392b);
    color: #fff; border: none; padding: 12px 28px; border-radius: 8px;
    font-weight: 700; font-size: 0.9rem; cursor: pointer;
    display: inline-flex; align-items: center; gap: 8px;
    box-shadow: 0 4px 15px rgba(148,0,0,0.3);
    transition: all 0.2s;
}
.btn-assign:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(148,0,0,0.4); }
.btn-del { background: none; border: none; color: #ef4444; cursor: pointer; padding: 5px 8px; border-radius: 6px; transition: 0.2s; }
.btn-del:hover { background: #fff5f5; }
.btn-edit-sm { background: #eff6ff; border: none; color: #1d4ed8; cursor: pointer; padding: 5px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 700; transition: 0.2s; }
.btn-edit-sm:hover { background: #dbeafe; }

/* ── Table ── */
.alloc-table { width: 100%; border-collapse: collapse; font-size: 0.87rem; }
.alloc-table th { background: #f8fafc; padding: 11px 14px; text-align: left; font-size: 0.68rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.alloc-table td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.alloc-table tr:hover td { background: #fafafa; }
.alloc-table tr:last-child td { border-bottom: none; }

/* ── Badges ── */
.badge-form { background: #fff5f5; color: #940000; padding: 4px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 700; }
.badge-teacher { background: #eff6ff; color: #1d4ed8; padding: 4px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 700; }
.badge-unassigned { background: #fffbeb; color: #f59e0b; padding: 4px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 700; }

/* ── Alert / Success ── */
.alert-ok  { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; padding: 12px 18px; border-radius: 8px; font-weight: 600; margin-bottom: 18px; }
.alert-err { background: #fff5f5; color: #940000; border: 1px solid #fca5a5; padding: 12px 18px; border-radius: 8px; font-weight: 600; margin-bottom: 18px; }
</style>

<div class="alloc-wrap">

    <!-- Page Header -->
    <div class="alloc-header">
        <div class="icon"><i class="fas fa-chalkboard-teacher"></i></div>
        <div>
            <div style="font-size:0.7rem; color:#940000; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:3px;">Academic Master &rsaquo; Class Teachers</div>
            <h3 style="margin:0; font-weight:900; color:#1e293b; font-size:1.3rem;">Class Teacher Allocation</h3>
            <p style="margin:3px 0 0; color:#64748b; font-size:0.85rem;">Assign and manage Class Teachers for student supervision and attendance tracking</p>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($success): ?><div class="alert-ok"><i class="fas fa-check-circle me-1"></i><?php echo $success; ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert-err"><i class="fas fa-exclamation-circle me-1"></i><?php echo $error; ?></div><?php endif; ?>

    <div style="display:grid; grid-template-columns:1fr 2fr; gap:22px; align-items:start;">

        <!-- ── LEFT: Allocation Form ── -->
        <div class="card-box">
            <div class="sec-title"><i class="fas fa-plus-circle"></i> Assign Class Teacher</div>
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                
                <div class="fg" style="margin-bottom: 14px;">
                    <label><i class="fas fa-school"></i> Select Class</label>
                    <select name="class_id" required>
                        <option value="">— Select Class —</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['class_id']; ?>">
                                <?php echo h($c['class_name']); ?> (Capacity: <?php echo $c['capacity']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="fg" style="margin-bottom: 14px;">
                    <label><i class="fas fa-user-tie"></i> Class Teacher</label>
                    <select name="teacher_id" required>
                        <option value="">— Select Teacher —</option>
                        <?php foreach ($teachers as $t): ?>
                            <option value="<?php echo $t['teacher_id']; ?>">
                                Mwl. <?php echo h($t['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn-assign" style="width:100%; justify-content:center; margin-top:10px;">
                    <i class="fas fa-user-check"></i> Assign Teacher
                </button>
            </form>

            <div style="margin-top:20px; padding:14px; background:#fff5f5; border-radius:8px; border-left:3px solid #940000; font-size:0.8rem; color:#64748b; line-height:1.6;">
                <strong style="color:#940000;"><i class="fas fa-info-circle"></i> Class Teacher Roles:</strong><br>
                A Class Teacher can record daily attendance metrics, oversee behavior/disciplinary issues, and add official administrative feedback on final student report remarks.
            </div>
        </div>

        <!-- ── RIGHT: Current Class Teachers List ── -->
        <div class="card-box">
            <div class="sec-title"><i class="fas fa-table"></i> Classes &amp; Assigned Class Teachers List</div>
            
            <div style="overflow-x:auto;">
                <table class="alloc-table">
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Class Teacher</th>
                            <th>Students</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($classes)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #94a3b8; padding: 40px 0;">No classes found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($classes as $c): ?>
                                <tr>
                                    <td>
                                        <span class="badge-form" style="font-size:0.85rem; padding: 6px 12px;">
                                            <?php echo h($c['class_name']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($c['first_name']): ?>
                                            <span class="badge-teacher" style="font-size:0.85rem; padding: 6px 12px;">
                                                <i class="fas fa-chalkboard-teacher"></i> Mwl. <?php echo h($c['first_name'] . ' ' . $c['last_name']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge-unassigned" style="font-size:0.85rem; padding: 6px 12px;">
                                                <i class="fas fa-exclamation-triangle"></i> Not Assigned
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="font-weight:700; color:#475569;">
                                        <?php echo $c['student_count']; ?> / <?php echo $c['capacity']; ?>
                                    </td>
                                    <td>
                                        <div style="display:flex; gap:6px;">
                                            <button class="btn-edit-sm" onclick="openEdit(<?php echo $c['class_id']; ?>, <?php echo (int)$c['class_teacher_id']; ?>, '<?php echo addslashes($c['class_name']); ?>')">
                                                <i class="fas fa-user-edit"></i> Edit
                                            </button>
                                            
                                            <?php if ($c['class_teacher_id']): ?>
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Do you want to clear the Class Teacher for this class?')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="class_id" value="<?php echo $c['class_id']; ?>">
                                                    <button type="submit" class="btn-del" title="Remove Class Teacher"><i class="fas fa-user-times"></i></button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<!-- Modal Quick Edit -->
<div id="edit-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:#fff; border-radius:16px; padding:30px; width:400px; box-shadow:0 25px 60px rgba(0,0,0,0.2); position:relative;">
        <div style="font-size:0.7rem; color:#940000; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Change Class Teacher</div>
        <h4 style="margin:0 0 20px; color:#1e293b; font-weight:900;" id="edit-title">—</h4>
        <form method="POST">
            <input type="hidden" name="action" value="assign">
            <input type="hidden" name="class_id" id="edit-class-id">
            
            <div class="fg" style="margin-bottom:20px;">
                <label>New Class Teacher</label>
                <select name="teacher_id" id="edit-teacher-id" required>
                    <option value="">— Select Teacher —</option>
                    <?php foreach ($teachers as $t): ?>
                        <option value="<?php echo $t['teacher_id']; ?>">Mwl. <?php echo h($t['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display:flex; gap:10px;">
                <button type="submit" class="btn-assign" style="flex:1; justify-content:center;">
                    <i class="fas fa-save"></i> Save Changes
                </button>
                <button type="button" onclick="closeEdit()" style="flex:1; background:#f1f5f9; border:none; border-radius:8px; font-weight:700; cursor:pointer; color:#475569;">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(classId, teacherId, className) {
    document.getElementById('edit-modal').style.display = 'flex';
    document.getElementById('edit-class-id').value = classId;
    document.getElementById('edit-teacher-id').value = teacherId ? teacherId : "";
    document.getElementById('edit-title').textContent = 'Class: ' + className;
}
function closeEdit() {
    document.getElementById('edit-modal').style.display = 'none';
}
document.getElementById('edit-modal').addEventListener('click', function(e) {
    if (e.target === this) closeEdit();
});
</script>

<?php require_once '../../includes/footer.php'; ?>
