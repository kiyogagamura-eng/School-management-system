<?php
require_once '../includes/bootstrap.php';
requireRole('discipline');

$page_title = "Discipline Master Dashboard";
require_once '../includes/header.php';

// Stats for Discipline
try {
    $stats = [
        'total_incidents' => $pdo->query("SELECT COUNT(*) FROM discipline_records")->fetchColumn(),
        'pending_incidents' => $pdo->query("SELECT COUNT(*) FROM discipline_records WHERE status = 'pending'")->fetchColumn(),
        'high_severity' => $pdo->query("SELECT COUNT(*) FROM discipline_records WHERE severity IN ('high', 'critical')")->fetchColumn(),
        'recent_records' => $pdo->query("
            SELECT dr.*, s.first_name, s.last_name, c.class_name 
            FROM discipline_records dr
            JOIN students s ON dr.student_id = s.student_id
            JOIN classes c ON s.class_id = c.class_id
            ORDER BY dr.incident_date DESC LIMIT 5
        ")->fetchAll()
    ];
} catch (PDOException $e) {
    $stats = ['total_incidents' => 0, 'pending_incidents' => 0, 'high_severity' => 0, 'recent_records' => []];
}
?>

<div class="main-content-inner">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-gavel" style="color: var(--corporate-red);"></i> DISCIPLINE DASHBOARD</h2>
            <p style="color: var(--secondary-text);">Welcome, <?php echo h(strtoupper($username)); ?>. Overview of school behavior records.</p>
        </div>
        <a href="records/create.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Incident Record</a>
    </div>

    <!-- Quick Stats -->
    <div class="dashboard-grid" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 30px;">
        <div class="card" style="border-left: 5px solid #940000; padding: 20px;">
            <div style="font-size: 0.8rem; font-weight: 700; color: #7f8c8d; text-transform: uppercase;">Total Incidents</div>
            <div style="font-size: 2.2rem; font-weight: 900; color: #940000;"><?php echo $stats['total_incidents']; ?></div>
        </div>
        <div class="card" style="border-left: 5px solid #f39c12; padding: 20px;">
            <div style="font-size: 0.8rem; font-weight: 700; color: #7f8c8d; text-transform: uppercase;">Pending Action</div>
            <div style="font-size: 2.2rem; font-weight: 900; color: #f39c12;"><?php echo $stats['pending_incidents']; ?></div>
        </div>
        <div class="card" style="border-left: 5px solid #e74c3c; padding: 20px;">
            <div style="font-size: 0.8rem; font-weight: 700; color: #7f8c8d; text-transform: uppercase;">High Severity</div>
            <div style="font-size: 2.2rem; font-weight: 900; color: #e74c3c;"><?php echo $stats['high_severity']; ?></div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
        <!-- Recent Incidents -->
        <div class="card shadow-premium">
            <div class="card-header" style="background: #FFF5F5; color: #8b0000;"><i class="fas fa-history"></i> Recent Incidents</div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Type</th>
                            <th>Severity</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($stats['recent_records'])): ?>
                            <tr><td colspan="5" style="text-align: center; color: #999;">No incident history found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($stats['recent_records'] as $r): ?>
                                <tr>
                                    <td><?php echo date('d M', strtotime($r['incident_date'])); ?></td>
                                    <td style="font-weight: 700;">
                                        <?php echo h($r['first_name'] . ' ' . $r['last_name']); ?><br>
                                        <small style="color: #7f8c8d;"><?php echo h($r['class_name']); ?></small>
                                    </td>
                                    <td><?php echo h($r['incident_type']); ?></td>
                                    <td>
                                        <span style="color: <?php echo $r['severity'] == 'critical' ? '#e74c3c' : ($r['severity'] == 'high' ? '#e67e22' : '#2ecc71'); ?>; font-weight: 800; font-size: 0.75rem; text-transform: uppercase;">
                                            <?php echo $r['severity']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge" style="background: <?php echo $r['status'] == 'resolved' ? '#d4edda' : ($r['status'] == 'pending' ? '#fff3cd' : '#f8d7da'); ?>; color: #333;">
                                            <?php echo strtoupper($r['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header" style="background: #FFF5F5; color: #8b0000;"><i class="fas fa-bolt"></i> Quick Links</div>
            <div class="card-body" style="display: flex; flex-direction: column; gap: 10px;">
                <button class="btn btn-outline" onclick="location.href='records/index.php'" style="text-align: left;"><i class="fas fa-list"></i> View All Records</button>
                <button class="btn btn-outline" onclick="location.href='records/behavior.php'" style="text-align: left;"><i class="fas fa-chart-line"></i> Behavior Reports</button>
                <button class="btn btn-outline" onclick="location.href='../admin/users/students.php'" style="text-align: left;"><i class="fas fa-user-graduate"></i> Search Student</button>
                <button class="btn btn-primary" onclick="alert('SMS System for Truancy ready to be configured.')" style="margin-top: 10px;"><i class="fas fa-sms"></i> Alert Parents</button>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
