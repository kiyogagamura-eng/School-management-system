<?php
require_once '../../includes/bootstrap.php';
requireRole(['discipline', 'admin', 'headteacher']);

$page_title = "Log Discipline Incident";

$success = '';
$error = '';

// Fetch students for dropdown
$students = $pdo->query("SELECT student_id, first_name, last_name, admission_number FROM students WHERE status = 'Active' ORDER BY first_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $incident_date = $_POST['incident_date'];
    $incident_type = trim($_POST['incident_type']);
    $severity = $_POST['severity'];
    $description = trim($_POST['description']);
    $action_taken = trim($_POST['action_taken']);
    $reported_by = $_SESSION['user_id'];

    if (empty($student_id) || empty($incident_type) || empty($incident_date)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO discipline_records (student_id, incident_date, incident_type, description, action_taken, severity, reported_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$student_id, $incident_date, $incident_type, $description, $action_taken, $severity, $reported_by]);
            $success = "Incident recorded successfully.";
            
            // Log Activity
            logActivity($_SESSION['user_id'], 'Discipline Incident', "Recorded incident for student ID $student_id");
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 25px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Records</a>
    </div>

    <div class="card shadow-premium" style="max-width: 800px; margin: 0 auto; border-top: 5px solid var(--corporate-red);">
        <div class="card-header" style="background: var(--header-gradient);">
            <h3 style="margin: 0; color: white;"><i class="fas fa-plus-circle"></i> Log Student Incident</h3>
        </div>
        <div class="card-body">
            <?php if ($success): ?>
                <div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 600;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div style="background: #fff5f5; color: #c62828; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 600;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Select Student <span class="text-red">*</span></label>
                        <select name="student_id" class="form-control select2" required>
                            <option value="">-- Choose Student --</option>
                            <?php foreach ($students as $s): ?>
                                <option value="<?php echo $s['student_id']; ?>"><?php echo h($s['first_name'] . ' ' . $s['last_name'] . ' (' . $s['admission_number'] . ')'); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Incident Date <span class="text-red">*</span></label>
                        <input type="date" name="incident_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Severity Level <span class="text-red">*</span></label>
                        <select name="severity" class="form-control" required>
                            <option value="low">Low (Warning)</option>
                            <option value="medium">Medium (Detention)</option>
                            <option value="high">High (Suspension)</option>
                            <option value="critical">Critical (Expulsion Recommended)</option>
                        </select>
                    </div>

                    <div class="form-group" style="grid-column: span 2;">
                        <label>Incident Type <span class="text-red">*</span></label>
                        <input type="text" name="incident_type" class="form-control" placeholder="e.g. Absenteeism, Fighting, Late coming, Theft" required>
                    </div>

                    <div class="form-group" style="grid-column: span 2;">
                        <label>Detailed Description</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Provide full details of the incident..."></textarea>
                    </div>

                    <div class="form-group" style="grid-column: span 2;">
                        <label>Action Taken / Punishment</label>
                        <textarea name="action_taken" class="form-control" rows="3" placeholder="What action was taken?"></textarea>
                    </div>
                </div>

                <div style="margin-top: 30px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 2; padding: 15px;"><i class="fas fa-save"></i> RECORD INCIDENT</button>
                    <a href="index.php" class="btn btn-outline" style="flex: 1; text-align: center; display: flex; align-items: center; justify-content: center; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #666;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Initialize Select2 if available for better student searching
    $(document).ready(function() {
        if ($.fn.select2) {
            $('.select2').select2({
                placeholder: "-- Search Student --",
                allowClear: true
            });
        }
    });
</script>

<?php require_once '../../includes/footer.php'; ?>
