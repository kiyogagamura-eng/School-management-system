<?php
require_once '../../includes/bootstrap.php';
requireRole(['discipline', 'admin', 'headteacher', 'dos']);

$page_title = "Discipline Records";

// Fetch incidents with student and reporter details
try {
    $stmt = $pdo->query("
        SELECT dr.*, s.first_name, s.last_name, s.admission_number, c.class_name, u.username as reporter
        FROM discipline_records dr
        JOIN students s ON dr.student_id = s.student_id
        JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON dr.reported_by = u.user_id
        ORDER BY dr.incident_date DESC, dr.created_at DESC
    ");
    $records = $stmt->fetchAll();
} catch (PDOException $e) {
    $records = [];
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0; color: var(--corporate-red);"><i class="fas fa-clipboard-list"></i> Discipline Records</h2>
            <p style="color: var(--secondary-text); margin-top: 5px;">View and manage student behavioral records.</p>
        </div>
        <a href="create.php" class="btn btn-primary" style="background: var(--corporate-red); border-color: var(--corporate-red); padding: 12px 25px;"><i class="fas fa-plus"></i> LOG NEW INCIDENT</a>
    </div>

    <div class="card shadow-premium">
        <div class="card-header" style="background: #f8fafc; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 800; color: #2C3E50;">All Incidents</span>
            <div style="display: flex; gap: 10px;">
                <input type="text" id="recordSearch" placeholder="Search student or type..." style="padding: 6px 15px; border: 1px solid #ddd; border-radius: 20px; font-size: 0.85rem; width: 250px;">
            </div>
        </div>
        <div class="card-body" style="padding: 0;">
            <table class="table" id="disciplineTable">
                <thead style="background: #fffafaf0;">
                    <tr>
                        <th style="padding-left: 20px;">Date</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Incident Type</th>
                        <th>Severity</th>
                        <th>Action Taken</th>
                        <th>Reported By</th>
                        <th style="text-align: right; padding-right: 20px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 50px; color: #999;">No discipline records found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($records as $r): 
                            $severity_colors = [
                                'low' => ['#f1f5f9', '#64748b'],
                                'medium' => ['#fff3e0', '#ef6c00'],
                                'high' => ['#fff5f5', '#940000'],
                                'critical' => ['#940000', '#ffffff']
                            ];
                            $colors = $severity_colors[$r['severity']] ?? ['#eee', '#333'];
                        ?>
                            <tr>
                                <td style="padding-left: 20px; font-weight: 600;"><?php echo date('d M Y', strtotime($r['incident_date'])); ?></td>
                                <td>
                                    <div style="font-weight: 700; color: #2C3E50;"><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></div>
                                    <div style="font-size: 0.75rem; color: #7f8c8d;"><?php echo h($r['admission_number']); ?></div>
                                </td>
                                <td style="font-weight: 600;"><?php echo h($r['class_name']); ?></td>
                                <td style="font-weight: 600; color: var(--corporate-red);"><?php echo h($r['incident_type']); ?></td>
                                <td>
                                    <span style="background: <?php echo $colors[0]; ?>; color: <?php echo $colors[1]; ?>; padding: 4px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase;">
                                        <?php echo h($r['severity']); ?>
                                    </span>
                                </td>
                                <td style="font-size: 0.85rem; max-width: 200px;"><?php echo h($r['action_taken'] ?: '---'); ?></td>
                                <td style="font-size: 0.8rem; color: #666;"><i class="fas fa-user-edit"></i> <?php echo h($r['reporter']); ?></td>
                                <td style="text-align: right; padding-right: 20px;">
                                    <a href="view.php?id=<?php echo $r['record_id']; ?>" style="color: #3498db; margin-right: 15px;"><i class="fas fa-eye"></i></a>
                                    <a href="edit.php?id=<?php echo $r['record_id']; ?>" style="color: #2ecc71; margin-right: 15px;"><i class="fas fa-edit"></i></a>
                                    <a href="delete.php?id=<?php echo $r['record_id']; ?>" style="color: #e74c3c;" onclick="return confirm('Delete this record?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    document.getElementById('recordSearch').addEventListener('keyup', function() {
        let value = this.value.toLowerCase();
        let rows = document.querySelectorAll('#disciplineTable tbody tr');
        
        rows.forEach(row => {
            let text = row.textContent.toLowerCase();
            row.style.display = text.includes(value) ? '' : 'none';
        });
    });
</script>

<?php require_once '../../includes/footer.php'; ?>
