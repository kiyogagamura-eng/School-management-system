<?php
require_once '../../includes/bootstrap.php';
requireRole(['discipline', 'admin', 'headteacher', 'dos']);

$page_title = "Behavior Reports";

try {
    $current_term = getCurrentTerm();
    $term_id = $current_term['term_id'];
    
    // Fetch behavior reports for current term
    $stmt = $pdo->prepare("
        SELECT br.*, s.first_name, s.last_name, s.admission_number, c.class_name, u.username as creator
        FROM behavior_reports br
        JOIN students s ON br.student_id = s.student_id
        JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON br.created_by = u.user_id
        WHERE br.term_id = ?
        ORDER BY c.form_level, c.stream, s.first_name
    ");
    $stmt->execute([$term_id]);
    $reports = $stmt->fetchAll();
} catch (PDOException $e) {
    $reports = [];
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0; color: var(--corporate-red);"><i class="fas fa-star"></i> Behavior Reports</h2>
            <p style="color: var(--secondary-text); margin-top: 5px;">Term-wise behavioral grading and comments.</p>
        </div>
        <a href="add-behavior.php" class="btn btn-primary" style="background: var(--corporate-red); border-color: var(--corporate-red); padding: 12px 25px;"><i class="fas fa-plus"></i> NEW REPORT</a>
    </div>

    <div class="card shadow-premium">
        <div class="card-header" style="background: #f8fafc; border-bottom: 1px solid #eee;">
            <span style="font-weight: 800; color: #2C3E50;">Current Term: <?php echo h($current_term['term_name'] ?? 'N/A'); ?></span>
        </div>
        <div class="card-body" style="padding: 0;">
            <table class="table">
                <thead>
                    <tr>
                        <th style="padding-left: 20px;">Student</th>
                        <th>Class</th>
                        <th>Behavior Grade</th>
                        <th>Comments</th>
                        <th>Evaluated By</th>
                        <th style="text-align: right; padding-right: 20px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($reports)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 50px; color: #999;">No behavior reports for this term yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($reports as $r): ?>
                            <tr>
                                <td style="padding-left: 20px;">
                                    <div style="font-weight: 700; color: #2C3E50;"><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></div>
                                    <div style="font-size: 0.75rem; color: #7f8c8d;"><?php echo h($r['admission_number']); ?></div>
                                </td>
                                <td style="font-weight: 600;"><?php echo h($r['class_name']); ?></td>
                                <td>
                                    <span style="font-size: 1.2rem; font-weight: 900; color: <?php echo $r['behavior_grade'] == 'A' ? '#2e7d32' : ($r['behavior_grade'] == 'F' ? '#c62828' : '#2C3E50'); ?>;">
                                        <?php echo h($r['behavior_grade']); ?>
                                    </span>
                                </td>
                                <td style="font-size: 0.85rem; max-width: 300px;"><?php echo h($r['comments']); ?></td>
                                <td style="font-size: 0.8rem; color: #666;"><?php echo h($r['creator']); ?></td>
                                <td style="text-align: right; padding-right: 20px;">
                                    <a href="edit-behavior.php?id=<?php echo $r['report_id']; ?>" style="color: #2ecc71; margin-right: 15px;"><i class="fas fa-edit"></i></a>
                                    <a href="delete-behavior.php?id=<?php echo $r['report_id']; ?>" style="color: #e74c3c;" onclick="return confirm('Delete this report?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
