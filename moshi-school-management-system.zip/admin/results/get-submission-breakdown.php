<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$class_id = $_GET['class_id'] ?? 0;
$current_year = date('Y');

if (!$class_id) {
    echo json_encode([]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            s.subject_name,
            u.username as teacher_name,
            (SELECT COUNT(*) FROM exams e WHERE e.class_id = cs.class_id AND e.subject_id = cs.subject_id AND YEAR(e.created_at) = ? AND e.is_published = 1) as is_published
        FROM class_subjects cs
        JOIN subjects s ON cs.subject_id = s.subject_id
        LEFT JOIN users u ON cs.teacher_id = u.user_id
        WHERE cs.class_id = ?
        ORDER BY s.subject_name ASC
    ");
    $stmt->execute([$current_year, $class_id]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode($results);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
