<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Class Performance Report";

// Fetch classes
$stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level ASC, stream ASC");
$classes = $stmt->fetchAll();

$selected_class_id = $_GET['class_id'] ?? '';

// Fetch distinct exam names for this class
$available_exams = [];
if ($selected_class_id) {
    $stmt = $pdo->prepare("SELECT DISTINCT exam_name FROM exams WHERE class_id = ? AND is_published = 1 ORDER BY created_at DESC");
    $stmt->execute([$selected_class_id]);
    $available_exams = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

$selected_exam = $_GET['exam_name'] ?? ($available_exams[0] ?? '');

// Class Stats Data
$class_info = null;
$student_performances = [];
$subject_breakdown = [];
$division_counts = ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0];

if ($selected_class_id && $selected_exam) {
    // 1. Get Class Details
    $stmt = $pdo->prepare("SELECT c.*, t.first_name, t.last_name FROM classes c LEFT JOIN teachers t ON c.class_teacher_id = t.teacher_id WHERE c.class_id = ?");
    $stmt->execute([$selected_class_id]);
    $class_info = $stmt->fetch();

    // 2. Get All Results for this class and exam
    $stmt = $pdo->prepare("
        SELECT r.student_id, r.grade, r.marks_obtained, sub.subject_name, s.first_name, s.last_name, s.gender, gs.point_value
        FROM results r
        JOIN students s ON r.student_id = s.student_id
        JOIN subjects sub ON r.subject_id = sub.subject_id
        JOIN exams e ON r.exam_id = e.exam_id
        LEFT JOIN grading_scale gs ON r.grade = gs.grade
        WHERE e.class_id = ? AND e.exam_name = ? AND r.status = 'published'
    ");
    $stmt->execute([$selected_class_id, $selected_exam]);
    $raw_results = $stmt->fetchAll();

    // Group by student
    $students_data = [];
    foreach ($raw_results as $r) {
        $sid = $r['student_id'];
        if (!isset($students_data[$sid])) {
            $students_data[$sid] = [
                'name' => $r['first_name'] . ' ' . $r['last_name'],
                'gender' => $r['gender'],
                'marks' => [],
                'total_marks' => 0
            ];
        }
        $students_data[$sid]['marks'][] = $r;
        $students_data[$sid]['total_marks'] += $r['marks_obtained'];

        // Subject breakdown
        if (!isset($subject_breakdown[$r['subject_name']])) {
            $subject_breakdown[$r['subject_name']] = ['sum' => 0, 'total' => 0, 'passed' => 0];
        }
        $subject_breakdown[$r['subject_name']]['sum'] += $r['marks_obtained'];
        $subject_breakdown[$r['subject_name']]['total']++;
        if ($r['marks_obtained'] >= 40) $subject_breakdown[$r['subject_name']]['passed']++;
    }

    foreach ($students_data as $sid => $data) {
        $div_info = calculateOLevelDivision($data['marks']);
        $div = $div_info['division'];
        if (isset($division_counts[$div])) $division_counts[$div]++;

        $count = count($data['marks']);
        $avg = $count > 0 ? ($data['total_marks'] / $count) : 0;

        $student_performances[] = [
            'name' => $data['name'],
            'gender' => $data['gender'],
            'avg' => $avg,
            'division' => $div,
            'points' => $div_info['total_points']
        ];
    }

    // Sort by average descending
    usort($student_performances, function($a, $b) { return $b['avg'] <=> $a['avg']; });
}

require_once '../../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="filter-card no-print">
        <form action="" method="GET" class="filter-grid">
            <div class="filter-group">
                <label class="filter-label"><i class="fas fa-chalkboard"></i> Select Class</label>
                <select name="class_id" class="custom-select" onchange="this.form.submit()">
                    <option value="">Choose Class...</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class_id == $c['class_id'] ? 'selected' : ''; ?>>
                            <?php echo h($c['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label class="filter-label"><i class="fas fa-file-alt"></i> Select Assessment</label>
                <select name="exam_name" class="custom-select" <?php echo !$selected_class_id ? 'disabled' : ''; ?> onchange="this.form.submit()">
                    <option value="">Choose Exam...</option>
                    <?php 
                    // Group exams using standard categories from helper
                    $standard_groups = getStandardExamNames();
                    $grouped_available_exams = [];
                    
                    // Categorize exams based on keywords in their names
                    foreach ($available_exams as $exam) {
                        $exam_name_lower = strtolower($exam);
                        $categorized = false;
                        
                        foreach ($standard_groups as $category => $keywords) {
                            foreach ($keywords as $keyword) {
                                if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                    $grouped_available_exams[$category][] = $exam;
                                    $categorized = true;
                                    break 2;
                                }
                            }
                        }
                        
                        // If not categorized, put in "Other Assessments"
                        if (!$categorized) {
                            $grouped_available_exams['Other Assessments'][] = $exam;
                        }
                    }
                    
                    // Display grouped options
                    foreach ($grouped_available_exams as $category => $exams_group): ?>
                        <optgroup label="<?php echo h($category); ?>">
                            <?php foreach ($exams_group as $exam): ?>
                                <option value="<?php echo h($exam); ?>" <?php echo $selected_exam == $exam ? 'selected' : ''; ?>>
                                    <?php echo h($exam); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="button" onclick="window.print()" class="btn-export <?php echo !$selected_exam ? 'disabled' : ''; ?>">
                <i class="fas fa-print"></i> Export Report
            </button>
        </form>
    </div>

    <?php if ($class_info): ?>
        <div class="row g-4">
            <!-- Header Info -->
            <div class="col-12 text-center mb-2">
                <h2 class="fw-black text-primary text-uppercase"><?php echo h($class_info['class_name']); ?> - PERFORMANCE SUMMARY</h2>
                <h5 class="text-muted fw-bold">Assessment: <?php echo h($selected_exam); ?></h5>
                <p class="text-muted">Class Teacher: <b><?php echo h($class_info['first_name'] . ' ' . $class_info['last_name']); ?></b></p>
            </div>

            <!-- Division Breakdown -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-white border-0 py-3 px-4">
                        <h6 class="fw-black m-0 text-muted">DIVISION SUMMARY</h6>
                    </div>
                    <div class="card-body px-4">
                        <?php foreach ($division_counts as $div => $count): 
                             $total_st = count($student_performances);
                             $pct = $total_st > 0 ? round(($count / $total_st) * 100) : 0;
                             $color = ($div == 'I' || $div == 'II') ? 'success' : ($div == 'III' ? 'primary' : ($div == 'IV' ? 'warning' : 'danger'));
                        ?>
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-<?php echo $color; ?> text-white fw-black rounded-3 text-center py-2 me-3" style="width: 50px;">
                                    <?php echo $div; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="small fw-bold">Students: <b><?php echo $count; ?></b></span>
                                        <span class="small fw-bold text-muted"><?php echo $pct; ?>%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-<?php echo $color; ?>" style="width: <?php echo $pct; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Class Statistics -->
            <div class="col-md-8">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm rounded-4 p-4 text-center bg-primary text-white">
                            <h6 class="small fw-bold opacity-75 mb-2">PASS RATE</h6>
                            <?php 
                                $passed = count(array_filter($student_performances, function($s) { return $s['avg'] >= 40; }));
                                $pass_rate = $total_st > 0 ? round(($passed / $total_st) * 100) : 0;
                            ?>
                            <h2 class="fw-black mb-0"><?php echo $pass_rate; ?>%</h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm rounded-4 p-4 text-center bg-secondary text-white">
                            <h6 class="small fw-bold opacity-75 mb-2">CLASS AVERAGE</h6>
                            <?php 
                                $sum_avg = array_sum(array_column($student_performances, 'avg'));
                                $class_avg = $total_st > 0 ? round($sum_avg / $total_st, 1) : 0;
                            ?>
                            <h2 class="fw-black mb-0"><?php echo $class_avg; ?>%</h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm rounded-4 p-4 text-center" style="background: #fff5f5; color: #940000;">
                            <h6 class="small fw-bold opacity-75 mb-2">TOTAL STUDENTS</h6>
                            <h2 class="fw-black mb-0"><?php echo $total_st; ?></h2>
                        </div>
                    </div>

                    <!-- Subject Wise -->
                    <div class="col-12">
                        <div class="card border-0 shadow-sm rounded-4">
                            <div class="card-header bg-white border-0 py-3 px-4">
                                <h6 class="fw-black m-0 text-muted">SUBJECT PERFORMANCE (CLASS-WISE)</h6>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover mb-0 align-middle">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-4">Subject</th>
                                            <th class="text-center">Average</th>
                                            <th class="text-center">Pass Rate</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($subject_breakdown as $name => $stats): 
                                            $s_avg = round($stats['sum'] / $stats['total'], 1);
                                            $s_rate = round(($stats['passed'] / $stats['total']) * 100);
                                            $s_color = $s_rate >= 70 ? 'success' : ($s_rate >= 40 ? 'warning' : 'danger');
                                        ?>
                                            <tr>
                                                <td class="ps-4 fw-bold"><?php echo h($name); ?></td>
                                                <td class="text-center fw-black text-primary"><?php echo $s_avg; ?>%</td>
                                                <td class="text-center fw-bold"><?php echo $s_rate; ?>%</td>
                                                <td class="text-center">
                                                    <span class="badge bg-<?php echo $s_color; ?>-soft text-<?php echo $s_color; ?>"><?php echo $s_rate >= 70 ? 'Strong' : ($s_rate >= 40 ? 'Average' : 'Weak'); ?></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Student Ranking Table -->
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-0 py-3 px-4 d-flex justify-content-between align-items-center">
                        <h5 class="fw-black m-0">STUDENT RANKING</h5>
                        <span class="text-muted small">Sorted by Average Score</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-uppercase small fw-bold text-muted">
                                <tr>
                                    <th class="ps-4">Rank</th>
                                    <th>Student Name</th>
                                    <th class="text-center">Gender</th>
                                    <th class="text-center">Avg Score</th>
                                    <th class="text-center">Div / Pts</th>
                                    <th class="text-center">Performance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($student_performances as $idx => $sp): 
                                    $rank = $idx + 1;
                                    $color = ($rank <= 3) ? 'warning' : 'secondary';
                                ?>
                                    <tr>
                                        <td class="ps-4">
                                            <span class="badge rounded-pill bg-<?php echo $color; ?> fw-black" style="width: 30px;"><?php echo $rank; ?></span>
                                        </td>
                                        <td class="fw-bold"><?php echo h($sp['name']); ?></td>
                                        <td class="text-center text-muted"><?php echo $sp['gender']; ?></td>
                                        <td class="text-center fw-black text-primary"><?php echo round($sp['avg'], 1); ?>%</td>
                                        <td class="text-center">
                                            <span class="badge bg-dark fw-bold"><?php echo $sp['division']; ?> - <?php echo $sp['points']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <?php 
                                                $p_pct = round($sp['avg']);
                                                $p_color = $p_pct >= 75 ? 'success' : ($p_pct >= 65 ? 'primary' : ($p_pct >= 45 ? 'warning' : 'danger'));
                                            ?>
                                            <div class="progress" style="height: 15px; width: 100px; margin: 0 auto; border-radius: 20px;">
                                                <div class="progress-bar bg-<?php echo $p_color; ?>" style="width: <?php echo $p_pct; ?>%"></div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif ($selected_class_id): ?>
        <div class="text-center p-5">
            <h4 class="text-muted">Please select an assessment to view reports for this class.</h4>
        </div>
    <?php else: ?>
        <div class="text-center p-5 mt-5 opacity-50">
            <i class="fas fa-school fa-6x mb-4"></i>
            <h3>Class performance reports will appear here</h3>
            <p>Select a class and an assessment from the filters above to begin.</p>
        </div>
    <?php endif; ?>
</div>

<style>
    .fw-black { font-weight: 900 !important; }
    
    /* Premium Filter Card */
    .filter-card {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        border: 1px solid #e2e8f0;
        padding: 25px;
        margin-bottom: 30px;
    }
    .filter-grid {
        display: grid;
        grid-template-columns: 1fr 1fr auto;
        gap: 20px;
        align-items: flex-end;
    }
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .filter-label {
        font-size: 0.75rem;
        font-weight: 800;
        text-transform: uppercase;
        color: #64748b;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .filter-label i { color: #940000; }
    
    .custom-select {
        height: 50px;
        border-radius: 12px;
        border: 2px solid #f1f5f9;
        background-color: #f8fafc;
        padding: 0 15px;
        font-weight: 700;
        color: #1e293b;
        transition: all 0.2s;
        cursor: pointer;
        width: 100%;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 15px center;
        background-size: 18px;
    }
    .custom-select:focus {
        border-color: #940000;
        background-color: #fff;
        outline: none;
        box-shadow: 0 0 0 4px rgba(148,0,0,0.1);
    }

    .btn-export {
        height: 50px;
        padding: 0 25px;
        border-radius: 12px;
        background: #940000;
        color: white;
        font-weight: 800;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s;
        border: none;
    }
    .btn-export:hover {
        background: #7d0000;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(148,0,0,0.2);
    }

    .div-badge {
        padding: 4px 12px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 0.7rem;
    }
    .div-I { background: #ecfdf5; color: #059669; }
    .div-II { background: #eff6ff; color: #2563eb; }
    .div-III { background: #fffbeb; color: #d97706; }
    .div-IV { background: #fff7ed; color: #ea580c; }
    .div-0 { background: #fef2f2; color: #dc2626; }

    .empty-state {
        text-align: center;
        padding: 80px 20px;
        background: #fff;
        border-radius: 20px;
        border: 2px dashed #e2e8f0;
    }

    @media print {
        .no-print { display: none !important; }
        .container-fluid { padding: 0 !important; }
        .card { box-shadow: none !important; border: 1px solid #ddd !important; }
    }
</style>

<?php require_once '../../includes/footer.php'; ?>
