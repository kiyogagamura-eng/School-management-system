<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Overall School Statistics";

// Fetch distinct exam names to filter
$stmt = $pdo->query("SELECT DISTINCT exam_name FROM exams WHERE is_published = 1 ORDER BY created_at DESC");
$available_exams = $stmt->fetchAll(PDO::FETCH_COLUMN);

$selected_exam = $_GET['exam_name'] ?? ($available_exams[0] ?? '');

// Statistics Arrays
$division_stats = ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, '0' => 0];
$subject_stats = [];
$gender_stats = ['Male' => ['total' => 0, 'pass' => 0, 'avg' => 0], 'Female' => ['total' => 0, 'pass' => 0, 'avg' => 0]];
$top_students = [];
$class_performance = [];

$total_sat = 0;
$overall_passed = 0;
$overall_total = 0;
$sum_all_avg = 0;

if ($selected_exam) {
    // 1. Get All Published Results for this exam
    $stmt = $pdo->prepare("
        SELECT r.student_id, r.grade, r.marks_obtained, s.gender, s.class_id, c.class_name, sub.subject_name, gs.point_value
        FROM results r
        JOIN students s ON r.student_id = s.student_id
        JOIN classes c ON s.class_id = c.class_id
        JOIN subjects sub ON r.subject_id = sub.subject_id
        JOIN exams e ON r.exam_id = e.exam_id
        LEFT JOIN grading_scale gs ON r.grade = gs.grade
        WHERE e.exam_name = ? AND r.status = 'published'
    ");
    $stmt->execute([$selected_exam]);
    $all_results = $stmt->fetchAll();

    // Group results by student to calculate divisions
    $student_results = [];
    foreach ($all_results as $r) {
        $student_results[$r['student_id']]['marks'][] = $r;
        $student_results[$r['student_id']]['gender'] = $r['gender'];
        $student_results[$r['student_id']]['class_id'] = $r['class_id'];
        $student_results[$r['student_id']]['class_name'] = $r['class_name'];
        
        // Subject Stats
        if (!isset($subject_stats[$r['subject_name']])) {
            $subject_stats[$r['subject_name']] = ['total' => 0, 'passed' => 0, 'sum' => 0];
        }
        $subject_stats[$r['subject_name']]['total']++;
        if ($r['marks_obtained'] >= 40) $subject_stats[$r['subject_name']]['passed']++;
        $subject_stats[$r['subject_name']]['sum'] += $r['marks_obtained'];
    }

    // Process Student Divisions & Gender Stats
    foreach ($student_results as $sid => $data) {
        $div_info = calculateOLevelDivision($data['marks']);
        $div = $div_info['division'];
        if (isset($division_stats[$div])) $division_stats[$div]++;

        // Calculate Average for this student
        $count = count($data['marks']);
        $sum = array_sum(array_column($data['marks'], 'marks_obtained'));
        $avg = $count > 0 ? ($sum / $count) : 0;
$sum_all_avg += $avg;

        // Gender stats
        $gen = $data['gender'];
        if (isset($gender_stats[$gen])) {
            $gender_stats[$gen]['total']++;
            $gender_stats[$gen]['avg'] += $avg;
            if ($avg >= 40) $gender_stats[$gen]['pass']++;
        }

        // Class Performance
        $cid = $data['class_id'];
        if (!isset($class_performance[$cid])) {
            $class_performance[$cid] = ['name' => $data['class_name'], 'total' => 0, 'sum_avg' => 0, 'div_i' => 0];
        }
        $class_performance[$cid]['total']++;
        $class_performance[$cid]['sum_avg'] += $avg;
        if ($div == 'I') $class_performance[$cid]['div_i']++;


        // Store for ranking
        $stmt_name = $pdo->prepare("SELECT first_name, last_name FROM students WHERE student_id = ?");
        $stmt_name->execute([$sid]);
        $s_name = $stmt_name->fetch();

        $top_students[] = [
            'name' => $s_name['first_name'] . ' ' . $s_name['last_name'],
            'avg' => $avg,
            'div' => $div,
            'class' => $data['class_name']
        ];
    }

    $total_sat = count($student_results);
    // Compute overall pass rate based on students passing (Division I-IV)
    $students_passed = $division_stats['I'] + $division_stats['II'] + $division_stats['III'] + $division_stats['IV'];
    $pass_rate = $total_sat > 0 ? round(($students_passed / $total_sat) * 100, 1) : 0;
    // Compute final school average
    $final_school_avg = $total_sat > 0 ? round($sum_all_avg / $total_sat, 1) : 0;

    // Sort top students
    usort($top_students, function($a, $b) { return $b['avg'] <=> $a['avg']; });
    $top_students = array_slice($top_students, 0, 10);

    // Finalize gender averages
    foreach ($gender_stats as &$gs) {
        if ($gs['total'] > 0) $gs['avg'] = round($gs['avg'] / $gs['total'], 1);
    }
}

require_once '../../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="filter-card no-print">
        <div class="row align-items-center">
            <div class="col">
                <h2 class="fw-black text-primary m-0"><i class="fas fa-chart-pie me-2"></i>SCHOOL PERFORMANCE DASHBOARD</h2>
                <p class="text-muted mb-0">Comprehensive analytical overview of academic results</p>
            </div>
            <div class="col-auto">
                <form action="" method="GET" class="d-flex gap-2">
                    <div class="filter-group">
                        <select name="exam_name" class="custom-select" onchange="this.form.submit()" style="min-width: 280px;">
                            <option value="">Select Assessment...</option>
                            <?php 
                            // Group exams using standard categories from helper
                            $standard_groups = getStandardExamNames();
                            $grouped_available_exams = [];
                            
                            // Categorize exams based on keywords in their names
                            foreach ($available_exams as $exam) {
                                $exam_name_lower = strtolower($exam);
                                $categorized = false;
                                
                                foreach ($standard_groups as $category => $keywords) {
                                    foreach ($keywords as $keyword) {
                                        if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                            $grouped_available_exams[$category][] = $exam;
                                            $categorized = true;
                                            break 2;
                                        }
                                    }
                                }
                                
                                // If not categorized, put in "Other Assessments"
                                if (!$categorized) {
                                    $grouped_available_exams['Other Assessments'][] = $exam;
                                }
                            }
                            
                            // Display grouped options
                            foreach ($grouped_available_exams as $category => $exams_group): ?>
                                <optgroup label="<?php echo h($category); ?>">
                                    <?php foreach ($exams_group as $exam): ?>
                                        <option value="<?php echo h($exam); ?>" <?php echo $selected_exam == $exam ? 'selected' : ''; ?>>
                                            <?php echo h($exam); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="button" onclick="downloadPDF()" class="btn-export">
                        <i class="fas fa-download"></i> Download PDF
                    </button>
                </form>
            </div>
        </div>
    </div>

    <?php if (!$selected_exam): ?>
        <div class="alert alert-info p-5 text-center shadow-sm rounded-4">
            <i class="fas fa-info-circle fa-4x mb-3 opacity-25"></i>
            <h3>No Published Results Found</h3>
            <p>Please ensure that exam results have been compiled and published by the administration.</p>
        </div>
    <?php else: ?>
        
        <!-- Dashboard Metrics Top Row -->
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-danger text-white"><i class="fas fa-users"></i></div>
                    <h6 class="text-muted fw-bold small text-uppercase">Total Students Sat</h6>
                    <h2 class="fw-black mb-1"><?php echo count($student_results); ?></h2>
                    <p class="small text-muted mb-0">Students sat for exams</p>
                    <i class="fas fa-users position-absolute end-0 bottom-0 p-3 opacity-25 fa-2x"></i>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-success text-white"><i class="fas fa-check-circle"></i></div>
                    <h6 class="text-muted fw-bold small text-uppercase">Overall Pass Rate</h6>
                    <h2 class="fw-black mb-1 text-success"><?php echo $pass_rate; ?>%</h2>
                    <p class="small text-muted mb-0">Pass rate this term</p>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-success" style="width: <?php echo $pass_rate; ?>%"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-warning text-white"><i class="fas fa-award"></i></div>
                    <h6 class="text-muted fw-bold small text-uppercase">Division I Students</h6>
                    <h2 class="fw-black mb-1 text-warning"><?php echo $division_stats['I']; ?></h2>
                    <p class="small text-muted mb-0">Highest honors achieved</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-primary text-white"><i class="fas fa-chart-line"></i></div>
                    <h6 class="text-muted fw-bold small text-uppercase">School Average</h6>
                    <h2 class="fw-black mb-1 text-primary"><?php echo $final_school_avg; ?>%</h2>
                    <p class="small text-muted mb-0">Average performance</p>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <!-- Division Statistics with Donut -->
            <div class="col-md-6">
                <div class="stat-card">
                    <h5 class="fw-black mb-4" style="color: #940000;">DIVISION DISTRIBUTION</h5>
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="donut-container">
                                <div class="donut-chart">
                                    <div class="donut-inner">
                                        <span class="display-6 fw-black"><?php echo $total_sat; ?></span>
                                        <span class="small text-muted fw-bold">Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex flex-column gap-2">
                                <?php foreach ($division_stats as $div => $count): 
                                    $pct = $total_sat > 0 ? round(($count / $total_sat) * 100) : 0;
                                    $dot_color = $div == 'I' ? '#059669' : ($div == 'II' ? '#2563eb' : ($div == 'III' ? '#d97706' : ($div == 'IV' ? '#ea580c' : '#dc2626')));
                                ?>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center gap-2">
                                            <div style="width: 10px; height: 10px; border-radius: 50%; background: <?php echo $dot_color; ?>;"></div>
                                            <span class="small fw-bold">Division <?php echo $div; ?></span>
                                        </div>
                                        <div class="text-end">
                                            <span class="small fw-black"><?php echo $count; ?></span>
                                            <span class="ms-2 small text-muted"><?php echo $pct; ?>%</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gender Performance with Cards -->
            <div class="col-md-6">
                <div class="stat-card">
                    <h5 class="fw-black mb-4" style="color: #940000;">GENDER PERFORMANCE COMPARISON</h5>
                    <div class="gender-card" style="background: #eff6ff;">
                        <i class="fas fa-male fa-2x text-primary"></i>
                        <div class="flex-grow-1">
                            <h6 class="small fw-bold text-muted text-uppercase mb-0">Boys</h6>
                            <h3 class="fw-black text-primary mb-0"><?php echo $gender_stats['Male']['avg']; ?>%</h3>
                            <p class="small text-muted mb-0"><?php echo $gender_stats['Male']['total']; ?> Students</p>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-primary-soft text-primary fw-black">PASS RATE: <?php echo $gender_stats['Male']['total'] > 0 ? round(($gender_stats['Male']['pass'] / $gender_stats['Male']['total']) * 100) : 0; ?>%</span>
                        </div>
                    </div>
                    <div class="gender-card" style="background: #fdf2f8;">
                        <i class="fas fa-female fa-2x text-danger"></i>
                        <div class="flex-grow-1">
                            <h6 class="small fw-bold text-muted text-uppercase mb-0">Girls</h6>
                            <h3 class="fw-black text-danger mb-0"><?php echo $gender_stats['Female']['avg']; ?>%</h3>
                            <p class="small text-muted mb-0"><?php echo $gender_stats['Female']['total']; ?> Students</p>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-danger-soft text-danger fw-black">PASS RATE: <?php echo $gender_stats['Female']['total'] > 0 ? round(($gender_stats['Female']['pass'] / $gender_stats['Female']['total']) * 100) : 0; ?>%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <!-- Subject Performance -->
            <div class="col-md-7">
                <div class="stat-card p-0">
                    <div class="p-4 border-bottom">
                        <h5 class="fw-black m-0" style="color: #940000;">SUBJECT PERFORMANCE SUMMARY</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table-premium">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th class="text-center">Students</th>
                                    <th class="text-center">Pass Rate</th>
                                    <th class="text-center">Average Score</th>
                                    <th class="text-center">Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    uasort($subject_stats, function($a, $b) { return ($b['passed']/$b['total']) <=> ($a['passed']/$a['total']); });
                                    foreach ($subject_stats as $name => $stats): 
                                        $rate = round(($stats['passed'] / $stats['total']) * 100);
                                        $avg = round($stats['sum'] / $stats['total'], 1);
                                        $status_color = $rate >= 75 ? 'success' : ($rate >= 45 ? 'warning' : 'danger');
                                ?>
                                    <tr>
                                        <td><?php echo h($name); ?></td>
                                        <td class="text-center"><?php echo $stats['total']; ?></td>
                                        <td class="text-center fw-black"><?php echo $rate; ?>%</td>
                                        <td class="text-center fw-black text-primary"><?php echo $avg; ?>%</td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $status_color; ?>-soft text-<?php echo $status_color; ?> fw-black">
                                                <?php echo $rate >= 75 ? 'Excellent' : ($rate >= 45 ? 'Satisfactory' : 'Needs Focus'); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Top Performing Students -->
            <div class="col-md-5">
                <div class="stat-card p-0">
                    <div class="p-4 border-bottom d-flex align-items-center gap-2">
                        <i class="fas fa-trophy text-warning"></i>
                        <h5 class="fw-black m-0" style="color: #940000;">TOP PERFORMERS</h5>
                    </div>
                    <div class="p-2">
                        <table class="table-premium">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Student</th>
                                    <th class="text-center">Division</th>
                                    <th class="text-center">Average</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_students as $idx => $ts): 
                                    $medal_color = $idx == 0 ? '#f59e0b' : ($idx == 1 ? '#94a3b8' : ($idx == 2 ? '#b45309' : '#e2e8f0'));
                                    $medal_text = $idx == 0 ? 'white' : ($idx == 1 ? 'white' : ($idx == 2 ? 'white' : '#64748b'));
                                ?>
                                    <tr>
                                        <td>
                                            <span class="medal" style="background: <?php echo $medal_color; ?>; color: <?php echo $medal_text; ?>;">
                                                <?php echo $idx + 1; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="fw-black"><?php echo h($ts['name']); ?></div>
                                            <div class="small text-muted fw-bold"><?php echo h($ts['class']); ?></div>
                                        </td>
                                        <td class="text-center small fw-bold"><?php echo $ts['div']; ?></td>
                                        <td class="text-center fw-black text-warning"><?php echo round($ts['avg'], 1); ?>%</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <!-- Division Summary Table -->
        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <div class="stat-card p-0">
                    <div class="p-4 border-bottom d-flex align-items-center gap-2">
                        <i class="fas fa-layer-group" style="color:#940000;"></i>
                        <h5 class="fw-black m-0" style="color: #940000;">DIVISION SUMMARY</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table-premium">
                            <thead>
                                <tr>
                                    <th>Division</th>
                                    <th class="text-center">Students</th>
                                    <th class="text-center">Percentage</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $div_labels = ['I'=>'Division I','II'=>'Division II','III'=>'Division III','IV'=>'Division IV','0'=>'Division 0'];
                                $div_colors = ['I'=>'success','II'=>'primary','III'=>'warning','IV'=>'danger','0'=>'dark'];
                                foreach ($division_stats as $d => $c): 
                                    $pct = $total_sat > 0 ? round(($c / $total_sat) * 100, 1) : 0;
                                    $clr = $div_colors[$d] ?? 'secondary';
                                ?>
                                <tr>
                                    <td>
                                        <span class="d-flex align-items-center gap-2">
                                            <span style="width:10px;height:10px;border-radius:50%;display:inline-block;" class="bg-<?php echo $clr; ?>"></span>
                                            <strong><?php echo $div_labels[$d] ?? $d; ?></strong>
                                        </span>
                                    </td>
                                    <td class="text-center fw-black"><?php echo $c; ?></td>
                                    <td class="text-center">
                                        <div class="d-flex align-items-center gap-2 justify-content-center">
                                            <div class="progress flex-grow-1" style="height:6px;max-width:80px;">
                                                <div class="progress-bar bg-<?php echo $clr; ?>" style="width:<?php echo $pct; ?>%"></div>
                                            </div>
                                            <span class="small fw-bold"><?php echo $pct; ?>%</span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-<?php echo $clr; ?>-soft text-<?php echo $clr; ?> fw-black" style="padding:5px 12px;border-radius:8px;">
                                            <?php echo $c; ?> Student<?php echo $c != 1 ? 's' : ''; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <tr style="background:#f8fafc;">
                                    <td><strong>Total</strong></td>
                                    <td class="text-center fw-black"><?php echo $total_sat; ?></td>
                                    <td class="text-center fw-black">100%</td>
                                    <td class="text-center"><span class="badge bg-dark text-white fw-black" style="padding:5px 12px;border-radius:8px;">All Students</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Class Ranking -->
            <div class="col-md-6">
                <div class="stat-card p-0">
                    <div class="p-4 border-bottom d-flex align-items-center gap-2">
                        <i class="fas fa-school" style="color:#940000;"></i>
                        <h5 class="fw-black m-0" style="color: #940000;">CLASS RANKING</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table-premium">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Class</th>
                                    <th class="text-center">Students</th>
                                    <th class="text-center">Average</th>
                                    <th class="text-center">Div I</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                uasort($class_performance, function($a,$b){ return ($b['sum_avg']/$b['total']) <=> ($a['sum_avg']/$a['total']); });
                                $rank = 0;
                                foreach ($class_performance as $cp): 
                                    $rank++;
                                    $class_avg = $cp['total'] > 0 ? round($cp['sum_avg'] / $cp['total'], 1) : 0;
                                ?>
                                <tr>
                                    <td><span class="medal" style="background:<?php echo $rank<=3?($rank==1?'#f59e0b':($rank==2?'#94a3b8':'#b45309')):'#e2e8f0'; ?>;color:<?php echo $rank<=3?'white':'#64748b'; ?>;"><?php echo $rank; ?></span></td>
                                    <td class="fw-black"><?php echo h($cp['name']); ?></td>
                                    <td class="text-center"><?php echo $cp['total']; ?></td>
                                    <td class="text-center fw-black text-primary"><?php echo $class_avg; ?>%</td>
                                    <td class="text-center"><span class="badge bg-success-soft text-success fw-black"><?php echo $cp['div_i']; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Info -->
        <div class="text-center mt-4 mb-3 small text-muted no-print">
            <i class="fas fa-info-circle me-1"></i> Showing <?php echo count($subject_stats); ?> subjects | <?php echo $total_sat; ?> students | Data from: <strong><?php echo h($selected_exam); ?></strong>
        </div>

    <?php endif; ?>
</div>

<style>
    /* === Grid System === */
    .row { display: flex; flex-wrap: wrap; margin: 0 -12px; }
    .row > [class*="col-"] { padding: 0 12px; box-sizing: border-box; }
    .col { flex: 1; }
    .col-auto { flex: 0 0 auto; width: auto; }
    .col-md-3 { flex: 0 0 25%; max-width: 25%; }
    .col-md-5 { flex: 0 0 41.666%; max-width: 41.666%; }
    .col-md-6 { flex: 0 0 50%; max-width: 50%; }
    .col-md-7 { flex: 0 0 58.333%; max-width: 58.333%; }
    .g-4 { gap: 24px; }
    .g-4 > [class*="col-"] { margin-bottom: 0; }
    .mb-5 { margin-bottom: 3rem !important; }
    .mt-4 { margin-top: 1.5rem !important; }
    .mb-3 { margin-bottom: 1rem !important; }
    .mb-4 { margin-bottom: 1.5rem !important; }
    .mb-1 { margin-bottom: 0.25rem !important; }
    .mb-0 { margin-bottom: 0 !important; }
    .m-0 { margin: 0 !important; }
    .p-0 { padding: 0 !important; }
    .p-2 { padding: 0.5rem !important; }
    .p-3 { padding: 1rem !important; }
    .p-4 { padding: 1.5rem !important; }
    .p-5 { padding: 3rem !important; }
    .py-4 { padding-top: 1.5rem !important; padding-bottom: 1.5rem !important; }
    .me-1 { margin-right: 0.25rem !important; }
    .me-2 { margin-right: 0.5rem !important; }
    .ms-2 { margin-left: 0.5rem !important; }
    .gap-2 { gap: 0.5rem !important; }
    .d-flex { display: flex !important; }
    .flex-wrap { flex-wrap: wrap !important; }
    .flex-column { flex-direction: column !important; }
    .flex-grow-1 { flex-grow: 1 !important; }
    .align-items-center { align-items: center !important; }
    .justify-content-between { justify-content: space-between !important; }
    .justify-content-center { justify-content: center !important; }
    .text-center { text-align: center !important; }
    .text-end { text-align: right !important; }
    .text-uppercase { text-transform: uppercase !important; }
    .small { font-size: 0.875rem !important; }
    .display-6 { font-size: 2rem; font-weight: 300; }
    .border-bottom { border-bottom: 1px solid #f1f5f9 !important; }
    .rounded-4 { border-radius: 16px !important; }
    .shadow-sm { box-shadow: 0 2px 8px rgba(0,0,0,0.05) !important; }
    .opacity-25 { opacity: 0.25 !important; }
    .position-absolute { position: absolute !important; }
    .end-0 { right: 0 !important; }
    .bottom-0 { bottom: 0 !important; }
    .progress { background: #e2e8f0; border-radius: 999px; overflow: hidden; height: 8px; }
    .progress-bar { height: 100%; border-radius: 999px; transition: width 0.6s ease; }
    .bg-success { background-color: #059669 !important; }
    .bg-primary { background-color: #2563eb !important; }
    .bg-warning { background-color: #d97706 !important; }
    .bg-danger { background-color: #dc2626 !important; }
    .bg-dark { background-color: #1e293b !important; }
    .text-success { color: #059669 !important; }
    .text-primary { color: #2563eb !important; }
    .text-warning { color: #d97706 !important; }
    .text-danger { color: #dc2626 !important; }
    .text-dark { color: #1e293b !important; }
    .text-white { color: white !important; }
    .text-muted { color: #94a3b8 !important; }
    .table-responsive { overflow-x: auto; }
    .container-fluid { width: 100%; padding: 0 15px; }
    .alert-info { background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; border-radius: 12px; }
    @media (max-width: 768px) {
        .col-md-3, .col-md-5, .col-md-6, .col-md-7 { flex: 0 0 100%; max-width: 100%; }
        .row { gap: 16px; }
        .filter-card .row { flex-direction: column; }
    }

    .fw-black { font-weight: 900 !important; }
    
    .filter-card {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        border: 1px solid #e2e8f0;
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: #fff;
        border-radius: 20px;
        padding: 25px;
        border: 1px solid #f1f5f9;
        box-shadow: 0 4px 20px rgba(0,0,0,0.03);
        height: 100%;
        position: relative;
        overflow: hidden;
        transition: all 0.3s;
    }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    
    .stat-icon {
        width: 45px;
        height: 45px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        margin-bottom: 15px;
    }

    .donut-container {
        position: relative;
        width: 180px;
        height: 180px;
        margin: 0 auto;
    }
    .donut-chart {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: conic-gradient(
            #059669 0deg <?php echo ($total_sat > 0) ? ($division_stats['I']/$total_sat)*360 : 0; ?>deg,
            #2563eb <?php echo ($total_sat > 0) ? ($division_stats['I']/$total_sat)*360 : 0; ?>deg <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II'])/$total_sat)*360 : 0; ?>deg,
            #d97706 <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II'])/$total_sat)*360 : 0; ?>deg <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II']+$division_stats['III'])/$total_sat)*360 : 0; ?>deg,
            #ea580c <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II']+$division_stats['III'])/$total_sat)*360 : 0; ?>deg <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II']+$division_stats['III']+$division_stats['IV'])/$total_sat)*360 : 0; ?>deg,
            #dc2626 <?php echo ($total_sat > 0) ? (($division_stats['I']+$division_stats['II']+$division_stats['III']+$division_stats['IV'])/$total_sat)*360 : 0; ?>deg 360deg
        );
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .donut-inner {
        width: 70%;
        height: 70%;
        background: white;
        border-radius: 50%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .gender-card {
        padding: 20px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .table-premium {
        width: 100%;
    }
    .table-premium th {
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        color: #94a3b8;
        padding: 15px 20px;
        border-bottom: 1px solid #f1f5f9;
    }
    .table-premium td {
        padding: 15px 20px;
        border-bottom: 1px solid #f1f5f9;
        font-weight: 600;
    }

    .medal {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 0.8rem;
        font-weight: 900;
    }

    .custom-select {
        height: 50px;
        border-radius: 12px;
        border: 2px solid #f1f5f9;
        background-color: #f8fafc;
        padding: 0 15px;
        font-weight: 700;
        color: #1e293b;
        transition: all 0.2s;
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 15px center;
        background-size: 18px;
    }
    .custom-select:focus {
        border-color: #940000;
        background-color: #fff;
        outline: none;
        box-shadow: 0 0 0 4px rgba(148,0,0,0.1);
    }

    .btn-export {
        height: 50px;
        padding: 0 25px;
        border-radius: 12px;
        background: #940000;
        color: white;
        font-weight: 800;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s;
        border: none;
    }
    .btn-export:hover {
        background: #7d0000;
        transform: translateY(-2px);
    }

    .metric-card {
        border-radius: 16px;
        border: none;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
    }

    .bronze { background: #cd7f32 !important; color: white !important; }

    .bg-success-soft { background: #dcfce7 !important; }
    .bg-primary-soft { background: #dbeafe !important; }
    .bg-warning-soft { background: #fef3c7 !important; }
    .bg-danger-soft { background: #fee2e2 !important; }
    .bg-dark-soft { background: #e2e8f0 !important; }

    .table-premium tr:hover { background: #f8fafc; }

    @media print {
        .main-sidebar, .main-header, .no-print, .btn { display: none !important; }
        .container-fluid { padding: 0 !important; }
        .card { box-shadow: none !important; border: 1px solid #eee !important; }
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
function downloadPDF() {
    var element = document.querySelector('.container-fluid');
    var noPrint = document.querySelectorAll('.no-print');
    
    // Temporarily hide no-print elements for PDF generation
    noPrint.forEach(el => el.style.display = 'none');
    
    var opt = {
      margin:       0.3,
      filename:     'School_Performance_Dashboard.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'in', format: 'a4', orientation: 'landscape' }
    };

    html2pdf().set(opt).from(element).save().then(() => {
        // Restore elements
        noPrint.forEach(el => el.style.display = '');
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
