<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Individual Student Report";

$success = '';
$error = '';

$selected_student_id = $_GET['student_id'] ?? '';
$selected_exam_name = $_GET['exam_name'] ?? '';

// Fetch all classes for the selector
$stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level ASC, stream ASC");
$classes = $stmt->fetchAll();

$selected_class_id = $_GET['class_id'] ?? '';

// If student is selected but class isn't, get class from student
if ($selected_student_id && !$selected_class_id) {
    $stmt = $pdo->prepare("SELECT class_id FROM students WHERE student_id = ?");
    $stmt->execute([$selected_student_id]);
    $selected_class_id = $stmt->fetchColumn();
}

// Fetch students for the selected class
$students_in_class = [];
if ($selected_class_id) {
    $stmt = $pdo->prepare("SELECT student_id, first_name, middle_name, last_name, admission_number FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
    $stmt->execute([$selected_class_id]);
    $students_in_class = $stmt->fetchAll();
}

// Fetch available exams for the selected class
$exams_in_class = [];
if ($selected_class_id) {
    $stmt = $pdo->prepare("SELECT DISTINCT exam_name FROM exams WHERE class_id = ? AND is_published = 1 ORDER BY created_at DESC");
    $stmt->execute([$selected_class_id]);
    $exams_in_class = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Fetch report data if all parameters are set
$report_data = null;
$student_info = null;
$class_info = null;
$subjects_results = [];
$summary = [];
$academic_year = date('Y');

if ($selected_student_id && $selected_exam_name) {
    // 1. Get Student & Class Info
    $stmt = $pdo->prepare("
        SELECT s.*, c.class_name, c.stream, c.form_level, t.first_name as teacher_first, t.last_name as teacher_last
        FROM students s
        JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN teachers t ON c.class_teacher_id = t.teacher_id
        WHERE s.student_id = ?
    ");
    $stmt->execute([$selected_student_id]);
    $student_info = $stmt->fetch();

    if ($student_info) {
        // 2. Get Results for this student and exam
        $stmt = $pdo->prepare("
            SELECT r.*, sub.subject_name, sub.subject_code, e.max_marks, e.pass_marks, gs.point_value, t.academic_year
            FROM results r
            JOIN exams e ON r.exam_id = e.exam_id
            JOIN subjects sub ON r.subject_id = sub.subject_id
            LEFT JOIN academic_terms t ON e.term_id = t.term_id
            LEFT JOIN grading_scale gs ON r.grade = gs.grade
            WHERE r.student_id = ? AND e.exam_name = ? AND r.status = 'published'
            ORDER BY sub.subject_name ASC
        ");
        $stmt->execute([$selected_student_id, $selected_exam_name]);
        $subjects_results = $stmt->fetchAll();

        if (!empty($subjects_results)) {
            $academic_year = $subjects_results[0]['academic_year'] ?? date('Y');
            // 3. Calculate Summary & Rankings
            // To get rank, we need averages of all students in the class for THIS exam name
            $stmt = $pdo->prepare("
                SELECT r.student_id, (SUM(r.marks_obtained) / SUM(e.max_marks)) * 100 as average_mark
                FROM results r
                JOIN exams e ON r.exam_id = e.exam_id
                WHERE e.class_id = ? AND e.exam_name = ? AND r.status = 'published'
                GROUP BY r.student_id
                ORDER BY average_mark DESC
            ");
            $stmt->execute([$student_info['class_id'], $selected_exam_name]);
            $class_rankings = $stmt->fetchAll();

            $total_students = count($class_rankings);
            $position = 0;
            $class_total_avg = 0;
            $student_avg = 0;

            foreach ($class_rankings as $idx => $rank) {
                $class_total_avg += $rank['average_mark'];
                if ($rank['student_id'] == $selected_student_id) {
                    $position = $idx + 1;
                    $student_avg = $rank['average_mark'];
                }
            }

            $class_avg_performance = $total_students > 0 ? ($class_total_avg / $total_students) : 0;
            
            // Division Calculation
            $div_info = calculateOLevelDivision($subjects_results);

            $summary = [
                'average' => round($student_avg, 1),
                'position' => $position,
                'total_students' => $total_students,
                'class_average' => round($class_avg_performance, 1),
                'division' => $div_info['division'],
                'points' => $div_info['total_points'],
                'subjects_sat' => count($subjects_results),
                'overall_grade' => calculateGrade($student_avg)
            ];
        } else {
            $error = "No published results found for this student and exam.";
        }
    } else {
        $error = "Student not found.";
    }
}

require_once '../../includes/header.php';
?>

<style>
    :root {
        --primary: #940000;
        --primary-dark: #7d0000;
        --secondary: #1e293b;
        --accent: #f59e0b;
        --bg-soft: #f8fafc;
        --card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
    }

    .report-wrapper {
        padding: 30px;
        background: #f1f5f9;
        min-height: calc(100vh - 70px);
    }

    /* Filter Section Styling */
    .filter-card {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        border: 1px solid #e2e8f0;
        padding: 25px;
        margin-bottom: 30px;
    }
    .filter-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr) auto;
        gap: 20px;
        align-items: flex-end;
    }
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .filter-label {
        font-size: 0.75rem;
        font-weight: 800;
        text-transform: uppercase;
        color: #64748b;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .filter-label i { color: #940000; font-size: 0.9rem; }
    
    .custom-select {
        height: 50px;
        border-radius: 12px;
        border: 2px solid #f1f5f9;
        background-color: #f8fafc;
        padding: 0 15px;
        font-weight: 700;
        color: #1e293b;
        transition: all 0.2s;
        cursor: pointer;
        width: 100%;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 15px center;
        background-size: 18px;
    }
    .custom-select:focus {
        border-color: #940000;
        background-color: #fff;
        outline: none;
        box-shadow: 0 0 0 4px rgba(148,0,0,0.1);
    }
    .custom-select:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        background-color: #f1f5f9;
    }

    .btn-reset {
        height: 50px;
        padding: 0 25px;
        border-radius: 12px;
        border: 2px solid #f1f5f9;
        background: #fff;
        color: #64748b;
        font-weight: 800;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all 0.2s;
        text-decoration: none;
        font-size: 0.9rem;
    }
    .btn-reset:hover {
        background: #fff5f5;
        color: #940000;
        border-color: #940000;
    }

    .selector-card {
        background: white;
        border-radius: 16px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: var(--card-shadow);
        border: 1px solid #e2e8f0;
    }

    .report-card-container {
        background: white;
        border-radius: 0; /* Traditional report card feel */
        padding: 40px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.1);
        max-width: 900px;
        margin: 0 auto;
        position: relative;
        overflow: hidden;
        border: 1px solid #ddd;
    }

    .report-header {
        text-align: center;
        border-bottom: 4px double var(--primary);
        padding-bottom: 20px;
        margin-bottom: 30px;
    }

    .school-logo {
        width: 100px;
        height: 100px;
        margin-bottom: 15px;
    }

    .school-name {
        font-size: 2rem;
        font-weight: 900;
        color: var(--primary);
        text-transform: uppercase;
        letter-spacing: 1px;
        margin: 0;
    }

    .report-type-badge {
        display: inline-block;
        background: var(--secondary);
        color: white;
        padding: 8px 25px;
        border-radius: 50px;
        font-weight: 700;
        font-size: 0.9rem;
        margin-top: 15px;
    }

    .student-meta {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
        margin-bottom: 40px;
    }

    .meta-box {
        background: #f1f5f9;
        padding: 20px;
        border-radius: 12px;
    }

    .meta-row {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px dashed #cbd5e1;
    }

    .meta-row:last-child { border-bottom: none; }
    .meta-label { font-weight: 700; color: #64748b; font-size: 0.85rem; text-transform: uppercase; }
    .meta-value { font-weight: 800; color: var(--secondary); }

    .results-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 40px;
    }

    .results-table th {
        background: var(--primary);
        color: white;
        padding: 15px;
        text-align: left;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .results-table td {
        padding: 15px;
        border: 1px solid #e2e8f0;
        font-weight: 600;
    }

    .grade-badge {
        display: inline-block;
        width: 32px;
        height: 32px;
        line-height: 32px;
        text-align: center;
        border-radius: 6px;
        color: white;
        font-weight: 900;
        font-size: 0.85rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .grade-A { background: #059669; }
    .grade-B { background: #10b981; }
    .grade-C { background: #f59e0b; }
    .grade-D { background: #ea580c; }
    .grade-F { background: #dc2626; }

    /* Performance Graph Styles */
    .performance-graph-container {
        margin-bottom: 40px;
        background: #f8fafc;
        padding: 25px;
        border-radius: 16px;
        border: 1px solid #e2e8f0;
        position: relative;
        z-index: 1;
    }

    .bar-item {
        margin-bottom: 15px;
    }
    .bar-label {
        display: flex;
        justify-content: space-between;
        font-size: 0.75rem;
        font-weight: 700;
        color: #475569;
        margin-bottom: 5px;
    }
    .bar-outer {
        background: #e2e8f0;
        height: 10px;
        border-radius: 10px;
        overflow: hidden;
    }
    .bar-inner {
        height: 100%;
        border-radius: 10px;
        transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .report-card-container::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 400px;
        height: 400px;
        background: url('../../assets/img/logo.png') no-repeat center;
        background-size: contain;
        opacity: 0.03;
        z-index: 0;
        pointer-events: none;
    }

    .summary-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        margin-bottom: 40px;
        position: relative;
        z-index: 1;
    }

    .summary-stat {
        text-align: center;
        padding: 15px;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }

    .stat-val {
        display: block;
        font-size: 1.8rem;
        font-weight: 900;
        color: var(--primary);
    }

    .stat-label {
        font-size: 0.7rem;
        font-weight: 800;
        color: #94a3b8;
        text-transform: uppercase;
    }

    .signature-section {
        margin-top: 60px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 100px;
    }

    .sig-box {
        text-align: center;
        border-top: 2px solid #333;
        padding-top: 10px;
        font-weight: 700;
        font-size: 0.9rem;
    }

    .btn-print-fixed {
        position: fixed;
        bottom: 30px;
        right: 30px;
        z-index: 100;
        background: var(--primary);
        color: white;
        padding: 15px 30px;
        border-radius: 50px;
        font-weight: 800;
        box-shadow: 0 10px 20px rgba(148,0,0,0.3);
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s;
    }

    .btn-print-fixed:hover {
        transform: translateY(-5px);
        background: var(--primary-dark);
    }

    @media print {
        .no-print, .main-sidebar, .main-header, .filter-card { display: none !important; }
        .report-wrapper { padding: 0; background: white; }
        .report-card-container { box-shadow: none; border: none; padding: 0; width: 100%; max-width: 100%; }
        body { background: white; }
    }
</style>

<div class="report-wrapper">
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                
                <!-- Selectors -->
                <div class="filter-card no-print">
        <form action="" method="GET" class="filter-grid">
            <div class="filter-group">
                <label class="filter-label"><i class="fas fa-chalkboard"></i> 1. Select Class</label>
                <select name="class_id" class="custom-select" onchange="this.form.submit()">
                    <option value="">Choose Class...</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class_id == $c['class_id'] ? 'selected' : ''; ?>>
                            <?php echo h($c['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <label class="filter-label"><i class="fas fa-user-graduate"></i> 2. Select Student</label>
                <select name="student_id" class="custom-select" <?php echo !$selected_class_id ? 'disabled' : ''; ?> onchange="this.form.submit()">
                    <option value="">Choose Student...</option>
                    <?php foreach ($students_in_class as $s): ?>
                        <option value="<?php echo $s['student_id']; ?>" <?php echo $selected_student_id == $s['student_id'] ? 'selected' : ''; ?>>
                            <?php echo h($s['first_name'] . ' ' . $s['last_name']); ?> (<?php echo h($s['admission_number']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <label class="filter-label"><i class="fas fa-file-alt"></i> 3. Select Exam</label>
                <select name="exam_name" class="custom-select" <?php echo !$selected_student_id ? 'disabled' : ''; ?> onchange="this.form.submit()">
                    <option value="">Choose Exam...</option>
                    <?php 
                    // Group exams using standard categories from helper
                    $standard_groups = getStandardExamNames();
                    $grouped_exams_in_class = [];
                    
                    // Categorize exams based on keywords in their names
                    foreach ($exams_in_class as $exam) {
                        $exam_name_lower = strtolower($exam);
                        $categorized = false;
                        
                        foreach ($standard_groups as $category => $keywords) {
                            foreach ($keywords as $keyword) {
                                if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                    $grouped_exams_in_class[$category][] = $exam;
                                    $categorized = true;
                                    break 2;
                                }
                            }
                        }
                        
                        // If not categorized, put in "Other Assessments"
                        if (!$categorized) {
                            $grouped_exams_in_class['Other Assessments'][] = $exam;
                        }
                    }
                    
                    // Display grouped options
                    foreach ($grouped_exams_in_class as $category => $exams_group): ?>
                        <optgroup label="<?php echo h($category); ?>">
                            <?php foreach ($exams_group as $exam): ?>
                                <option value="<?php echo h($exam); ?>" <?php echo $selected_exam_name == $exam ? 'selected' : ''; ?>>
                                    <?php echo h($exam); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </div>

            <a href="student-report.php" class="btn-reset">
                <i class="fas fa-sync-alt"></i> Reset
            </a>
        </form>
    </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger text-center fw-bold">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo h($error); ?>
                    </div>
                <?php endif; ?>

                <?php if ($report_data || !empty($subjects_results)): ?>
                    
                    <button class="btn-print-fixed no-print" onclick="window.print()">
                        <i class="fas fa-print"></i> PRINT REPORT CARD
                    </button>

                    <!-- The Report Card -->
                    <div class="report-card-container">
                        <div class="report-header">
                            <img src="../../assets/img/logo.png" class="school-logo" onerror="this.src='https://via.placeholder.com/100?text=LOGO'">
                            <h1 class="school-name">Moshi Public Secondary School</h1>
                            <p class="mb-0 text-muted fw-bold">P.O. Box 1234, Moshi - Kilimanjaro</p>
                            <p class="text-muted small">Tel: +255 712 345 678 | Email: info@moshisec.sc.tz</p>
                            <span class="report-type-badge">ACADEMIC PROGRESS REPORT CARD</span>
                        </div>

                        <div class="student-meta">
                            <div class="meta-box">
                                <div class="meta-row">
                                    <span class="meta-label">Full Name:</span>
                                    <span class="meta-value"><?php echo h($student_info['first_name'] . ' ' . ($student_info['middle_name'] ? $student_info['middle_name'] . ' ' : '') . $student_info['last_name']); ?></span>
                                </div>
                                <div class="meta-row">
                                    <span class="meta-label">Admission No:</span>
                                    <span class="meta-value"><?php echo h($student_info['admission_number']); ?></span>
                                </div>
                                <div class="meta-row">
                                    <span class="meta-label">Gender:</span>
                                    <span class="meta-value"><?php echo h($student_info['gender']); ?></span>
                                </div>
                            </div>
                            <div class="meta-box">
                                <div class="meta-row">
                                    <span class="meta-label">Class & Stream:</span>
                                    <span class="meta-value"><?php echo h($student_info['class_name']); ?></span>
                                </div>
                                <div class="meta-row">
                                    <span class="meta-label">Academic Year:</span>
                                    <span class="meta-value"><?php echo h($academic_year); ?></span>
                                </div>
                                <div class="meta-row">
                                    <span class="meta-label">Assessment:</span>
                                    <span class="meta-value"><?php echo h($selected_exam_name); ?></span>
                                </div>
                            </div>
                        </div>

                        <table class="results-table">
                            <thead>
                                <tr>
                                    <th>Subject Description</th>
                                    <th class="text-center">Marks (%)</th>
                                    <th class="text-center">Grade</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subjects_results as $res): ?>
                                    <tr>
                                        <td><?php echo h($res['subject_name']); ?> (<?php echo h($res['subject_code']); ?>)</td>
                                        <td class="text-center fw-bold"><?php echo round($res['marks_obtained']); ?></td>
                                        <td class="text-center">
                                            <span class="grade-badge grade-<?php echo h($res['grade']); ?>"><?php echo h($res['grade']); ?></span>
                                        </td>
                                        <td class="small text-muted italic">
                                            <?php 
                                            switch($res['grade']) {
                                                case 'A': echo "Excellent Performance"; break;
                                                case 'B': echo "Very Good Effort"; break;
                                                case 'C': echo "Good Performance"; break;
                                                case 'D': echo "Satisfactory Effort"; break;
                                                case 'F': echo "Unsatisfactory - Work Harder"; break;
                                                default: echo "-";
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <div class="performance-graph-container">
                            <h6 class="fw-black mb-3" style="font-size: 0.75rem; color: var(--primary); text-transform: uppercase;"><i class="fas fa-chart-bar me-2"></i>Subject Performance Analysis</h6>
                            <div class="row">
                                <?php 
                                // Split subjects into two columns for the graph
                                $chunks = array_chunk($subjects_results, ceil(count($subjects_results) / 2));
                                foreach ($chunks as $chunk):
                                ?>
                                <div class="col-md-6">
                                    <?php foreach ($chunk as $res): 
                                        $pct = round($res['marks_obtained']);
                                        $color = ($pct >= 75) ? '#059669' : (($pct >= 45) ? '#3b82f6' : '#dc2626');
                                    ?>
                                        <div class="bar-item">
                                            <div class="bar-label">
                                                <span><?php echo h($res['subject_name']); ?></span>
                                                <span><?php echo $pct; ?>%</span>
                                            </div>
                                            <div class="bar-outer">
                                                <div class="bar-inner" style="width: <?php echo $pct; ?>%; background: <?php echo $color; ?>;"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="summary-grid">
                            <div class="summary-stat">
                                <span class="stat-val"><?php echo $summary['average']; ?>%</span>
                                <span class="stat-label">Average Score</span>
                            </div>
                            <div class="summary-stat">
                                <span class="stat-val"><?php echo $summary['overall_grade']; ?></span>
                                <span class="stat-label">Overall Grade</span>
                            </div>
                            <div class="summary-stat">
                                <span class="stat-val"><?php echo $summary['division']; ?></span>
                                <span class="stat-label">Division (Pts: <?php echo $summary['points']; ?>)</span>
                            </div>
                            <div class="summary-stat" style="border-color: var(--primary);">
                                <span class="stat-val"><?php echo $summary['position']; ?> / <?php echo $summary['total_students']; ?></span>
                                <span class="stat-label">Class Position</span>
                            </div>
                        </div>

                        <div style="background: #fff5f5; padding: 20px; border-radius: 12px; border-left: 5px solid var(--primary); margin-bottom: 40px;">
                            <h5 class="fw-bold mb-1" style="color: var(--primary); font-size: 0.9rem;">TEACHER'S GENERAL REMARKS</h5>
                            <p class="text-muted mb-0" style="font-style: italic;">
                                <?php 
                                if ($summary['average'] >= 75) echo "An excellent student with consistent high performance across all subjects. Keep up the great work!";
                                elseif ($summary['average'] >= 65) echo "A very good performance. There is still room for improvement in some core subjects.";
                                elseif ($summary['average'] >= 45) echo "A satisfactory performance. More effort is needed to reach higher grades.";
                                else echo "Performance is below average. Serious attention and more study hours are required.";
                                ?>
                            </p>
                        </div>

                        <div class="signature-section">
                            <div class="sig-box">
                                <p class="mb-0 fw-bold"><?php echo h($student_info['teacher_first'] . ' ' . $student_info['teacher_last']); ?></p>
                                <p class="text-muted small">Class Teacher's Signature</p>
                            </div>
                            <div class="sig-box">
                                <p class="mb-0 fw-bold">Mwl. Innocent Machaka</p>
                                <p class="text-muted small">Headmaster's Signature & Stamp</p>
                            </div>
                        </div>

                        <div class="text-center mt-5 pt-4 text-muted small" style="border-top: 1px solid #eee;">
                            Generated by ShuleXpert Management System on <?php echo date('d M Y, H:i'); ?>
                        </div>
                    </div>

                <?php elseif ($selected_student_id && $selected_exam_name): ?>
                    <div class="text-center p-5">
                        <i class="fas fa-file-invoice-dollar fa-5x text-muted mb-3 opacity-25"></i>
                        <h3 class="text-muted">No Data Found</h3>
                        <p>We couldn't find any published results for the selected criteria.</p>
                    </div>
                <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-search"></i>
            <h3>Select a student to view their report card</h3>
            <p>You can filter by class, then choose a student and an assessment from the options above.</p>
        </div>
    <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
