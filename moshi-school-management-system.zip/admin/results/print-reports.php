<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$class_id = $_GET['class'] ?? '';
$exam_name = $_GET['exam'] ?? '';

if (!$class_id || !$exam_name) {
    echo "<!DOCTYPE html><html><head><title>Error</title><link href='https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap' rel='stylesheet'><style>body{font-family:'Inter',sans-serif;background:#f8fafc;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;} .error-card{background:white;padding:40px;border-radius:12px;box-shadow:0 4px 6px rgba(0,0,0,0.05);text-align:center;} .btn{display:inline-block;margin-top:20px;padding:10px 20px;background:#940000;color:white;text-decoration:none;border-radius:6px;font-weight:700;}</style></head><body><div class='error-card'><h2 style='color:#940000;margin-top:0;'>Missing Parameters</h2><p>Please select a class and exam first.</p><a href='compile.php' class='btn'>Back to Compilation</a></div></body></html>";
    exit;
}

// Fetch class info
$stmt = $pdo->prepare("SELECT * FROM classes WHERE class_id = ?");
$stmt->execute([$class_id]);
$class = $stmt->fetch();

// Fetch subjects for this exam/class
$stmt = $pdo->prepare("
    SELECT e.exam_id, s.subject_id, s.subject_name, e.max_marks 
    FROM exams e 
    JOIN subjects s ON e.subject_id = s.subject_id 
    WHERE e.class_id = ? AND e.exam_name = ? AND e.is_published = 1
    ORDER BY s.subject_name ASC
");
$stmt->execute([$class_id, $exam_name]);
$subjects = $stmt->fetchAll();

// Fetch active students
$stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll();

// Fetch results
$exam_ids = array_column($subjects, 'exam_id');
$result_lookup = [];
if (!empty($exam_ids)) {
    $inClause = implode(',', $exam_ids);
    $stmt = $pdo->query("
        SELECT r.*, gs.point_value 
        FROM results r 
        LEFT JOIN grading_scale gs ON r.grade = gs.grade 
        WHERE r.exam_id IN ($inClause)
    ");
    while ($r = $stmt->fetch()) {
        $result_lookup[$r['student_id']][$r['exam_id']] = $r;
    }
}

// Custom CSS for Print
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print Reports - <?php echo h($class['class_name'] . ' - ' . $exam_name); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; margin: 0; padding: 0; background: #f5f5f5; color: #333; }
        .report-page {
            background: white;
            width: 210mm;
            min-height: 297mm;
            padding: 20mm;
            margin: 20px auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            position: relative;
            page-break-after: always;
            box-sizing: border-box;
        }
        @media print {
            body { background: none; }
            .report-page { margin: 0; box-shadow: none; border: none; }
            .no-print { display: none; }
        }
        .header { text-align: center; border-bottom: 3px double #8b0000; padding-bottom: 15px; margin-bottom: 25px; }
        .school-logo { width: 80px; height: 80px; margin-bottom: 10px; }
        .school-name { font-size: 1.6rem; font-weight: 900; color: #8b0000; text-transform: uppercase; margin: 5px 0; }
        .report-title { font-size: 1.1rem; font-weight: 700; color: #555; border: 1px solid #ddd; display: inline-block; padding: 5px 20px; border-radius: 20px; margin-top: 10px; }
        
        .student-info { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; font-size: 0.9rem; }
        .info-item { border-bottom: 1px dotted #ccc; padding: 5px 0; }
        .info-label { font-weight: 700; color: #777; width: 140px; display: inline-block; }
        
        .marks-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .marks-table th { background: #8b0000; color: white; padding: 12px; text-align: left; font-size: 0.85rem; text-transform: uppercase; }
        .marks-table td { padding: 10px 12px; border: 1px solid #eee; font-size: 0.9rem; }
        .marks-table tr:nth-child(even) { background: #fafafa; }
        
        .summary-box { display: flex; justify-content: space-between; gap: 20px; margin-top: 20px; }
        .summary-card { flex: 1; border: 2px solid #8b0000; border-radius: 10px; padding: 15px; text-align: center; }
        .summary-val { font-size: 1.4rem; font-weight: 900; color: #8b0000; display: block; }
        .summary-label { font-size: 0.75rem; color: #777; font-weight: 700; text-transform: uppercase; }

        .footer-sig { margin-top: 60px; display: grid; grid-template-columns: 1fr 1fr; gap: 50px; text-align: center; }
        .sig-box { border-top: 1px solid #333; padding-top: 10px; font-size: 0.85rem; font-weight: 700; }
        
        .no-print-toolbar {
            position: fixed; top: 0; left: 0; right: 0; background: #333; color: white; padding: 10px 20px;
            display: flex; justify-content: space-between; align-items: center; z-index: 1000;
        }
        .btn-print { background: #8b0000; color: white; border: none; padding: 8px 20px; border-radius: 5px; cursor: pointer; font-weight: 700; }
    </style>
</head>
<body>

<div class="no-print-toolbar no-print">
    <span><i class="fas fa-file-pdf"></i> Ready to Print: <strong><?php echo count($students); ?> Reports</strong></span>
    <div>
        <button onclick="window.print()" class="btn-print">PRINT ALL NOW</button>
        <button onclick="window.close()" style="background: #555; color: white; border: none; padding: 8px 15px; border-radius: 5px; margin-left: 10px; cursor: pointer;">CLOSE</button>
    </div>
</div>

<div style="height: 50px;" class="no-print"></div>

<?php foreach ($students as $st): 
    $sid = $st['student_id'];
    $st_marks = $result_lookup[$sid] ?? [];
    $total_obtained = 0;
    $count = 0;
    
    // Process for Division
    $division_input = [];
    foreach ($subjects as $sub) {
        $eid = $sub['exam_id'];
        if (isset($st_marks[$eid])) {
            $division_input[$eid] = $st_marks[$eid];
            $total_obtained += $st_marks[$eid]['marks_obtained'];
            $count++;
        }
    }
    
    $avg = $count > 0 ? ($total_obtained / $count) : 0;
    $div_info = calculateOLevelDivision($division_input);
?>
    <div class="report-page">
        <div class="header">
            <img src="../../assets/img/logo.png" class="school-logo" onerror="this.src='https://via.placeholder.com/100?text=LOGO'">
            <div class="school-name">Moshi Public Secondary School</div>
            <div style="font-size: 0.85rem; color: #666;">P.O. Box 1234, Moshi - Kilimanjaro | Tel: 0712 345 678</div>
            <div class="report-title">STUDENT ACADEMIC REPORT CARD</div>
        </div>

        <div class="student-info">
            <div>
                <div class="info-item"><span class="info-label">Student Name:</span> <strong><?php echo h($st['first_name'] . ' ' . $st['last_name']); ?></strong></div>
                <div class="info-item"><span class="info-label">Admission No:</span> <?php echo h($st['admission_number']); ?></div>
            </div>
            <div>
                <div class="info-item"><span class="info-label">Class:</span> <?php echo h($class['class_name']); ?></div>
                <div class="info-item"><span class="info-label">Examination:</span> <?php echo h($exam_name); ?></div>
            </div>
        </div>

        <table class="marks-table">
            <thead>
                <tr>
                    <th>Subject Name</th>
                    <th style="text-align: center;">Marks</th>
                    <th style="text-align: center;">Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subjects as $sub): 
                    $eid = $sub['exam_id'];
                    $res = $st_marks[$eid] ?? null;
                ?>
                    <tr>
                        <td><?php echo h($sub['subject_name']); ?></td>
                        <td style="text-align: center; font-weight: 700;"><?php echo $res ? round($res['marks_obtained']) : '-'; ?></td>
                        <td style="text-align: center; font-weight: 900; color: #8b0000;"><?php echo $res ? h($res['grade']) : '-'; ?></td>
                        <td style="font-size: 0.8rem; color: #666;">
                            <?php 
                            if ($res) {
                                switch($res['grade']) {
                                    case 'A': echo "Excellent"; break;
                                    case 'B': echo "Very Good"; break;
                                    case 'C': echo "Good"; break;
                                    case 'D': echo "Satisfactory"; break;
                                    case 'F': echo "Fail"; break;
                                    default: echo "-";
                                }
                            } else { echo "Not Sat"; }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="summary-box">
            <div class="summary-card">
                <span class="summary-label">Average Mark</span>
                <span class="summary-val"><?php echo round($avg, 1); ?>%</span>
            </div>
            <div class="summary-card">
                <span class="summary-label">Division & Points</span>
                <span class="summary-val"><?php echo $div_info['division'] != '0' ? $div_info['division'] . ' - ' . $div_info['total_points'] : '0'; ?></span>
            </div>
            <div class="summary-card">
                <span class="summary-label">Overall Grade</span>
                <span class="summary-val"><?php echo calculateGrade($avg); ?></span>
            </div>
        </div>

        <div style="margin-top: 30px; font-size: 0.9rem; border: 1px solid #eee; padding: 15px; border-radius: 8px;">
            <strong>Class Teacher's Comments:</strong>
            <div style="border-bottom: 1px solid #ddd; height: 30px; margin-bottom: 5px;"></div>
            <strong>Headmaster's Comments:</strong>
            <div style="border-bottom: 1px solid #ddd; height: 30px;"></div>
        </div>

        <div class="footer-sig">
            <div class="sig-box">Class Teacher's Signature</div>
            <div class="sig-box">Headmaster's Signature & Stamp</div>
        </div>
        
        <div style="position: absolute; bottom: 15mm; right: 20mm; font-size: 0.7rem; color: #aaa;">
            Printed on <?php echo date('d M Y, H:i'); ?> | Moshi SMS - Government Management
        </div>
    </div>
<?php endforeach; ?>

</body>
</html>
