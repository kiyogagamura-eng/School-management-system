<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$class_id = $_GET['class_id'] ?? null;
$exam_name = $_GET['exam_name'] ?? null;

if (!$class_id || !$exam_name) {
    echo json_encode([
        'ready' => false,
        'message' => 'Parameters not set',
        'total_students' => 0,
        'pass_rate' => '0%',
        'avg_score' => '0%',
        'subjects_count' => 0,
        'status_check' => [
            'total' => 0,
            'approved' => 0,
            'pending' => 0
        ]
    ]);
    exit;
}



try {
    // 1. Get subjects for this class/exam
    $stmt = $pdo->prepare("
        SELECT e.exam_id, s.subject_name, e.max_marks 
        FROM exams e 
        JOIN subjects s ON e.subject_id = s.subject_id 
        WHERE e.class_id = ? AND e.exam_name = ?
    ");
    $stmt->execute([$class_id, $exam_name]);
    $subjects = $stmt->fetchAll();
    
    if (empty($subjects)) {
        echo json_encode(['ready' => false, 'message' => 'No published subjects found.']);
        exit;
    }

    $exam_ids = array_column($subjects, 'exam_id');
    $inClause = implode(',', $exam_ids);

    // 2. Count total students in class
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ? AND status = 'Active'");
    $stmt->execute([$class_id]);
    $total_students = $stmt->fetchColumn();

    // 3. Calculate Stats
    $stmt = $pdo->query("
        SELECT 
            (SUM(r.marks_obtained) / SUM(e.max_marks)) * 100 as avg_score,
            SUM(CASE WHEN r.grade NOT IN ('F', '0', 'N/A') THEN 1 ELSE 0 END) as pass_count,
            COUNT(*) as total_entries
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        WHERE r.exam_id IN ($inClause)
    ");
    $raw_stats = $stmt->fetch();
    
    // Average Score per student (not per entry)
    $stmt = $pdo->query("
        SELECT AVG(student_avg) as final_avg FROM (
            SELECT r.student_id, (SUM(r.marks_obtained) / SUM(e.max_marks)) * 100 as student_avg 
            FROM results r
            JOIN exams e ON r.exam_id = e.exam_id
            WHERE r.exam_id IN ($inClause) 
            GROUP BY r.student_id
        ) as sub
    ");
    $final_avg = $stmt->fetchColumn();

    $pass_rate = $total_students > 0 ? round(($raw_stats['pass_count'] / ($total_students * count($subjects))) * 100, 1) : 0;

    echo json_encode([
        'ready' => true,
        'total_students' => $total_students,
        'pass_rate' => $pass_rate . '%',
        'avg_score' => round($final_avg, 2) . '%',
        'subjects_count' => count($subjects),
        'status_check' => [
            'total' => count($subjects),
            'approved' => count($subjects), // Simplified for now
            'pending' => 0
        ]
    ]);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
