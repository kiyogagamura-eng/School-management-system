<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Subject Performance Report";

// Fetch subjects
$stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name ASC");
$subjects = $stmt->fetchAll();

$selected_subject_id = $_GET['subject_id'] ?? '';

// Fetch distinct exam names for this subject
$available_exams = [];
if ($selected_subject_id) {
    $stmt = $pdo->prepare("SELECT DISTINCT exam_name FROM exams WHERE subject_id = ? AND is_published = 1 ORDER BY created_at DESC");
    $stmt->execute([$selected_subject_id]);
    $available_exams = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

$selected_exam = $_GET['exam_name'] ?? ($available_exams[0] ?? '');

// Subject Stats Data
$subject_info = null;
$class_comparisons = [];
$total_sat = 0;
$total_passed = 0;
$total_sum = 0;
$grade_distribution = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'F' => 0];

if ($selected_subject_id && $selected_exam) {
    // 1. Get Subject Info
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE subject_id = ?");
    $stmt->execute([$selected_subject_id]);
    $subject_info = $stmt->fetch();

    // 2. Get All Results for this subject and exam across all classes
    $stmt = $pdo->prepare("
        SELECT r.marks_obtained, r.grade, c.class_id, c.class_name
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        JOIN classes c ON e.class_id = c.class_id
        WHERE e.subject_id = ? AND e.exam_name = ? AND r.status = 'published'
    ");
    $stmt->execute([$selected_subject_id, $selected_exam]);
    $raw_results = $stmt->fetchAll();

    foreach ($raw_results as $r) {
        $total_sat++;
        $total_sum += $r['marks_obtained'];
        if ($r['marks_obtained'] >= 40) $total_passed++;

        // Grade Dist
        $g = $r['grade'];
        if (isset($grade_distribution[$g])) $grade_distribution[$g]++;

        // Class Wise
        $cid = $r['class_id'];
        if (!isset($class_comparisons[$cid])) {
            $class_comparisons[$cid] = ['name' => $r['class_name'], 'sat' => 0, 'sum' => 0, 'passed' => 0];
        }
        $class_comparisons[$cid]['sat']++;
        $class_comparisons[$cid]['sum'] += $r['marks_obtained'];
        if ($r['marks_obtained'] >= 40) $class_comparisons[$cid]['passed']++;
    }
}

require_once '../../includes/header.php';
?>

<div class="container-fluid" style="padding: 20px;">
    <!-- Filters -->
    <div class="card no-print" style="background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; border: none;">
        <div class="card-body" style="padding: 25px;">
            <form action="" method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 250px;">
                    <label style="font-weight: 700; font-size: 0.8rem; color: #475569; text-transform: uppercase; margin-bottom: 8px; display: block;">Select Subject</label>
                    <select name="subject_id" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 0.95rem; outline: none; background: #f8fafc;" onchange="this.form.submit()">
                        <option value="">Choose Subject...</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?php echo $s['subject_id']; ?>" <?php echo $selected_subject_id == $s['subject_id'] ? 'selected' : ''; ?>>
                                <?php echo h($s['subject_name']); ?> (<?php echo h($s['subject_code']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="flex: 1; min-width: 250px;">
                    <label style="font-weight: 700; font-size: 0.8rem; color: #475569; text-transform: uppercase; margin-bottom: 8px; display: block;">Select Assessment</label>
                    <select name="exam_name" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 0.95rem; outline: none; background: #f8fafc;" <?php echo !$selected_subject_id ? 'disabled' : ''; ?> onchange="this.form.submit()">
                        <option value="">Choose Exam...</option>
                                <?php 
                                // Group exams using standard categories from helper
                                $standard_groups = getStandardExamNames();
                                $grouped_available_exams = [];
                                
                                // Categorize exams based on keywords in their names
                                foreach ($available_exams as $exam) {
                                    $exam_name_lower = strtolower($exam);
                                    $categorized = false;
                                    
                                    foreach ($standard_groups as $category => $keywords) {
                                        foreach ($keywords as $keyword) {
                                            if (stripos($exam_name_lower, strtolower($keyword)) !== false) {
                                                $grouped_available_exams[$category][] = $exam;
                                                $categorized = true;
                                                break 2;
                                            }
                                        }
                                    }
                                    
                                    // If not categorized, put in "Other Assessments"
                                    if (!$categorized) {
                                        $grouped_available_exams['Other Assessments'][] = $exam;
                                    }
                                }
                                
                                // Display grouped options
                                foreach ($grouped_available_exams as $category => $exams_group): ?>
                                    <optgroup label="<?php echo h($category); ?>">
                                        <?php foreach ($exams_group as $exam): ?>
                                            <option value="<?php echo h($exam); ?>" <?php echo $selected_exam == $exam ? 'selected' : ''; ?>>
                                                <?php echo h($exam); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="min-width: 200px;">
                    <button type="button" onclick="downloadPDF()" class="<?php echo !$selected_exam ? 'disabled' : ''; ?>" style="width: 100%; padding: 12px 20px; background: #940000; color: white; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; transition: background 0.2s;">
                        <i class="fas fa-download me-2"></i> Download PDF
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php if ($subject_info && $total_sat > 0): ?>
        <div class="row g-4">
            <!-- Header -->
            <div class="col-12 text-center mb-4">
                <span class="badge bg-primary px-3 py-2 mb-2"><?php echo h($subject_info['subject_code']); ?></span>
                <h1 class="fw-black text-primary text-uppercase m-0"><?php echo h($subject_info['subject_name']); ?> ANALYSIS</h1>
                <h5 class="text-muted">Assessment: <?php echo h($selected_exam); ?></h5>
            </div>

            <!-- Core Metrics -->
            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 bg-primary text-white">
                    <div class="card-body p-4 text-center">
                        <h6 class="small fw-bold opacity-75 mb-3 text-uppercase">Total Students Sat</h6>
                        <h1 class="display-4 fw-black m-0"><?php echo $total_sat; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 h-100" style="background: #f0fdf4; border: 1px solid #bcf0da;">
                    <div class="card-body p-4 text-center">
                        <h6 class="small fw-bold text-success mb-3 text-uppercase">Overall Pass Rate</h6>
                        <?php $p_rate = round(($total_passed / $total_sat) * 100); ?>
                        <h1 class="display-4 fw-black text-success m-0"><?php echo $p_rate; ?>%</h1>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 h-100" style="background: #eff6ff; border: 1px solid #bfdbfe;">
                    <div class="card-body p-4 text-center">
                        <h6 class="small fw-bold text-primary mb-3 text-uppercase">Subject Average</h6>
                        <?php $s_avg = round($total_sum / $total_sat, 1); ?>
                        <h1 class="display-4 fw-black text-primary m-0"><?php echo $s_avg; ?>%</h1>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 h-100" style="background: #fdf2f8; border: 1px solid #fbcfe8;">
                    <div class="card-body p-4 text-center">
                        <h6 class="small fw-bold text-danger mb-3 text-uppercase">Failed Count</h6>
                        <h1 class="display-4 fw-black text-danger m-0"><?php echo ($total_sat - $total_passed); ?></h1>
                    </div>
                </div>
            </div>

            <!-- Grade Distribution -->
            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-white border-0 py-3 px-4">
                        <h6 class="fw-black m-0 text-muted">GRADE DISTRIBUTION</h6>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <?php foreach ($grade_distribution as $grade => $count): 
                             $pct = round(($count / $total_sat) * 100);
                             $color = ($grade == 'A' || $grade == 'B') ? 'success' : ($grade == 'C' ? 'primary' : ($grade == 'D' ? 'warning' : 'danger'));
                        ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="fw-black">Grade <?php echo $grade; ?></span>
                                    <span class="small fw-bold text-muted"><?php echo $count; ?> Students (<?php echo $pct; ?>%)</span>
                                </div>
                                <div class="progress" style="height: 12px; border-radius: 20px;">
                                    <div class="progress-bar bg-<?php echo $color; ?>" style="width: <?php echo $pct; ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Class Wise Comparison -->
            <div class="col-md-7">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-white border-0 py-3 px-4">
                        <h6 class="fw-black m-0 text-muted">PERFORMANCE BY CLASS</h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light small fw-bold text-muted text-uppercase">
                                <tr>
                                    <th class="ps-4">Class Name</th>
                                    <th class="text-center">Sat</th>
                                    <th class="text-center">Avg Score</th>
                                    <th class="text-center">Pass Rate</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($class_comparisons as $cid => $stats): 
                                    $c_avg = round($stats['sum'] / $stats['sat'], 1);
                                    $c_rate = round(($stats['passed'] / $stats['sat']) * 100);
                                    $c_color = $c_rate >= 70 ? 'success' : ($c_rate >= 40 ? 'warning' : 'danger');
                                ?>
                                    <tr>
                                        <td class="ps-4 fw-bold"><?php echo h($stats['name']); ?></td>
                                        <td class="text-center"><?php echo $stats['sat']; ?></td>
                                        <td class="text-center fw-black text-primary"><?php echo $c_avg; ?>%</td>
                                        <td class="text-center">
                                            <div class="d-flex align-items-center justify-content-center gap-2">
                                                <span class="fw-bold"><?php echo $c_rate; ?>%</span>
                                                <div class="progress d-none d-md-flex" style="height: 5px; width: 50px;">
                                                    <div class="progress-bar bg-<?php echo $c_color; ?>" style="width: <?php echo $c_rate; ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $c_color; ?>-soft text-<?php echo $c_color; ?>"><?php echo $c_rate >= 70 ? 'Leading' : ($c_rate >= 40 ? 'Average' : 'Critical'); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif ($selected_subject_id && $selected_exam): ?>
        <div class="text-center p-5">
            <h4 class="text-muted">No published data found for this subject and assessment.</h4>
        </div>
    <?php else: ?>
        <div class="text-center p-5 mt-5 opacity-50">
            <i class="fas fa-microscope fa-6x mb-4 text-primary"></i>
            <h3>Subject analytics will appear here</h3>
            <p>Select a subject and an assessment from the filters above to begin analysis.</p>
        </div>
    <?php endif; ?>
</div>

<style>
    .fw-black { font-weight: 900 !important; }
    .bg-success-soft { background-color: #ecfdf5; }
    .bg-warning-soft { background-color: #fffbeb; }
    .bg-danger-soft { background-color: #fef2f2; }
    @media print {
        .no-print { display: none !important; }
        .card { border: 1px solid #eee !important; box-shadow: none !important; }
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
function downloadPDF() {
    var element = document.querySelector('.container-fluid');
    var noPrint = document.querySelectorAll('.no-print');
    
    // Temporarily hide no-print elements for PDF generation
    noPrint.forEach(el => el.style.display = 'none');
    
    var opt = {
      margin:       0.3,
      filename:     'Subject_Performance_Report.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'in', format: 'a4', orientation: 'landscape' }
    };

    html2pdf().set(opt).from(element).save().then(() => {
        // Restore elements
        noPrint.forEach(el => el.style.display = '');
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
