<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Results Management";

// Fetch Stats
$stats = [
    'total_subjects' => 0,
    'submitted' => 0,
    'pending' => 0,
    'approved' => 0,
    'published' => 0
];

try {
    // Total subjects assigned to classes
    $stats['total_subjects'] = $pdo->query("SELECT COUNT(*) FROM class_subjects")->fetchColumn();
    
    // Submissions breakdown
    $stmt = $pdo->query("SELECT status, COUNT(DISTINCT exam_id, subject_id, class_id) as count FROM results GROUP BY status");
    $submissions = $stmt->fetchAll();
    
    foreach ($submissions as $s) {
        if ($s['status'] == 'submitted') $stats['submitted'] = $s['count'];
        if ($s['status'] == 'published') $stats['published'] = $s['count'];
    }
    
    // Approved is essentially 'published' in this system's current logic
    $stats['approved'] = $stats['published'];
    $stats['pending'] = max(0, $stats['total_subjects'] - ($stats['submitted'] + $stats['published']));

} catch (Exception $e) {}

// Fetch Submission Workflow Table Data
$workflow = [];
try {
    $query = "
        SELECT 
            cs.class_id, c.class_name, 
            cs.subject_id, s.subject_name,
            t.first_name as teacher_first, t.last_name as teacher_last,
            MAX(e.exam_id) as exam_id, MAX(e.exam_name) as exam_name, MAX(e.exam_date) as exam_date,
            MAX(r.status) as submission_status,
            MAX(r.last_updated) as submitted_on
        FROM class_subjects cs
        JOIN classes c ON cs.class_id = c.class_id
        JOIN subjects s ON cs.subject_id = s.subject_id
        LEFT JOIN teachers t ON cs.teacher_id = t.teacher_id
        LEFT JOIN exams e ON cs.class_id = e.class_id AND cs.subject_id = e.subject_id
        LEFT JOIN (
            SELECT exam_id, class_id, subject_id, status, MAX(last_updated) as last_updated
            FROM results
            GROUP BY exam_id, class_id, subject_id
        ) r ON e.exam_id = r.exam_id AND cs.class_id = r.class_id AND cs.subject_id = r.subject_id
        GROUP BY cs.class_id, cs.subject_id
        ORDER BY c.form_level, c.stream, s.subject_name
    ";
    $workflow = $pdo->query($query)->fetchAll();
} catch (Exception $e) {}

// Fetch Classes for Compilation
$stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level ASC, stream ASC");
$classes = $stmt->fetchAll();

require_once '../../includes/header.php';
?>

<style>
    .results-management-container {
        padding: 20px;
        background: #f8fafc;
        min-height: 100vh;
    }
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 15px;
        margin-bottom: 30px;
    }
    .stat-card {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        gap: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        border-bottom: 4px solid transparent;
    }
    .stat-card.total { border-bottom-color: #940000; }
    .stat-card.submitted { border-bottom-color: #64748b; }
    .stat-card.pending { border-bottom-color: #94a3b8; }
    .stat-card.approved { border-bottom-color: #7d0000; }
    .stat-card.published { border-bottom-color: #940000; }
    
    .stat-icon {
        width: 45px;
        height: 45px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }
    
    .workflow-section {
        background: #fff;
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    
    .compilation-section {
        display: grid;
        grid-template-columns: 350px 1fr 300px;
        gap: 25px;
    }
    
    .status-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
    }
    .status-submitted { background: #fff5f5; color: #940000; }
    .status-pending { background: #f8fafc; color: #64748b; }
    .status-not-submitted { background: #f8fafc; color: #94a3b8; }
    
    .action-btn-group {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .action-btn {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px;
        border-radius: 10px;
        background: #fff;
        border: 1px solid #e2e8f0;
        color: #475569;
        text-decoration: none;
        transition: all 0.2s;
        font-weight: 600;
        font-size: 0.9rem;
    }
    .action-btn:hover {
        border-color: #940000;
        color: #940000;
        background: #fff5f5;
    }
    .action-btn.primary {
        background: #940000;
        color: #fff;
        border-color: #940000;
    }
    .action-btn.primary:hover {
        background: #7d0000;
    }
</style>

<div class="results-management-container">
    <div class="page-header" style="margin-bottom: 25px;">
        <h2 style="font-weight: 900; color: #1e293b;"><i class="fas fa-poll" style="color: #940000;"></i> Results Management</h2>
        <p style="color: #64748b; font-size: 0.95rem;">Manage results workflow from teachers submission to final report compilation.</p>
    </div>

    <!-- Stats Row -->
    <div class="stats-grid">
        <div class="stat-card total">
            <div class="stat-icon" style="background: #fff5f5; color: #940000;"><i class="fas fa-copy"></i></div>
            <div>
                <div style="font-size: 1.5rem; font-weight: 800; color: #1e293b;"><?php echo $stats['total_subjects']; ?></div>
                <div style="font-size: 0.75rem; color: #64748b; font-weight: 600;">Total Subjects</div>
            </div>
        </div>
        <div class="stat-card submitted">
            <div class="stat-icon" style="background: #f8fafc; color: #64748b;"><i class="fas fa-paper-plane"></i></div>
            <div>
                <div style="font-size: 1.5rem; font-weight: 800; color: #1e293b;"><?php echo $stats['submitted']; ?></div>
                <div style="font-size: 0.75rem; color: #64748b; font-weight: 600;">Submitted</div>
            </div>
        </div>
        <div class="stat-card pending">
            <div class="stat-icon" style="background: #f8fafc; color: #94a3b8;"><i class="fas fa-clock"></i></div>
            <div>
                <div style="font-size: 1.5rem; font-weight: 800; color: #1e293b;"><?php echo $stats['pending']; ?></div>
                <div style="font-size: 0.75rem; color: #64748b; font-weight: 600;">Pending</div>
            </div>
        </div>
        <div class="stat-card approved">
            <div class="stat-icon" style="background: #fff5f5; color: #7d0000;"><i class="fas fa-check-circle"></i></div>
            <div>
                <div style="font-size: 1.5rem; font-weight: 800; color: #1e293b;"><?php echo $stats['approved']; ?></div>
                <div style="font-size: 0.75rem; color: #64748b; font-weight: 600;">Approved</div>
            </div>
        </div>
        <div class="stat-card published">
            <div class="stat-icon" style="background: #fff5f5; color: #940000;"><i class="fas fa-bullhorn"></i></div>
            <div>
                <div style="font-size: 1.5rem; font-weight: 800; color: #1e293b;"><?php echo $stats['published']; ?></div>
                <div style="font-size: 0.75rem; color: #64748b; font-weight: 600;">Published</div>
            </div>
        </div>
    </div>

    <!-- Step 1 Section -->
    <div class="workflow-section">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; gap: 15px; flex-wrap: wrap;">
            <h5 style="color: #940000; font-size: 0.8rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin: 0;">
                <i class="fas fa-chevron-right"></i> STEP 1: RESULTS SUBMISSION & APPROVAL WORKFLOW
            </h5>
            
            <div style="display: flex; gap: 10px;">
                <div style="position: relative;">
                    <i class="fas fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; font-size: 0.8rem;"></i>
                    <input type="text" id="workflowSearch" placeholder="Search subject or teacher..." style="padding: 8px 12px 8px 35px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 0.8rem; width: 220px; outline: none; transition: border 0.2s;">
                </div>
                <select id="classFilter" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 0.8rem; color: #475569; outline: none; cursor: pointer;">
                    <option value="">All Classes</option>
                    <?php 
                    $unique_classes = array_unique(array_column($workflow, 'class_name'));
                    sort($unique_classes);
                    foreach ($unique_classes as $cn): ?>
                        <option value="<?php echo h($cn); ?>"><?php echo h($cn); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        
        <div id="workflowAccordion" style="display: flex; flex-direction: column; gap: 15px;">
            <?php 
            // Group workflow by class
            $grouped_workflow = [];
            foreach ($workflow as $item) {
                $grouped_workflow[$item['class_name']][] = $item;
            }
            
            foreach ($grouped_workflow as $class_name => $subjects): 
                $safe_id = 'class_' . preg_replace('/[^a-zA-Z0-9]/', '_', $class_name);
            ?>
                <div class="class-group" style="border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background: #fff;">
                    <div class="class-header" onclick="toggleAccordion('<?php echo $safe_id; ?>')" style="padding: 15px 20px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: background 0.2s;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 35px; height: 35px; background: #940000; color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.8rem;">
                                <?php echo h(substr($class_name, 0, 2)); ?>
                            </div>
                            <h6 style="margin: 0; font-weight: 800; color: #1e293b;"><?php echo h($class_name); ?> <span style="font-weight: 500; color: #64748b; font-size: 0.75rem;">(<?php echo count($subjects); ?> Subjects)</span></h6>
                        </div>
                        <i class="fas fa-chevron-down accordion-icon" id="icon_<?php echo $safe_id; ?>" style="color: #94a3b8; transition: transform 0.3s;"></i>
                    </div>
                    
                    <div class="class-content" id="content_<?php echo $safe_id; ?>" style="display: none; padding: 0 10px 10px;">
                        <table class="table" style="width: 100%; border-collapse: separate; border-spacing: 0 8px;">
                            <thead>
                                <tr style="color: #64748b; font-size: 0.7rem; font-weight: 800; text-transform: uppercase;">
                                    <th style="padding: 10px;">Subject</th>
                                    <th>Teacher</th>
                                    <th>Submission</th>
                                    <th>Approval</th>
                                    <th style="text-align: right;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subjects as $item): 
                                    $status = $item['submission_status'] ?: 'not_submitted';
                                    $status_class = ($status == 'published') ? 'status-submitted' : ($status == 'submitted' ? 'status-pending' : 'status-not-submitted');
                                    $status_text = ($status == 'published') ? 'Approved' : ($status == 'submitted' ? 'Submitted' : 'Not Submitted');
                                ?>
                                <tr class="workflow-row" data-subject="<?php echo h(strtolower($item['subject_name'])); ?>" data-teacher="<?php echo h(strtolower($item['teacher_first'] . ' ' . $item['teacher_last'])); ?>" style="background: #fdfdfd; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border-radius: 8px;">
                                    <td style="padding: 12px 10px; border-radius: 8px 0 0 8px; font-weight: 700; color: #1e293b;"><?php echo h($item['subject_name']); ?></td>
                                    <td style="font-size: 0.8rem; color: #475569; font-weight: 600;"><?php echo h($item['teacher_first'] . ' ' . $item['teacher_last']); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>" style="font-size: 0.65rem;">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($status == 'published'): ?>
                                            <span style="color: #940000; font-weight: 700; font-size: 0.7rem;"><i class="fas fa-check-double"></i> Approved</span>
                                        <?php elseif ($status == 'submitted'): ?>
                                            <span style="color: #64748b; font-weight: 700; font-size: 0.7rem;"><i class="fas fa-hourglass-half"></i> Review</span>
                                        <?php else: ?>
                                            <span style="color: #94a3b8; font-weight: 700; font-size: 0.7rem;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: right; border-radius: 0 8px 8px 0; padding-right: 10px;">
                                        <?php if ($status == 'submitted'): ?>
                                            <a href="view-submission.php?exam=<?php echo $item['exam_id']; ?>&class=<?php echo $item['class_id']; ?>&subject=<?php echo $item['subject_id']; ?>" class="btn btn-primary" style="font-size: 0.65rem; padding: 4px 10px; border-radius: 5px;"><i class="fas fa-eye"></i> Review</a>
                                        <?php elseif ($status == 'not_submitted'): ?>
                                            <button class="btn btn-outline" style="font-size: 0.65rem; padding: 4px 10px; border-radius: 5px; border-color: #ef4444; color: #ef4444;"><i class="fas fa-bell"></i> Remind</button>
                                        <?php else: ?>
                                            <a href="view-submission.php?exam=<?php echo $item['exam_id']; ?>&class=<?php echo $item['class_id']; ?>&subject=<?php echo $item['subject_id']; ?>" class="btn btn-outline" style="font-size: 0.65rem; padding: 4px 10px; border-radius: 5px;"><i class="fas fa-file-alt"></i> View</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Step 2 Section -->
    <div style="text-align: center; margin: 30px 0;">
        <i class="fas fa-arrow-down" style="font-size: 1.5rem; color: #3b82f6;"></i>
    </div>

    <div class="compilation-section">
        <!-- LEFT: Compile Report Controls -->
        <div class="card" style="padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
            <h5 style="color: #940000; font-size: 0.8rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 20px;">
                <i class="fas fa-cog"></i> COMPILE REPORT & PUBLISH
            </h5>
            
            <form id="compilationForm" action="compile.php" method="GET">
                <div class="form-group mb-4">
                    <label style="font-weight: 700; font-size: 0.85rem; color: #475569;">Select Class</label>
                    <select name="class_id" id="classSelect" class="form-control" style="background: #f8fafc; border: 1px solid #e2e8f0; height: 45px; border-radius: 8px;">
                        <option value="">Choose Class...</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group mb-4">
                    <label style="font-weight: 700; font-size: 0.85rem; color: #475569;">Select Exam</label>
                    <select name="exam_name" id="examSelect" class="form-control" style="background: #f8fafc; border: 1px solid #e2e8f0; height: 45px; border-radius: 8px;">
                        <option value="">Choose Exam Type...</option>
                        <option value="Annual / End of Term Exam">Annual / End of Term Exam</option>
                        <option value="Mid-Term Exam">Mid-Term Exam</option>
                        <option value="Weekly Test">Weekly Test</option>
                    </select>
                </div>
                
                <div style="background: #f8fafc; padding: 15px; border-radius: 10px; margin-top: 20px;">
                    <div style="font-size: 0.75rem; font-weight: 800; color: #64748b; margin-bottom: 10px; text-transform: uppercase;">Status Check</div>
                    <div id="statusCheckContainer" style="display: flex; flex-direction: column; gap: 8px;">
                        <div style="font-size: 0.8rem; display: flex; align-items: center; gap: 8px; color: #94a3b8;">
                            <i class="fas fa-circle-notch"></i> Total Subjects: -
                        </div>
                        <div style="font-size: 0.8rem; display: flex; align-items: center; gap: 8px; color: #94a3b8;">
                            <i class="fas fa-circle-notch"></i> Approved Subjects: -
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- CENTER: Preview Summary -->
        <div class="card" style="padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h5 style="color: #940000; font-size: 0.8rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">
                    <i class="fas fa-chart-bar"></i> Compilation Summary
                </h5>
                <span id="lastCompiledText" style="font-size: 0.7rem; color: #94a3b8; font-weight: 600;">Last Compiled: Never</span>
            </div>
            
            <div id="summaryStatsGrid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px;">
                <div style="background: #f8fafc; padding: 15px; border-radius: 10px; text-align: center;">
                    <div id="statTotalStudents" style="font-size: 1.2rem; font-weight: 800; color: #1e293b;">-</div>
                    <div style="font-size: 0.65rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Total Students</div>
                </div>
                <div style="background: #fff5f5; padding: 15px; border-radius: 10px; text-align: center;">
                    <div id="statPassRate" style="font-size: 1.2rem; font-weight: 800; color: #940000;">-</div>
                    <div style="font-size: 0.65rem; color: #940000; font-weight: 700; text-transform: uppercase;">Pass Rate</div>
                </div>
                <div style="background: #f8fafc; padding: 15px; border-radius: 10px; text-align: center;">
                    <div id="statAvgScore" style="font-size: 1.2rem; font-weight: 800; color: #475569;">-</div>
                    <div style="font-size: 0.65rem; color: #475569; font-weight: 700; text-transform: uppercase;">Avg. Score</div>
                </div>
            </div>
            
            <div id="previewContainer" style="border: 1px solid #f1f5f9; border-radius: 10px; overflow: hidden;">
                <div style="background: #f8fafc; padding: 10px 15px; font-size: 0.75rem; font-weight: 800; color: #64748b; border-bottom: 1px solid #f1f5f9;">
                    Preview of Compiled Report
                </div>
                <div id="previewPlaceholder" style="padding: 40px; text-align: center; color: #94a3b8;">
                    <i class="fas fa-table" style="font-size: 2rem; margin-bottom: 10px; opacity: 0.2;"></i>
                    <p style="font-size: 0.8rem; margin: 0;">Select a class and exam to see preview</p>
                </div>
            </div>
        </div>

        <!-- RIGHT: Actions -->
        <div class="action-btn-group">
            <h5 style="color: #940000; font-size: 0.8rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 15px; padding-left: 5px;">
                <i class="fas fa-chart-line"></i> ADVANCED REPORTS
            </h5>
            
            <a href="student-report.php" class="action-btn" style="border-left: 4px solid #940000;">
                <i class="fas fa-user-graduate" style="color: #940000; font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem; font-weight: 700;">Individual Report Card</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">View single student's performance</div>
                </div>
            </a>

            <a href="class-stats.php" class="action-btn" style="border-left: 4px solid #3b82f6;">
                <i class="fas fa-users" style="color: #3b82f6; font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem; font-weight: 700;">Class Performance</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Stats for all students in a class</div>
                </div>
            </a>

            <a href="school-stats.php" class="action-btn" style="border-left: 4px solid #10b981;">
                <i class="fas fa-school" style="color: #10b981; font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem; font-weight: 700;">Overall School Stats</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">School-wide division & pass rates</div>
                </div>
            </a>

            <a href="subject-stats.php" class="action-btn" style="border-left: 4px solid #f59e0b;">
                <i class="fas fa-book-open" style="color: #f59e0b; font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem; font-weight: 700;">Subject Analytics</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Analyze performance per subject</div>
                </div>
            </a>

            <h5 style="color: #940000; font-size: 0.8rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin: 15px 0 10px; padding-left: 5px;">
                <i class="fas fa-bolt"></i> QUICK ACTIONS
            </h5>
            
            <button onclick="submitCompile()" class="action-btn primary" style="width: 100%; text-align: left; cursor: pointer;">
                <i class="fas fa-cogs" style="font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem;">Compile & Publish</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Generate final report cards</div>
                </div>
            </button>

            <a href="../../api/ussd.php" target="_blank" class="action-btn" style="background: #f8fafc;">
                <i class="fas fa-mobile-alt" style="color: #64748b; font-size: 1.2rem;"></i>
                <div>
                    <div style="font-size: 0.9rem;">USSD Simulator</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Test mobile result lookup</div>
                </div>
            </a>
        </div>
    </div>
</div>

<script>
const classSelect = document.getElementById('classSelect');
const examSelect = document.getElementById('examSelect');

function updateStats() {
    const classId = classSelect.value;
    const examName = examSelect.value;

    if (!classId || !examName) return;

    // Show loading state
    document.getElementById('statusCheckContainer').innerHTML = '<div style="font-size: 0.8rem; color: #94a3b8;"><i class="fas fa-spinner fa-spin"></i> Checking status...</div>';

    fetch(`get-compilation-stats.php?class_id=${classId}&exam_name=${encodeURIComponent(examName)}`)
        .then(response => response.json())
        .then(data => {
            if (data.ready) {
                // Update Stats Cards
                document.getElementById('statTotalStudents').innerText = data.total_students;
                document.getElementById('statPassRate').innerText = data.pass_rate;
                document.getElementById('statAvgScore').innerText = data.avg_score;

                // Update Status Check
                document.getElementById('statusCheckContainer').innerHTML = `
                    <div style="font-size: 0.8rem; display: flex; align-items: center; gap: 8px; color: #10b981;">
                        <i class="fas fa-check-circle"></i> Total Subjects: ${data.status_check.total}
                    </div>
                    <div style="font-size: 0.8rem; display: flex; align-items: center; gap: 8px; color: #10b981;">
                        <i class="fas fa-check-circle"></i> Approved Subjects: ${data.status_check.approved}
                    </div>
                `;
                
                document.getElementById('previewPlaceholder').innerHTML = `
                    <div style="padding: 20px; text-align: center;">
                        <i class="fas fa-check-double" style="font-size: 2rem; color: #10b981; margin-bottom: 10px;"></i>
                        <p style="font-size: 0.85rem; color: #1e293b; font-weight: 600;">Data is ready for compilation!</p>
                        <p style="font-size: 0.75rem; color: #64748b;">${data.subjects_count} subjects found for this exam.</p>
                    </div>
                `;
            } else {
                // Reset stats
                document.getElementById('statTotalStudents').innerText = '-';
                document.getElementById('statPassRate').innerText = '-';
                document.getElementById('statAvgScore').innerText = '-';
                document.getElementById('statusCheckContainer').innerHTML = `<div style="font-size: 0.8rem; color: #ef4444;"><i class="fas fa-exclamation-triangle"></i> ${data.message}</div>`;
                document.getElementById('previewPlaceholder').innerHTML = `<p style="font-size: 0.8rem; color: #94a3b8;">${data.message}</p>`;
            }
        })
        .catch(err => {
            console.error(err);
        });
}

classSelect.addEventListener('change', updateStats);
examSelect.addEventListener('change', updateStats);

function submitCompile() {
    const classId = classSelect.value;
    const examName = examSelect.value;

    if (!classId || !examName) {
        Swal.fire({
            icon: 'warning',
            title: 'Selection Required',
            text: 'Please select both a class and an exam type before compiling.'
        });
        return;
    }

    document.getElementById('compilationForm').submit();
}
function toggleAccordion(id) {
    const content = document.getElementById('content_' + id);
    const icon = document.getElementById('icon_' + id);
    
    if (content.style.display === 'none') {
        content.style.display = 'block';
        icon.style.transform = 'rotate(180deg)';
    } else {
        content.style.display = 'none';
        icon.style.transform = 'rotate(0deg)';
    }
}

// Updated Workflow Table Filtering
const workflowSearch = document.getElementById('workflowSearch');
const classFilter = document.getElementById('classFilter');

function filterWorkflow() {
    const searchTerm = workflowSearch.value.toLowerCase();
    const classTerm = classFilter.value.toLowerCase();
    const classGroups = document.querySelectorAll('.class-group');

    classGroups.forEach(group => {
        const className = group.querySelector('h6').innerText.toLowerCase();
        const rows = group.querySelectorAll('.workflow-row');
        let visibleRowsInGroup = 0;

        rows.forEach(row => {
            const subjectName = row.getAttribute('data-subject');
            const teacherName = row.getAttribute('data-teacher');
            
            const matchesSearch = subjectName.includes(searchTerm) || teacherName.includes(searchTerm);
            const matchesClass = classTerm === '' || className.includes(classTerm);
            
            if (matchesSearch && matchesClass) {
                row.style.display = '';
                visibleRowsInGroup++;
            } else {
                row.style.display = 'none';
            }
        });

        // Hide entire class group if no subjects match
        if (visibleRowsInGroup > 0) {
            group.style.display = '';
            // Auto-expand if searching
            if (searchTerm !== '' || classTerm !== '') {
                const content = group.querySelector('.class-content');
                const icon = group.querySelector('.accordion-icon');
                content.style.display = 'block';
                icon.style.transform = 'rotate(180deg)';
            }
        } else {
            group.style.display = 'none';
        }
    });
}

workflowSearch.addEventListener('input', filterWorkflow);
classFilter.addEventListener('change', filterWorkflow);
</script>

<?php require_once '../../includes/footer.php'; ?>
