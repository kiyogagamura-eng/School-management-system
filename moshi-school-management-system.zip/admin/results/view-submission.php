<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$exam_id = $_GET['exam'] ?? 0;
$class_id = $_GET['class'] ?? 0;
$subject_id = $_GET['subject'] ?? 0;

if (!$exam_id || !$class_id || !$subject_id) {
    redirect('review.php');
}

// Fetch group details
$stmt = $pdo->prepare("
    SELECT e.exam_name, c.class_name, s.subject_name 
    FROM exams e 
    JOIN classes c ON c.class_id = ? 
    JOIN subjects s ON s.subject_id = ? 
    WHERE e.exam_id = ?
");
$stmt->execute([$class_id, $subject_id, $exam_id]);
$details = $stmt->fetch();

if (!$details) redirect('review.php');

$page_title = "View Submission: " . $details['exam_name'];

// Fetch marks in this group
$stmt = $pdo->prepare("
    SELECT r.*, s.first_name, s.last_name, s.admission_number
    FROM results r
    JOIN students s ON r.student_id = s.student_id
    WHERE r.exam_id = ? AND r.class_id = ? AND r.subject_id = ?
    ORDER BY s.first_name ASC
");
$stmt->execute([$exam_id, $class_id, $subject_id]);
$results = $stmt->fetchAll();

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <?php if (isset($_SESSION['success'])): ?>
        <div style="background: #fff5f5; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000;"><i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div style="background: #f8fafc; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000;"><i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div style="margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <a href="review.php" class="btn btn-outline" style="font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Review</a>
        </div>
        <div style="background: white; padding: 10px 25px; border-radius: 30px; border: 1px solid #ddd; font-weight: 700; color: var(--corporate-red);">
            <?php echo h($details['exam_name'] . ' | ' . $details['class_name'] . ' | ' . $details['subject_name']); ?>
        </div>
    </div>

    <div class="card shadow-premium">
        <div class="card-header" style="background: var(--header-gradient); color: white;">
            <h3 style="margin: 0;"><i class="fas fa-eye"></i> Submission Details</h3>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Admission No</th>
                        <th>Student Name</th>
                        <th>Marks Obtained</th>
                        <th>Grade</th>
                        <th>Remarks</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $r): ?>
                        <tr>
                            <td style="font-family: monospace;"><?php echo h($r['admission_number']); ?></td>
                            <td style="font-weight: 700;"><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></td>
                            <td style="font-weight: 700; color: var(--corporate-red);"><?php echo $r['marks_obtained']; ?></td>
                            <td><span class="badge" style="background: #eee; color: #333;"><?php echo h($r['grade']); ?></span></td>
                            <td><?php echo h($r['remarks']); ?></td>
                            <td>
                                <?php if ($r['status'] == 'submitted'): ?>
                                    <span style="color: #ef6c00; font-weight: 700;">Pending Review</span>
                                <?php else: ?>
                                    <span style="color: #2e7d32; font-weight: 700;">Published</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php if (!empty($results) && $results[0]['status'] == 'submitted'): ?>
                <div style="margin-top: 30px; text-align: right;">
                    <form action="review.php" method="POST">
                        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                        <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
                        <button type="submit" name="publish" class="btn btn-primary" style="padding: 15px 40px;">
                            <i class="fas fa-check"></i> APPROVE & PUBLISH ALL
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
