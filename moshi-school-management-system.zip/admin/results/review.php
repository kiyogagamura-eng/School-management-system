<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos']); // Only DOS can review and publish results

$page_title = "Recently Submitted Results";

$success = '';
$error = '';

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}

// Handle Approval/Publishing from view-submission.php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['publish'])) {
    $exam_id = $_POST['exam_id'];
    $class_id = $_POST['class_id'];
    $subject_id = $_POST['subject_id'];
    
    try {
        $stmt = $pdo->prepare("UPDATE results SET status = 'published' WHERE exam_id = ? AND class_id = ? AND subject_id = ? AND status = 'submitted'");
        $stmt->execute([$exam_id, $class_id, $subject_id]);
        $_SESSION['success'] = "Results for this subject have been approved and marked as published.";
        logActivity($_SESSION['user_id'], 'Approved Results', "Approved subject results for Exam ID $exam_id, Class ID $class_id");
    } catch (PDOException $e) {
        $_SESSION['error'] = "Update failed: " . $e->getMessage();
    }
    
    header("Location: view-submission.php?exam=$exam_id&class=$class_id&subject=$subject_id");
    exit();
}
$query = "
    SELECT 
        r.exam_id, r.class_id, r.subject_id,
        e.exam_name, c.class_name, s.subject_name,
        MAX(r.last_updated) as last_submission
    FROM results r
    JOIN exams e ON r.exam_id = e.exam_id
    JOIN classes c ON r.class_id = c.class_id
    JOIN subjects s ON r.subject_id = s.subject_id
    WHERE r.status = 'submitted'
    ORDER BY c.form_level, c.stream, e.exam_name
";
$raw_submissions = $pdo->query($query)->fetchAll();

// Process submissions into a nested array: [class_name][exam_name][]
$submissions_by_class = [];
foreach ($raw_submissions as $sub) {
    if (!$sub['class_id']) continue;
    $class_id = $sub['class_id'];
    $exam_name = $sub['exam_name'];
    
    if (!isset($submissions_by_class[$class_id])) {
        $submissions_by_class[$class_id] = [
            'class_name' => $sub['class_name'],
            'exams' => []
        ];
    }
    
    if (!isset($submissions_by_class[$class_id]['exams'][$exam_name])) {
        $submissions_by_class[$class_id]['exams'][$exam_name] = [
            'exam_id' => $sub['exam_id'], // Use the first found ID
            'subjects' => [],
            'last_submission' => $sub['last_submission']
        ];
    }
    
    $submissions_by_class[$class_id]['exams'][$exam_name]['subjects'][] = [
        'name' => $sub['subject_name'],
        'id' => $sub['subject_id']
    ];
    if ($sub['last_submission'] > $submissions_by_class[$class_id]['exams'][$exam_name]['last_submission']) {
        $submissions_by_class[$class_id]['exams'][$exam_name]['last_submission'] = $sub['last_submission'];
    }
}

// Fetch Class Progress (How many subjects per class are ready)
$class_progress = [];
try {
    $current_year = date('Y');
    // Get all classes
    $stmt = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY form_level, c.stream");
    // Actually the above has a syntax error in my head, let's use the full query
    $stmt = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY form_level, stream");
    $all_classes = $stmt->fetchAll();
    
    foreach ($all_classes as $c) {
        $cid = $c['class_id'];
        
        // Count assigned subjects
        $stmt_s = $pdo->prepare("SELECT COUNT(*) FROM class_subjects WHERE class_id = ?");
        $stmt_s->execute([$cid]);
        $total = (int)$stmt_s->fetchColumn();
        
        // Count submitted subjects for the CURRENT YEAR
        $stmt_r = $pdo->prepare("
            SELECT COUNT(DISTINCT e.subject_id) 
            FROM exams e 
            JOIN results r ON e.exam_id = r.exam_id
            WHERE e.class_id = ? 
            AND r.status = 'submitted'
            AND (YEAR(e.exam_date) = ? OR (e.exam_date IS NULL AND YEAR(e.created_at) = ?))
        ");
        $stmt_r->execute([$cid, $current_year, $current_year]);
        $ready = (int)$stmt_r->fetchColumn();
        
        // Count published subjects for the CURRENT YEAR
        $stmt_p = $pdo->prepare("
            SELECT COUNT(DISTINCT e.subject_id) 
            FROM exams e 
            JOIN results r ON e.exam_id = r.exam_id
            WHERE e.class_id = ? 
            AND r.status = 'published'
            AND (YEAR(e.exam_date) = ? OR (e.exam_date IS NULL AND YEAR(created_at) = ?))
        ");
        $stmt_p->execute([$cid, $current_year, $current_year]);
        $published = (int)$stmt_p->fetchColumn();
        
        if ($ready > 0 || $total > 0 || $published > 0) {
            $class_progress[] = [
                'class_id' => $cid,
                'class_name' => $c['class_name'],
                'total_subjects' => $total,
                'submitted_subjects' => $ready,
                'published_subjects' => $published
            ];
        }
    }
} catch (Exception $e) {}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <?php if ($success): ?>
        <div style="background: #fff5f5; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div style="background: #f8fafc; color: #940000; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #940000;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
        <div>
            <h2 style="margin: 0; color: var(--corporate-red);"><i class="fas fa-tasks"></i> Results Submission Progress</h2>
            <p style="color: var(--secondary-text); margin-top: 5px;">Track which subjects have been submitted by teachers.</p>
        </div>
        <a href="compile.php" class="btn btn-primary" style="padding: 12px 25px; background: var(--corporate-red); border-color: var(--corporate-red);"><i class="fas fa-layer-group"></i> COMPILE REPORT CARDS</a>
    </div>

    <!-- Class Progress Tracker -->
    <div style="margin-bottom: 35px;">
        <h4 style="margin-bottom: 15px; color: #2C3E50;"><i class="fas fa-tasks"></i> Class Submission Progress</h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 15px;">
            <?php foreach ($class_progress as $cp): 
                $percent = $cp['total_subjects'] > 0 ? round(($cp['submitted_subjects'] / $cp['total_subjects']) * 100) : 0;
                $color = $percent == 100 ? '#940000' : '#64748b';
            ?>
                <div class="card" style="padding: 15px; border-top: 3px solid <?php echo $color; ?>; margin-bottom: 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <span style="font-weight: 900; font-size: 0.9rem; color: #2C3E50;"><?php echo h($cp['class_name']); ?></span>
                        <span style="font-size: 0.75rem; font-weight: 700; color: <?php echo $color; ?>;"><?php echo $percent; ?>%</span>
                    </div>
                    <div style="background: #f1f1f1; height: 6px; border-radius: 3px; overflow: hidden; margin-bottom: 5px;">
                        <div style="width: <?php echo $percent; ?>%; background: <?php echo $color; ?>; height: 100%; transition: width 0.5s;"></div>
                    </div>
                    <div style="font-size: 0.7rem; color: #7F8C8D; margin-bottom: 5px;">
                        <?php echo $cp['submitted_subjects']; ?> pending approval
                    </div>
                    <div style="font-size: 0.7rem; color: #2e7d32; font-weight: 700;">
                        <?php echo $cp['published_subjects']; ?> of <?php echo $cp['total_subjects']; ?> published
                    </div>
                    <?php if ($cp['published_subjects'] >= $cp['total_subjects'] && $cp['total_subjects'] > 0): ?>
                        <div style="margin-top: 10px; text-align: center;">
                            <a href="compile.php?class_id=<?php echo $cp['class_id']; ?>" style="font-size: 0.7rem; font-weight: 900; color: #940000; text-decoration: none;">
                                <i class="fas fa-arrow-right"></i> GO TO COMPILE
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Simplified View -->

    <div class="submissions-section">
        <h4 style="margin-bottom: 20px; color: #2C3E50;"><i class="fas fa-layer-group"></i> Submissions by Class</h4>
        
        <?php if (empty($submissions_by_class)): ?>
            <div class="card shadow-premium" style="text-align: center; padding: 40px; color: var(--secondary-text);">
                <i class="fas fa-check-circle" style="font-size: 3rem; margin-bottom: 15px; color: #940000;"></i>
                <h4>All clear! No pending subject results.</h4>
            </div>
        <?php else: ?>
            <?php foreach ($submissions_by_class as $class_id => $data): ?>
                <div class="card shadow-premium" style="margin-bottom: 30px; border-left: 5px solid var(--corporate-red);">
                    <div class="card-header" style="background: #f8fafc; border-bottom: 2px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 1.1rem; font-weight: 900; color: var(--corporate-red);">
                            <i class="fas fa-school"></i> <?php echo h($data['class_name']); ?>
                        </span>
                        <span class="badge" style="background: #f1f5f9; color: #475569; font-size: 0.75rem;">
                            <?php echo count($data['exams']); ?> Pending Exam(s)
                        </span>
                    </div>
                    <div class="card-body" style="padding: 0;">
                        <table class="table" style="margin: 0;">
                            <thead>
                                <tr style="background: #ffffff; border-bottom: 1px solid #eee;">
                                    <th style="padding-left: 25px; border-bottom: 2px solid #eee; font-size: 0.75rem; color: #64748b;">EXAM NAME</th>
                                    <th style="border-bottom: 2px solid #eee; font-size: 0.75rem; color: #64748b;">READY SUBJECTS</th>
                                    <th style="border-bottom: 2px solid #eee; font-size: 0.75rem; color: #64748b;">LAST ACTIVITY</th>
                                    <th style="text-align: right; padding-right: 25px; border-bottom: 2px solid #eee; font-size: 0.75rem; color: #64748b;">ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['exams'] as $exam_name => $e): 
                                    // Calculate total subjects for this class to show accurate progress
                                    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM class_subjects WHERE class_id = ?");
                                    $total_stmt->execute([$class_id]);
                                    $total_class_subjects = $total_stmt->fetchColumn();
                                    
                                    // Count published for this specific exam name
                                    $pub_stmt = $pdo->prepare("SELECT COUNT(DISTINCT r.subject_id) FROM results r JOIN exams e ON r.exam_id = e.exam_id WHERE e.class_id = ? AND e.exam_name = ? AND r.status = 'published'");
                                    $pub_stmt->execute([$class_id, $exam_name]);
                                    $published_count = $pub_stmt->fetchColumn();

                                    $subjects_count = count($e['subjects']);
                                    $is_fully_published = $published_count >= $total_class_subjects && $total_class_subjects > 0;
                                    $percent = $total_class_subjects > 0 ? round(($published_count / $total_class_subjects) * 100) : 0;
                                    $status_color = $is_fully_published ? '#940000' : '#64748b';
                                ?>
                                    <tr>
                                        <td style="padding-left: 25px;">
                                            <div style="font-weight: 800; color: #1e293b;"><?php echo h($exam_name); ?></div>
                                            <div style="font-size: 0.75rem; color: #64748b; margin-top: 5px; display: flex; flex-wrap: wrap; gap: 8px;">
                                                <?php foreach ($e['subjects'] as $sub_info): ?>
                                                    <a href="view-submission.php?exam=<?php echo $e['exam_id']; ?>&class=<?php echo $class_id; ?>&subject=<?php echo $sub_info['id']; ?>" 
                                                       style="background: #fff5f5; color: #940000; padding: 2px 10px; border-radius: 4px; text-decoration: none; font-weight: 700; border: 1px solid rgba(148,0,0,0.1); transition: all 0.2s;">
                                                        <i class="fas fa-book"></i> <?php echo h($sub_info['name']); ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        </td>
                                        <td style="vertical-align: middle;">
                                            <div style="display: flex; align-items: center; gap: 10px;">
                                                <div style="flex: 1; height: 6px; background: #f1f5f9; border-radius: 3px; overflow: hidden; max-width: 120px;">
                                                    <div style="width: <?php echo $percent; ?>%; background: <?php echo $status_color; ?>; height: 100%;"></div>
                                                </div>
                                                <span style="font-size: 0.75rem; font-weight: 800; color: <?php echo $status_color; ?>;">
                                                    <?php echo $subjects_count; ?> / <?php echo $total_class_subjects; ?>
                                                </span>
                                            </div>
                                        </td>
                                        <td style="font-size: 0.8rem; color: #64748b; vertical-align: middle;">
                                            <?php echo date('d M, H:i', strtotime($e['last_submission'])); ?>
                                        </td>
                                        <td style="text-align: right; padding-right: 25px; vertical-align: middle;">
                                            <?php if ($is_fully_published): ?>
                                                <a href="compile.php?class_id=<?php echo $class_id; ?>&exam_name=<?php echo urlencode($exam_name); ?>" class="btn btn-primary" style="padding: 6px 15px; font-size: 0.75rem; font-weight: 800; border-radius: 8px;">
                                                    <i class="fas fa-check-double"></i> GO TO COMPILE
                                                </a>
                                            <?php else: ?>
                                                <button onclick="toggleAccordion('class_<?php echo preg_replace('/[^a-zA-Z0-9]/', '_', $data['class_name']); ?>')" class="btn btn-outline" style="padding: 6px 15px; font-size: 0.75rem; font-weight: 800; border-radius: 8px;">
                                                    <i class="fas fa-search"></i> REVIEW PENDING (<?php echo $subjects_count; ?>)
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

            
            <?php
            $stmt = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY form_level, stream");
            $all_classes = $stmt->fetchAll();
            ?>
            
            <div style="display: flex; gap: 10px; margin-bottom: 25px; overflow-x: auto; padding-bottom: 10px;">
                <?php foreach ($all_classes as $c): ?>
                    <button onclick="showBreakdown(<?php echo $c['class_id']; ?>, '<?php echo h($c['class_name']); ?>')" class="btn btn-outline" style="white-space: nowrap; font-size: 0.8rem; padding: 5px 15px; border-radius: 20px;">
                        <?php echo h($c['class_name']); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <div id="breakdown-container" style="display: none; animation: fadeIn 0.3s;">
                <h5 id="breakdown-title" style="color: var(--corporate-red); border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 15px;"></h5>
                <div id="breakdown-content" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px;">
                    <!-- AJAX/Dynamic content goes here -->
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function showBreakdown(classId, className) {
    const container = document.getElementById('breakdown-container');
    const title = document.getElementById('breakdown-title');
    const content = document.getElementById('breakdown-content');
    
    container.style.display = 'block';
    title.innerHTML = `<i class="fas fa-folder-open"></i> Submission Status: ${className}`;
    content.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
    
    fetch(`get-submission-breakdown.php?class_id=${classId}`)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                content.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 20px; color: #7f8c8d;">No subjects assigned to this class.</div>';
                return;
            }
            
            let html = '';
            data.forEach(item => {
                const isDone = item.is_published == 1;
                const statusColor = isDone ? '#27ae60' : '#e74c3c';
                const statusIcon = isDone ? 'fa-check-circle' : 'fa-clock';
                const statusText = isDone ? 'SUBMITTED' : 'PENDING';
                
                html += `
                    <div style="background: #fff; border: 1px solid #eee; padding: 12px; border-radius: 8px; border-left: 4px solid ${statusColor}; display: flex; align-items: center; justify-content: space-between;">
                        <div>
                            <div style="font-weight: 700; font-size: 0.85rem; color: #2c3e50;">${item.subject_name}</div>
                            <div style="font-size: 0.7rem; color: #7f8c8d;"><i class="fas fa-user-tie"></i> ${item.teacher_name || 'Not Assigned'}</div>
                        </div>
                        <div style="text-align: right;">
                            <span style="font-size: 0.65rem; font-weight: 900; color: ${statusColor}; background: ${statusColor}15; padding: 3px 8px; border-radius: 4px; display: block; margin-bottom: 4px;">
                                <i class="fas ${statusIcon}"></i> ${statusText}
                            </span>
                        </div>
                    </div>
                `;
            });
            content.innerHTML = html;
        })
        .catch(err => {
            content.innerHTML = '<div style="grid-column: 1/-1; color: #c62828;">Error loading data.</div>';
        });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
