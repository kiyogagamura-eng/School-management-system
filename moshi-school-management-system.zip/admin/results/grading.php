<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Manage Grading Scale";

$success = '';
$error = '';

// Handle CRUD
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_scale'])) {
        try {
            $pdo->beginTransaction();
            // Clear existing
            $pdo->exec("TRUNCATE TABLE grading_scale");
            
            $stmt = $pdo->prepare("INSERT INTO grading_scale (grade, min_marks, max_marks, remarks, point_value) VALUES (?, ?, ?, ?, ?)");
            
            $grades = $_POST['grade'];
            $mins = $_POST['min_marks'];
            $maxs = $_POST['max_marks'];
            $remarks = $_POST['remarks'];
            $points = $_POST['point_value'];

            for ($i = 0; $i < count($grades); $i++) {
                if (empty($grades[$i])) continue;
                $stmt->execute([$grades[$i], $mins[$i], $maxs[$i], $remarks[$i], $points[$i]]);
            }
            
            $pdo->commit();
            $success = "Grading scale updated successfully!";
            logActivity($_SESSION['user_id'], 'Updated Grading Scale', 'Modified academic grading thresholds and point values.');
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Fetch current scale
$stmt = $pdo->query("SELECT * FROM grading_scale ORDER BY min_marks DESC");
$scale = $stmt->fetchAll();

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="background: linear-gradient(135deg, #f8f9fa, #ffffff); border-left: 5px solid var(--corporate-red); padding: 20px; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
        <h4 style="margin: 0 0 5px; color: var(--corporate-red);"><i class="fas fa-percentage"></i> Academic Grading Policy</h4>
        <p style="margin: 0; color: #555;">Define the percentage thresholds and point values for student grades across the entire system.</p>
    </div>

    <?php if ($success): ?><div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #2ecc71;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div><?php endif; ?>
    <?php if ($error): ?><div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #f44336;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div><?php endif; ?>

    <div class="card shadow-premium" style="max-width: 1000px;">
        <div class="card-header" style="background: var(--header-gradient); color: white;">
            <h3 style="margin: 0;"><i class="fas fa-edit"></i> Configure Scale</h3>
        </div>
        <div class="card-body">
            <form action="" method="POST" id="gradingForm">
                <table class="table" id="gradingTable">
                    <thead>
                        <tr>
                            <th style="width: 100px;">Grade</th>
                            <th>Min %</th>
                            <th>Max %</th>
                            <th style="width: 120px;">Point Value</th>
                            <th>Remarks</th>
                            <th style="width: 50px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($scale as $row): ?>
                            <tr>
                                <td><input type="text" name="grade[]" class="form-control" value="<?php echo h($row['grade']); ?>" required style="text-align: center; font-weight: 700;"></td>
                                <td><input type="number" step="0.01" name="min_marks[]" class="form-control" value="<?php echo $row['min_marks']; ?>" required></td>
                                <td><input type="number" step="0.01" name="max_marks[]" class="form-control" value="<?php echo $row['max_marks']; ?>" required></td>
                                <td><input type="number" name="point_value[]" class="form-control" value="<?php echo $row['point_value'] ?? 0; ?>" required style="text-align: center;"></td>
                                <td><input type="text" name="remarks[]" class="form-control" value="<?php echo h($row['remarks']); ?>"></td>
                                <td><button type="button" class="btn btn-outline" style="color: #e74c3c; border: none;" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div style="margin-top: 20px; display: flex; justify-content: space-between;">
                    <button type="button" class="btn btn-outline" onclick="addRow()"><i class="fas fa-plus"></i> Add New Grade</button>
                    <button type="submit" name="update_scale" class="btn btn-primary" style="padding: 12px 40px;"><i class="fas fa-save"></i> SAVE CHANGES</button>
                </div>
            </form>
        </div>
    </div>

    <div class="alert alert-info" style="margin-top: 30px; max-width: 1000px; border-left: 5px solid var(--corporate-red); background: #fdfdfd;">
        <h4 style="color: var(--corporate-red); margin-top: 0;"><i class="fas fa-info-circle"></i> Important Note</h4>
        <p>Changes to this scale will apply <b>immediately</b> to all previously entered marks.</p>
        <p style="margin-bottom: 0;"><b>Point Values:</b> Used for O-Level and A-Level result totals. Standard scale is usually A=1, B=2, C=3, D=4, E=5, S=6, F=7.</p>
    </div>
</div>

<script>
function addRow() {
    const tbody = document.querySelector('#gradingTable tbody');
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td><input type="text" name="grade[]" class="form-control" placeholder="X" required style="text-align: center; font-weight: 700;"></td>
        <td><input type="number" step="0.01" name="min_marks[]" class="form-control" placeholder="0" required></td>
        <td><input type="number" step="0.01" name="max_marks[]" class="form-control" placeholder="100" required></td>
        <td><input type="number" name="point_value[]" class="form-control" placeholder="0" required style="text-align: center;"></td>
        <td><input type="text" name="remarks[]" class="form-control" placeholder="Remark..."></td>
        <td><button type="button" class="btn btn-outline" style="color: #e74c3c; border: none;" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
    `;
    tbody.appendChild(newRow);
}

function removeRow(btn) {
    if (confirm('Are you sure you want to remove this grade level?')) {
        btn.closest('tr').remove();
    }
}
</script>

<?php require_once '../../includes/footer.php'; ?>
