<?php
require_once '../../includes/bootstrap.php';
requireRole(['dos']); // Only DOS (Academic Director) can publish results

$page_title = "Compile Report Cards";

$success = '';
$error = '';

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}

// Fetch classes
$stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level ASC, stream ASC");
$classes = $stmt->fetchAll();

$selected_class = $_GET['class_id'] ?? '';
$selected_exam_name = $_GET['exam_name'] ?? '';

// Handle Publish Final Report
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['publish_reports'])) {
    $class_id = $_POST['class_id'];
    $exam_name = $_POST['exam_name'];
    $selected_year = $_POST['selected_year'] ?? date('Y');
    $notify = isset($_POST['notify_parents']);
    
    try {
        $pdo->beginTransaction();
        
        // 1. Get all subject exams matching this name and class
        $stmt = $pdo->prepare("SELECT exam_id FROM exams WHERE class_id = ? AND exam_name = ? AND (YEAR(exam_date) = ? OR (exam_date IS NULL AND YEAR(created_at) = ?))");
        $stmt->execute([$class_id, $exam_name, $selected_year, $selected_year]);
        $exams = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($exams)) {
            $inClause = implode(',', array_fill(0, count($exams), '?'));
            
            // 2. Mark all those results as 'published'
            $stmt = $pdo->prepare("UPDATE results SET status = 'published' WHERE exam_id IN ($inClause) AND status = 'submitted'");
            $stmt->execute($exams);
            
            // Generate aggregate data for SMS with detailed breakdown
            if ($notify) {
                // Fetch all results for all students in this publish batch
                $stmt = $pdo->prepare("
                    SELECT r.student_id, st.first_name, st.last_name, st.parent_phone, 
                           s.subject_name, r.marks_obtained, r.grade
                    FROM results r
                    JOIN exams e ON r.exam_id = e.exam_id
                    JOIN students st ON r.student_id = st.student_id
                    JOIN subjects s ON r.subject_id = s.subject_id
                    WHERE r.exam_id IN ($inClause) AND r.status = 'published'
                    ORDER BY r.student_id, s.subject_name ASC
                ");
                $stmt->execute($exams);
                $all_published_results = $stmt->fetchAll(PDO::FETCH_GROUP|PDO::FETCH_ASSOC);
                
                $sms_sent = 0;
                foreach ($all_published_results as $student_id => $results) {
                    $first_student = $results[0];
                    if (empty($first_student['parent_phone'])) continue;
                    
                    // Header
                    $msg = "RESULTS FOR\n";
                    $msg .= mb_strtoupper($first_student['first_name'] . " " . $first_student['last_name']) . "\n";
                    
                    // Subjects
                    foreach ($results as $res) {
                        $msg .= $res['subject_name'] . "--" . round($res['marks_obtained']) . "--(" . $res['grade'] . ")\n";
                    }
                    
                    // Division & Summary
                    $div_info = calculateOLevelDivision($results);
                    $msg .= "\nDiv: " . $div_info['division'] . " Pts: " . $div_info['total_points'];
                    $msg .= "\nLog in: " . base_url() . " to view full report.";
                    
                    if (sendSMS($first_student['parent_phone'], $msg)) {
                        $sms_sent++;
                    }
                }
            }
            
            $pdo->commit();
            $_SESSION['success'] = "Report Cards published successfully!";
            if ($notify) $_SESSION['success'] .= " Sent SMS to $sms_sent parents.";
            
            logActivity($_SESSION['user_id'], 'Published Report Cards', "Published full report cards for $exam_name (Class $class_id)");
        } else {
            throw new Exception("No submitted exams found matching these criteria.");
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: compile.php?class_id=" . urlencode($class_id) . "&exam_name=" . urlencode($exam_name) . "&year=" . urlencode($selected_year));
    exit();
}

$selected_year = $_GET['year'] ?? date('Y');
$current_year = (int)date('Y');

$min_year_stmt = $pdo->query("SELECT MIN(YEAR(created_at)) FROM exams");
$min_year = (int)$min_year_stmt->fetchColumn();
if (!$min_year || $min_year < 2000 || $min_year > $current_year) $min_year = $current_year;

if ((int)$selected_year > $current_year) {
    $error = "The selected academic year has not arrived yet (You cannot choose a future year like $selected_year).";
    $selected_year = $current_year;
} elseif ((int)$selected_year < $min_year) {
    $error = "The selected academic year is in the past (You cannot choose a year before $min_year).";
    $selected_year = $current_year;
}

// Fetch available years (Dynamic up to current year)
$years = range($min_year, $current_year);

// Fetch available Exam Names for the selected class and year
$exam_names = [];
if ($selected_class) {
    $stmt = $pdo->prepare("
        SELECT DISTINCT exam_name, exam_type 
        FROM exams 
        WHERE class_id = ? 
        AND (YEAR(exam_date) = ? OR (exam_date IS NULL AND YEAR(created_at) = ?))
    ");
    $stmt->execute([$selected_class, $selected_year, $selected_year]);
    $exam_names = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Group exam names into categories and UNIQUE them
$grouped_exams = [
    'Mid-Term Exams' => [],
    'End of Term Exams (Annual)' => [],
    'Weekly / Monthly Tests' => []
];

$used_labels = [];

foreach ($exam_names as $en_row) {
    $en = $en_row['exam_name'];
    $e_type = $en_row['exam_type'];
    
    // Clean the name: Remove any 4-digit year (e.g., 2023, 2024)
    $clean_name = preg_replace('/\b20\d{2}\b/', '', $en);
    $clean_name = trim(preg_replace('/\s+/', ' ', $clean_name));
    
    $group = 'Weekly / Monthly Tests';
    $label = $clean_name;

    if ($e_type === 'midterm') {
        $group = 'Mid-Term Exams';
    } elseif ($e_type === 'endterm') {
        $group = 'End of Term Exams (Annual)';
    } elseif ($e_type === 'test' || $e_type === 'assignment' || $e_type === 'practical') {
        $group = 'Weekly / Monthly Tests';
    }

    // Only add unique labels per group
    if (!isset($used_labels[$group][$label])) {
        $grouped_exams[$group][$en] = $label;
        $used_labels[$group][$label] = true;
    }
}

// Generate the Matrix if both selected
$matrix = [];
$subjects = [];
$student_list = [];

if ($selected_class && $selected_exam_name) {
    // Get all subjects that have exams for this name
    $stmt = $pdo->prepare("
        SELECT MAX(e.exam_id) as exam_id, s.subject_id, s.subject_name, e.max_marks 
        FROM exams e 
        JOIN subjects s ON e.subject_id = s.subject_id 
        WHERE e.class_id = ? AND e.exam_name = ?
        GROUP BY s.subject_id
        ORDER BY s.subject_name ASC
    ");
    $stmt->execute([$selected_class, $selected_exam_name]);
    $subjects = $stmt->fetchAll();
    
    // Get all active students in the class
    $stmt = $pdo->prepare("SELECT student_id, first_name, last_name, admission_number FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name ASC");
    $stmt->execute([$selected_class]);
    $student_list = $stmt->fetchAll();
    
    // Fetch all submitted results
    $exams_ids = array_column($subjects, 'exam_id');
    if (!empty($exams_ids)) {
        $inClause = implode(',', $exams_ids);
        $stmt = $pdo->query("
            SELECT r.student_id, r.exam_id, r.marks_obtained, r.grade, r.status, gs.point_value 
            FROM results r
            LEFT JOIN grading_scale gs ON r.grade = gs.grade
            WHERE r.exam_id IN ($inClause)
        ");
        $all_results = $stmt->fetchAll();
        
        $result_lookup = [];
        $status_check = []; // track non-published to see if we can still publish
        
        foreach ($all_results as $r) {
            $result_lookup[$r['student_id']][$r['exam_id']] = $r;
            $status_check[$r['status']] = true;
        }
        
        $all_published = !isset($status_check['submitted']) && isset($status_check['published']);
        $has_pending = isset($status_check['submitted']);

        // Build matrix
        foreach ($student_list as $st) {
            $sid = $st['student_id'];
            $st_total = 0;
            $st_max = 0;
            $taken = 0;
            
            $row = [
                'student' => $st,
                'marks' => []
            ];
            
            foreach ($subjects as $sub) {
                $eid = $sub['exam_id'];
                if (isset($result_lookup[$sid][$eid])) {
                    $mark = $result_lookup[$sid][$eid]['marks_obtained'];
                    $row['marks'][$eid] = $result_lookup[$sid][$eid];
                    $st_total += $mark;
                    $st_max += $sub['max_marks'];
                    $taken++;
                } else {
                    $row['marks'][$eid] = null;
                }
            }
            
            $row['total'] = $st_total;
            $row['max'] = $st_max;
            $row['average'] = $st_max > 0 ? ($st_total / $st_max) * 100 : 0;
            
            // Calculate Division (Best 7)
            $row['division_info'] = calculateOLevelDivision(array_filter($row['marks']));
            
            $matrix[$sid] = $row;
        }
        
        // Calculate Rank based on average
        uasort($matrix, function($a, $b) {
            return $b['average'] <=> $a['average']; // Descending
        });
        
        $rank = 1;
        $prev_avg = -1;
        $actual_rank = 1;
        
        $total_students = count($matrix);
        $total_sum_avg = 0;
        $pass_count = 0;

        foreach ($matrix as $sid => &$row) {
            if ($row['average'] != $prev_avg) {
                $row['rank'] = $actual_rank;
            } else {
                $row['rank'] = $rank; // Tie
            }
            $prev_avg = $row['average'];
            $actual_rank++;
            $rank = $row['rank'];

            // For stats
            $total_sum_avg += $row['average'];
            if ($row['average'] >= 50) $pass_count++;
        }
        unset($row);

        $summary_stats = [
            'total_students' => $total_students,
            'pass_rate' => $total_students > 0 ? round(($pass_count / $total_students) * 100) . '%' : '0%',
            'avg_score' => $total_students > 0 ? round($total_sum_avg / $total_students, 1) . '%' : '0%'
        ];
    }
}

require_once '../../includes/header.php';
?>

<style>
    :root {
        --corporate-red: #940000;
        --accent-soft-red: rgba(148,0,0,0.05);
        --slate-gray: #1e293b;
        --secondary-text: #64748b;
    }
    .compile-container { padding: 20px; background: #f8fafc; min-height: 100vh; font-family: 'Inter', sans-serif; }
    
    .card-premium {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid rgba(0,0,0,0.05);
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        margin-bottom: 30px;
        overflow: hidden;
    }
    .card-header-premium {
        padding: 20px 25px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #fff;
    }
    .header-title { color: var(--corporate-red); font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; gap: 10px; }
    
    .matrix-table { width: 100%; border-collapse: separate; border-spacing: 0; }
    .matrix-table th { background: #f8fafc; color: var(--secondary-text); font-weight: 800; font-size: 0.75rem; text-transform: uppercase; padding: 15px; border-bottom: 2px solid #edf2f7; text-align: center; }
    .matrix-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; color: var(--slate-gray); vertical-align: middle; }
    
    .form-control-premium {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        height: 45px;
        font-weight: 600;
        color: #1e293b;
        padding: 0 15px;
        transition: all 0.3s;
    }
    .form-control-premium:focus { border-color: var(--corporate-red); box-shadow: 0 0 0 3px var(--accent-soft-red); outline: none; }
    
    .compilation-section {
        display: grid;
        grid-template-columns: 320px 1fr 300px;
        gap: 20px;
        margin-top: 20px;
    }
    
    .action-btn {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 18px;
        border-radius: 12px;
        background: #fff;
        border: 1px solid #e2e8f0;
        color: #475569;
        text-decoration: none;
        transition: all 0.2s;
        font-weight: 700;
        margin-bottom: 12px;
        text-align: left;
        width: 100%;
        cursor: pointer;
    }
    .action-btn:hover { border-color: #940000; color: #940000; background: #fff5f5; transform: translateY(-2px); }
    .action-btn.primary { background: #940000; color: #fff; border-color: #940000; box-shadow: 0 4px 12px rgba(148,0,0,0.2); }
    .action-btn.primary:hover { background: #7d0000; color: #fff; }
    
    .stat-mini-card { background: #f8fafc; padding: 15px; border-radius: 12px; text-align: center; border: 1px solid #f1f5f9; }
    .stat-mini-card.highlight { background: #fff5f5; border-color: #fecaca; }
    
    @media (max-width: 1200px) { .compilation-section { grid-template-columns: 1fr; } }
    @media print { .no-print { display: none !important; } .compile-container { padding: 0; background: white; } }
</style>

<div class="compile-container">
    
    <?php if (!empty($success)): ?>
        <div style="background: #ecfdf5; border-left: 5px solid #10b981; color: #065f46; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-check-circle" style="font-size: 1.2rem;"></i> <?php echo h($success); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div style="background: #fef2f2; border-left: 5px solid #ef4444; color: #991b1b; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-exclamation-circle" style="font-size: 1.2rem;"></i> <?php echo h($error); ?>
        </div>
    <?php endif; ?>

    <!-- Main Dashboard Grid -->
    <div class="compilation-section">
        
        <!-- LEFT COLUMN: Controls -->
        <div class="no-print">
            <div class="card-premium" style="padding: 25px;">
                <h5 style="color: #940000; font-size: 0.85rem; font-weight: 900; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 25px; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-cog"></i> COMPILE REPORT & PUBLISH
                </h5>
                
                <form action="" method="GET">
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="font-weight: 700; color: #475569; font-size: 0.8rem; margin-bottom: 8px; display: block;">Select Academic Year</label>
                        <select name="year" class="form-control-premium" onchange="this.form.submit()" required style="width: 100%;">
                            <?php foreach ($years as $y): ?>
                                <option value="<?php echo $y; ?>" <?php echo $selected_year == $y ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="font-weight: 700; color: #475569; font-size: 0.8rem; margin-bottom: 8px; display: block;">Select Class</label>
                        <select name="class_id" class="form-control-premium" onchange="this.form.submit()" required style="width: 100%;">
                            <option value="">Choose Class...</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class == $c['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo h($c['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label style="font-weight: 700; color: #475569; font-size: 0.8rem; margin-bottom: 8px; display: block;">Select Exam</label>
                        <select name="exam_name" class="form-control-premium" onchange="this.form.submit()" required style="width: 100%;">
                            <option value="">Choose Exam Type...</option>
                            <?php foreach ($grouped_exams as $group_name => $exams_in_group): ?>
                                <?php if (!empty($exams_in_group)): ?>
                                    <optgroup label="<?php echo h($group_name); ?>">
                                        <?php foreach ($exams_in_group as $original_val => $cleaned_label): ?>
                                            <option value="<?php echo h($original_val); ?>" <?php echo $selected_exam_name === $original_val ? 'selected' : ''; ?>>
                                                <?php echo h($cleaned_label); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #edf2f7;">
                        <div style="font-size: 0.75rem; font-weight: 900; color: #64748b; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 0.5px;">Status Check</div>
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <div style="font-size: 0.85rem; display: flex; align-items: center; gap: 10px; color: <?php echo $selected_class ? '#1e293b' : '#94a3b8'; ?>;">
                                <i class="fas <?php echo $selected_class ? 'fa-check-circle' : 'fa-circle-notch'; ?>" style="color: <?php echo $selected_class ? '#2e7d32' : '#cbd5e1'; ?>;"></i>
                                Total Subjects: <b><?php echo $selected_class ? count($subjects) : '-'; ?></b>
                            </div>
                            <div style="font-size: 0.85rem; display: flex; align-items: center; gap: 10px; color: <?php echo !empty($matrix) ? '#1e293b' : '#94a3b8'; ?>;">
                                <i class="fas <?php echo !empty($matrix) ? 'fa-check-circle' : 'fa-circle-notch'; ?>" style="color: <?php echo !empty($matrix) ? '#2e7d32' : '#cbd5e1'; ?>;"></i>
                                Approved Subjects: <b><?php echo !empty($matrix) ? count($subjects) : '-'; ?></b>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- CENTER COLUMN: Matrix & Summary -->
        <div>
            <div class="card-premium">
                <div class="card-header-premium" style="background: #fff; border-bottom: 1px solid #f1f5f9;">
                    <span class="header-title">
                        <i class="fas fa-chart-line"></i> COMPILATION SUMMARY
                    </span>
                    <span style="font-size: 0.7rem; color: #94a3b8; font-weight: 700;">Last Compiled: <?php echo !empty($matrix) ? 'Just Now' : 'Never'; ?></span>
                </div>
                <div class="card-body" style="padding: 25px;">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px;">
                        <div class="stat-mini-card">
                            <div style="font-size: 1.4rem; font-weight: 900; color: #1e293b;"><?php echo $summary_stats['total_students'] ?? '-'; ?></div>
                            <div style="font-size: 0.65rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Total Students</div>
                        </div>
                        <div class="stat-mini-card highlight">
                            <div style="font-size: 1.4rem; font-weight: 900; color: #940000;"><?php echo $summary_stats['pass_rate'] ?? '-'; ?></div>
                            <div style="font-size: 0.65rem; color: #940000; font-weight: 800; text-transform: uppercase;">Pass Rate</div>
                        </div>
                        <div class="stat-mini-card">
                            <div style="font-size: 1.4rem; font-weight: 900; color: #1e293b;"><?php echo $summary_stats['avg_score'] ?? '-'; ?></div>
                            <div style="font-size: 0.65rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Avg. Score</div>
                        </div>
                    </div>

                    <div style="border: 1px solid #f1f5f9; border-radius: 12px; overflow: hidden;">
                        <div style="background: #f8fafc; padding: 12px 20px; border-bottom: 1px solid #f1f5f9; font-size: 0.75rem; font-weight: 900; color: #64748b;">
                            <i class="fas fa-eye"></i> Preview of Compiled Report
                        </div>
                        <?php if (empty($matrix)): ?>
                            <div style="padding: 60px 20px; text-align: center; color: #94a3b8;">
                                <i class="fas fa-table" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.1;"></i>
                                <p style="font-size: 0.9rem; margin: 0; font-weight: 500;">Select a class and exam to see preview</p>
                            </div>
                        <?php else: ?>
                            <div style="overflow-x: auto;">
                                <table class="matrix-table" style="font-size: 0.85rem;">
                                    <thead>
                                        <tr>
                                            <th style="padding-left: 20px; text-align: left;">Rank</th>
                                            <th style="text-align: left;">Student</th>
                                            <?php foreach (array_slice($subjects, 0, 5) as $sub): ?>
                                                <th><?php echo substr($sub['subject_name'], 0, 3); ?>.</th>
                                            <?php endforeach; ?>
                                            <?php if(count($subjects) > 5): ?><th>...</th><?php endif; ?>
                                            <th>Total</th>
                                            <th>AVG</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (array_slice($matrix, 0, 10) as $row): ?>
                                            <tr>
                                                <td style="padding-left: 20px; font-weight: 800; color: #940000;">#<?php echo $row['rank']; ?></td>
                                                <td style="font-weight: 700;"><?php echo h($row['student']['first_name']); ?></td>
                                                <?php foreach (array_slice($subjects, 0, 5) as $sub): 
                                                    $res = $row['marks'][$sub['exam_id']] ?? null;
                                                ?>
                                                    <td style="text-align: center;"><?php echo $res ? round($res['marks_obtained']) : '-'; ?></td>
                                                <?php endforeach; ?>
                                                <?php if(count($subjects) > 5): ?><td>-</td><?php endif; ?>
                                                <td style="text-align: center; font-weight: 800;"><?php echo round($row['total']); ?></td>
                                                <td style="text-align: center; font-weight: 800; color: #940000;"><?php echo round($row['average']); ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php if(count($matrix) > 10): ?>
                                    <div style="padding: 10px; text-align: center; background: #fff5f5; font-size: 0.7rem; font-weight: 700; color: #940000;">
                                        Showing top 10 of <?php echo count($matrix); ?> students. Full table below.
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN: Actions -->
        <div class="no-print">
            <h5 style="color: #940000; font-size: 0.8rem; font-weight: 900; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; padding-left: 5px;">
                <i class="fas fa-bolt"></i> QUICK ACTIONS
            </h5>
            
            <?php 
                $is_ready = ($selected_class && $selected_exam_name && !empty($matrix)); 
                $opacity = $is_ready ? '1' : '0.4';
                $pointer = $is_ready ? 'pointer' : 'not-allowed';
                $href_print = $is_ready ? "print-reports.php?class=$selected_class&exam=".urlencode($selected_exam_name) : "javascript:void(0)";
                $pointer_events = $is_ready ? 'auto' : 'none';
            ?>

            <button type="button" onclick="document.querySelector('.compilation-section form').submit()" class="action-btn primary" style="cursor: pointer; <?php if(!$selected_class || !$selected_exam_name) echo 'opacity: 0.5; pointer-events: none;'; ?>">
                <i class="fas fa-file-invoice" style="font-size: 1.4rem;"></i>
                <div>
                    <div>Compile Report Cards</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Generate final report cards</div>
                </div>
            </button>

            <a href="<?php echo $is_ready ? '#finalize-section' : 'javascript:void(0)'; ?>" class="action-btn" style="opacity: <?php echo $opacity; ?>; cursor: <?php echo $pointer; ?>; pointer-events: <?php echo $pointer_events; ?>;">
                <i class="fas fa-paper-plane" style="color: #940000; font-size: 1.4rem;"></i>
                <div>
                    <div>Publish Results</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Make results visible to students</div>
                </div>
            </a>

            <a href="<?php echo $href_print; ?>" class="action-btn" style="opacity: <?php echo $opacity; ?>; cursor: <?php echo $pointer; ?>; pointer-events: <?php echo $pointer_events; ?>;">
                <i class="fas fa-file-pdf" style="color: #9333ea; font-size: 1.4rem;"></i>
                <div>
                    <div>Download Reports (PDF)</div>
                    <div style="font-size: 0.65rem; opacity: 0.8; font-weight: 400;">Download compiled reports</div>
                </div>
            </a>

            <a href="<?php echo $is_ready ? '#finalize-section' : 'javascript:void(0)'; ?>" class="action-btn" style="background: #fffbeb; border-color: #f59e0b; opacity: <?php echo $opacity; ?>; cursor: <?php echo $pointer; ?>; pointer-events: <?php echo $pointer_events; ?>;">
                <i class="fas fa-sms" style="color: #f59e0b; font-size: 1.4rem;"></i>
                <div>
                    <div style="color: #92400e;">Send SMS Notifications</div>
                    <div style="font-size: 0.65rem; color: #92400e; opacity: 0.8; font-weight: 400;">Notify parents about results</div>
                </div>
            </a>
        </div>
    </div>

    <!-- FULL MATRIX SECTION -->
    <?php if ($selected_class && $selected_exam_name): ?>
        <div id="finalize-section" style="margin-top: 40px;">
            <?php if (empty($subjects)): ?>
                <div class="card-premium" style="text-align: center; padding: 60px; color: var(--secondary-text);">
                    <i class="fas fa-info-circle" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                    <h4>No submitted subject marks found for this exam name.</h4>
                    <p>Ensure teachers have submitted their marks for "<?php echo h($selected_exam_name); ?>".</p>
                </div>
            <?php elseif (!empty($matrix)): ?>
                <div class="card-premium" style="animation: slideUp 0.4s ease-out;">
                    <div class="card-header-premium">
                        <span class="header-title">
                            <i class="fas fa-th-list"></i> Detailed Scorecard Matrix: <?php echo h($selected_exam_name); ?>
                        </span>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <span class="status-pill status-published" style="font-size: 0.7rem; background: #fff5f5; color: #940000; padding: 4px 12px; border-radius: 50px; font-weight: 800;">
                                <i class="fas fa-book"></i> <?php echo count($subjects); ?> Subjects
                            </span>
                            <button onclick="window.print()" class="btn btn-outline no-print" style="padding: 5px 15px; font-size: 0.75rem; font-weight: 800; border-radius: 8px;"><i class="fas fa-print"></i> Print Matrix</button>
                        </div>
                    </div>
                    <div class="card-body" style="padding: 0; overflow-x: auto;">
                        <table class="matrix-table">
                            <thead>
                                <tr>
                                    <th style="min-width: 60px; text-align: center;">Rank</th>
                                    <th style="min-width: 220px; text-align: left; padding-left: 25px;">Student Information</th>
                                    <?php foreach ($subjects as $sub): ?>
                                        <th style="min-width: 80px;" title="<?php echo h($sub['subject_name']); ?>">
                                            <?php echo substr(h($sub['subject_name']), 0, 4); ?>.<br>
                                            <span style="font-size: 0.65rem; opacity: 0.6;">/<?php echo $sub['max_marks']; ?></span>
                                        </th>
                                    <?php endforeach; ?>
                                    <th style="min-width: 80px; background: #fff5f5; color: var(--corporate-red);">Total</th>
                                    <th style="min-width: 80px; background: #fff5f5; color: var(--corporate-red);">AVG %</th>
                                    <th style="min-width: 120px; text-align: center;">Div / Pts</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($matrix as $row): ?>
                                    <tr>
                                        <td style="text-align: center; font-weight: 900; color: <?php echo $row['rank'] <= 3 ? '#940000' : '#64748b'; ?>;">
                                            <?php if($row['rank'] <= 3): ?><i class="fas fa-medal"></i> <?php endif; ?>
                                            #<?php echo $row['rank']; ?>
                                        </td>
                                        <td style="padding-left: 25px;">
                                            <div style="font-weight: 800; color: #1e293b;"><?php echo h($row['student']['first_name'] . ' ' . $row['student']['last_name']); ?></div>
                                            <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 700;"><?php echo h($row['student']['admission_number']); ?></div>
                                        </td>
                                        <?php foreach ($subjects as $sub): 
                                            $eid = $sub['exam_id'];
                                            $res = $row['marks'][$eid] ?? null;
                                        ?>
                                            <td style="text-align: center;">
                                                <?php if ($res): ?>
                                                    <div style="font-weight: 800; color: #1e293b;"><?php echo round($res['marks_obtained']); ?></div>
                                                    <div style="font-size: 0.65rem; font-weight: 900; color: #940000;"><?php echo h($res['grade']); ?></div>
                                                <?php else: ?>
                                                    <span style="color: #cbd5e1; font-weight: 900;">-</span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endforeach; ?>
                                        <td style="text-align: center; font-weight: 900; background: rgba(148,0,0,0.02);"><?php echo round($row['total']); ?></td>
                                        <td style="text-align: center; font-weight: 900; background: rgba(148,0,0,0.02); color: var(--corporate-red);"><?php echo round($row['average'], 1); ?>%</td>
                                        <td style="text-align: center;">
                                            <?php 
                                                $div = $row['division_info']['division'];
                                                $points = $row['division_info']['total_points'];
                                                $badge_bg = ($div == 'I' || $div == 'II' || $div == 'III') ? '#940000' : '#64748b';
                                                if ($div == 'N/A') $badge_bg = '#f1f5f9';
                                                $badge_color = ($div == 'N/A') ? '#64748b' : 'white';
                                            ?>
                                            <span style="background: <?php echo $badge_bg; ?>; color: <?php echo $badge_color; ?>; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 900; display: inline-block;">
                                                <?php echo $div == 'N/A' ? 'N/A' : ($div == '0' ? '0' : $div . ' - ' . $points); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if ($has_pending): ?>
                    <div class="card-footer" style="background: #ffffff; padding: 30px; border-top: 1px solid #f1f5f9;">
                        <form action="" method="POST" style="background: #f8fafc; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);">
                            <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                            <input type="hidden" name="exam_name" value="<?php echo h($selected_exam_name); ?>">
                            <input type="hidden" name="selected_year" value="<?php echo h($selected_year); ?>">
                            
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px;">
                                <div style="color: var(--corporate-red); font-size: 1.2rem;"><i class="fas fa-bullhorn"></i></div>
                                <h4 style="margin: 0; color: #1e293b; font-weight: 800;">Finalize & Publish Report Cards</h4>
                            </div>
                            
                            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 25px; line-height: 1.5;">
                                This action will aggregate all individual subject marks into final report cards and make them available to students and parents on their respective dashboards.
                            </p>
                            
                            <label style="display: flex; align-items: center; gap: 12px; margin-bottom: 25px; cursor: pointer; background: white; padding: 15px; border-radius: 10px; border: 1px solid #edf2f7;">
                                <input type="checkbox" name="notify_parents" checked style="width: 20px; height: 20px; accent-color: var(--corporate-red); cursor: pointer;">
                                <span style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">Notify parents immediately via summary SMS (Avg % & Grade)</span>
                            </label>
                            
                            <button type="submit" name="publish_reports" class="btn btn-primary" style="padding: 16px 30px; font-size: 1rem; width: 100%; font-weight: 800; border-radius: 12px; box-shadow: 0 10px 20px rgba(148,0,0,0.15); display: flex; align-items: center; justify-content: center; gap: 10px;">
                                <i class="fas fa-paper-plane"></i> PUBLISH ALL REPORT CARDS
                            </button>
                            
                            <div style="text-align: center; margin-top: 15px; font-size: 0.75rem; color: #940000; font-weight: 700;">
                                <i class="fas fa-exclamation-triangle"></i> This action is permanent and will trigger notifications.
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="card-footer" style="padding: 40px; text-align: center; background: #fff5f5; border-top: 1px solid #fecaca; border-radius: 0 0 16px 16px;">
                        <div style="font-size: 3rem; color: #940000; margin-bottom: 15px;"><i class="fas fa-check-circle"></i></div>
                        <h3 style="color: #940000; font-weight: 900; margin-bottom: 10px;">Already Published</h3>
                        <p style="color: #c53030; font-weight: 600; margin-bottom: 25px;">The report cards for this assessment have already been finalized and published.</p>
                        
                        <div style="display: flex; justify-content: center; gap: 15px; flex-wrap: wrap;">
                            <a href="print-reports.php?class=<?php echo $selected_class; ?>&exam=<?php echo urlencode($selected_exam_name); ?>" class="btn btn-outline" style="padding: 12px 30px; border-radius: 50px; border-color: #940000; color: #940000; font-weight: 800;">
                                <i class="fas fa-print"></i> MANAGE / PRINT REPORTS
                            </a>
                            
                            <form action="" method="POST" style="display: inline-block;">
                                <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                                <input type="hidden" name="exam_name" value="<?php echo h($selected_exam_name); ?>">
                                <input type="hidden" name="selected_year" value="<?php echo h($selected_year); ?>">
                                <input type="hidden" name="notify_parents" value="1">
                                <button type="submit" name="publish_reports" class="btn" style="padding: 12px 30px; border-radius: 50px; background: #f59e0b; color: white; border: none; font-weight: 800; cursor: pointer; box-shadow: 0 4px 10px rgba(245, 158, 11, 0.2);">
                                    <i class="fas fa-sms"></i> RESEND SMS NOTIFICATIONS
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../../includes/footer.php'; ?>
