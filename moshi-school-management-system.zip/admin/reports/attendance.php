<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Attendance Reports";

// Fetch all classes
$stmt = $pdo->query("SELECT * FROM classes ORDER BY class_name ASC");
$classes = $stmt->fetchAll();

$selected_class = $_GET['class_id'] ?? null;
$report_date = $_GET['date'] ?? date('Y-m-d');

$report_data = [];
if ($selected_class) {
    $stmt = $pdo->prepare("
        SELECT s.first_name, s.last_name, s.admission_number,
        (SELECT COUNT(*) FROM attendance WHERE student_id = s.student_id AND attendance_date = ? AND status = 'present') as present_periods,
        (SELECT COUNT(*) FROM attendance WHERE student_id = s.student_id AND attendance_date = ? AND status = 'absent') as absent_periods
        FROM students s
        WHERE s.class_id = ?
        ORDER BY s.first_name ASC
    ");
    $stmt->execute([$report_date, $report_date, $selected_class]);
    $report_data = $stmt->fetchAll();
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="max-width: 1000px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-chart-line"></i> Daily Attendance Summary</h2>
        </header>

        <div class="card" style="margin-bottom: 30px;">
            <div class="card-body">
                <form action="" method="GET" style="display: flex; gap: 20px; align-items: flex-end;">
                    <div class="form-group" style="margin: 0;">
                        <label>Select Class</label>
                        <select name="class_id" class="form-control" required>
                            <option value="">-- Choose Class --</option>
                            <?php foreach ($classes as $c): ?><option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class == $c['class_id'] ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin: 0;">
                        <label>Date</label>
                        <input type="date" name="date" class="form-control" value="<?php echo $report_date; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">GENERATE REPORT</button>
                </form>
            </div>
        </div>

        <?php if ($selected_class): ?>
            <div class="card fade-in">
                <div class="card-header">Attendance for <?php echo date('d M Y', strtotime($report_date)); ?></div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Admission No</th>
                                <th>Student Name</th>
                                <th>Present Periods</th>
                                <th>Absent Periods</th>
                                <th>Daily Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($report_data as $r): 
                                $total = $r['present_periods'] + $r['absent_periods'];
                                $perc = $total > 0 ? ($r['present_periods'] / $total) * 100 : 0;
                            ?>
                                <tr>
                                    <td><?php echo $r['admission_number']; ?></td>
                                    <td style="font-weight: 700;"><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></td>
                                    <td style="color: #2ecc71; font-weight: 700;"><?php echo $r['present_periods']; ?></td>
                                    <td style="color: var(--corporate-red); font-weight: 700;"><?php echo $r['absent_periods']; ?></td>
                                    <td>
                                        <?php if ($perc >= 100): ?>
                                            <span style="background: #e8f5e9; color: #2e7d32; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem;">FULL ATTENDANCE</span>
                                        <?php elseif ($perc > 0): ?>
                                            <span style="background: #fff8e1; color: #f57f17; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem;">PARTIAL</span>
                                        <?php else: ?>
                                            <span style="background: #ffebee; color: #c62828; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem;">ABSENT</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div style="margin-top: 20px; text-align: right;">
                        <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Export PDF</button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
