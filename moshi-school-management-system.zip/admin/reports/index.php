<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Reports & Analytics Hub";
require_once '../../includes/header.php';
?>

<div class="fade-in">
    <div class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <h2 style="margin: 0;"><i class="fas fa-chart-line"></i> Reports & Analytics</h2>
        <p style="color: var(--secondary-text); margin-top: 5px;">Select a report category to view detailed analytics and export data.</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 20px;">
        <!-- Performance Reports -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid var(--corporate-red);">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="font-size: 3rem; color: var(--corporate-red); margin-bottom: 20px;">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h3>Academic Performance</h3>
                <p style="color: var(--secondary-text); margin-bottom: 30px;">Analyze student grades, class averages, and subject performance metrics over time.</p>
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <a href="performance.php" class="btn btn-primary">View Report</a>
                </div>
            </div>
        </div>

        <!-- Attendance Reports -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid #2ecc71;">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="font-size: 3rem; color: #2ecc71; margin-bottom: 20px;">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3>Attendance Tracker</h3>
                <p style="color: var(--secondary-text); margin-bottom: 30px;">Monitor student and teacher attendance rates, identify chronic absenteeism, and view weekly trends.</p>
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <a href="attendance.php" class="btn btn-primary" style="background: #2ecc71; border-color: #2ecc71;">View Report</a>
                </div>
            </div>
        </div>

        <!-- System Activity Reports -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid #3498db;">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="font-size: 3rem; color: #3498db; margin-bottom: 20px;">
                    <i class="fas fa-history"></i>
                </div>
                <h3>System Activity Logs</h3>
                <p style="color: var(--secondary-text); margin-bottom: 30px;">Review user logins, system interactions, configuration changes, and complete audit trails.</p>
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <a href="activity.php" class="btn btn-primary" style="background: #3498db; border-color: #3498db;">View Report</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
