<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Academic Performance Analytics";

// Fetch Grade Distribution
$grade_stats = [];
try {
    $stmt = $pdo->query("SELECT grade, COUNT(*) as count FROM results GROUP BY grade ORDER BY grade ASC");
    $grade_stats = $stmt->fetchAll();
} catch (PDOException $e) {
    //
}

// Fetch Performance per Class
$class_perf = [];
try {
    $stmt = $pdo->query("
        SELECT c.class_name, AVG(r.marks_obtained) as avg_marks, COUNT(DISTINCT r.student_id) as student_count
        FROM results r
        JOIN classes c ON r.class_id = c.class_id
        GROUP BY c.class_id
        ORDER BY avg_marks DESC
    ");
    $class_perf = $stmt->fetchAll();
} catch (PDOException $e) {
    //
}

// Fetch Top Students
$top_students = [];
try {
    $stmt = $pdo->query("
        SELECT s.first_name, s.last_name, c.class_name, AVG(r.marks_obtained) as avg_marks
        FROM results r
        JOIN students s ON r.student_id = s.student_id
        JOIN classes c ON s.class_id = c.class_id
        GROUP BY s.student_id
        ORDER BY avg_marks DESC
        LIMIT 10
    ");
    $top_students = $stmt->fetchAll();
} catch (PDOException $e) {
    //
}
?>
<?php
require_once '../../includes/header.php';
?>

<style>
    .chart-container { background: white; border-radius: 12px; padding: 25px; margin-bottom: 30px; box-shadow: var(--shadow-soft); }
    .bar { height: 25px; background: var(--corporate-red); border-radius: 4px; color: white; padding: 0 10px; font-size: 0.8rem; display: flex; align-items: center; margin-bottom: 10px; }
</style>

<div class="main-content-inner">
    <div style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="margin: 0;"><i class="fas fa-chart-bar"></i> Performance Analytics</h2>
            <div style="font-weight: 700; color: var(--secondary-text);"><?php echo date('F Y'); ?> Overview</div>
        </header>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
            <!-- Grade Distribution -->
            <div class="chart-container">
                <h4 style="margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 15px;">Overall Grade Distribution</h4>
                <?php if (empty($grade_stats)): ?>
                    <p style="color: var(--secondary-text); text-align: center;">No exam data available.</p>
                <?php else: ?>
                    <?php 
                    $max_count = max(array_column($grade_stats, 'count'));
                    foreach ($grade_stats as $stat): 
                        $width = ($stat['count'] / $max_count) * 100;
                    ?>
                        <div style="margin-bottom: 15px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-weight: 700;">
                                <span>Grade <?php echo $stat['grade']; ?></span>
                                <span><?php echo $stat['count']; ?> Students</span>
                            </div>
                            <div style="background: #eee; border-radius: 10px; overflow: hidden;">
                                <div class="bar" style="width: <?php echo $width; ?>%; transition: width 1s;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Class Comparison -->
            <div class="chart-container">
                <h4 style="margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 15px;">Top Performing Classes (Average %)</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Class</th>
                            <th>Avg Score</th>
                            <th>Students</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rank = 1; foreach ($class_perf as $c): ?>
                            <tr>
                                <td style="font-weight: 900; color: var(--corporate-red);">#<?php echo $rank++; ?></td>
                                <td style="font-weight: 700;"><?php echo h($c['class_name']); ?></td>
                                <td><?php echo round($c['avg_marks'], 1); ?>%</td>
                                <td><?php echo $c['student_count']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($class_perf)): ?>
                            <tr><td colspan="4" style="text-align: center;">No class data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Top Students -->
            <div class="chart-container" style="grid-column: span 2;">
                <h4 style="margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 15px;">Academic Excellence: Top 10 Students</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <?php foreach ($top_students as $idx => $s): ?>
                        <div style="background: #fdfdfd; border: 1px solid #eee; border-radius: 10px; padding: 20px; position: relative;">
                            <div style="position: absolute; top: -10px; right: -10px; background: var(--corporate-red); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 0.8rem;"><?php echo $idx + 1; ?></div>
                            <h5 style="margin: 0;"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?></h5>
                            <div style="font-size: 0.75rem; color: var(--secondary-text); margin-top: 5px;"><?php echo h($s['class_name']); ?></div>
                            <div style="margin-top: 15px; font-weight: 900; color: var(--corporate-red); font-size: 1.2rem;"><?php echo round($s['avg_marks'], 1); ?>%</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 30px; text-align: center;">
            <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Generate Full Report</button>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
