<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Teacher Activity Logs";

// Fetch System Logs
try {
    $stmt = $pdo->query("
        SELECT l.*, u.username, u.role
        FROM activity_logs l
        JOIN users u ON l.user_id = u.user_id
        WHERE u.role = 'teacher'
        ORDER BY l.created_at DESC
        LIMIT 50
    ");
    $logs = $stmt->fetchAll();
} catch (PDOException $e) {
    $logs = [];
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="max-width: 1000px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-history"></i> Teacher Activity Audit Trail</h2>
            <p style="color: var(--secondary-text);">Monitor input actions, attendance marking, and results entry.</p>
        </header>

        <div class="card">
            <div class="card-body" style="padding: 0;">
                <table class="table">
                    <thead style="background: #f8f9fa;">
                        <tr>
                            <th>Date & Time</th>
                            <th>Teacher</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr><td colspan="5" style="text-align: center; padding: 40px; color: var(--secondary-text);">No activity recorded yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo date('d/m/Y H:i', strtotime($log['created_at'])); ?></td>
                                    <td style="font-weight: 700; color: var(--corporate-red);"><?php echo h($log['username']); ?></td>
                                    <td><span class="badge" style="background: #eee; color: #555;"><?php echo strtoupper($log['action']); ?></span></td>
                                    <td style="font-size: 0.85rem;"><?php echo h($log['description']); ?></td>
                                    <td style="font-family: monospace; font-size: 0.8rem;"><?php echo $log['ip_address']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
