<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Backup & Recovery";

$success_msg = '';
$error_msg = '';

// Backup directory inside project
$backup_dir = BASE_PATH . '/admin/backups/';
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}

// Handle backup creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    requireCSRF();
    
    if ($_POST['action'] === 'create_backup') {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "backup_moshi_sms_{$timestamp}.sql";
        $filepath = $backup_dir . $filename;
        
        try {
            // Get all tables
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            $sql_dump = "-- ShuleXpert Database Backup\n";
            $sql_dump .= "-- Generated: " . date('Y-m-d H:i:s') . " by admin\n";
            $sql_dump .= "-- Database: " . DB_NAME . "\n\n";
            $sql_dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
            
            foreach ($tables as $table) {
                // Table structure
                $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
                $createKey = array_key_exists('Create Table', $create) ? 'Create Table' : 'Create View';
                $sql_dump .= "\n-- Table: $table\n";
                $sql_dump .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql_dump .= $create[$createKey] . ";\n\n";
                
                // Table data
                $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($rows)) {
                    $cols = array_keys($rows[0]);
                    $col_list = implode('`, `', $cols);
                    $sql_dump .= "INSERT INTO `$table` (`$col_list`) VALUES\n";
                    $row_sqls = [];
                    foreach ($rows as $row) {
                        $values = array_map(function($val) use ($pdo) {
                            return $val === null ? 'NULL' : $pdo->quote($val);
                        }, array_values($row));
                        $row_sqls[] = "(" . implode(', ', $values) . ")";
                    }
                    $sql_dump .= implode(",\n", $row_sqls) . ";\n\n";
                }
            }
            
            $sql_dump .= "SET FOREIGN_KEY_CHECKS=1;\n";
            
            if (file_put_contents($filepath, $sql_dump)) {
                $success_msg = "Backup created successfully: <strong>$filename</strong> (" . number_format(filesize($filepath)/1024, 1) . " KB)";
            } else {
                $error_msg = "Failed to write backup file. Check folder permissions.";
            }
        } catch(Exception $e) {
            $error_msg = "Backup failed: " . $e->getMessage();
        }
    }
    
    if ($_POST['action'] === 'delete_backup') {
        $del_file = basename($_POST['filename'] ?? '');
        $del_path = $backup_dir . $del_file;
        if ($del_file && file_exists($del_path) && str_starts_with($del_file, 'backup_')) {
            unlink($del_path);
            $success_msg = "Backup deleted: $del_file";
        }
    }
}

// Handle download
if (isset($_GET['download'])) {
    $dl_file = basename($_GET['download']);
    $dl_path = $backup_dir . $dl_file;
    if (file_exists($dl_path) && str_starts_with($dl_file, 'backup_')) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $dl_file . '"');
        header('Content-Length: ' . filesize($dl_path));
        readfile($dl_path);
        exit;
    }
}

// List existing backups
$backups = [];
if (is_dir($backup_dir)) {
    $files = glob($backup_dir . 'backup_*.sql');
    foreach ($files as $f) {
        $backups[] = [
            'name'     => basename($f),
            'size'     => filesize($f),
            'mtime'    => filemtime($f),
            'path'     => $f
        ];
    }
    usort($backups, fn($a, $b) => $b['mtime'] - $a['mtime']);
}

// Get DB stats
$db_stats = [];
try {
    $db_stats['tables'] = $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = '" . DB_NAME . "'")->fetchColumn();
    $db_stats['size_mb'] = $pdo->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) FROM information_schema.TABLES WHERE TABLE_SCHEMA = '" . DB_NAME . "'")->fetchColumn();
    $db_stats['users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $db_stats['students'] = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
} catch(PDOException $e) {}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-database" style="color:#8b0000;"></i> Backup & Recovery
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">Protect your data - create and download database backups</p>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <input type="hidden" name="action" value="create_backup">
            <button type="submit" class="btn btn-primary" style="background:#8b0000; border-color:#8b0000; display:flex; align-items:center; gap:8px; padding:12px 25px; font-size:1rem;">
                <i class="fas fa-download"></i> Create New Backup Now
            </button>
        </form>
    </div>

    <?php if ($success_msg): ?>
        <div style="background:#d4edda; color:#155724; padding:12px 20px; border-radius:8px; border:1px solid #c3e6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-check-circle"></i> <?php echo $success_msg; ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background:#f8d7da; color:#721c24; padding:12px 20px; border-radius:8px; border:1px solid #f5c6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-exclamation-triangle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns:1fr 2fr; gap:25px;">
        <!-- Database Info -->
        <div style="display:flex; flex-direction:column; gap:20px;">
            <!-- DB Stats -->
            <div class="card" style="border-top:4px solid #8b0000;">
                <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #eee;">
                    <i class="fas fa-info-circle"></i> Database Information
                </div>
                <div class="card-body" style="display:flex; flex-direction:column; gap:12px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px dashed #eee; padding-bottom:10px;">
                        <span style="font-size:0.85rem; color:#7F8C8D; font-weight:700;">Database Name</span>
                        <span style="font-weight:700; color:#2C3E50; font-family:monospace;"><?php echo DB_NAME; ?></span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px dashed #eee; padding-bottom:10px;">
                        <span style="font-size:0.85rem; color:#7F8C8D; font-weight:700;">Total Tables</span>
                        <span style="font-weight:900; color:#8b0000; font-size:1.1rem;"><?php echo $db_stats['tables'] ?? '-'; ?></span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px dashed #eee; padding-bottom:10px;">
                        <span style="font-size:0.85rem; color:#7F8C8D; font-weight:700;">Database Size</span>
                        <span style="font-weight:900; color:#8b0000; font-size:1.1rem;"><?php echo ($db_stats['size_mb'] ?? 0); ?> MB</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px dashed #eee; padding-bottom:10px;">
                        <span style="font-size:0.85rem; color:#7F8C8D; font-weight:700;">Total Users</span>
                        <span style="font-weight:900; color:#2C3E50;"><?php echo $db_stats['users'] ?? '-'; ?></span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.85rem; color:#7F8C8D; font-weight:700;">Total Students</span>
                        <span style="font-weight:900; color:#2C3E50;"><?php echo $db_stats['students'] ?? '-'; ?></span>
                    </div>
                </div>
            </div>

            <!-- Important Notice -->
            <div class="card" style="background:#FFF5F5; border:1px solid #8b0000; padding:0;">
                <div class="card-body" style="padding:20px;">
                    <div style="display:flex; gap:12px; align-items:flex-start; margin-bottom:15px;">
                        <i class="fas fa-exclamation-circle" style="color:#8b0000; font-size:1.3rem; margin-top:2px;"></i>
                        <div>
                            <div style="font-weight:900; color:#8b0000; margin-bottom:5px;">Backup Guidelines</div>
                            <ul style="margin:0; padding-left:20px; font-size:0.82rem; color:#555; line-height:2;">
                                <li>Backup <strong>daily</strong> during school term</li>
                                <li>Download and store backups <strong>offline</strong></li>
                                <li>Keep <strong>at least 7 days</strong> of history</li>
                                <li>Test restoration <strong>monthly</strong></li>
                                <li>Backup <strong>before any major changes</strong></li>
                            </ul>
                        </div>
                    </div>
                    <div style="background:white; padding:12px; border-radius:8px; border:1px dashed #8b0000; font-size:0.78rem; color:#8b0000; font-weight:700; text-align:center;">
                        <i class="fas fa-server"></i> Backups stored at: <code>/admin/backups/</code>
                    </div>
                </div>
            </div>
        </div>

        <!-- Backup History -->
        <div class="card">
            <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
                <span><i class="fas fa-history"></i> Backup History (<?php echo count($backups); ?> files)</span>
            </div>
            <?php if (empty($backups)): ?>
                <div class="card-body" style="text-align:center; padding:60px; color:#7F8C8D;">
                    <i class="fas fa-database" style="font-size:3rem; opacity:0.15; display:block; margin-bottom:15px;"></i>
                    <p style="margin:0; font-size:0.9rem;">No backups yet. Click "Create New Backup Now" above.</p>
                </div>
            <?php else: ?>
            <div class="card-body" style="padding:0;">
                <table style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                    <thead>
                        <tr style="background:#f8f9fa;">
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Backup File</th>
                            <th style="padding:12px 15px; text-align:right; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Size</th>
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Created</th>
                            <th style="padding:12px 15px; text-align:center; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($backups as $i => $bk): ?>
                        <tr style="border-bottom:1px solid #f0f0f0; background:<?php echo $i===0?'#f0fff4':'white'; ?>;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='<?php echo $i===0?'#f0fff4':'white'; ?>'">
                            <td style="padding:12px 15px;">
                                <div style="display:flex; align-items:center; gap:10px;">
                                    <i class="fas fa-file-archive" style="color:#8b0000; font-size:1.2rem;"></i>
                                    <div>
                                        <div style="font-weight:700; color:#2C3E50; font-size:0.82rem;"><?php echo h($bk['name']); ?></div>
                                        <?php if ($i === 0): ?>
                                            <span style="background:#d4edda; color:#155724; font-size:0.68rem; padding:1px 7px; border-radius:10px; font-weight:700;">LATEST</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td style="padding:12px 15px; text-align:right; font-weight:700; color:#2C3E50; font-size:0.82rem;">
                                <?php echo number_format($bk['size'] / 1024, 1); ?> KB
                            </td>
                            <td style="padding:12px 15px; font-size:0.8rem; color:#7F8C8D;">
                                <?php echo date('d M Y H:i', $bk['mtime']); ?>
                            </td>
                            <td style="padding:12px 15px; text-align:center;">
                                <div style="display:flex; gap:8px; justify-content:center;">
                                    <a href="?download=<?php echo urlencode($bk['name']); ?>" style="background:#27ae60; color:white; padding:5px 12px; border-radius:5px; font-size:0.78rem; font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:5px;">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this backup permanently?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <input type="hidden" name="action" value="delete_backup">
                                        <input type="hidden" name="filename" value="<?php echo h($bk['name']); ?>">
                                        <button type="submit" style="background:#e74c3c; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.78rem; font-weight:700;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
