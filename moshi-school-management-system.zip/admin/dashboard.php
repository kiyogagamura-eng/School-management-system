<?php
require_once '../includes/bootstrap.php';
requireRole('admin');

$username = $_SESSION['username'] ?? 'Admin';
$page_title = "Admin Dashboard";

$stats = [
    'total_students' => 0,
    'total_teachers' => 0,
    'total_classes' => 0,
    'total_parents' => 0,
    'parents_with_sms' => 0,
    'parents_unverified' => 0,
    'sms_sent_today' => 0,
    'active_users' => 0,
    'sms_balance' => '0 TZS',
    'sms_remaining' => 0
];

try {
    $stats['total_students'] = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $stats['total_teachers'] = $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
    $stats['total_classes'] = $pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
    $stats['total_parents'] = $pdo->query("SELECT COUNT(*) FROM parents")->fetchColumn();
    
    // Parents SMS
    $stats['parents_with_sms'] = $pdo->query("SELECT COUNT(*) FROM parents WHERE parent_phone IS NOT NULL AND parent_phone != ''")->fetchColumn();
    $stats['parents_unverified'] = max(0, $stats['total_parents'] - $stats['parents_with_sms']);
    
    // SMS Sent Today
    $stats['sms_sent_today'] = $pdo->query("SELECT COUNT(*) FROM communications WHERE comm_type = 'sms' AND DATE(sent_date) = CURDATE()")->fetchColumn();
    
    // Active Users (Logged in last 24 hours)
    $stats['active_users'] = $pdo->query("SELECT COUNT(*) FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchColumn();
} catch (PDOException $e) {
    // Fail silently
}

// Fetch SMS Balance (from NextSMS)
try {
    $url = 'https://messaging-service.co.tz/api/sms/v1/balance';
    $credentials = base64_encode(NEXTSMS_USERNAME . ':' . NEXTSMS_PASSWORD);
        
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPGET        => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Basic ' . $credentials,
            'Accept: application/json'
        ],
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
    ]);
    $api_response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($api_response, true);
        if (isset($data['sms_balance'])) {
            $stats['sms_remaining'] = $data['sms_balance'];
            $stats['sms_balance'] = ($data['sms_balance'] * 16) . ' TZS';
        } elseif (isset($data['balance'])) {
            $stats['sms_remaining'] = $data['balance'];
            $stats['sms_balance'] = ($data['balance'] * 16) . ' TZS';
        }
    }
} catch (Exception $e) {}

// Fetch login/logout activities
$recent_activities = [];
try {
    $recent_activities = $pdo->query("
        SELECT al.*, u.username 
        FROM activity_logs al 
        LEFT JOIN users u ON u.user_id = al.user_id 
        WHERE al.action IN ('login', 'logout', 'failed_login', 'auth_fail', 'lock_account', 'unlock_account', 'unlock', 'lock') 
        ORDER BY al.created_at DESC 
        LIMIT 6
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}

require_once '../includes/header.php';
?>

<div class="main-content-inner" style="background:#FAFBFD; min-height:85vh; padding:20px;">
    <!-- Welcome Header Card (Clean Light Style with soft accents) -->
    <div style="background:#FFFFFF; color:#2C3E50; border-radius:12px; padding:30px; margin-bottom:30px; box-shadow:0 4px 20px rgba(0,0,0,0.05); border:1px solid #E2E6ED; border-left:6px solid #8b0000; position:relative; overflow:hidden;">
        <div style="position:absolute; right:-20px; top:-20px; font-size:9rem; opacity:0.02; color:#8b0000;">
            <i class="fas fa-shield-alt"></i>
        </div>
        <div style="position:relative; z-index:1;">
            <h1 style="margin:0; font-size:2rem; font-weight:800; color:#2C3E50;">WELCOME, <span style="color:#8b0000;"><?php echo strtoupper(h($username)); ?></span></h1>
            <p style="margin:8px 0 0; font-size:0.95rem; color:#7F8C8D; font-weight:600;">System Administrator &bull; Government Management Portal</p>
            <div style="display:inline-block; background:#FFF5F5; border:1px solid rgba(139,0,0,0.15); padding:6px 12px; border-radius:4px; font-size:0.8rem; margin-top:15px; font-weight:700; color:#8b0000;">
                <i class="fas fa-calendar-day" style="margin-right:5px;"></i> Today: <?php echo date('d M Y - H:i'); ?>
            </div>
        </div>
    </div>

    <!-- Quick Stats Grid (Clean Corporate Color Palette) -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:20px; margin-bottom:30px;">
        <!-- Students -->
        <div class="card shadow-premium" style="border-radius:12px; border:none; border-top:4px solid #8b0000; background:#FFF; padding:20px; display:flex; align-items:center; gap:20px;">
            <div style="background:#FFF5F5; width:55px; height:55px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.6rem; color:#8b0000; border:2px solid #8b0000;">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div>
                <div style="font-size:0.78rem; color:#7F8C8D; font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">Students</div>
                <div style="font-size:2rem; font-weight:900; color:#2C3E50; line-height:1.1; margin-top:3px;"><?php echo number_format($stats['total_students']); ?></div>
            </div>
        </div>

        <!-- Teachers -->
        <div class="card shadow-premium" style="border-radius:12px; border:none; border-top:4px solid #8b0000; background:#FFF; padding:20px; display:flex; align-items:center; gap:20px;">
            <div style="background:#FFF5F5; width:55px; height:55px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.6rem; color:#8b0000; border:2px solid #8b0000;">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div>
                <div style="font-size:0.78rem; color:#7F8C8D; font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">Teachers</div>
                <div style="font-size:2rem; font-weight:900; color:#2C3E50; line-height:1.1; margin-top:3px;"><?php echo number_format($stats['total_teachers']); ?></div>
            </div>
        </div>

        <!-- Families -->
        <div class="card shadow-premium" style="border-radius:12px; border:none; border-top:4px solid #8b0000; background:#FFF; padding:20px; display:flex; align-items:center; gap:20px;">
            <div style="background:#FFF5F5; width:55px; height:55px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.6rem; color:#8b0000; border:2px solid #8b0000;">
                <i class="fas fa-users"></i>
            </div>
            <div>
                <div style="font-size:0.78rem; color:#7F8C8D; font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">Parents</div>
                <div style="font-size:2rem; font-weight:900; color:#2C3E50; line-height:1.1; margin-top:3px;"><?php echo number_format($stats['total_parents']); ?></div>
            </div>
        </div>

        <!-- System Users Active -->
        <div class="card shadow-premium" style="border-radius:12px; border:none; border-top:4px solid #8b0000; background:#FFF; padding:20px; display:flex; align-items:center; gap:20px;">
            <div style="background:#FFF5F5; width:55px; height:55px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.6rem; color:#8b0000; border:2px solid #8b0000;">
                <i class="fas fa-network-wired"></i>
            </div>
            <div>
                <div style="font-size:0.78rem; color:#7F8C8D; font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">Active Users</div>
                <div style="font-size:2rem; font-weight:900; color:#2C3E50; line-height:1.1; margin-top:3px;"><?php echo number_format($stats['active_users']); ?></div>
            </div>
        </div>
    </div>

    <!-- Main Workspace Grid -->
    <div style="display:grid; grid-template-columns:3fr 2fr; gap:25px;">
        
        <!-- LEFT: Recent Logins/Logouts & Activities -->
        <div style="display:flex; flex-direction:column; gap:25px;">
            <div class="card shadow-premium" style="border-radius:12px; overflow:hidden; border:none;">
                <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #F3D9D9; display:flex; justify-content:space-between; align-items:center; padding:15px 20px;">
                    <span style="font-weight:800; font-size:1rem; display:flex; align-items:center; gap:10px;">
                        <i class="fas fa-user-clock" style="color:#8b0000;"></i> Login & Logout Activities
                    </span>
                    <a href="security/logs.php" style="font-size:0.8rem; font-weight:700; color:#8b0000; text-decoration:none;">View Full Security Logs &rarr;</a>
                </div>
                <div class="card-body" style="padding:10px 20px;">
                    <?php if (empty($recent_activities)): ?>
                        <div style="text-align:center; padding:40px; color:#7F8C8D;">
                            <i class="fas fa-shield-alt" style="font-size:2.5rem; opacity:0.1; display:block; margin-bottom:10px;"></i>
                            No records available at this time.
                        </div>
                    <?php else: ?>
                        <ul style="list-style:none; padding:0; margin:0;">
                            <?php foreach ($recent_activities as $act): 
                                $isLogout = ($act['action'] === 'logout');
                                $isFail = in_array($act['action'], ['failed_login', 'auth_fail', 'lock_account']);
                                $icon = '<i class="fas fa-sign-in-alt"></i>';
                                $bg = '#FFF5F5';
                                $color = '#8b0000';
                                $title = 'User Login';
                                
                                if ($isLogout) {
                                    $icon = '<i class="fas fa-sign-out-alt"></i>';
                                    $title = 'User Logout';
                                } elseif ($isFail) {
                                    $icon = '<i class="fas fa-exclamation-triangle"></i>';
                                    $title = 'Failed Attempt';
                                }
                            ?>
                            <li style="padding:12px 0; border-bottom:1px solid #f5f5f5; display:flex; align-items:center; gap:15px; justify-content:space-between;">
                                <div style="display:flex; align-items:center; gap:15px;">
                                    <div style="background:<?php echo $bg; ?>; color:<?php echo $color; ?>; width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1rem; border:1px solid rgba(139,0,0,0.1);">
                                        <?php echo $icon; ?>
                                    </div>
                                    <div>
                                        <div style="font-weight:700; color:#2C3E50; font-size:0.85rem;"><?php echo h($act['username'] ?: 'System'); ?> - <span style="font-weight:500; font-size:0.78rem; color:#7F8C8D;"><?php echo $title; ?></span></div>
                                        <div style="font-size:0.75rem; color:#7F8C8D; margin-top:2px;">IP: <?php echo h($act['ip_address']); ?> &bull; <?php echo h($act['description']); ?></div>
                                    </div>
                                </div>
                                <div style="text-align:right; font-size:0.72rem; color:#7F8C8D; font-weight:700;">
                                    <span><?php echo date('H:i', strtotime($act['created_at'])); ?></span><br>
                                    <span style="font-weight:500; color:#BDC3C7;"><?php echo date('d M', strtotime($act['created_at'])); ?></span>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Access Admin Navigation -->
            <div class="card shadow-premium" style="border-radius:12px; border:none; padding:20px;">
                <h4 style="color:#2C3E50; font-weight:800; font-size:0.9rem; margin:0 0 15px; text-transform:uppercase; letter-spacing:0.5px;"><i class="fas fa-network-wired" style="color:#8b0000;"></i> Administrator Tools</h4>
                <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px;">
                    <a href="users/index.php" style="display:flex; align-items:center; gap:12px; padding:15px; background:#FAFBFD; border:1px solid #E2E6ED; border-radius:6px; text-decoration:none; color:#2C3E50; font-weight:700; font-size:0.85rem; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#E2E6ED'">
                        <i class="fas fa-users-cog" style="color:#8b0000; font-size:1.2rem;"></i> User Management
                    </a>
                    <a href="roles/index.php" style="display:flex; align-items:center; gap:12px; padding:15px; background:#FAFBFD; border:1px solid #E2E6ED; border-radius:6px; text-decoration:none; color:#2C3E50; font-weight:700; font-size:0.85rem; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#E2E6ED'">
                        <i class="fas fa-user-shield" style="color:#8b0000; font-size:1.2rem;"></i> Roles & Permissions
                    </a>
                    <a href="security/index.php" style="display:flex; align-items:center; gap:12px; padding:15px; background:#FAFBFD; border:1px solid #E2E6ED; border-radius:6px; text-decoration:none; color:#2C3E50; font-weight:700; font-size:0.85rem; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#E2E6ED'">
                        <i class="fas fa-shield-alt" style="color:#8b0000; font-size:1.2rem;"></i> Security & Locked Users
                    </a>
                    <a href="settings/general.php" style="display:flex; align-items:center; gap:12px; padding:15px; background:#FAFBFD; border:1px solid #E2E6ED; border-radius:6px; text-decoration:none; color:#2C3E50; font-weight:700; font-size:0.85rem; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#E2E6ED'">
                        <i class="fas fa-cogs" style="color:#8b0000; font-size:1.2rem;"></i> System Settings
                    </a>
                </div>
            </div>
        </div>

        <!-- RIGHT: Backup Status & Health -->
        <div style="display:flex; flex-direction:column; gap:25px;">
            <!-- Live Backup Widget -->
            <div class="card shadow-premium" style="background:#FFF; border:none; border-radius:12px; display:flex; flex-direction:column; gap:10px;">
                <div class="card-header" style="background:#FFF5F5; border-bottom:1px solid #FDF0C8; color:#8b0000; font-weight:900; padding:15px 20px;"><i class="fas fa-server"></i> System Health & Auto Backups</div>
                <div class="card-body" style="padding:20px;">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:15px;">
                        <span style="display:inline-block; width:10px; height:10px; background:#8b0000; border-radius:50%;"></span>
                        <span style="font-weight:700; font-size:0.9rem; color:#8b0000;">Auto-Backup Active (12H Interval)</span>
                    </div>
                    
                    <div style="font-size:0.85rem; color:#7F8C8D; display:flex; justify-content:space-between; margin-bottom:10px; border-bottom:1px solid #f8f9fa; padding-bottom:8px;">
                        <span>SMS Portal Credit</span>
                        <span style="color:#8b0000; font-weight:900;"><?php echo $stats['sms_balance']; ?></span>
                    </div>

                    <div style="font-size:0.85rem; color:#7F8C8D; display:flex; justify-content:space-between; margin-bottom:10px; border-bottom:1px solid #f8f9fa; padding-bottom:8px;">
                        <span>Last Auto Check</span>
                        <span style="color:#2C3E50; font-weight:700;">Just now (Every load)</span>
                    </div>
                    
                    <div style="background:#FFF5F5; border:1px dashed rgba(139,0,0,0.2); padding:12px; border-radius:6px; font-size:0.78rem; color:#8b0000; line-height:1.4; margin:15px 0;">
                        <i class="fas fa-info-circle"></i> Database backups are saved automatically to <code>/admin/backups/</code> every 12 hours check.
                    </div>

                    <div style="display:flex; flex-direction:column; gap:8px;">
                        <a href="backup/index.php" style="background:#8b0000; border-color:#8b0000; color:white; font-size:0.82rem; font-weight:700; text-align:center; padding:10px; border-radius:6px; text-decoration:none; display:block; transition:all 0.2s;" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">
                            <i class="fas fa-database"></i> Database Backups Page
                        </a>
                        <a href="database/index.php" style="background:#FAFBFD; border:1px solid #E2E6ED; color:#2C3E50; font-size:0.82rem; font-weight:700; text-align:center; padding:10px; border-radius:6px; text-decoration:none; display:block; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#E2E6ED'">
                            <i class="fas fa-broom"></i> DB Health & Table Cleanup
                        </a>
                    </div>
                </div>
            </div>

            <!-- Security Operations Notice -->
            <div class="card shadow-premium" style="background:#FFF5F5; border:1px solid #8b0000; border-radius:12px; padding:20px;">
                <div style="display:flex; gap:12px; align-items:flex-start;">
                    <i class="fas fa-shield-alt" style="color:#8b0000; font-size:1.8rem;"></i>
                    <div>
                        <div style="font-weight:900; color:#8b0000; font-size:0.95rem; margin-bottom:5px;">Security Enforcement</div>
                        <p style="margin:0; font-size:0.8rem; color:#555; line-height:1.5;">This account enforces system-wide user credentials, failed attempts configuration, account isolation, and restoration monitoring.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/header.php'; ?>
