<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "System Activity Logs";
require_once '../../includes/header.php';

// Fetch Logs
try {
    $stmt = $pdo->query("
        SELECT l.*, u.username 
        FROM activity_logs l 
        LEFT JOIN users u ON l.user_id = u.user_id 
        ORDER BY l.created_at DESC 
        LIMIT 100
    ");
    $logs = $stmt->fetchAll();
} catch (PDOException $e) { $logs = []; }
?>

<div class="main-content-inner">
    <div style="max-width: 1100px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-list-alt"></i> Global Activity Audit Trail</h2>
            <p style="color: var(--secondary-text);">Complete history of all critical system actions across all user roles.</p>
        </header>

        <div class="card">
            <div class="card-body" style="padding: 0;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td style="font-size: 0.85rem;"><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                                <td style="font-weight: 700;"><?php echo h($log['username'] ?? 'System'); ?></td>
                                <td><span class="badge" style="background: #eee; color: #333;"><?php echo strtoupper($log['action']); ?></span></td>
                                <td style="font-size: 0.85rem;"><?php echo h($log['description']); ?></td>
                                <td style="font-family: monospace; font-size: 0.75rem;"><?php echo $log['ip_address']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($logs)): ?>
                            <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--secondary-text);">No logs found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
