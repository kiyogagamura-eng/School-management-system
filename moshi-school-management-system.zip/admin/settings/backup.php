<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "System Backup";
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="max-width: 800px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-database"></i> Database Backup & Recovery</h2>
            <p style="color: var(--secondary-text);">Secure your data with periodic backups.</p>
        </header>

        <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
            <div class="card-header">Create New Backup</div>
            <div class="card-body" style="text-align: center; padding: 40px;">
                <div style="font-size: 4rem; color: #eee; margin-bottom: 20px;">
                    <i class="fas fa-cloud-download-alt"></i>
                </div>
                <h3>Full System Snapshot</h3>
                <p style="color: var(--secondary-text); margin-bottom: 30px;">This will generate a ZIP file containing the database SQL and uploaded media files.</p>
                <button class="btn btn-primary" onclick="alert('Backup generation started. This may take a few minutes.')"><i class="fas fa-play"></i> GENERATE BACKUP NOW</button>
            </div>
        </div>

        <div class="card" style="margin-top: 30px;">
            <div class="card-header">Recent Backups</div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Filename</th>
                            <th>Date</th>
                            <th>Size</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>mps_backup_20260317.sql</td>
                            <td>17 Mar 2026</td>
                            <td>4.2 MB</td>
                            <td><a href="#" style="color: var(--corporate-red);"><i class="fas fa-download"></i> Download</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
