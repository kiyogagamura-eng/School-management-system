<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Academic Settings";
require_once '../../includes/header.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_term'])) {
    $term_id = $_POST['term_id'];
    try {
        $pdo->beginTransaction();
        $pdo->exec("UPDATE academic_terms SET is_current = 0");
        $stmt = $pdo->prepare("UPDATE academic_terms SET is_current = 1 WHERE term_id = ?");
        $stmt->execute([$term_id]);
        $pdo->commit();
        $success = "Current academic term updated.";
    } catch (PDOException $e) { $pdo->rollBack(); $error = "Update failed."; }
}

// Fetch all terms
$stmt = $pdo->query("SELECT * FROM academic_terms ORDER BY start_date DESC");
$terms = $stmt->fetchAll();
?>

<div class="main-content-inner">
    <div style="max-width: 800px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-calendar-alt"></i> Academic Term Management</h2>
            <p style="color: var(--secondary-text);">Manage the current active term and viewing historic terms.</p>
        </header>

        <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
            <div class="card-header">Current Term Control</div>
            <div class="card-body">
                <?php if ($success): ?><div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;"><?php echo $success; ?></div><?php endif; ?>
                <form action="" method="POST" style="display: flex; gap: 15px; align-items: flex-end; margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 30px;">
                    <div class="form-group" style="flex: 1; margin: 0;">
                        <label>Select Active Term</label>
                        <select name="term_id" class="form-control">
                            <?php foreach ($terms as $t): ?>
                                <option value="<?php echo $t['term_id']; ?>" <?php echo $t['is_current'] ? 'selected' : ''; ?>>
                                    <?php echo h($t['term_name']); ?> (<?php echo date('Y', strtotime($t['start_date'])); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="update_term" class="btn btn-primary">UPDATE ACTIVE TERM</button>
                </form>

                <table class="table" style="font-size: 0.9rem;">
                    <thead>
                        <tr>
                            <th>Term Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($terms as $t): ?>
                            <tr>
                                <td><?php echo h($t['term_name']); ?></td>
                                <td><?php echo $t['start_date']; ?></td>
                                <td><?php echo $t['end_date']; ?></td>
                                <td>
                                    <?php if ($t['is_current']): ?>
                                        <span style="color: #2ecc71; font-weight: 900;"><i class="fas fa-check-circle"></i> ACTIVE</span>
                                    <?php else: ?>
                                        <span style="color: #bbb;">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
