<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "System Configuration";

$success_msg = '';
$error_msg = '';

// Load current settings from DB
$settings = [];
try {
    $rows = $pdo->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
    foreach ($rows as $r) {
        $settings[$r['setting_key']] = $r['setting_value'];
    }
} catch(PDOException $e) {}

// Default values if not set
$defaults = [
    'school_name'       => 'Moshi Public Secondary School',
    'school_email'      => 'admin@mps.sc.tz',
    'school_phone'      => '+255 700 000 000',
    'school_address'    => 'Moshi, Kilimanjaro, Tanzania',
    'school_motto'      => 'Excellence Through Knowledge',
    'academic_year'     => '2025/2026',
    'current_term'      => 'Term 2',
    'session_timeout'   => '30',
    'max_login_attempts'=> '5',
    'sms_enabled'       => '1',
    'email_enabled'     => '0',
    'maintenance_mode'  => '0',
    'results_visible'   => '1',
];

foreach ($defaults as $key => $val) {
    if (!isset($settings[$key])) $settings[$key] = $val;
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCSRF();
    $section = $_POST['section'] ?? '';

    $save_keys = [];
    if ($section === 'school_identity') {
        $save_keys = ['school_name','school_email','school_phone','school_address','school_motto'];
    } elseif ($section === 'academic') {
        $save_keys = ['academic_year','current_term'];
    } elseif ($section === 'security_config') {
        $save_keys = ['session_timeout','max_login_attempts'];
    } elseif ($section === 'features') {
        $_POST['sms_enabled']    = isset($_POST['sms_enabled'])    ? '1' : '0';
        $_POST['email_enabled']  = isset($_POST['email_enabled'])  ? '1' : '0';
        $_POST['maintenance_mode']= isset($_POST['maintenance_mode'])? '1' : '0';
        $_POST['results_visible']= isset($_POST['results_visible'])? '1' : '0';
        $save_keys = ['sms_enabled','email_enabled','maintenance_mode','results_visible'];
    }

    try {
        foreach ($save_keys as $key) {
            $val = $_POST[$key] ?? '';
            // Upsert
            $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value=?, updated_by=?");
            $stmt->execute([$key, $val, $_SESSION['user_id'], $val, $_SESSION['user_id']]);
            $settings[$key] = $val;
        }
        $success_msg = "Settings saved successfully!";
    } catch(PDOException $e) {
        $error_msg = "Error saving settings: " . $e->getMessage();
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-cogs" style="color:#8b0000;"></i> System Configuration
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">School setup, academic year, security & feature toggles</p>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div style="background:#d4edda; color:#155724; padding:12px 20px; border-radius:8px; border:1px solid #c3e6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-check-circle"></i> <?php echo h($success_msg); ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background:#f8d7da; color:#721c24; padding:12px 20px; border-radius:8px; border:1px solid #f5c6cb; margin-bottom:20px;">
            <i class="fas fa-exclamation-triangle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:25px;">

        <!-- School Identity -->
        <div class="card" style="border-top:4px solid #8b0000;">
            <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #eee;">
                <i class="fas fa-school"></i> School Identity
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="section" value="school_identity">
                    
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">School Name</label>
                        <input type="text" name="school_name" class="form-control" value="<?php echo h($settings['school_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">School Email</label>
                        <input type="email" name="school_email" class="form-control" value="<?php echo h($settings['school_email']); ?>">
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Contact Phone</label>
                        <input type="text" name="school_phone" class="form-control" value="<?php echo h($settings['school_phone']); ?>">
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Address</label>
                        <input type="text" name="school_address" class="form-control" value="<?php echo h($settings['school_address']); ?>">
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">School Motto</label>
                        <input type="text" name="school_motto" class="form-control" value="<?php echo h($settings['school_motto']); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary" style="background:#8b0000; border-color:#8b0000;">
                        <i class="fas fa-save"></i> Save School Info
                    </button>
                </form>
            </div>
        </div>

        <!-- Academic Year -->
        <div class="card" style="border-top:4px solid #1a5276;">
            <div class="card-header" style="background:#eaf2ff; color:#1a5276; border-bottom:1px solid #d0e4f7;">
                <i class="fas fa-calendar-alt"></i> Academic Configuration
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="section" value="academic">
                    
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Academic Year</label>
                        <select name="academic_year" class="form-control">
                            <?php foreach (['2024/2025','2025/2026','2026/2027'] as $yr): ?>
                            <option value="<?php echo $yr; ?>" <?php echo $settings['academic_year']===$yr?'selected':''; ?>>
                                <?php echo $yr; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Current Term</label>
                        <select name="current_term" class="form-control">
                            <?php foreach (['Term 1','Term 2','Term 3'] as $term): ?>
                            <option value="<?php echo $term; ?>" <?php echo $settings['current_term']===$term?'selected':''; ?>>
                                <?php echo $term; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Quick links to manage -->
                    <div style="background:#f8f9fa; border-radius:8px; padding:15px; margin:15px 0;">
                        <div style="font-weight:700; font-size:0.82rem; color:#7F8C8D; text-transform:uppercase; margin-bottom:12px;">Quick Setup Links</div>
                        <div style="display:flex; flex-direction:column; gap:8px;">
                            <a href="<?php echo BASE_URL; ?>admin/classes/index.php" style="display:flex; align-items:center; gap:10px; padding:8px 12px; background:white; border-radius:6px; border:1px solid #eee; text-decoration:none; color:#2C3E50; font-size:0.85rem; font-weight:600; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#eee'">
                                <i class="fas fa-chalkboard" style="color:#8b0000;"></i> Manage Classes & Streams
                            </a>
                            <a href="<?php echo BASE_URL; ?>admin/subjects/index.php" style="display:flex; align-items:center; gap:10px; padding:8px 12px; background:white; border-radius:6px; border:1px solid #eee; text-decoration:none; color:#2C3E50; font-size:0.85rem; font-weight:600; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#eee'">
                                <i class="fas fa-book" style="color:#8b0000;"></i> Manage Subjects
                            </a>
                            <a href="<?php echo BASE_URL; ?>admin/timetable/index.php" style="display:flex; align-items:center; gap:10px; padding:8px 12px; background:white; border-radius:6px; border:1px solid #eee; text-decoration:none; color:#2C3E50; font-size:0.85rem; font-weight:600; transition:all 0.2s;" onmouseover="this.style.borderColor='#8b0000'" onmouseout="this.style.borderColor='#eee'">
                                <i class="fas fa-calendar-alt" style="color:#8b0000;"></i> Exam Timetables
                            </a>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background:#1a5276; border-color:#1a5276;">
                        <i class="fas fa-save"></i> Save Academic Settings
                    </button>
                </form>
            </div>
        </div>

        <!-- Security Config -->
        <div class="card" style="border-top:4px solid #e74c3c;">
            <div class="card-header" style="background:#fdedec; color:#e74c3c; border-bottom:1px solid #fadbd8;">
                <i class="fas fa-shield-alt"></i> Security Configuration
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="section" value="security_config">
                    
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Session Timeout (minutes)</label>
                        <input type="number" name="session_timeout" class="form-control" value="<?php echo h($settings['session_timeout']); ?>" min="5" max="480">
                        <small style="color:#7F8C8D;">Default: 30 minutes. Users auto-logout after inactivity.</small>
                    </div>
                    <div class="form-group">
                        <label style="font-weight:700; font-size:0.85rem; color:#2C3E50;">Max Failed Login Attempts</label>
                        <input type="number" name="max_login_attempts" class="form-control" value="<?php echo h($settings['max_login_attempts']); ?>" min="3" max="20">
                        <small style="color:#7F8C8D;">Account locks after this many failed attempts.</small>
                    </div>
                    
                    <div style="background:#fdedec; border-radius:8px; padding:15px; margin:10px 0; font-size:0.82rem; color:#7F8C8D;">
                        <i class="fas fa-info-circle" style="color:#e74c3c;"></i> 
                        Changes take effect on next user login. Current default: <strong>5 attempts → 30 min lock</strong>.
                    </div>

                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <button type="submit" class="btn btn-primary" style="background:#e74c3c; border-color:#e74c3c;">
                            <i class="fas fa-save"></i> Save Security Settings
                        </button>
                        <a href="security/index.php" class="btn btn-outline" style="border-color:#e74c3c; color:#e74c3c;">
                            <i class="fas fa-users-cog"></i> Manage Accounts
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Feature Toggles -->
        <div class="card" style="border-top:4px solid #27ae60;">
            <div class="card-header" style="background:#eafaf1; color:#27ae60; border-bottom:1px solid #a9dfbf;">
                <i class="fas fa-toggle-on"></i> Feature Controls
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="section" value="features">
                    
                    <?php 
                    $toggles = [
                        'sms_enabled'     => ['label'=>'SMS Notifications', 'icon'=>'fa-sms', 'desc'=>'Enable sending SMS to parents via NextSMS'],
                        'email_enabled'   => ['label'=>'Email Notifications', 'icon'=>'fa-envelope', 'desc'=>'Enable sending email alerts (SMTP required)'],
                        'results_visible' => ['label'=>'Results Visible to Students', 'icon'=>'fa-chart-bar', 'desc'=>'Allow students to view their exam results'],
                        'maintenance_mode'=> ['label'=>'Maintenance Mode', 'icon'=>'fa-tools', 'desc'=>'Lock system for non-admins (maintenance)'],
                    ];
                    foreach ($toggles as $key => $t): 
                        $enabled = $settings[$key] === '1';
                    ?>
                    <div style="display:flex; align-items:center; justify-content:space-between; padding:14px 0; border-bottom:1px dashed #eee;">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <div style="width:36px; height:36px; border-radius:8px; background:<?php echo $enabled?'#eafaf1':'#f8f9fa'; ?>; display:flex; align-items:center; justify-content:center;">
                                <i class="fas <?php echo $t['icon']; ?>" style="color:<?php echo $enabled?'#27ae60':'#bdc3c7'; ?>;"></i>
                            </div>
                            <div>
                                <div style="font-weight:700; font-size:0.88rem; color:#2C3E50;"><?php echo $t['label']; ?></div>
                                <div style="font-size:0.75rem; color:#7F8C8D;"><?php echo $t['desc']; ?></div>
                            </div>
                        </div>
                        <!-- Toggle Switch -->
                        <label style="position:relative; display:inline-block; width:48px; height:26px; cursor:pointer; flex-shrink:0;">
                            <input type="checkbox" name="<?php echo $key; ?>" <?php echo $enabled?'checked':''; ?> style="opacity:0; width:0; height:0;" id="toggle_<?php echo $key; ?>">
                            <span onclick="toggleSwitch(this)" style="position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:<?php echo $enabled?'#27ae60':'#bdc3c7'; ?>; border-radius:26px; transition:all 0.3s;">
                                <span style="position:absolute; content:''; height:20px; width:20px; left:<?php echo $enabled?'24px':'3px'; ?>; bottom:3px; background:white; border-radius:50%; transition:all 0.3s; display:block;"></span>
                            </span>
                        </label>
                    </div>
                    <?php endforeach; ?>

                    <div style="margin-top:20px;">
                        <button type="submit" class="btn btn-primary" style="background:#27ae60; border-color:#27ae60;">
                            <i class="fas fa-save"></i> Save Feature Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleSwitch(el) {
    const checkbox = el.previousElementSibling;
    const knob = el.querySelector('span');
    const isOn = checkbox.checked;
    el.style.background = isOn ? '#bdc3c7' : '#27ae60';
    knob.style.left = isOn ? '3px' : '24px';
    checkbox.checked = !isOn;
}
</script>

<?php require_once '../../includes/footer.php'; ?>
