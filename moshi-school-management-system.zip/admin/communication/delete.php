<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    redirect('index.php', "Announcement ID required.");
}

$id = $_GET['id'];

try {
    $stmt = $pdo->prepare("DELETE FROM announcements WHERE announcement_id = ?");
    $stmt->execute([$id]);
    redirect('index.php', "Announcement deleted successfully.");
} catch (PDOException $e) {
    redirect('index.php', "Deletion failed: " . $e->getMessage(), "error");
}
?>
