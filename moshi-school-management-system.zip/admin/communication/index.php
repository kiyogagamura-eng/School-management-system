<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos', 'discipline']);

$page_title = "Announcements & Notices";

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_announcement'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $priority = $_POST['priority'];
    $target_role = $_POST['target_role'];
    $target_id = !empty($_POST['target_class_id_ann']) ? $_POST['target_class_id_ann'] : null;

    try {
        $stmt = $pdo->prepare("INSERT INTO announcements (title, content, priority, target_role, target_id, created_by) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $content, $priority, $target_role, $target_id, $_SESSION['user_id']]);
        $success = "Announcement posted successfully!";
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch all announcements
$stmt = $pdo->query("SELECT a.*, u.username as author FROM announcements a JOIN users u ON a.created_by = u.user_id ORDER BY a.created_at DESC");
$announcements = $stmt->fetchAll();

// NEW: Fetch data for SMS targeting
$classes = $pdo->query("SELECT * FROM classes ORDER BY class_name ASC")->fetchAll();
$teachers_list = $pdo->query("SELECT teacher_id, first_name, last_name, phone FROM teachers WHERE status = 'Active' ORDER BY first_name ASC")->fetchAll();
$students_list = $pdo->query("SELECT student_id, first_name, last_name, parent_phone FROM students WHERE status = 'Active' ORDER BY first_name ASC")->fetchAll();

$current_tab = $_GET['tab'] ?? 'announcements';

// Handle SMS Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_sms'])) {
    $target = $_POST['sms_target'];
    $message = trim($_POST['sms_message']);
    $recipients = []; // Array of phone numbers

    try {
        if ($target == 'all_parents') {
            $stmt = $pdo->query("SELECT parent_phone FROM students WHERE status = 'Active' AND parent_phone != ''");
            $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } elseif ($target == 'specific_parent') {
            $stmt = $pdo->prepare("SELECT parent_phone FROM students WHERE student_id = ?");
            $stmt->execute([$_POST['target_student_id']]);
            $phone = $stmt->fetchColumn();
            if ($phone) $recipients[] = $phone;
        } elseif ($target == 'multiple_parents') {
            if (isset($_POST['selected_students']) && is_array($_POST['selected_students'])) {
                $placeholders = implode(',', array_fill(0, count($_POST['selected_students']), '?'));
                $stmt = $pdo->prepare("SELECT parent_phone FROM students WHERE student_id IN ($placeholders) AND parent_phone != ''");
                $stmt->execute($_POST['selected_students']);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
        } elseif ($target == 'class_parents') {
            $stmt = $pdo->prepare("SELECT parent_phone FROM students WHERE class_id = ? AND status = 'Active' AND parent_phone != ''");
            $stmt->execute([$_POST['target_class_id']]);
            $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } elseif ($target == 'all_teachers') {
            $stmt = $pdo->query("SELECT phone FROM teachers WHERE status = 'Active' AND phone != ''");
            $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } elseif ($target == 'multiple_teachers') {
            if (isset($_POST['selected_teachers']) && is_array($_POST['selected_teachers'])) {
                $placeholders = implode(',', array_fill(0, count($_POST['selected_teachers']), '?'));
                $stmt = $pdo->prepare("SELECT phone FROM teachers WHERE teacher_id IN ($placeholders) AND phone != ''");
                $stmt->execute($_POST['selected_teachers']);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
        } elseif ($target == 'specific_teacher') {
            $stmt = $pdo->prepare("SELECT phone FROM teachers WHERE teacher_id = ?");
            $stmt->execute([$_POST['target_teacher_id']]);
            $phone = $stmt->fetchColumn();
            if ($phone) $recipients[] = $phone;
        } elseif ($target == 'class_teacher') {
            $stmt = $pdo->prepare("SELECT t.phone FROM classes c JOIN teachers t ON c.class_teacher_id = t.teacher_id WHERE c.class_id = ?");
            $stmt->execute([$_POST['target_class_id']]);
            $phone = $stmt->fetchColumn();
            if ($phone) $recipients[] = $phone;
        }

        $count = 0;
        $unique_recipients = array_filter(array_unique($recipients));
        foreach ($unique_recipients as $phone) {
            if (sendSMS($phone, $message)) {
                $count++;
            }
        }
        
        if ($count > 0) {
            $success = "Successfully sent $count SMS message(s).";
        } else {
            $error = "No valid recipients found or SMS gateway error.";
        }
    } catch (PDOException $e) {
        $error = "System error: " . $e->getMessage();
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<style>
    .tab-btn { padding: 10px 20px; border: none; background: #eee; cursor: pointer; border-radius: 5px 5px 0 0; font-weight: 700; color: #777; }
    .tab-btn.active { background: var(--corporate-red); color: white; }
    .tab-content { display: none; }
    .tab-content.active { display: block; }
</style>

<div class="main-content-inner">
    <div style="margin-bottom: 30px;">
        <div style="display: flex; gap: 5px; border-bottom: 2px solid var(--corporate-red);">
            <button class="tab-btn <?php echo $current_tab == 'announcements' ? 'active' : ''; ?>" onclick="window.location.href='?tab=announcements'">ANNOUNCEMENTS</button>
            <button class="tab-btn <?php echo $current_tab == 'sms' ? 'active' : ''; ?>" onclick="window.location.href='?tab=sms'">SEND SMS</button>
        </div>
    </div>

    <!-- Announcements Tab -->
    <div class="tab-content <?php echo $current_tab == 'announcements' ? 'active' : ''; ?>">
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px;">
            <div>
                <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
                    <div class="card-header">Post Announcement</div>
                    <div class="card-body">
                        <?php if ($success && $current_tab == 'announcements'): ?><div style="background: #e8f5e9; color: #2e7d32; padding: 10px; border-radius: 5px; margin-bottom: 15px;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div><?php endif; ?>
                        
                        <form action="" method="POST">
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Target Audience</label>
                                <select name="target_role" class="form-control" onchange="toggleAnnTarget(this.value)">
                                    <option value="all">All Users</option>
                                    <option value="teacher">Teachers Only</option>
                                    <option value="student">Students & Parents (All)</option>
                                    <option value="specific_class">Specific Class Only</option>
                                </select>
                            </div>
                            <div class="form-group" id="ann_class_field" style="display: none;">
                                <label>Select Target Class</label>
                                <select name="target_class_id_ann" class="form-control">
                                    <option value="">-- Choose Class --</option>
                                    <?php foreach ($classes as $c): ?>
                                        <option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Priority</label>
                                <select name="priority" class="form-control">
                                    <option value="normal">Normal</option>
                                    <option value="high">Urgent</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Message</label>
                                <textarea name="content" class="form-control" rows="5" required></textarea>
                            </div>
                            <button type="submit" name="post_announcement" class="btn btn-primary" style="width: 100%;">POST NOTICE</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <script>
            function toggleAnnTarget(val) {
                document.getElementById('ann_class_field').style.display = (val === 'specific_class') ? 'block' : 'none';
            }
            </script>

            <div>
                <div class="card">
                    <div class="card-header">Existing Notices</div>
                    <div class="card-body" style="padding: 0;">
                        <?php if (empty($announcements)): ?>
                            <div style="padding: 40px; text-align: center; color: var(--secondary-text);">No announcements yet.</div>
                        <?php else: ?>
                            <?php foreach ($announcements as $a): ?>
                                <div style="padding: 20px; border-bottom: 1px solid #eee;">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                        <div>
                                            <h4 style="margin: 0;"><?php echo h($a['title']); ?></h4>
                                            <div style="font-size: 0.75rem; color: var(--secondary-text); margin: 5px 0 10px;">
                                                By <?php echo h($a['author']); ?> | <?php echo date('d M Y', strtotime($a['created_at'])); ?>
                                            </div>
                                        </div>
                                         <a href="javascript:void(0)" 
                                            class="btn-delete-confirm"
                                            data-url="delete.php?id=<?php echo $a['announcement_id']; ?>" 
                                            data-name="<?php echo h($a['title']); ?>"
                                            data-type="Notice"
                                            title="Delete" 
                                            style="color: var(--corporate-red);">
                                             <i class="fas fa-trash-alt"></i>
                                         </a>
                                     </div>
                                     <p style="font-size: 0.9rem;"><?php echo nl2br(h($a['content'])); ?></p>
                                 </div>
                             <?php endforeach; ?>
                         <?php endif; ?>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 
     <!-- SMS Tab -->
     <div class="tab-content <?php echo $current_tab == 'sms' ? 'active' : ''; ?>">
         <div style="max-width: 800px; margin: 0 auto;">
             <div class="card shadow-premium" style="border-top: 5px solid #940000;">
                 <div class="card-header">Send SMS Notification</div>
                 <div class="card-body">
                     <?php if ($success && $current_tab == 'sms'): ?><div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div><?php endif; ?>
                     
                     <form action="" method="POST" id="smsForm">
                         <div class="form-group">
                             <label>Target Audience</label>
                             <select name="sms_target" id="sms_target" class="form-control" required onchange="toggleTargetFields()">
                                 <option value="">-- Select Target --</option>
                                 <option value="all_parents">All Parents</option>
                                 <option value="specific_parent">Single Student's Parent</option>
                                 <option value="multiple_parents">Multiple Parents (Selection)</option>
                                 <option value="class_parents">All Parents in a Class</option>
                                 <option value="all_teachers">All Teachers</option>
                                 <option value="specific_teacher">Single Teacher</option>
                                 <option value="multiple_teachers">Multiple Teachers (Selection)</option>
                                 <option value="class_teacher">Class Teacher of Specific Class</option>
                             </select>
                         </div>
 
                         <!-- Class Selection Field -->
                         <div class="form-group" id="class_field" style="display: none;">
                             <label>Select Class</label>
                             <select name="target_class_id" class="form-control">
                                 <?php foreach ($classes as $c): ?>
                                     <option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option>
                                 <?php endforeach; ?>
                             </select>
                         </div>
 
                         <!-- Specific Teacher Field -->
                         <div class="form-group" id="teacher_field" style="display: none;">
                             <label>Select Teacher</label>
                             <select name="target_teacher_id" class="form-control">
                                 <?php foreach ($teachers_list as $t): ?>
                                     <option value="<?php echo $t['teacher_id']; ?>"><?php echo h($t['first_name'] . ' ' . $t['last_name']); ?> (<?php echo $t['phone']; ?>)</option>
                                 <?php endforeach; ?>
                             </select>
                         </div>

                         <!-- Multiple Teachers Field -->
                         <div class="form-group" id="multi_teacher_field" style="display: none;">
                             <label>Choose Teachers (Tick to Select)</label>
                             <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 5px; background: #fafafa;">
                                 <?php foreach ($teachers_list as $t): ?>
                                     <label style="display: block; padding: 5px 0; border-bottom: 1px solid #eee; cursor: pointer;">
                                         <input type="checkbox" name="selected_teachers[]" value="<?php echo $t['teacher_id']; ?>">
                                         <span style="font-size: 0.9rem; margin-left: 5px;"><?php echo h($t['first_name'] . ' ' . $t['last_name']); ?> (<?php echo $t['phone']; ?>)</span>
                                     </label>
                                 <?php endforeach; ?>
                             </div>
                         </div>
 
                         <!-- Specific Parent Field -->
                         <div class="form-group" id="parent_field" style="display: none;">
                             <label>Select Student (Sends to Parent)</label>
                             <select name="target_student_id" class="form-control">
                                 <?php foreach ($students_list as $s): ?>
                                     <option value="<?php echo $s['student_id']; ?>"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?> (Parent: <?php echo $s['parent_phone']; ?>)</option>
                                 <?php endforeach; ?>
                             </select>
                         </div>

                         <!-- Multiple Parents Field -->
                         <div class="form-group" id="multi_parent_field" style="display: none;">
                             <label>Choose Students/Parents (Tick to Select)</label>
                             <div style="max-height: 250px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 5px; background: #fafafa;">
                                 <input type="text" placeholder="Search student name..." class="form-control" style="margin-bottom: 10px; font-size: 0.8rem;" onkeyup="filterMultiList(this, 'multi_parent_list')">
                                 <div id="multi_parent_list">
                                     <?php foreach ($students_list as $s): ?>
                                         <label style="display: block; padding: 5px 0; border-bottom: 1px solid #eee; cursor: pointer;">
                                             <input type="checkbox" name="selected_students[]" value="<?php echo $s['student_id']; ?>">
                                             <span style="font-size: 0.9rem; margin-left: 5px;"><?php echo h($s['first_name'] . ' ' . $s['last_name']); ?> (Parent: <?php echo $s['parent_phone']; ?>)</span>
                                         </label>
                                     <?php endforeach; ?>
                                 </div>
                             </div>
                         </div>
 
                         <div class="form-group">
                             <label>Message Content</label>
                             <textarea name="sms_message" class="form-control" rows="4" required placeholder="Type your SMS message here..." maxlength="160" onkeyup="countChars(this)"></textarea>
                             <small id="charCount" style="color: var(--secondary-text);">0 / 160 characters (1 SMS)</small>
                         </div>
 
                         <div style="margin-top: 30px;">
                             <button type="submit" name="send_sms" class="btn btn-primary" style="background: #940000; border-color: #940000; width: 100%; color: #FFFFFF; font-weight: 800;">
                                 <i class="fas fa-paper-plane"></i> SEND SMS NOW
                             </button>
                         </div>
                     </form>
                 </div>
             </div>
             
             <div style="text-align: center; margin-top: 20px;">
                 <a href="settings.php" style="color: #940000; font-weight: 700;"><i class="fas fa-wallet"></i> Check SMS Balance</a>
             </div>
         </div>
     </div>
 </div>
 
 <script>
 function toggleTargetFields() {
     const target = document.getElementById('sms_target').value;
     document.getElementById('class_field').style.display = (target === 'class_parents' || target === 'class_teacher') ? 'block' : 'none';
     document.getElementById('teacher_field').style.display = (target === 'specific_teacher') ? 'block' : 'none';
     document.getElementById('parent_field').style.display = (target === 'specific_parent') ? 'block' : 'none';
     document.getElementById('multi_teacher_field').style.display = (target === 'multiple_teachers') ? 'block' : 'none';
     document.getElementById('multi_parent_field').style.display = (target === 'multiple_parents') ? 'block' : 'none';
 }
 
 function countChars(obj) {
     const len = obj.value.length;
     const smsCount = Math.ceil(len / 160) || 1;
     document.getElementById('charCount').innerHTML = len + ' / 160 characters (' + smsCount + ' SMS)';
 }

 function filterMultiList(input, listId) {
     const filter = input.value.toUpperCase();
     const list = document.getElementById(listId);
     const labels = list.getElementsByTagName('label');
     for (let i = 0; i < labels.length; i++) {
         const txtValue = labels[i].textContent || labels[i].innerText;
         if (txtValue.toUpperCase().indexOf(filter) > -1) {
             labels[i].style.display = "";
         } else {
             labels[i].style.display = "none";
         }
     }
 }
 </script>

<?php require_once '../../includes/footer.php'; ?>
