<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Communication Settings";
require_once '../../includes/header.php';

// Fetch Live Balance from NextSMS
$sms_balance = "0 TZS";
$credits_remaining = "0 SMS";
$status_color = "#f39c12"; // Default
$status_text = "CONNECTING...";

try {
    $url = 'https://messaging-service.co.tz/api/sms/v1/balance';
    $credentials = base64_encode(NEXTSMS_USERNAME . ':' . NEXTSMS_PASSWORD);
        
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPGET        => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Basic ' . $credentials,
            'Accept: application/json'
        ],
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if (isset($data['sms_balance'])) {
            $sms_balance = ($data['sms_balance'] * 16) . " TZS";
            $credits_remaining = $data['sms_balance'] . " SMS";
            $status_color = "#2ecc71";
            $status_text = "ONLINE";
        } elseif (isset($data['balance'])) {
            $sms_balance = ($data['balance'] * 16) . " TZS";
            $credits_remaining = $data['balance'] . " SMS";
            $status_color = "#2ecc71";
            $status_text = "ONLINE";
        } else {
            // Unrecognized response format
            $status_color = "#e74c3c";
            $status_text = "API ERROR";
        }
    } else {
        $status_color = "#e74c3c";
        $status_text = "API ERROR ($httpCode)";
    }
} catch (Exception $e) {
    $status_color = "#e74c3c";
    $status_text = "OFFLINE";
}
?>

<div class="main-content-inner">
    <div style="max-width: 900px; margin: 0 auto; padding: 20px;">
        <header class="page-header" style="margin-bottom: 30px;">
            <h2><i class="fas fa-sms"></i> SMS & Communication Credits</h2>
            <p style="color: var(--secondary-text);">Manage your SMS gateway subscription and balance.</p>
        </header>

        <div class="dashboard-grid" style="grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));">
            <div class="card shadow-premium" style="border-top: 5px solid #f39c12;">
                <div class="card-header" style="background: #fff8e1; color: #f57f17; font-weight: 700;">Account Balance</div>
                <div class="card-body" style="text-align: center; padding: 30px;">
                    <div style="font-size: 2.5rem; font-weight: 900; color: #333; margin-bottom: 10px;"><?php echo $sms_balance; ?></div>
                    <div style="color: #2ecc71; font-weight: 700;"><i class="fas fa-check-circle"></i> Gateway Online</div>
                    <div style="margin-top: 20px; color: var(--secondary-text); font-size: 0.9rem;">Approx. <strong><?php echo $credits_remaining; ?></strong> remaining.</div>
                    <a href="https://nextsms.co.tz/" target="_blank" class="btn btn-primary" style="margin-top: 30px; background: #f39c12; width: 100%;">TOP-UP ACCOUNT</a>
                </div>
            </div>

            <div class="card">
                <div class="card-header">Gateway Configuration</div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Provider</label>
                        <input type="text" class="form-control" value="NextSMS (Kitanzania)" readonly>
                    </div>
                    <div class="form-group">
                        <label>Sender ID</label>
                        <input type="text" class="form-control" value="<?php echo NEXTSMS_SENDER_ID; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <div style="padding: 10px; background: #e8f5e9; color: <?php echo $status_color; ?>; border: 1px solid <?php echo $status_color; ?>; border-radius: 5px; font-weight: 700; font-size: 0.85rem;">
                            <i class="fas fa-link"></i> <?php echo $status_text; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card" style="margin-top: 30px; border-left: 4px solid #3498db;">
            <div class="card-header" style="background: #ebf5fb; color: #2980b9;"><i class="fas fa-info-circle"></i> SMS Top-up Instructions (NextSMS)</div>
            <div class="card-body">
                <p>To top up your SMS credits via NextSMS, follow these instructions:</p>
                <ol style="margin-left: 20px; line-height: 1.8;">
                    <li>Log in to your <strong>NextSMS Dashboard</strong> at <a href="https://nextsms.co.tz" target="_blank">nextsms.co.tz</a>.</li>
                    <li>Click on <strong>Recharge / Buy SMS</strong>.</li>
                    <li>Select mobile money (Tigo Pesa, M-Pesa, Airtel Money) or Bank push.</li>
                    <li>Follow the prompt to complete the payment instantly on your phone.</li>
                    <li>Your balance will reflect <strong>immediately</strong> in this dashboard after successful payment.</li>
                </ol>
                <div style="margin-top: 15px; background: #e8f5e9; padding: 10px; border-radius: 5px; font-size: 0.9rem; color: #2ecc71;">
                    <i class="fas fa-check-circle"></i> NextSMS recharges are processed automatically.
                </div>
            </div>
        </div>

        <div class="card" style="margin-top: 30px;">
            <div class="card-header">Usage History (Last 30 Days)</div>
            <div class="card-body table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Recipient Group</th>
                            <th>Count</th>
                            <th>Cost</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>10 Mar 2026</td>
                            <td>Form 4 Parents</td>
                            <td>120</td>
                            <td>600.00 TZS</td>
                        </tr>
                        <tr>
                            <td>05 Mar 2026</td>
                            <td>All Staff</td>
                            <td>45</td>
                            <td>225.00 TZS</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
