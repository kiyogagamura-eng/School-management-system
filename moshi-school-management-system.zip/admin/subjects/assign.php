<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['id'])) {
    redirect('index.php', "Subject ID required for assignment.");
}

$subject_id = $_GET['id'];
$page_title = "Assign Subject to Classes";
$error = '';
$success = '';

// Fetch subject data
try {
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE subject_id = ?");
    $stmt->execute([$subject_id]);
    $subject = $stmt->fetch();
    
    if (!$subject) {
        redirect('index.php', "Subject not found.", "error");
    }

    // Fetch all classes
    $stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream");
    $classes = $stmt->fetchAll();

    // Fetch all teachers
    $stmt = $pdo->query("SELECT * FROM teachers ORDER BY first_name, last_name");
    $teachers = $stmt->fetchAll();

    // Fetch current assignments for this subject
    $stmt = $pdo->prepare("SELECT class_id, teacher_id FROM class_subjects WHERE subject_id = ?");
    $stmt->execute([$subject_id]);
    $current_assignments = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // class_id => teacher_id
} catch (PDOException $e) {
    redirect('index.php', "Database error: " . $e->getMessage(), "error");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $assigned_classes = $_POST['classes'] ?? []; // Array of class_ids
    $teacher_assignments = $_POST['teachers'] ?? []; // Array of class_id => teacher_id

    try {
        $pdo->beginTransaction();

        // 1. Clear existing assignments for this subject
        $stmt = $pdo->prepare("DELETE FROM class_subjects WHERE subject_id = ?");
        $stmt->execute([$subject_id]);

        // 2. Insert new assignments
        if (!empty($assigned_classes)) {
            $stmt = $pdo->prepare("INSERT INTO class_subjects (class_id, subject_id, teacher_id) VALUES (?, ?, ?)");
            foreach ($assigned_classes as $class_id) {
                $teacher_id = !empty($teacher_assignments[$class_id]) ? $teacher_assignments[$class_id] : null;
                $stmt->execute([$class_id, $subject_id, $teacher_id]);
            }
        }

        $pdo->commit();
        redirect('index.php', "Assignments for subject '{$subject['subject_name']}' updated successfully.");
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Update failed: " . $e->getMessage();
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Subjects</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
        <div class="card-header" style="background: var(--header-gradient);">
            <h3 style="margin: 0;"><i class="fas fa-link"></i> <?php echo $page_title; ?>: <?php echo h($subject['subject_name']); ?></h3>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <p style="color: var(--secondary-text); margin-bottom: 20px;">Select the classes where this subject is taught and assign a teacher for each class.</p>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 50px;">Select</th>
                            <th>Class Name</th>
                            <th>Assign Teacher</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($classes as $class): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="classes[]" value="<?php echo $class['class_id']; ?>" 
                                           <?php echo isset($current_assignments[$class['class_id']]) ? 'checked' : ''; ?>
                                           style="width: 18px; height: 18px; cursor: pointer; accent-color: var(--corporate-red);">
                                </td>
                                <td style="font-weight: 700;"><?php echo h($class['class_name']); ?></td>
                                <td>
                                    <select name="teachers[<?php echo $class['class_id']; ?>]" class="form-control" style="max-width: 300px;">
                                        <option value="">-- Choose Teacher --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['teacher_id']; ?>" 
                                                <?php echo (isset($current_assignments[$class['class_id']]) && $current_assignments[$class['class_id']] == $teacher['teacher_id']) ? 'selected' : ''; ?>>
                                                <?php echo h($teacher['first_name'] . ' ' . $teacher['last_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div style="margin-top: 40px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; padding: 12px;">SAVE ASSIGNMENTS</button>
                    <a href="index.php" class="btn btn-outline" style="flex: 1; text-align: center; border: 1px solid #ddd; padding: 10px; border-radius: 4px; text-decoration: none; color: #666; display: flex; align-items: center; justify-content: center;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
