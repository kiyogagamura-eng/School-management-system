<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Add New Subject";

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject_name = trim($_POST['subject_name']);
    $subject_code = strtoupper(trim($_POST['subject_code']));
    $description = trim($_POST['description']);
    $is_compulsory = isset($_POST['is_compulsory']) ? 1 : 0;

    if (empty($subject_name) || empty($subject_code)) {
        $error = "Subject name and code are required.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO subjects (subject_name, subject_code, description, is_compulsory) VALUES (?, ?, ?, ?)");
            $stmt->execute([$subject_name, $subject_code, $description, $is_compulsory]);
            redirect('index.php', "Subject '$subject_name' added successfully.");
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Subject code '$subject_code' already exists.";
            } else {
                $error = "Error adding subject: " . $e->getMessage();
            }
        }
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Subjects</a>
    </div>

        <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
            <div class="card-header" style="background: var(--header-gradient);">
                <h3 style="margin: 0;"><i class="fas fa-book"></i> <?php echo $page_title; ?></h3>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div class="form-group">
                        <label>Subject Name <span class="text-red">*</span></label>
                        <input type="text" name="subject_name" class="form-control" required placeholder="e.g. Mathematics">
                    </div>
                    <div class="form-group">
                        <label>Subject Code <span class="text-red">*</span></label>
                        <input type="text" name="subject_code" class="form-control" required placeholder="e.g. MATH101">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Brief subject description..."></textarea>
                    </div>
                    <div class="form-group">
                        <label style="display: flex; align-items: center; cursor: pointer; font-weight: 500;">
                            <input type="checkbox" name="is_compulsory" value="1" checked style="width: 20px; height: 20px; margin-right: 10px; accent-color: var(--corporate-red);">
                            This is a compulsory subject
                        </label>
                    </div>

                    <div style="margin-top: 30px; display: flex; gap: 15px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1;">SAVE SUBJECT</button>
                        <a href="index.php" class="btn btn-outline" style="flex: 1;">CANCEL</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
