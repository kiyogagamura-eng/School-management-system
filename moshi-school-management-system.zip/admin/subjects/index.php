<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Subject Management";

// Fetch all subjects
try {
    $stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name ASC");
    $subjects = $stmt->fetchAll();
} catch (PDOException $e) {
    $subjects = [];
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h2 style="margin: 0;"><i class="fas fa-book"></i> <?php echo $page_title; ?></h2>
        <a href="create.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Subject</a>
    </div>

            <div class="card">
                <div class="card-header">Available Subjects</div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Subject ID</th>
                                <th>Subject Name</th>
                                <th>Subject Code</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($subjects)): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center; color: var(--secondary-text);">No subjects found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($subjects as $subject): ?>
                                    <tr>
                                        <td>#<?php echo $subject['subject_id']; ?></td>
                                        <td style="font-weight: 700;"><?php echo h($subject['subject_name']); ?></td>
                                        <td><span style="font-family: monospace; background: #eee; padding: 2px 5px; border-radius: 3px;"><?php echo h($subject['subject_code']); ?></span></td>
                                        <td>
                                            <?php echo $subject['is_compulsory'] ? '<span class="text-red" style="font-weight: 700;">Compulsory</span>' : 'Optional'; ?>
                                        </td>
                                        <td>
                                            <a href="edit.php?id=<?php echo $subject['subject_id']; ?>" title="Edit" style="margin-right: 15px; color: #3498db;"><i class="fas fa-edit"></i></a>
                                            <a href="assign.php?id=<?php echo $subject['subject_id']; ?>" title="Assign to Classes" style="margin-right: 15px; color: #2ecc71;"><i class="fas fa-link"></i></a>
                                            <a href="javascript:void(0)" 
                                               class="btn-delete-confirm"
                                               data-url="delete.php?id=<?php echo $subject['subject_id']; ?>" 
                                               data-name="<?php echo h($subject['subject_name']); ?>"
                                               data-type="Subject"
                                               title="Delete" 
                                               style="color: var(--corporate-red);">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
