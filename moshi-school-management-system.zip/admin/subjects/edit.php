<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['id'])) {
    redirect('index.php', "Subject ID required.");
}

$id = $_GET['id'];
$page_title = "Edit Subject";
$error = '';
$success = '';

// Fetch subject data
try {
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE subject_id = ?");
    $stmt->execute([$id]);
    $subject = $stmt->fetch();
    
    if (!$subject) {
        redirect('index.php', "Subject not found.", "error");
    }
} catch (PDOException $e) {
    redirect('index.php', "Database error: " . $e->getMessage(), "error");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject_name = trim($_POST['subject_name']);
    $subject_code = strtoupper(trim($_POST['subject_code']));
    $description = trim($_POST['description']);
    $is_compulsory = isset($_POST['is_compulsory']) ? 1 : 0;

    if (empty($subject_name) || empty($subject_code)) {
        $error = "Subject name and code are required.";
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE subjects SET subject_name = ?, subject_code = ?, description = ?, is_compulsory = ? WHERE subject_id = ?");
            $stmt->execute([$subject_name, $subject_code, $description, $is_compulsory, $id]);
            redirect('index.php', "Subject '$subject_name' updated successfully.");
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Subject code '$subject_code' already exists.";
            } else {
                $error = "Error updating subject: " . $e->getMessage();
            }
        }
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Subjects</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
        <div class="card-header" style="background: var(--header-gradient);">
            <h3 style="margin: 0;"><i class="fas fa-edit"></i> <?php echo $page_title; ?></h3>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label>Subject Name <span class="text-red">*</span></label>
                    <input type="text" name="subject_name" class="form-control" required value="<?php echo h($subject['subject_name']); ?>">
                </div>
                <div class="form-group">
                    <label>Subject Code <span class="text-red">*</span></label>
                    <input type="text" name="subject_code" class="form-control" required value="<?php echo h($subject['subject_code']); ?>">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3"><?php echo h($subject['description']); ?></textarea>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; cursor: pointer; font-weight: 500;">
                        <input type="checkbox" name="is_compulsory" value="1" <?php echo $subject['is_compulsory'] ? 'checked' : ''; ?> style="width: 20px; height: 20px; margin-right: 10px; accent-color: var(--corporate-red);">
                        This is a compulsory subject
                    </label>
                </div>

                <div style="margin-top: 30px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">UPDATE SUBJECT</button>
                    <a href="index.php" class="btn btn-outline" style="flex: 1; text-align: center; border: 1px solid #ddd; padding: 10px; border-radius: 4px; text-decoration: none; color: #666;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
