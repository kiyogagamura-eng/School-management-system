<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['id'])) {
    redirect('index.php', "Subject ID required.");
}

$id = $_GET['id'];

try {
    $pdo->beginTransaction();

    // 1. Check if subject has results or exams
    $stmt_r = $pdo->prepare("SELECT COUNT(*) FROM results WHERE subject_id = ?");
    $stmt_r->execute([$id]);
    $res_count = $stmt_r->fetchColumn();

    $stmt_e = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE subject_id = ?");
    $stmt_e->execute([$id]);
    $exam_count = $stmt_e->fetchColumn();

    if ($res_count > 0 || $exam_count > 0) {
        throw new Exception("Cannot delete subject. It has $res_count results and $exam_count exams recorded. Deleting it would destroy student academic history.");
    }

    // 2. Clear class_subjects links
    $pdo->prepare("DELETE FROM class_subjects WHERE subject_id = ?")->execute([$id]);
    
    // 3. Delete Subject
    $pdo->prepare("DELETE FROM subjects WHERE subject_id = ?")->execute([$id]);

    $pdo->commit();
    redirect('index.php', "Subject deleted successfully.");
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redirect('index.php', $e->getMessage(), "error");
}
?>
