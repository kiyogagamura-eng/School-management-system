<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['class_id']) || !isset($_GET['subject_id']) || !isset($_GET['teacher_id'])) {
    redirect('../users/edit-teacher.php?id=' . ($_GET['teacher_id'] ?? ''), "Missing parameters for removal.", "error");
}

$class_id = $_GET['class_id'];
$subject_id = $_GET['subject_id'];
$teacher_id = $_GET['teacher_id'];

try {
    // We set teacher_id to NULL to unassign the teacher but keep the subject-class link
    // OR we can delete the row if the user wants to remove the subject from the class entirely.
    // Given the request "mfutia mwalimu masomo", setting to NULL is the most direct fix.
    
    $stmt = $pdo->prepare("UPDATE class_subjects SET teacher_id = NULL WHERE class_id = ? AND subject_id = ? AND teacher_id = ?");
    $stmt->execute([$class_id, $subject_id, $teacher_id]);

    redirect('../users/edit-teacher.php?id=' . $teacher_id, "Subject assignment removed from teacher successfully.");
} catch (PDOException $e) {
    redirect('../users/edit-teacher.php?id=' . $teacher_id, "Removal failed: " . $e->getMessage(), "error");
}
