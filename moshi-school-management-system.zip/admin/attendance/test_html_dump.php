<?php
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['PHP_SELF'] = '/admin/attendance/student-report.php';
// We set student_id to 6 to simulate a valid request. 
// If teacher 4 doesn't have student 6, we'll see a block.
$_GET = ['student_id' => '1', 'start_date' => '2026-01-01', 'end_date' => '2026-04-06'];

require_once 'includes/bootstrap.php';
$stmt = $pdo->prepare("SELECT user_id, role FROM users WHERE role = 'teacher' AND user_id = (SELECT user_id FROM teachers WHERE teacher_id = 4)");
$stmt->execute();
$teacher_user = $stmt->fetch();

session_start();
$_SESSION['user_id'] = $teacher_user['user_id'];
$_SESSION['role'] = $teacher_user['role'];

ob_start();
require 'admin/attendance/student-report.php';
$html = ob_get_clean();
file_put_contents('teacher_report_output_test.html', $html);
echo "HTML written successfully.\n";
