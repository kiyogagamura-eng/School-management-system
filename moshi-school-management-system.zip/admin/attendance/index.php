<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'dos', 'headteacher', 'teacher']); // Only authorized staff can mark attendance

$page_title = "Mark Attendance";

// Fetch Classes
$stmt = $pdo->query("SELECT * FROM classes ORDER BY class_name");
$classes = $stmt->fetchAll();

// Fetch Subjects
$stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name");
$subjects = $stmt->fetchAll();

$selected_class = $_GET['class_id'] ?? null;
$selected_subject = $_GET['subject_id'] ?? null;
$selected_date = $_GET['date'] ?? date('Y-m-d');
$start_time = $_GET['start_time'] ?? date('H:i');

$students = [];
if ($selected_class) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE class_id = ? AND status = 'Active' ORDER BY first_name");
    $stmt->execute([$selected_class]);
    $students = $stmt->fetchAll();
}

require_once '../../includes/header.php';
?>

<div class="container-fluid py-4 fade-in">
    <!-- Main Filter Bar -->
    <div class="filter-card mb-4 border-0">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-lg-3">
                <label class="small fw-bold text-secondary text-uppercase mb-1" style="font-size: 10px;">Select Class Group</label>
                <select name="class_id" class="form-select border-0 bg-light py-2" style="font-weight: 600; border-radius: 8px;" required onchange="this.form.submit()">
                    <option value="">Choose Class...</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= $c['class_id'] ?>" <?= $selected_class == $c['class_id'] ? 'selected' : '' ?>>
                            <?= h($c['class_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-3">
                <label class="small fw-bold text-secondary text-uppercase mb-1" style="font-size: 10px;">Subject / Module</label>
                <select name="subject_id" class="form-select border-0 bg-light py-2" style="font-weight: 600; border-radius: 8px;" required>
                    <option value="">Choose Subject...</option>
                    <?php foreach ($subjects as $s): ?>
                        <option value="<?= $s['subject_id'] ?>" <?= $selected_subject == $s['subject_id'] ? 'selected' : '' ?>>
                            <?= h($s['subject_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-3">
                <label class="small fw-bold text-secondary text-uppercase mb-1" style="font-size: 10px;">Date</label>
                <input type="date" name="date" class="form-control border-0 bg-light py-2" value="<?= $selected_date ?>" required style="border-radius: 8px;">
            </div>
            <div class="col-lg-3 mt-lg-auto">
                <button type="submit" class="btn btn-primary w-100 py-2 shadow-sm fw-bold" style="border-radius: 8px;">
                    <i class="fas fa-users-viewfinder me-1"></i> LOAD CLASS LIST
                </button>
            </div>
        </form>
    </div>

    <?php if ($selected_class && !empty($students)): ?>
    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <form action="save.php" method="POST" id="attendanceForm">
            <input type="hidden" name="class_id" value="<?= $selected_class ?>">
            <input type="hidden" name="subject_id" value="<?= $selected_subject ?>">
            <input type="hidden" name="attendance_date" value="<?= $selected_date ?>">
            <input type="hidden" name="start_time" value="<?= $start_time ?>">

            <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold text-dark"><i class="fas fa-clipboard-list me-2 text-danger"></i>MARKING SHEET</h6>
                <div class="d-flex gap-2">
                    <button type="button" onclick="markAll('present')" class="btn btn-soft-success btn-sm fw-bold px-3" style="font-size: 10px; background: rgba(40,167,69,0.1); color:#28a745; border-radius: 20px;">
                        <i class="fas fa-check-double me-1"></i> ALL PRESENT
                    </button>
                    <button type="submit" class="btn btn-success btn-sm px-4 fw-bold shadow-sm" style="border-radius: 20px;">
                        <i class="fas fa-save me-1"></i> SAVE ALL
                    </button>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr class="small text-secondary fw-bold text-uppercase" style="font-size: 10px;">
                            <th class="ps-4">Student Identity</th>
                            <th class="text-center">Status Control</th>
                            <th class="pe-4">Special Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center">
                                    <div class="avatar-initials me-3" style="width:38px; height:38px; font-size: 0.8rem; background: #f8f9fa; color: #666; border: 1px solid #eee;">
                                        <?= strtoupper(substr($student['first_name'],0,1).substr($student['last_name'],0,1)) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark"><?= h($student['first_name'] . ' ' . $student['last_name']) ?></div>
                                        <div class="text-muted small" style="font-size: 10px;"><?= h($student['admission_number']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="d-inline-flex gap-1 p-1 bg-light rounded-pill border">
                                    <input type="radio" class="btn-check" name="status[<?= $student['student_id'] ?>]" id="p_<?= $student['student_id'] ?>" value="present" required>
                                    <label class="btn btn-outline-success btn-sm rounded-pill btn-status" for="p_<?= $student['student_id'] ?>">PRE</label>

                                    <input type="radio" class="btn-check" name="status[<?= $student['student_id'] ?>]" id="a_<?= $student['student_id'] ?>" value="absent">
                                    <label class="btn btn-outline-danger btn-sm rounded-pill btn-status" for="a_<?= $student['student_id'] ?>">ABS</label>

                                    <input type="radio" class="btn-check" name="status[<?= $student['student_id'] ?>]" id="e_<?= $student['student_id'] ?>" value="excused">
                                    <label class="btn btn-outline-warning btn-sm rounded-pill btn-status" for="e_<?= $student['student_id'] ?>">EXC</label>
                                </div>
                            </td>
                            <td class="pe-4">
                                <input type="text" name="remarks[<?= $student['student_id'] ?>]" class="form-control form-control-sm border-0 bg-light" placeholder="Optional remark..." style="font-size: 11px; border-radius: 6px;">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
    <?php elseif ($selected_class): ?>
        <div class="text-center py-5">
            <div class="text-muted mb-3"><i class="fas fa-user-slash fa-3x opacity-25"></i></div>
            <h5 class="text-muted">No active students found in this class.</h5>
        </div>
    <?php endif; ?>
</div>

<style>
    .btn-status { font-size: 9px !important; font-weight: 800 !important; padding: 4px 12px !important; border: none !important; }
    .btn-check:checked + .btn-outline-success { background: #28a745 !important; color: white !important; }
    .btn-check:checked + .btn-outline-danger { background: #dc3545 !important; color: white !important; }
    .btn-check:checked + .btn-outline-warning { background: #ffc107 !important; color: #856404 !important; }
</style>

<script>
function markAll(status) {
    document.querySelectorAll(`input[value="${status}"]`).forEach(input => input.checked = true);
}
</script>

<?php require_once '../../includes/footer.php'; ?>
