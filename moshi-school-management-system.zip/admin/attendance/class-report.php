<?php
require_once '../../includes/bootstrap.php';
requireLogin();

$page_title = "Class Attendance Matrix";
$role = $_SESSION['role'] ?? 'guest';

// For teachers: get their teacher_id and restrict to their classes
$teacher_filter_id = null;
if ($role === 'teacher') {
    $t_stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
    $t_stmt->execute([$_SESSION['user_id']]);
    $t_row = $t_stmt->fetch();
    $teacher_filter_id = $t_row['teacher_id'] ?? null;
}

// Fetch Classes (all for admin, only teacher's for teacher)
if ($teacher_filter_id) {
    $stmt = $pdo->prepare("
        SELECT DISTINCT c.* FROM classes c
        LEFT JOIN class_subjects cs ON c.class_id = cs.class_id
        WHERE cs.teacher_id = ? OR c.class_teacher_id = ?
        ORDER BY c.class_name
    ");
    $stmt->execute([$teacher_filter_id, $teacher_filter_id]);
} else {
    $stmt = $pdo->query("SELECT * FROM classes ORDER BY class_name");
}
$classes = $stmt->fetchAll();

$selected_class = $_GET['class_id'] ?? null;
$selected_date  = $_GET['date'] ?? date('Y-m-d');

// Validation for year limit
$selected_year = (int)date('Y', strtotime($selected_date));
$current_year  = (int)date('Y');
$date_error = "";

if ($selected_year > $current_year) {
    $date_error = "The selected year has not arrived yet (You cannot choose a future year like $selected_year).";
    $selected_class = null;
} elseif ($selected_year < 2024) {
    $date_error = "The selected year is in the past (You cannot choose a year before 2024).";
    $selected_class = null;
}

$attendance_matrix = [];
$subjects   = [];
$class_info = null;
$present_total = 0;
$absent_total  = 0;
$excused_total = 0;

if ($selected_class) {
    // Security: teachers can only view their own classes
    if ($teacher_filter_id) {
        $allowed_ids = array_column($classes, 'class_id');
        if (!in_array($selected_class, $allowed_ids)) {
            $selected_class = null;
        }
    }
}

if ($selected_class) {
    $stmt = $pdo->prepare("SELECT * FROM classes WHERE class_id = ?");
    $stmt->execute([$selected_class]);
    $class_info = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT DISTINCT s.subject_id, s.subject_name
        FROM subjects s
        JOIN attendance a ON s.subject_id = a.subject_id
        WHERE a.class_id = ? AND a.attendance_date = ?
    ");
    $stmt->execute([$selected_class, $selected_date]);
    $subjects = $stmt->fetchAll();

    $stmt = $pdo->prepare("
        SELECT s.student_id, s.first_name, s.last_name, s.admission_number,
               a.subject_id, a.status
        FROM students s
        LEFT JOIN attendance a ON s.student_id = a.student_id AND a.attendance_date = ?
        WHERE s.class_id = ? AND s.status = 'Active'
        ORDER BY s.first_name
    ");
    $stmt->execute([$selected_date, $selected_class]);
    $raw_data = $stmt->fetchAll();

    foreach ($raw_data as $row) {
        $attendance_matrix[$row['student_id']]['name'] = $row['first_name'] . ' ' . $row['last_name'];
        $attendance_matrix[$row['student_id']]['adm']  = $row['admission_number'];
        $attendance_matrix[$row['student_id']]['initials'] =
            strtoupper(substr($row['first_name'], 0, 1) . substr($row['last_name'], 0, 1));
        if ($row['subject_id']) {
            $attendance_matrix[$row['student_id']]['subjects'][$row['subject_id']] = $row['status'];
            if ($row['status'] == 'present')     $present_total++;
            elseif ($row['status'] == 'absent')  $absent_total++;
            elseif ($row['status'] == 'excused') $excused_total++;
        }
    }
}

$total_records  = $present_total + $absent_total + $excused_total;
$attend_rate    = $total_records > 0 ? round(($present_total / $total_records) * 100, 1) : 0;
$student_count  = count($attendance_matrix);

require_once '../../includes/header.php';
?>

<style>
/* ==============================================
   CLASS ATTENDANCE MATRIX — PREMIUM REDESIGN
   ============================================== */

.car-page { padding: 0 0 40px; }

/* ---- Filter Hero ---- */
.car-filter-hero {
    background: var(--premium-gradient);
    border: 2px solid var(--corporate-red);
    border-radius: 24px;
    padding: 36px 40px 32px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
    box-shadow: var(--premium-shadow);
}
.car-filter-hero::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 220px; height: 220px;
    background: rgba(148,0,0,0.03);
    border-radius: 50%;
    pointer-events: none;
}
.car-filter-hero::after {
    content: '';
    position: absolute;
    bottom: -80px; left: -40px;
    width: 280px; height: 280px;
    background: rgba(148,0,0,0.02);
    border-radius: 50%;
    pointer-events: none;
}
.car-hero-label {
    color: var(--corporate-red);
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.car-form-row {
    display: flex;
    align-items: flex-end;
    gap: 16px;
    flex-wrap: nowrap;
}
.car-form-col-wide { flex: 0 0 44%; min-width: 0; }
.car-form-col-date { flex: 0 0 28%; min-width: 160px; }
@media (max-width: 700px) {
    .car-form-row { flex-wrap: wrap; }
    .car-form-col-wide, .car-form-col-date { flex: 1 1 100%; }
}

.car-field-label {
    display: block;
    color: var(--secondary-text);
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 8px;
}
.car-select-wrap { position: relative; }
.car-select-ico {
    position: absolute;
    left: 15px; top: 50%;
    transform: translateY(-50%);
    color: #940000;
    font-size: 0.85rem;
    z-index: 2;
    pointer-events: none;
}
.car-select {
    width: 100%;
    padding: 14px 16px 14px 40px;
    background: rgba(255,255,255,0.97);
    border: none;
    border-radius: 14px;
    font-size: 0.875rem;
    font-weight: 600;
    color: #1a1a1a;
    font-family: inherit;
    appearance: none;
    -webkit-appearance: none;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    transition: box-shadow 0.2s, transform 0.2s;
}
.car-select:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(255,255,255,0.35), 0 4px 20px rgba(0,0,0,0.15);
    transform: translateY(-1px);
}
.car-date-input {
    width: 100%;
    padding: 14px 16px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 14px;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--primary-text);
    font-family: inherit;
    transition: background 0.2s, border-color 0.2s;
}
.car-date-input:focus {
    outline: none;
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.5);
}
.car-submit-btn {
    background: var(--corporate-red);
    color: #fff;
    border: none;
    border-radius: 14px;
    padding: 14px 28px;
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 1px;
    text-transform: uppercase;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 9px;
    box-shadow: 0 8px 25px rgba(148,0,0,0.2);
    transition: transform 0.2s, box-shadow 0.2s;
    font-family: inherit;
    margin-top: 24px;
    align-self: flex-start;
    white-space: nowrap;
}
.car-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 35px rgba(0,0,0,0.3);
}
.car-submit-btn:active { transform: scale(0.97); }
.car-btn-dot {
    width: 8px; height: 8px;
    background: #fff;
    border-radius: 50%;
    animation: pulse-dot 1.5s infinite;
}
@keyframes pulse-dot {
    0%,100% { opacity:1; transform:scale(1); }
    50%      { opacity:0.4; transform:scale(0.6); }
}

/* ---- Class Info Header Card ---- */
.car-class-header {
    background: #fff;
    border-radius: 20px;
    padding: 24px 32px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 30px rgba(0,0,0,0.06);
    border: 1px solid #f5f5f5;
    animation: fadeInUp 0.4s ease-out;
    flex-wrap: wrap;
    gap: 16px;
}
.car-class-left { display: flex; align-items: center; gap: 18px; }
.car-class-icon {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, #940000, #c0392b);
    color: #fff;
    border-radius: 16px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.3rem;
    box-shadow: 0 8px 20px rgba(148,0,0,0.25);
    flex-shrink: 0;
}
.car-class-name { font-size: 1.2rem; font-weight: 800; color: #1a1a1a; margin-bottom: 3px; }
.car-class-date {
    display: flex; align-items: center; gap: 6px;
    font-size: 0.8rem; color: #999; font-weight: 600;
}
.car-class-date i { color: #ccc; }

/* ---- Stats Strip ---- */
.car-stats-strip {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}
@media (max-width: 800px) { .car-stats-strip { grid-template-columns: repeat(2,1fr); } }
@media (max-width: 480px) { .car-stats-strip { grid-template-columns: 1fr; } }

.car-stat {
    background: #fff;
    border-radius: 16px;
    padding: 20px 18px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 18px rgba(0,0,0,0.04);
    position: relative;
    overflow: hidden;
    animation: fadeInUp 0.4s ease-out both;
    transition: transform 0.2s, box-shadow 0.2s;
}
.car-stat:hover { transform: translateY(-3px); box-shadow: 0 10px 30px rgba(0,0,0,0.09); }
.car-stat:nth-child(1) { animation-delay:0.05s; }
.car-stat:nth-child(2) { animation-delay:0.10s; }
.car-stat:nth-child(3) { animation-delay:0.15s; }
.car-stat:nth-child(4) { animation-delay:0.20s; }
.car-stat-bar-l {
    position: absolute;
    left: 0; top: 0;
    width: 4px; height: 100%;
    border-radius: 16px 0 0 16px;
}
.car-stat-ico {
    width: 40px; height: 40px;
    border-radius: 11px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem;
    margin-bottom: 12px;
}
.car-stat-num { font-size: 1.8rem; font-weight: 800; line-height: 1; margin-bottom: 4px; }
.car-stat-lbl { font-size: 0.72rem; color: #999; font-weight: 600; }
.car-stat-prog { margin-top: 12px; height: 3px; background: #f0f0f0; border-radius: 4px; overflow: hidden; }
.car-stat-prog-fill { height: 100%; border-radius: 4px; }

.cs-green .car-stat-bar-l { background: #940000; }
.cs-green .car-stat-ico   { background: #fff5f5; color: #940000; }
.cs-green .car-stat-num   { color: #940000; }
.cs-green .car-stat-prog-fill { background: #940000; }

.cs-blue .car-stat-bar-l  { background: #64748b; }
.cs-blue .car-stat-ico    { background: #f1f5f9; color: #64748b; }
.cs-blue .car-stat-num    { color: #64748b; }
.cs-blue .car-stat-prog-fill { background: #64748b; }

.cs-red .car-stat-bar-l   { background: #940000; opacity: 0.7; }
.cs-red .car-stat-ico     { background: #fff5f5; color: #940000; }
.cs-red .car-stat-num     { color: #940000; }
.cs-red .car-stat-prog-fill { background: #940000; }

.cs-amber .car-stat-bar-l { background: #94a3b8; }
.cs-amber .car-stat-ico   { background: #f8fafc; color: #94a3b8; }
.cs-amber .car-stat-num   { color: #94a3b8; }
.cs-amber .car-stat-prog-fill { background: #94a3b8; }

/* ---- Matrix Card ---- */
.car-matrix-card {
    background: #fff;
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 24px rgba(0,0,0,0.05);
    animation: fadeInUp 0.5s ease-out 0.25s both;
}
.car-matrix-head {
    padding: 20px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #f8f8f8;
}
.car-matrix-title {
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #bbb;
}
.car-matrix-legend {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
}
.car-legend-item {
    display: flex; align-items: center; gap: 5px;
    font-size: 0.72rem; font-weight: 600; color: #888;
}
.car-legend-dot {
    width: 20px; height: 20px;
    border-radius: 6px;
    display: flex; align-items: center; justify-content: center;
    font-size: 0.6rem; font-weight: 800; color: #fff;
}

/* ---- Matrix Table ---- */
.car-table { width: 100%; border-collapse: collapse; }
.car-table thead tr { background: #fafafa; }
.car-table th {
    padding: 11px 14px;
    font-size: 0.62rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: #ccc;
    text-align: center;
    border-bottom: 1px solid #f3f3f3;
    white-space: nowrap;
}
.car-table th.student-col { text-align: left; padding-left: 24px; min-width: 210px; }
.car-table tbody tr {
    border-bottom: 1px solid #fafafa;
    transition: background 0.15s;
}
.car-table tbody tr:last-child { border-bottom: none; }
.car-table tbody tr:hover { background: #fdfcfc; }
.car-table td {
    padding: 13px 14px;
    text-align: center;
    vertical-align: middle;
}
.car-table td.student-col { text-align: left; padding-left: 24px; }

.car-student-wrap { display: flex; align-items: center; gap: 10px; }
.car-student-avatar {
    width: 34px; height: 34px;
    border-radius: 10px;
    background: linear-gradient(135deg, #f5e5e5, #edd5d5);
    color: #940000;
    font-size: 0.7rem;
    font-weight: 800;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.car-student-name { font-size: 0.85rem; font-weight: 700; color: #1a1a1a; }
.car-student-adm  { font-size: 0.7rem; color: #bbb; font-weight: 600; margin-top: 1px; }

/* Status dots */
.car-dot {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px; height: 28px;
    border-radius: 8px;
    font-size: 0.65rem;
    font-weight: 800;
    letter-spacing: 0.2px;
}
.dot-present { background: #fff5f5; color: #940000; }
.dot-absent  { background: #f8fafc; color: #64748b; }
.dot-excused { background: #f1f5f9; color: #94a3b8; }
.dot-none    { background: #f5f5f5; color: #ccc; }

/* ---- Empty State ---- */
.car-empty {
    text-align: center;
    padding: 70px 20px;
    background: #fff;
    border-radius: 20px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
}
.car-empty-ico { font-size: 3.5rem; color: #eddede; margin-bottom: 18px; }
.car-empty-text { font-size: 0.9rem; font-weight: 700; color: #ccc; }

/* ---- Prompt ---- */
.car-prompt {
    text-align: center;
    padding: 70px 20px;
    background: #fff;
    border-radius: 20px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
}
.car-prompt-ico { font-size: 4rem; color: #f0e8e8; margin-bottom: 20px; }
.car-prompt-title { font-size: 1.05rem; font-weight: 700; color: #333; margin-bottom: 8px; }
.car-prompt-sub   { font-size: 0.85rem; color: #bbb; }

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(14px); }
    to   { opacity: 1; transform: translateY(0); }
}
</style>

<div class="car-page fade-in">

    <?php if (!empty($date_error)): ?>
        <div style="background: #fef2f2; border-left: 5px solid #ef4444; color: #991b1b; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; font-weight: 700; display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
            <i class="fas fa-exclamation-circle" style="font-size: 1.2rem;"></i> <?php echo h($date_error); ?>
        </div>
    <?php endif; ?>

    <!-- ====== FILTER HERO ====== -->
    <div class="car-filter-hero">
        <div class="car-hero-label">
            <i class="fas fa-th-large"></i> Class Attendance Matrix
        </div>
        <form method="GET" action="" id="car-form" onsubmit="return carValidate()">
            <div class="car-form-row">
                <!-- Class select -->
                <div class="car-form-col-wide">
                    <span class="car-field-label">Select Class Group</span>
                    <div class="car-select-wrap">
                        <i class="fas fa-chalkboard car-select-ico"></i>
                        <select name="class_id" class="car-select" id="car-class-select">
                            <option value="">Choose class...</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['class_id'] ?>" <?= $selected_class == $c['class_id'] ? 'selected' : '' ?>>
                                    <?= h($c['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Date -->
                <div class="car-form-col-date">
                    <span class="car-field-label">Date Coverage</span>
                    <input type="date" name="date" class="car-date-input" value="<?= $selected_date ?>">
                </div>

                <!-- Button -->
                <div>
                    <button type="submit" class="car-submit-btn" id="car-submit-btn">
                        <span class="car-btn-dot"></span>
                        <i class="fas fa-layer-group"></i> Generate Analytics
                    </button>
                </div>
            </div>
        </form>
    </div>

    <?php if ($selected_class && $class_info): ?>

    <!-- ====== CLASS HEADER ====== -->
    <div class="car-class-header">
        <div class="car-class-left">
            <div class="car-class-icon"><i class="fas fa-chalkboard-teacher"></i></div>
            <div>
                <div class="car-class-name"><?= h($class_info['class_name']) ?> — Attendance Matrix</div>
                <div class="car-class-date">
                    <i class="fas fa-calendar-day"></i>
                    <?= date('l, d F Y', strtotime($selected_date)) ?>
                </div>
            </div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <span style="background:rgba(148,0,0,0.07); color:#940000; border-radius:10px; padding:5px 14px; font-size:0.78rem; font-weight:700;">
                <i class="fas fa-users me-1"></i><?= $student_count ?> Students
            </span>
            <span style="background:#f5f5f5; color:#555; border-radius:10px; padding:5px 14px; font-size:0.78rem; font-weight:700;">
                <i class="fas fa-book-open me-1"></i><?= count($subjects) ?> Subjects
            </span>
        </div>
    </div>

    <?php if (!empty($attendance_matrix)): ?>

    <!-- ====== STATS STRIP ====== -->
    <div class="car-stats-strip">
        <div class="car-stat cs-green">
            <div class="car-stat-bar-l"></div>
            <div class="car-stat-ico"><i class="fas fa-percentage"></i></div>
            <div class="car-stat-num"><?= $attend_rate ?>%</div>
            <div class="car-stat-lbl">Attendance Rate</div>
            <div class="car-stat-prog">
                <div class="car-stat-prog-fill" style="width:<?= $attend_rate ?>%"></div>
            </div>
        </div>
        <div class="car-stat cs-blue">
            <div class="car-stat-bar-l"></div>
            <div class="car-stat-ico"><i class="fas fa-check-circle"></i></div>
            <div class="car-stat-num"><?= $present_total ?></div>
            <div class="car-stat-lbl">Present Records</div>
            <div class="car-stat-prog">
                <div class="car-stat-prog-fill" style="width:<?= $total_records>0?round(($present_total/$total_records)*100):0 ?>%"></div>
            </div>
        </div>
        <div class="car-stat cs-red">
            <div class="car-stat-bar-l"></div>
            <div class="car-stat-ico"><i class="fas fa-times-circle"></i></div>
            <div class="car-stat-num"><?= $absent_total ?></div>
            <div class="car-stat-lbl">Absent Records</div>
            <div class="car-stat-prog">
                <div class="car-stat-prog-fill" style="width:<?= $total_records>0?round(($absent_total/$total_records)*100):0 ?>%"></div>
            </div>
        </div>
        <div class="car-stat cs-amber">
            <div class="car-stat-bar-l"></div>
            <div class="car-stat-ico"><i class="fas fa-file-alt"></i></div>
            <div class="car-stat-num"><?= $excused_total ?></div>
            <div class="car-stat-lbl">Excused Records</div>
            <div class="car-stat-prog">
                <div class="car-stat-prog-fill" style="width:<?= $total_records>0?round(($excused_total/$total_records)*100):0 ?>%"></div>
            </div>
        </div>
    </div>

    <!-- ====== MATRIX TABLE ====== -->
    <div class="car-matrix-card">
        <div class="car-matrix-head">
            <div class="car-matrix-title">Subject-Wise Attendance Grid</div>
            <div class="car-matrix-legend">
                <div class="car-legend-item">
                    <div class="car-legend-dot" style="background:#fff5f5; color:#940000;">P</div>
                    <span>Present</span>
                </div>
                <div class="car-legend-item">
                    <div class="car-legend-dot" style="background:#f8fafc; color:#64748b;">A</div>
                    <span>Absent</span>
                </div>
                <div class="car-legend-item">
                    <div class="car-legend-dot" style="background:#f1f5f9; color:#94a3b8;">E</div>
                    <span>Excused</span>
                </div>
                <div class="car-legend-item">
                    <div class="car-legend-dot" style="background:#f5f5f5; color:#ccc;">—</div>
                    <span>No Record</span>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="car-table">
                <thead>
                    <tr>
                        <th class="student-col">Student Information</th>
                        <?php foreach ($subjects as $sub): ?>
                        <th title="<?= h($sub['subject_name']) ?>">
                            <?= h(implode(' ', array_map(fn($w) => strtoupper(substr($w,0,3)), explode(' ', $sub['subject_name'])))) ?>
                        </th>
                        <?php endforeach; ?>
                        <th>Summary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance_matrix as $sid => $data): ?>
                    <?php
                        $s_present = 0; $s_absent = 0; $s_excused = 0;
                        foreach ($data['subjects'] ?? [] as $status) {
                            if ($status == 'present')     $s_present++;
                            elseif ($status == 'absent')  $s_absent++;
                            elseif ($status == 'excused') $s_excused++;
                        }
                        $s_total = $s_present + $s_absent + $s_excused;
                        $s_rate  = $s_total > 0 ? round(($s_present / $s_total) * 100) : 0;
                    ?>
                    <tr>
                        <td class="student-col">
                            <div class="car-student-wrap">
                                <div class="car-student-avatar"><?= h($data['initials']) ?></div>
                                <div>
                                    <div class="car-student-name"><?= h($data['name']) ?></div>
                                    <div class="car-student-adm"><?= h($data['adm']) ?></div>
                                </div>
                            </div>
                        </td>
                        <?php foreach ($subjects as $sub): ?>
                        <td>
                            <?php
                                $status = $data['subjects'][$sub['subject_id']] ?? 'none';
                                if ($status == 'present')     { $dcls = 'dot-present'; $lbl = 'P'; }
                                elseif ($status == 'absent')  { $dcls = 'dot-absent';  $lbl = 'A'; }
                                elseif ($status == 'excused') { $dcls = 'dot-excused'; $lbl = 'E'; }
                                else                          { $dcls = 'dot-none';    $lbl = '—'; }
                            ?>
                            <span class="car-dot <?= $dcls ?>" title="<?= ucfirst($status) ?>"><?= $lbl ?></span>
                        </td>
                        <?php endforeach; ?>
                        <td>
                            <?php if ($s_total > 0): ?>
                            <div style="display:flex; align-items:center; gap:6px; justify-content:center;">
                                <div style="font-size:0.75rem; font-weight:800; color:<?= $s_rate >= 75 ? '#940000' : '#64748b' ?>">
                                    <?= $s_rate ?>%
                                </div>
                                <div style="width:40px; height:4px; background:#f0f0f0; border-radius:4px; overflow:hidden;">
                                    <div style="width:<?= $s_rate ?>%; height:100%; background:<?= $s_rate >= 75 ? '#940000' : '#64748b' ?>; border-radius:4px;"></div>
                                </div>
                            </div>
                            <?php else: ?>
                            <span style="color:#ddd; font-size:0.8rem;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php else: ?>
    <div class="car-empty">
        <div class="car-empty-ico"><i class="fas fa-calendar-times"></i></div>
        <div class="car-empty-text">No attendance records found for this date and class.</div>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <!-- Prompt -->
    <div class="car-prompt">
        <div class="car-prompt-ico"><i class="fas fa-chalkboard-teacher"></i></div>
        <div class="car-prompt-title">Select a Class to Start</div>
        <div class="car-prompt-sub">Choose a class and date above, then click <strong>Generate Analytics</strong></div>
    </div>
    <?php endif; ?>

</div>

<script>
function carValidate() {
    const sel = document.getElementById('car-class-select');
    if (!sel || !sel.value) {
        sel.style.boxShadow = '0 0 0 3px rgba(255,80,80,0.45)';
        setTimeout(() => { sel.style.boxShadow = ''; }, 900);
        alert('Please choose a class first.');
        return false;
    }
    const btn = document.getElementById('car-submit-btn');
    if (btn) {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        btn.style.opacity = '0.75';
        btn.style.pointerEvents = 'none';
    }
    return true;
}
</script>

<?php require_once '../../includes/footer.php'; ?>
