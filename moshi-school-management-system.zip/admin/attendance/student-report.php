<?php
require_once '../../includes/bootstrap.php';
requireLogin();

$page_title = "Attendance Analysis";
$role = $_SESSION['role'] ?? 'guest';

$selected_student = $_GET['student_id'] ?? null;
$start_date = $_GET['start_date'] ?? date('Y-01-01');
$end_date   = $_GET['end_date']   ?? date('Y-m-d');

// For teachers: restrict to their own classes only
$teacher_filter_id = null;
if ($role === 'teacher') {
    $t_stmt = $pdo->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
    $t_stmt->execute([$_SESSION['user_id']]);
    $t_row = $t_stmt->fetch();
    $teacher_filter_id = $t_row['teacher_id'] ?? null;
}

// Fetch Students grouped by class
if ($teacher_filter_id) {
    // Teacher: only see students from their assigned classes
    $stmt = $pdo->prepare("
        SELECT c.class_name, s.student_id, s.first_name, s.last_name, s.admission_number 
        FROM students s
        JOIN classes c ON s.class_id = c.class_id
        WHERE s.status = 'Active'
          AND (
            c.class_id IN (SELECT class_id FROM class_subjects WHERE teacher_id = ?)
            OR c.class_teacher_id = ?
          )
        ORDER BY c.class_name, s.first_name
    ");
    $stmt->execute([$teacher_filter_id, $teacher_filter_id]);
} else {
    // Admin: see all students
    $stmt = $pdo->query("
        SELECT c.class_name, s.student_id, s.first_name, s.last_name, s.admission_number 
        FROM students s
        JOIN classes c ON s.class_id = c.class_id
        WHERE s.status = 'Active'
        ORDER BY c.class_name, s.first_name
    ");
}
$all_students = $stmt->fetchAll(PDO::FETCH_ASSOC | PDO::FETCH_GROUP);

$attendance_history = [];
$student_info = null;

if ($selected_student) {
    // Security: if teacher, verify student belongs to their class
    if ($teacher_filter_id) {
        $allowed_ids = [];
        foreach ($all_students as $class_students) {
            foreach ($class_students as $s) {
                $allowed_ids[] = $s['student_id'];
            }
        }
        if (!in_array($selected_student, $allowed_ids)) {
            $db_error = "Security Check Failed: This student (ID: {$selected_student}) is not in your class. You are not authorized to view their report.";
            $selected_student = null; // Blocked - not their student
        }
    }
}

if ($selected_student) {
    try {
        $stmt = $pdo->prepare("SELECT s.*, c.class_name, c.stream FROM students s JOIN classes c ON s.class_id = c.class_id WHERE s.student_id = ?");
        $stmt->execute([$selected_student]);
        $student_info = $stmt->fetch();

        // LEFT JOIN so general attendance (null subject_id) is also included
        $stmt = $pdo->prepare("SELECT a.*, COALESCE(s.subject_name, 'General') as subject_name FROM attendance a LEFT JOIN subjects s ON a.subject_id = s.subject_id WHERE a.student_id = ? AND a.attendance_date BETWEEN ? AND ? ORDER BY a.attendance_date DESC, a.period ASC");
        $stmt->execute([$selected_student, $start_date, $end_date]);
        $attendance_history = $stmt->fetchAll();
    } catch (PDOException $e) {
        $db_error = $e->getMessage();
    }
}

require_once '../../includes/header.php';
?>

<style>
/* =============================================
   ATTENDANCE ANALYSIS — PREMIUM REDESIGN
   ============================================= */

.sar-page { padding: 0 0 40px; }

/* ---- Filter Hero Card ---- */
.sar-filter-hero {
    background: var(--premium-gradient);
    border: 2px solid var(--corporate-red);
    border-radius: 24px;
    padding: 36px 40px 32px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
    box-shadow: var(--premium-shadow);
}
.sar-filter-hero::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 220px; height: 220px;
    background: rgba(148,0,0,0.03);
    border-radius: 50%;
}
.sar-filter-hero::after {
    content: '';
    position: absolute;
    bottom: -80px; left: -40px;
    width: 280px; height: 280px;
    background: rgba(148,0,0,0.02);
    border-radius: 50%;
}
.sar-filter-hero-title {
    color: var(--corporate-red);
    font-size: 0.75rem;
    font-weight: 800;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.sar-filter-hero-title i { color: var(--corporate-red); opacity: 0.5; }

.sar-select-wrapper { position: relative; }
.sar-select-wrapper .sar-select-icon {
    position: absolute;
    left: 16px; top: 50%;
    transform: translateY(-50%);
    color: #940000;
    font-size: 0.9rem;
    z-index: 2;
    pointer-events: none;
}
.sar-select {
    width: 100%;
    padding: 14px 16px 14px 42px;
    background: rgba(255,255,255,0.97);
    border: none;
    border-radius: 14px;
    font-size: 0.9rem;
    font-weight: 600;
    color: #1a1a1a;
    font-family: inherit;
    appearance: none;
    -webkit-appearance: none;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    transition: box-shadow 0.2s, transform 0.2s;
}
.sar-select:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(255,255,255,0.4), 0 4px 20px rgba(0,0,0,0.15);
    transform: translateY(-1px);
}

.sar-date-label {
    color: var(--secondary-text);
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 8px;
    display: block;
}
.sar-date-input {
    width: 100%;
    padding: 13px 16px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 14px;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--primary-text);
    font-family: inherit;
    transition: background 0.2s, border-color 0.2s;
}
.sar-date-input:focus {
    outline: none;
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.5);
}
.sar-form-sep {
    color: #ddd;
    font-size: 1.1rem;
    padding-bottom: 14px;
    flex-shrink: 0;
}
.sar-analyze-btn {
    background: var(--corporate-red);
    color: #fff;
    border: none;
    border-radius: 14px;
    padding: 14px 32px;
    font-size: 0.875rem;
    font-weight: 800;
    letter-spacing: 1px;
    text-transform: uppercase;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 8px 25px rgba(148,0,0,0.2);
    transition: transform 0.2s, box-shadow 0.2s;
    font-family: inherit;
    margin-top: 24px;
    width: fit-content;
}
.sar-analyze-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 35px rgba(0,0,0,0.3);
}
.sar-analyze-btn:active { transform: scale(0.97); }
.sar-analyze-btn .btn-dot {
    width: 8px; height: 8px;
    background: #fff;
    border-radius: 50%;
    animation: pulse-dot 1.5s infinite;
}
@keyframes pulse-dot {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(0.7); }
}

/* ---- Filter Form Layout ---- */
.sar-form-row {
    display: flex;
    align-items: flex-end;
    gap: 14px;
    flex-wrap: nowrap;
}
.sar-form-col-wide { flex: 0 0 42%; min-width: 0; }
.sar-form-col-date { flex: 0 0 20%; min-width: 130px; }
.sar-form-sep {
    color: rgba(255,255,255,0.4);
    font-size: 1.1rem;
    padding-bottom: 14px;
    flex-shrink: 0;
}
@media (max-width: 700px) {
    .sar-form-row { flex-wrap: wrap; }
    .sar-form-col-wide, .sar-form-col-date { flex: 1 1 100%; }
    .sar-form-sep { display: none; }
}

/* ---- Student Profile Card ---- */
.sar-profile-card {
    background: #fff;
    border-radius: 20px;
    padding: 28px 32px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 30px rgba(0,0,0,0.06);
    border: 1px solid #f5f5f5;
    animation: fadeInUp 0.4s ease-out;
}
.sar-profile-left { display: flex; align-items: center; gap: 20px; }
.sar-avatar {
    width: 70px; height: 70px;
    background: linear-gradient(135deg, #940000, #c0392b);
    color: #fff;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: 800;
    box-shadow: 0 8px 20px rgba(148,0,0,0.3);
    flex-shrink: 0;
}
.sar-profile-name {
    font-size: 1.25rem;
    font-weight: 800;
    color: #1a1a1a;
    margin-bottom: 4px;
}
.sar-profile-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}
.sar-meta-chip {
    background: #f4f4f4;
    color: #555;
    border-radius: 8px;
    padding: 3px 10px;
    font-size: 0.75rem;
    font-weight: 600;
}
.sar-meta-chip.red-chip {
    background: rgba(148,0,0,0.08);
    color: #940000;
}
.sar-profile-right {
    background: linear-gradient(135deg, #fef9f9, #fff5f5);
    border: 1px solid rgba(148,0,0,0.1);
    border-radius: 16px;
    padding: 16px 24px;
    text-align: center;
    min-width: 120px;
}
.sar-period-label {
    font-size: 0.65rem;
    color: #999;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-bottom: 4px;
}
.sar-period-val {
    font-size: 0.8rem;
    font-weight: 700;
    color: #940000;
}

/* ---- Stats Grid ---- */
.sar-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 28px;
}
@media (max-width: 900px) { .sar-stats-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 500px) { .sar-stats-grid { grid-template-columns: 1fr; } }

.sar-stat-card {
    background: #fff;
    border-radius: 18px;
    padding: 22px 20px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
    animation: fadeInUp 0.5s ease-out both;
    transition: transform 0.25s, box-shadow 0.25s;
}
.sar-stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 35px rgba(0,0,0,0.1);
}
.sar-stat-card:nth-child(1) { animation-delay: 0.05s; }
.sar-stat-card:nth-child(2) { animation-delay: 0.1s; }
.sar-stat-card:nth-child(3) { animation-delay: 0.15s; }
.sar-stat-card:nth-child(4) { animation-delay: 0.2s; }

.sar-stat-accent {
    position: absolute;
    top: 0; left: 0;
    width: 4px;
    height: 100%;
    border-radius: 18px 0 0 18px;
}
.sar-stat-icon {
    width: 44px; height: 44px;
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem;
    margin-bottom: 14px;
}
.sar-stat-num {
    font-size: 2rem;
    font-weight: 800;
    line-height: 1;
    margin-bottom: 4px;
}
.sar-stat-lbl {
    font-size: 0.75rem;
    color: #888;
    font-weight: 600;
    letter-spacing: 0.3px;
}
.sar-stat-bar {
    margin-top: 14px;
    height: 4px;
    background: #f0f0f0;
    border-radius: 4px;
    overflow: hidden;
}
.sar-stat-bar-fill {
    height: 100%;
    border-radius: 4px;
    transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Variations */
.sc-green .sar-stat-accent { background: linear-gradient(180deg,#2ecc71,#27ae60); }
.sc-green .sar-stat-icon { background: #eafaf1; color: #27ae60; }
.sc-green .sar-stat-num { color: #27ae60; }
.sc-green .sar-stat-bar-fill { background: linear-gradient(90deg,#2ecc71,#27ae60); }

.sc-red .sar-stat-accent { background: linear-gradient(180deg,#e74c3c,#c0392b); }
.sc-red .sar-stat-icon { background: #fdf0ef; color: #c0392b; }
.sc-red .sar-stat-num { color: #c0392b; }
.sc-red .sar-stat-bar-fill { background: linear-gradient(90deg,#e74c3c,#c0392b); }

.sc-amber .sar-stat-accent { background: linear-gradient(180deg,#f39c12,#d68910); }
.sc-amber .sar-stat-icon { background: #fef9e7; color: #d68910; }
.sc-amber .sar-stat-num { color: #d68910; }
.sc-amber .sar-stat-bar-fill { background: linear-gradient(90deg,#f39c12,#d68910); }

.sc-blue .sar-stat-accent { background: linear-gradient(180deg,#3498db,#2980b9); }
.sc-blue .sar-stat-icon { background: #eaf4fb; color: #2980b9; }
.sc-blue .sar-stat-num { color: #2980b9; }
.sc-blue .sar-stat-bar-fill { background: linear-gradient(90deg,#3498db,#2980b9); }

/* ---- Chart + Table Section ---- */
.sar-bottom-grid {
    display: grid;
    grid-template-columns: 300px 1fr;
    gap: 22px;
    margin-bottom: 24px;
}
@media (max-width: 900px) { .sar-bottom-grid { grid-template-columns: 1fr; } }

.sar-donut-card {
    background: #fff;
    border-radius: 20px;
    padding: 28px 24px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    align-items: center;
    animation: fadeInUp 0.5s ease-out 0.25s both;
}
.sar-donut-title {
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #aaa;
    margin-bottom: 22px;
    align-self: flex-start;
}
.sar-donut-wrap {
    position: relative;
    width: 170px; height: 170px;
    margin-bottom: 24px;
}
.sar-donut-wrap canvas { display: block; }
.sar-donut-center {
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}
.sar-donut-pct {
    font-size: 1.6rem;
    font-weight: 800;
    color: #1a1a1a;
    line-height: 1;
}
.sar-donut-sub {
    font-size: 0.65rem;
    color: #999;
    font-weight: 600;
    letter-spacing: 0.5px;
}
.sar-legend {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.sar-legend-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.sar-legend-left {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    color: #444;
}
.sar-legend-dot {
    width: 10px; height: 10px;
    border-radius: 50%;
}
.sar-legend-count {
    font-size: 0.85rem;
    font-weight: 700;
    color: #1a1a1a;
}

/* ---- Table Card ---- */
.sar-table-card {
    background: #fff;
    border-radius: 20px;
    overflow: hidden;
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    animation: fadeInUp 0.5s ease-out 0.3s both;
}
.sar-table-head {
    padding: 22px 28px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #f5f5f5;
}
.sar-table-head-title {
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #aaa;
}
.sar-table-head-count {
    background: rgba(148,0,0,0.08);
    color: #940000;
    border-radius: 8px;
    padding: 3px 10px;
    font-size: 0.75rem;
    font-weight: 700;
}

.sar-table { width: 100%; border-collapse: collapse; }
.sar-table thead tr {
    background: #fafafa;
}
.sar-table th {
    padding: 12px 20px;
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: #bbb;
    text-align: left;
    border-bottom: 1px solid #f0f0f0;
}
.sar-table th:first-child { padding-left: 28px; }
.sar-table th:last-child { padding-right: 28px; }

.sar-table tbody tr {
    border-bottom: 1px solid #fafafa;
    transition: background 0.15s;
}
.sar-table tbody tr:last-child { border-bottom: none; }
.sar-table tbody tr:hover { background: #fdfcfc; }
.sar-table td {
    padding: 15px 20px;
    font-size: 0.875rem;
    color: #333;
    vertical-align: middle;
}
.sar-table td:first-child { padding-left: 28px; }
.sar-table td:last-child { padding-right: 28px; }

.sar-date-main { font-weight: 700; color: #1a1a1a; font-size: 0.875rem; }
.sar-date-time { font-size: 0.72rem; color: #bbb; font-weight: 600; margin-top: 2px; }

.sar-subject-pill {
    background: #f6f6f6;
    border-radius: 8px;
    padding: 5px 12px;
    font-size: 0.8rem;
    font-weight: 600;
    color: #444;
    display: inline-block;
}

.sar-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.3px;
    text-transform: uppercase;
}
.badge-present { background: #eafaf1; color: #27ae60; }
.badge-absent  { background: #fdf0ef; color: #c0392b; }
.badge-late    { background: #fef9e7; color: #d68910; }
.badge-present::before { content: '●'; font-size: 0.5rem; }
.badge-absent::before  { content: '●'; font-size: 0.5rem; }
.badge-late::before    { content: '●'; font-size: 0.5rem; }

.sar-remark { font-size: 0.8rem; color: #999; font-style: italic; }

/* Empty State */
.sar-empty {
    text-align: center;
    padding: 60px 20px;
}
.sar-empty-icon {
    font-size: 3rem;
    color: #e0e0e0;
    margin-bottom: 16px;
}
.sar-empty-text {
    font-size: 0.9rem;
    color: #bbb;
    font-weight: 600;
}

/* Animation */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(16px); }
    to   { opacity: 1; transform: translateY(0); }
}
</style>

<div class="sar-page fade-in">

    <!-- ====== FILTER HERO ====== -->
    <div class="sar-filter-hero">
        <div class="sar-filter-hero-title">
            <i class="fas fa-chart-bar"></i> Student Attendance Report
        </div>

        <form method="GET" action="" id="sar-form">
            <div class="sar-form-row">
                <!-- Student Select -->
                <div class="sar-form-col-wide">
                    <span class="sar-date-label">Select Student</span>
                    <div class="sar-select-wrapper">
                        <i class="fas fa-user-graduate sar-select-icon"></i>
                        <select name="student_id" class="sar-select" id="sar-student-select" onchange="if(this.value) this.form.submit();">
                            <option value="">Choose student name...</option>
                            <?php foreach ($all_students as $class_name => $students): ?>
                                <optgroup label="<?= h($class_name) ?>">
                                    <?php foreach ($students as $s): ?>
                                        <option value="<?= $s['student_id'] ?>" <?= $selected_student == $s['student_id'] ? 'selected' : '' ?>>
                                            <?= h($s['first_name'] . ' ' . $s['last_name'] . ' (' . $s['admission_number'] . ')') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Date From -->
                <div class="sar-form-col-date">
                    <span class="sar-date-label">Date From</span>
                    <input type="date" name="start_date" class="sar-date-input" value="<?= $start_date ?>">
                </div>

                <!-- Separator -->
                <div class="sar-form-sep">→</div>

                <!-- Date To -->
                <div class="sar-form-col-date">
                    <span class="sar-date-label">Date To</span>
                    <input type="date" name="end_date" class="sar-date-input" value="<?= $end_date ?>">
                </div>
            </div>
            <button type="submit" class="sar-analyze-btn" id="sar-submit-btn" style="pointer-events: auto; z-index: 999; position: relative;">
                <i class="fas fa-search" id="sar-btn-icon"></i>
                <span id="sar-btn-text">Analyze Report</span>
            </button>
        </form>
    </div>

    <?php if (isset($db_error)): ?>
    <div style="background: #fdf0ef; color: #c0392b; padding: 20px; border-radius: 14px; margin-bottom: 24px; border: 1px solid #f5c6cb;">
        <h4 style="margin-top: 0;"><i class="fas fa-exclamation-triangle"></i> Error Loading Data</h4>
        <p style="margin-bottom: 0;"><?= h($db_error) ?></p>
    </div>
    <?php endif; ?>

    <?php if ($student_info): ?>
    <?php
        $total   = count($attendance_history);
        $present = 0; $absent = 0; $late = 0;
        foreach($attendance_history as $rec) {
            if ($rec['status'] == 'present')  $present++;
            elseif ($rec['status'] == 'absent') $absent++;
            elseif ($rec['status'] == 'late')   $late++;
        }
        $rate       = $total > 0 ? round(($present / $total) * 100, 1) : 0;
        $absent_pct = $total > 0 ? round(($absent  / $total) * 100, 1) : 0;
        $late_pct   = $total > 0 ? round(($late    / $total) * 100, 1) : 0;
        $initials    = strtoupper(substr($student_info['first_name'],0,1) . substr($student_info['last_name'],0,1));
    ?>

    <!-- ====== STUDENT PROFILE CARD ====== -->
    <div class="sar-profile-card">
        <div class="sar-profile-left">
            <div class="sar-avatar"><?= $initials ?></div>
            <div>
                <div class="sar-profile-name"><?= h($student_info['first_name'] . ' ' . $student_info['last_name']) ?></div>
                <div class="sar-profile-meta">
                    <span class="sar-meta-chip red-chip"><i class="fas fa-id-card me-1"></i><?= h($student_info['admission_number']) ?></span>
                    <span class="sar-meta-chip"><i class="fas fa-school me-1"></i><?= h($student_info['class_name']) ?></span>
                    <?php if (!empty($student_info['stream'])): ?>
                    <span class="sar-meta-chip"><i class="fas fa-code-branch me-1"></i><?= h($student_info['stream']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="sar-profile-right">
            <div class="sar-period-label">Analysis Period</div>
            <div class="sar-period-val"><?= date('d M Y', strtotime($start_date)) ?></div>
            <div style="color:#ccc; font-size:0.6rem; margin: 3px 0;">to</div>
            <div class="sar-period-val"><?= date('d M Y', strtotime($end_date)) ?></div>
        </div>
    </div>

    <!-- ====== STATS GRID ====== -->
    <div class="sar-stats-grid">
        <!-- Attendance Rate -->
        <div class="sar-stat-card sc-green">
            <div class="sar-stat-accent"></div>
            <div class="sar-stat-icon"><i class="fas fa-percentage"></i></div>
            <div class="sar-stat-num"><?= $rate ?>%</div>
            <div class="sar-stat-lbl">Attendance Rate</div>
            <div class="sar-stat-bar">
                <div class="sar-stat-bar-fill" style="width: <?= $rate ?>%;"></div>
            </div>
        </div>

        <!-- Present -->
        <div class="sar-stat-card sc-blue">
            <div class="sar-stat-accent"></div>
            <div class="sar-stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="sar-stat-num"><?= $present ?></div>
            <div class="sar-stat-lbl">Sessions Present</div>
            <div class="sar-stat-bar">
                <div class="sar-stat-bar-fill" style="width: <?= $total > 0 ? round(($present/$total)*100) : 0 ?>%;"></div>
            </div>
        </div>

        <!-- Absent -->
        <div class="sar-stat-card sc-red">
            <div class="sar-stat-accent"></div>
            <div class="sar-stat-icon"><i class="fas fa-times-circle"></i></div>
            <div class="sar-stat-num"><?= $absent ?></div>
            <div class="sar-stat-lbl">Missed Sessions</div>
            <div class="sar-stat-bar">
                <div class="sar-stat-bar-fill" style="width: <?= $total > 0 ? round(($absent/$total)*100) : 0 ?>%;"></div>
            </div>
        </div>

        <!-- Late -->
        <div class="sar-stat-card sc-amber">
            <div class="sar-stat-accent"></div>
            <div class="sar-stat-icon"><i class="fas fa-clock"></i></div>
            <div class="sar-stat-num"><?= $late ?></div>
            <div class="sar-stat-lbl">Late Arrivals</div>
            <div class="sar-stat-bar">
                <div class="sar-stat-bar-fill" style="width: <?= $total > 0 ? round(($late/$total)*100) : 0 ?>%;"></div>
            </div>
        </div>
    </div>

    <!-- ====== DONUT + TABLE ====== -->
    <div class="sar-bottom-grid">

        <!-- Donut Chart -->
        <div class="sar-donut-card">
            <div class="sar-donut-title">Distribution</div>
            <div class="sar-donut-wrap">
                <canvas id="attendanceDonut" width="170" height="170"></canvas>
                <div class="sar-donut-center">
                    <div class="sar-donut-pct"><?= $rate ?>%</div>
                    <div class="sar-donut-sub">PRESENT</div>
                </div>
            </div>
            <div class="sar-legend">
                <div class="sar-legend-item">
                    <div class="sar-legend-left">
                        <div class="sar-legend-dot" style="background:#3498db;"></div>
                        Present
                    </div>
                    <div class="sar-legend-count"><?= $present ?></div>
                </div>
                <div class="sar-legend-item">
                    <div class="sar-legend-left">
                        <div class="sar-legend-dot" style="background:#e74c3c;"></div>
                        Absent
                    </div>
                    <div class="sar-legend-count"><?= $absent ?></div>
                </div>
                <div class="sar-legend-item">
                    <div class="sar-legend-left">
                        <div class="sar-legend-dot" style="background:#f39c12;"></div>
                        Late
                    </div>
                    <div class="sar-legend-count"><?= $late ?></div>
                </div>
                <div class="sar-legend-item" style="border-top:1px solid #f5f5f5; padding-top:10px; margin-top:2px;">
                    <div class="sar-legend-left" style="font-weight:700; color:#1a1a1a;">
                        Total Sessions
                    </div>
                    <div class="sar-legend-count"><?= $total ?></div>
                </div>
            </div>
        </div>

        <!-- Records Table -->
        <div class="sar-table-card">
            <div class="sar-table-head">
                <div class="sar-table-head-title">Detailed Records Log</div>
                <div class="sar-table-head-count"><?= $total ?> Records</div>
            </div>
            <div class="table-responsive" style="max-height: 460px; overflow-y: auto;">
                <table class="sar-table">
                    <thead>
                        <tr>
                            <th>Date & Time</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($attendance_history)): ?>
                        <tr>
                            <td colspan="4">
                                <div class="sar-empty">
                                    <div class="sar-empty-icon"><i class="fas fa-calendar-times"></i></div>
                                    <div class="sar-empty-text">No records found for this period</div>
                                </div>
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($attendance_history as $row): ?>
                        <tr>
                            <td>
                                <div class="sar-date-main"><?= date('d M Y', strtotime($row['attendance_date'])) ?></div>
                                <div class="sar-date-time"><i class="fas fa-hashtag" style="font-size:0.6rem;"></i> Period <?= $row['period'] ?? '—' ?></div>
                            </td>
                            <td>
                                <span class="sar-subject-pill">
                                    <i class="fas fa-book-open" style="font-size:0.65rem; margin-right:5px; color:#aaa;"></i>
                                    <?= h($row['subject_name']) ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                    $s = $row['status'];
                                    if ($s == 'present')    { $bcls = 'badge-present'; $ico = 'fa-check'; }
                                    elseif ($s == 'absent') { $bcls = 'badge-absent';  $ico = 'fa-times'; }
                                    else                    { $bcls = 'badge-late';    $ico = 'fa-clock'; }
                                ?>
                                <span class="sar-status-badge <?= $bcls ?>">
                                    <?= ucfirst(h($s)) ?>
                                </span>
                            </td>
                            <td>
                                <span class="sar-remark"><?= h($row['remarks'] ?: '—') ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Inline Chart Script -->
    <script>
    (function() {
        const canvas = document.getElementById('attendanceDonut');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const W = canvas.width, H = canvas.height;
        const cx = W/2, cy = H/2, r = 68, inner = 48;

        const data = [
            { val: <?= $present ?>, color: '#3498db' },
            { val: <?= $absent  ?>, color: '#e74c3c' },
            { val: <?= $late    ?>, color: '#f39c12' }
        ];
        const total = data.reduce((a,d) => a + d.val, 0) || 1;

        function drawDonut(progress) {
            ctx.clearRect(0, 0, W, H);
            let start = -Math.PI / 2;
            const gap = 0.04;

            if (total === 0) {
                ctx.beginPath();
                ctx.arc(cx, cy, r, 0, Math.PI * 2);
                ctx.arc(cx, cy, inner, Math.PI * 2, 0, true);
                ctx.fillStyle = '#f0f0f0';
                ctx.fill();
                return;
            }

            data.forEach(d => {
                if (d.val === 0) return;
                const sweep = (d.val / total) * Math.PI * 2 * progress - gap;
                if (sweep <= 0) return;

                ctx.beginPath();
                ctx.arc(cx, cy, r, start + gap/2, start + sweep + gap/2);
                ctx.arc(cx, cy, inner, start + sweep + gap/2, start + gap/2, true);
                ctx.closePath();

                const grad = ctx.createRadialGradient(cx, cy, inner, cx, cy, r);
                grad.addColorStop(0, d.color + 'cc');
                grad.addColorStop(1, d.color);
                ctx.fillStyle = grad;
                ctx.shadowColor = d.color + '55';
                ctx.shadowBlur = 6;
                ctx.fill();
                ctx.shadowBlur = 0;

                start += (d.val / total) * Math.PI * 2 * progress;
            });
        }

        let prog = 0;
        const anim = setInterval(() => {
            prog = Math.min(prog + 0.03, 1);
            drawDonut(prog);
            if (prog >= 1) clearInterval(anim);
        }, 16);
    })();
    </script>

    <?php endif; ?>

    <?php if (!$student_info): ?>
    <!-- Prompt when no student selected -->
    <div style="text-align:center; padding: 60px 20px; background:#fff; border-radius:20px; border:1px solid #f0f0f0; box-shadow:0 4px 20px rgba(0,0,0,0.05);">
        <div style="font-size:4rem; color:#f0e8e8; margin-bottom:20px;"><i class="fas fa-user-graduate"></i></div>
        <div style="font-size:1.05rem; font-weight:700; color:#333; margin-bottom:8px;">Select a Student to Begin</div>
        <div style="font-size:0.85rem; color:#bbb;">Choose a student and date range above, then click <strong>Analyze Report</strong></div>
    </div>
    </div>
    <?php endif; ?>

</div>

<?php require_once '../../includes/footer.php'; ?>
