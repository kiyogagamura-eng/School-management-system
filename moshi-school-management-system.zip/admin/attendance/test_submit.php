<?php
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['PHP_SELF'] = '/admin/attendance/student-report.php';
$_GET = ['student_id' => '1', 'start_date' => '2026-01-01', 'end_date' => '2026-04-06'];

require_once 'includes/bootstrap.php';
// Mock teacher login
$stmt = $pdo->query("SELECT user_id, role FROM users WHERE role = 'teacher' AND username = 'teacher'");
$teacher_user = $stmt->fetch();
if (!$teacher_user) {
    $teacher_user = $pdo->query("SELECT user_id, role FROM users WHERE role = 'teacher'")->fetch();
}

session_start();
$_SESSION['user_id'] = $teacher_user['user_id'];
$_SESSION['role'] = $teacher_user['role'];

// Now intercept output of student-report
ob_start();
require 'admin/attendance/student-report.php';
$html = ob_get_clean();

// Check if there are any specific errors in the output
if (strpos($html, 'Error Loading Data') !== false) {
    echo "Found Error Loading Data!\n";
    preg_match('/<p style="margin-bottom: 0;">(.*?)<\/p>/', $html, $matches);
    echo $matches[1] . "\n";
} else if (strpos($html, 'Select a Student to Begin') !== false) {
    echo "Student was blocked by security check!\n";
} else {
    echo "Report generated successfully!\n";
    preg_match('/<div class="sar-profile-name">(.*?)<\/div>/', $html, $matches);
    echo "Loaded student profile for: " . ($matches[1] ?? 'Unknown') . "\n";
}
