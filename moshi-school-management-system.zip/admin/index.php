<?php
require_once '../includes/bootstrap.php';
requireRole('admin');
header("Location: dashboard.php");
exit();
?>
