<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['id'])) {
    redirect('index.php', 'No class selected.', 'error');
}
$class_id = $_GET['id'];

// Get class info
$stmt = $pdo->prepare("
    SELECT c.*, t.first_name, t.last_name, t.employee_id
    FROM classes c 
    LEFT JOIN teachers t ON c.class_teacher_id = t.teacher_id 
    WHERE c.class_id = ?
");
$stmt->execute([$class_id]);
$class_info = $stmt->fetch();

if (!$class_info) {
    redirect('index.php', 'Class not found.', 'error');
}

$page_title = "Class Details: " . h($class_info['class_name']);

// Get students and today's attendance status (checking the first period marked today as the daily status)
$today = date('Y-m-d');
$stmt = $pdo->prepare("
    SELECT s.*, 
    (SELECT status FROM attendance a WHERE a.student_id = s.student_id AND a.attendance_date = ? ORDER BY period ASC LIMIT 1) as today_status,
    (SELECT remarks FROM attendance a WHERE a.student_id = s.student_id AND a.attendance_date = ? ORDER BY period ASC LIMIT 1) as today_remarks
    FROM students s
    WHERE s.class_id = ? AND s.status = 'Active'
    ORDER BY s.first_name, s.last_name
");
$stmt->execute([$today, $today, $class_id]);
$students = $stmt->fetchAll();

// Calculate stats
$total = count($students);
$present = 0;
$absent = 0;
$late = 0;
$not_marked = 0;

$absent_students = [];

foreach ($students as $s) {
    if ($s['today_status'] === 'present') {
        $present++;
    } elseif ($s['today_status'] === 'absent') {
        $absent++;
        $absent_students[] = $s;
    } elseif ($s['today_status'] === 'late') {
        $late++;
    } else {
        $not_marked++;
    }
}

$attendance_rate = $total > 0 ? round((($present + $late) / $total) * 100, 1) : 0;

require_once '../../includes/header.php';
?>
<style>
    .stat-card {
        background: var(--primary-white);
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        border: 1px solid rgba(148,0,0,0.05);
    }
    .stat-card .num {
        font-size: 32px;
        font-weight: 700;
        margin-bottom: 5px;
    }
    .stat-card .label {
        font-size: 12px;
        color: var(--secondary-text);
        text-transform: uppercase;
        font-weight: 700;
        letter-spacing: 1px;
    }
    .status-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
    }
    .status-present { background: rgba(39, 174, 96, 0.1); color: #27ae60; }
    .status-absent { background: rgba(231, 76, 60, 0.1); color: #e74c3c; }
    .status-late { background: rgba(243, 156, 18, 0.1); color: #f39c12; }
    .status-none { background: #eee; color: #7f8c8d; }
</style>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700; text-decoration: none;"><i class="fas fa-arrow-left"></i> Back to Classes</a>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; background: white; padding: 25px; border-radius: 12px; border-left: 5px solid var(--corporate-red); box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <div>
            <h2 style="margin: 0; color: var(--corporate-red); margin-bottom: 5px;"><i class="fas fa-door-open"></i> <?php echo h($class_info['class_name']); ?></h2>
            <div style="color: var(--secondary-text); font-size: 14px; display: flex; gap: 20px;">
                <span><b>Form Level:</b> <?php echo h($class_info['form_level']); ?></span>
                <span><b>Stream:</b> <?php echo h($class_info['stream']); ?></span>
                <span><b>Class Teacher:</b> <?php echo $class_info['first_name'] ? h($class_info['first_name'] . ' ' . $class_info['last_name']) : '<span style="color: #e74c3c;">Not Assigned</span>'; ?></span>
            </div>
        </div>
        <div>
            <a href="../users/add-student.php?class_id=<?php echo $class_id; ?>" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add Student</a>
        </div>
    </div>

    <!-- Today's Attendance Summary -->
    <h3 style="margin-bottom: 15px; color: var(--primary-text);"><i class="fas fa-calendar-day"></i> Today's Attendance Summary (<?php echo date('d M Y'); ?>)</h3>
    
    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="border-bottom: 4px solid var(--primary-text);">
            <div class="num"><?php echo $total; ?></div>
            <div class="label">Total Students</div>
        </div>
        <div class="stat-card" style="border-bottom: 4px solid #27ae60;">
            <div class="num" style="color: #27ae60;"><?php echo $present; ?></div>
            <div class="label">Present</div>
        </div>
        <div class="stat-card" style="border-bottom: 4px solid #e74c3c;">
            <div class="num" style="color: #e74c3c;"><?php echo $absent; ?></div>
            <div class="label">Absent</div>
        </div>
        <div class="stat-card" style="border-bottom: 4px solid #f39c12;">
            <div class="num" style="color: #f39c12;"><?php echo $late; ?></div>
            <div class="label">Late</div>
        </div>
        <div class="stat-card" style="background: var(--corporate-red); color: white;">
            <div class="num" style="color: white;"><?php echo $attendance_rate; ?>%</div>
            <div class="label" style="color: rgba(255,255,255,0.8);">Attendance Rate</div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
        <!-- Full Roster -->
        <div class="card" style="border-top: 3px solid var(--corporate-red);">
            <div class="card-header" style="background: var(--header-gradient); display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin: 0; font-size: 16px;"><i class="fas fa-list"></i> Full Student Roster</h3>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if ($students): ?>
                <table class="table" style="margin: 0;">
                    <thead style="background: #f8f9fa;">
                        <tr>
                            <th>Adm. Number</th>
                            <th>Student Name</th>
                            <th>Gender</th>
                            <th>Today's Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?php echo h($s['admission_number']); ?></td>
                            <td><a href="../users/student-profile.php?id=<?php echo $s['student_id']; ?>" style="color: var(--primary-text); font-weight: 700; text-decoration: none;"><?php echo h($s['first_name'] . ' ' . $s['middle_name'] . ' ' . $s['last_name']); ?></a></td>
                            <td><?php echo h($s['gender']); ?></td>
                            <td>
                                <?php if ($s['today_status'] === 'present'): ?>
                                    <span class="status-badge status-present">Present</span>
                                <?php elseif ($s['today_status'] === 'absent'): ?>
                                    <span class="status-badge status-absent">Absent</span>
                                <?php elseif ($s['today_status'] === 'late'): ?>
                                    <span class="status-badge status-late">Late</span>
                                <?php else: ?>
                                    <span class="status-badge status-none">Not Marked</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div style="padding: 30px; text-align: center; color: var(--secondary-text);">
                    <p>No active students in this class.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Absent Students Highlight -->
        <div class="card" style="border-top: 3px solid #e74c3c;">
            <div class="card-header" style="background: #fffafa; display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin: 0; font-size: 16px; color: #e74c3c;"><i class="fas fa-user-times"></i> Absent Today</h3>
                <span class="badge badge-red" style="padding: 5px 10px; border-radius: 20px; background: #e74c3c; color: white;"><?php echo $absent; ?> Students</span>
            </div>
            <div class="card-body">
                <?php if ($absent_students): ?>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <?php foreach ($absent_students as $as): ?>
                        <li style="padding: 12px 0; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-weight: 700; color: var(--primary-text); font-size: 14px;"><?php echo h($as['first_name'] . ' ' . $as['last_name']); ?></div>
                                <div style="font-size: 11px; color: var(--secondary-text);"><?php echo h($as['admission_number']); ?></div>
                                <?php if ($as['today_remarks']): ?>
                                    <div style="font-size: 11px; color: #e74c3c; margin-top: 3px;"><i class="fas fa-comment"></i> <?php echo h($as['today_remarks']); ?></div>
                                <?php endif; ?>
                            </div>
                            <a href="../communication/index.php?tab=sms&student_id=<?php echo $as['student_id']; ?>" class="btn btn-outline" style="border-color: #e74c3c; color: #e74c3c; padding: 5px 10px; font-size: 11px;"><i class="fas fa-envelope"></i> SMS Parent</a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div style="text-align: center; padding: 20px 0; color: #27ae60;">
                        <i class="fas fa-check-circle fa-3x" style="margin-bottom: 10px;"></i>
                        <p style="font-weight: 700; font-size: 14px;">Perfect Attendance!</p>
                        <p style="font-size: 12px;">No students marked absent today.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
