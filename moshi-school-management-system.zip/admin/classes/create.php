<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Create New Class";

$error = '';
$success = '';

// Fetch teachers for dropdown
try {
    $stmt = $pdo->query("SELECT teacher_id, first_name, last_name FROM teachers WHERE status = 'Active' ORDER BY first_name ASC");
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = trim($_POST['class_name']);
    $form_level = (int)$_POST['form_level'];
    $stream = trim($_POST['stream']);
    $academic_year = trim($_POST['academic_year']);
    $capacity = (int)$_POST['capacity'];
    $class_teacher_id = !empty($_POST['class_teacher_id']) ? $_POST['class_teacher_id'] : null;

    if (empty($class_name)) {
        $error = "Class name is required.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO classes (class_name, form_level, stream, academic_year, capacity, class_teacher_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$class_name, $form_level, $stream, $academic_year, $capacity, $class_teacher_id]);
            redirect('index.php', "Class $class_name created successfully.");
        } catch (PDOException $e) {
            $error = "Error creating class: " . $e->getMessage();
        }
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Classes</a>
    </div>

        <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
            <div class="card-header" style="background: var(--header-gradient);">
                <h3 style="margin: 0;"><i class="fas fa-chalkboard"></i> <?php echo $page_title; ?></h3>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="error-msg" style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group" style="grid-column: span 2;">
                            <label>Class Name <span class="text-red">*</span></label>
                            <input type="text" name="class_name" class="form-control" required placeholder="e.g. Form 1A">
                            <small style="color: var(--secondary-text);">Naming convention: Form [Level] [Stream]</small>
                        </div>
                        <div class="form-group">
                            <label>Form Level <span class="text-red">*</span></label>
                            <select name="form_level" class="form-control" required>
                                <option value="1">Form 1</option>
                                <option value="2">Form 2</option>
                                <option value="3">Form 3</option>
                                <option value="4">Form 4</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Stream <span class="text-red">*</span></label>
                            <input type="text" name="stream" class="form-control" required placeholder="e.g. A">
                        </div>
                        <div class="form-group">
                            <label>Academic Year <span class="text-red">*</span></label>
                            <input type="text" name="academic_year" class="form-control" required value="<?php echo date('Y'); ?>">
                        </div>
                        <div class="form-group">
                            <label>Class Capacity <span class="text-red">*</span></label>
                            <input type="number" name="capacity" class="form-control" required value="40">
                        </div>
                        <div class="form-group" style="grid-column: span 2;">
                            <label>Class Teacher</label>
                            <select name="class_teacher_id" class="form-control">
                                <option value="">Assign Later...</option>
                                <?php foreach ($teachers as $t): ?>
                                    <option value="<?php echo $t['teacher_id']; ?>"><?php echo h($t['first_name'] . ' ' . $t['last_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small style="color: var(--secondary-text);">Only active teachers are listed.</small>
                        </div>
                    </div>

                    <div style="margin-top: 40px; display: flex; gap: 15px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1;">CREATE NEW CLASS</button>
                        <a href="index.php" class="btn btn-outline" style="flex: 1;">CANCEL</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
