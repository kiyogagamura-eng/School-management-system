<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

if (!isset($_GET['id'])) {
    redirect('index.php', "Class ID required.");
}

$id = $_GET['id'];

try {
    $pdo->beginTransaction();

    // 1. Check if class has students
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ?");
    $stmt->execute([$id]);
    if ($stmt->fetchColumn() > 0) {
        throw new Exception("Cannot delete class. It still contains active students. Move students first.");
    }

    // 2. Clear subject links
    $pdo->prepare("DELETE FROM class_subjects WHERE class_id = ?")->execute([$id]);
    
    // 3. Delete Class
    $pdo->prepare("DELETE FROM classes WHERE class_id = ?")->execute([$id]);

    $pdo->commit();
    redirect('index.php', "Class deleted successfully.");
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redirect('index.php', $e->getMessage(), "error");
}
?>
