<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Assign Subjects to Class";

$error = '';
$success = '';

// Fetch all classes for selection
try {
    $stmt = $pdo->query("SELECT * FROM classes ORDER BY class_name ASC");
    $classes = $stmt->fetchAll();

    $stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name ASC");
    $subjects = $stmt->fetchAll();

    $stmt = $pdo->query("SELECT * FROM teachers WHERE status = 'Active' ORDER BY first_name ASC");
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_id = $_POST['class_id'];
    $subject_id = $_POST['subject_id'];
    $teacher_id = $_POST['teacher_id'];
    $academic_term = trim($_POST['academic_term']);

    if (empty($class_id) || empty($subject_id) || empty($teacher_id)) {
        $error = "All fields are required.";
    } else {
        try {
            // Check if already assigned
            $check = $pdo->prepare("SELECT id FROM class_subjects WHERE class_id = ? AND subject_id = ? AND academic_term = ?");
            $check->execute([$class_id, $subject_id, $academic_term]);
            
            if ($check->rowCount() > 0) {
                $error = "This subject is already assigned to this class for the specified term.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO class_subjects (class_id, subject_id, teacher_id, academic_term) VALUES (?, ?, ?, ?)");
                $stmt->execute([$class_id, $subject_id, $teacher_id, $academic_term]);
                $success = "Subject successfully assigned to class.";
            }
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Fetch existing assignments
try {
    $stmt = $pdo->query("
        SELECT cs.*, c.class_name, s.subject_name, s.subject_code, t.first_name, t.last_name 
        FROM class_subjects cs
        JOIN classes c ON cs.class_id = c.class_id
        JOIN subjects s ON cs.subject_id = s.subject_id
        JOIN teachers t ON cs.teacher_id = t.teacher_id
        ORDER BY c.class_name ASC, s.subject_name ASC
    ");
    $assignments = $stmt->fetchAll();
} catch (PDOException $e) {
    $assignments = [];
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <header class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <h2 style="margin: 0;"><?php echo $page_title; ?></h2>
        <p style="color: var(--secondary-text); margin-top: 5px;">Link subjects to classes and assign teachers for the current term.</p>
    </header>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px;">
                <!-- Assignment Form -->
                <div>
                    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
                        <div class="card-header">Create Assignment</div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 12px; border-radius: 5px; margin-bottom: 20px; font-size: 0.85rem; border-left: 3px solid var(--corporate-red);"><?php echo $error; ?></div>
                            <?php endif; ?>
                            <?php if ($success): ?>
                                <div style="background: #e8f5e9; color: #2e7d32; padding: 12px; border-radius: 5px; margin-bottom: 20px; font-size: 0.85rem; border-left: 3px solid #2e7d32;"><?php echo $success; ?></div>
                            <?php endif; ?>

                            <form action="" method="POST">
                                <div class="form-group">
                                    <label>Select Class</label>
                                    <select name="class_id" class="form-control" required>
                                        <option value="">-- Choose Class --</option>
                                        <?php foreach ($classes as $c): ?><option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Select Subject</label>
                                    <select name="subject_id" class="form-control" required>
                                        <option value="">-- Choose Subject --</option>
                                        <?php foreach ($subjects as $s): ?><option value="<?php echo $s['subject_id']; ?>"><?php echo h($s['subject_name'] . ' (' . $s['subject_code'] . ')'); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Select Teacher</label>
                                    <select name="teacher_id" class="form-control" required>
                                        <option value="">-- Choose Teacher --</option>
                                        <?php foreach ($teachers as $t): ?><option value="<?php echo $t['teacher_id']; ?>"><?php echo h($t['first_name'] . ' ' . $t['last_name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Academic Term</label>
                                    <input type="text" name="academic_term" class="form-control" required value="Term 1, <?php echo date('Y'); ?>">
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">ASSIGN SUBJECT</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Assignment List -->
                <div>
                    <div class="card">
                        <div class="card-header">Current Assignments</div>
                        <div class="card-body">
                            <table class="table" style="font-size: 0.85rem;">
                                <thead>
                                    <tr>
                                        <th>Class</th>
                                        <th>Subject</th>
                                        <th>Teacher</th>
                                        <th>Term</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($assignments)): ?>
                                        <tr><td colspan="5" style="text-align: center; color: var(--secondary-text);">No assignments yet.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($assignments as $a): ?>
                                            <tr>
                                                <td style="font-weight: 700; color: var(--corporate-red);"><?php echo h($a['class_name']); ?></td>
                                                <td><?php echo h($a['subject_name']); ?></td>
                                                <td><?php echo h($a['first_name'] . ' ' . $a['last_name']); ?></td>
                                                <td><?php echo h($a['academic_term']); ?></td>
                                                <td>
                                                    <a href="javascript:void(0)" 
                                                       class="btn-delete-confirm"
                                                       data-url="remove.php?id=<?php echo $a['id']; ?>" 
                                                       data-name="<?php echo h($a['subject_name']); ?> for <?php echo h($a['class_name']); ?>"
                                                       data-type="Assignment"
                                                       style="color: var(--corporate-red);"><i class="fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
