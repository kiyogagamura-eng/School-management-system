<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Edit Class";

if (!isset($_GET['id'])) {
    redirect('index.php', "Class ID required.");
}

$id = $_GET['id'];
$error = '';
$success = '';

// Fetch class details
try {
    $stmt = $pdo->prepare("SELECT * FROM classes WHERE class_id = ?");
    $stmt->execute([$id]);
    $class = $stmt->fetch();
    
    if (!$class) {
        redirect('index.php', "Class not found.");
    }
} catch (PDOException $e) {
    redirect('index.php', "Database error.");
}

// Fetch teachers for dropdown
try {
    $stmt = $pdo->query("SELECT teacher_id, first_name, last_name FROM teachers WHERE status = 'Active' ORDER BY first_name ASC");
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = trim($_POST['class_name']);
    $form_level = (int)$_POST['form_level'];
    $stream = trim($_POST['stream']);
    $academic_year = trim($_POST['academic_year']);
    $capacity = (int)$_POST['capacity'];
    $class_teacher_id = !empty($_POST['class_teacher_id']) ? $_POST['class_teacher_id'] : null;

    if (empty($class_name)) {
        $error = "Class name is required.";
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE classes SET class_name = ?, form_level = ?, stream = ?, academic_year = ?, capacity = ?, class_teacher_id = ? WHERE class_id = ?");
            $stmt->execute([$class_name, $form_level, $stream, $academic_year, $capacity, $class_teacher_id, $id]);
            redirect('index.php', "Class $class_name updated successfully.");
        } catch (PDOException $e) {
            $error = "Error updating class: " . $e->getMessage();
        }
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="index.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Classes</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
        <div class="card-header" style="background: var(--header-gradient);">
            <h3 style="margin: 0;"><i class="fas fa-edit"></i> <?php echo $page_title; ?></h3>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="error-msg" style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--corporate-red);">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Class Name <span class="text-red">*</span></label>
                        <input type="text" name="class_name" class="form-control" required value="<?php echo h($class['class_name']); ?>">
                        <small style="color: var(--secondary-text);">Naming convention: Form [Level] [Stream]</small>
                    </div>
                    <div class="form-group">
                        <label>Form Level <span class="text-red">*</span></label>
                        <select name="form_level" class="form-control" required>
                            <option value="1" <?php echo $class['form_level'] == 1 ? 'selected' : ''; ?>>Form 1</option>
                            <option value="2" <?php echo $class['form_level'] == 2 ? 'selected' : ''; ?>>Form 2</option>
                            <option value="3" <?php echo $class['form_level'] == 3 ? 'selected' : ''; ?>>Form 3</option>
                            <option value="4" <?php echo $class['form_level'] == 4 ? 'selected' : ''; ?>>Form 4</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Stream <span class="text-red">*</span></label>
                        <input type="text" name="stream" class="form-control" required value="<?php echo h($class['stream']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Academic Year <span class="text-red">*</span></label>
                        <input type="text" name="academic_year" class="form-control" required value="<?php echo h($class['academic_year']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Class Capacity <span class="text-red">*</span></label>
                        <input type="number" name="capacity" class="form-control" required value="<?php echo h($class['capacity']); ?>">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Class Teacher</label>
                        <select name="class_teacher_id" class="form-control">
                            <option value="">Assign Later...</option>
                            <?php foreach ($teachers as $t): ?>
                                <option value="<?php echo $t['teacher_id']; ?>" <?php echo $class['class_teacher_id'] == $t['teacher_id'] ? 'selected' : ''; ?>>
                                    <?php echo h($t['first_name'] . ' ' . $t['last_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: var(--secondary-text);">Only active teachers are listed.</small>
                    </div>
                </div>

                <div style="margin-top: 40px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">SAVE CHANGES</button>
                    <a href="index.php" class="btn btn-outline" style="flex: 1;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
