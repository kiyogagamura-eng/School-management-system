<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Class Management";

// Fetch all classes with teacher info and student count
try {
    $stmt = $pdo->query("
        SELECT c.*, t.first_name, t.last_name, 
        (SELECT COUNT(*) FROM students WHERE class_id = c.class_id) as student_count,
        (SELECT COUNT(*) FROM attendance WHERE class_id = c.class_id AND attendance_date = CURDATE() AND status = 'present') as present_today,
        (SELECT COUNT(*) FROM attendance WHERE class_id = c.class_id AND attendance_date = CURDATE()) as marked_today
        FROM classes c 
        LEFT JOIN teachers t ON c.class_teacher_id = t.teacher_id 
        ORDER BY c.form_level ASC, c.stream ASC
    ");
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h2 style="margin: 0;"><i class="fas fa-chalkboard"></i> <?php echo $page_title; ?></h2>
        <a href="create.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create New Class</a>
    </div>

            <div class="card">
                <div class="card-header">School Classes</div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Class Name</th>
                                <th>Form Level</th>
                                <th>Stream</th>
                                <th>Class Teacher</th>
                                <th>Capacity</th>
                                <th>Students</th>
                                <th>Today's Attendance</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($classes)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; color: var(--secondary-text);">No classes defined yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($classes as $class): ?>
                                    <tr>
                                        <td style="font-weight: 700; color: var(--corporate-red);"><?php echo h($class['class_name']); ?></td>
                                        <td>Form <?php echo $class['form_level']; ?></td>
                                        <td><?php echo h($class['stream']); ?></td>
                                        <td style="font-weight: 500;">
                                            <?php 
                                            echo $class['first_name'] ? h($class['first_name'] . ' ' . $class['last_name']) : '<span style="color: #f39c12; font-style: italic;">Not Assigned</span>'; 
                                            ?>
                                        </td>
                                        <td><?php echo $class['capacity']; ?></td>
                                        <td>
                                            <span style="font-weight: 700;"><?php echo $class['student_count']; ?></span> / <?php echo $class['capacity']; ?>
                                        </td>
                                        <td>
                                            <?php if ($class['marked_today'] > 0): 
                                                $pct = round(($class['present_today'] / $class['marked_today']) * 100);
                                                $color = $pct >= 90 ? '#27ae60' : ($pct >= 75 ? '#f39c12' : '#e74c3c');
                                            ?>
                                                <div style="display: flex; align-items: center; gap: 8px;">
                                                    <div style="flex: 1; height: 8px; background: #eee; border-radius: 4px; overflow: hidden; width: 60px;">
                                                        <div style="height: 100%; width: <?php echo $pct; ?>%; background: <?php echo $color; ?>;"></div>
                                                    </div>
                                                    <span style="font-weight: 700; color: <?php echo $color; ?>; font-size: 0.85rem;"><?php echo $pct; ?>%</span>
                                                </div>
                                            <?php else: ?>
                                                <span style="color: var(--secondary-text); font-style: italic; font-size: 0.8rem;"><i class="fas fa-clock"></i> Not Marked</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="view.php?id=<?php echo $class['class_id']; ?>" title="View List" style="margin-right: 15px; color: #3498db;"><i class="fas fa-list"></i></a>
                                            <a href="edit.php?id=<?php echo $class['class_id']; ?>" title="Edit" style="margin-right: 15px; color: #3498db;"><i class="fas fa-edit"></i></a>
                                            <a href="assign-teacher.php?id=<?php echo $class['class_id']; ?>" title="Assign Teacher" style="margin-right: 15px; color: #2ecc71;"><i class="fas fa-user-plus"></i></a>
                                            <a href="javascript:void(0)" 
                                               class="btn-delete-confirm"
                                               data-url="delete.php?id=<?php echo $class['class_id']; ?>" 
                                               data-name="<?php echo h($class['class_name']); ?>"
                                               data-type="Class"
                                               title="Delete" 
                                               style="color: var(--corporate-red);">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
