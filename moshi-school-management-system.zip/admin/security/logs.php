<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Activity Logs";

// Filters
$filter_user = $_GET['user'] ?? '';
$filter_date = $_GET['date'] ?? '';
$filter_role = $_GET['role'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 50;
$offset = ($page - 1) * $per_page;

// Build query
$where = [];
$params = [];
if ($filter_user) { $where[] = "u.username LIKE ?"; $params[] = "%$filter_user%"; }
if ($filter_date) { $where[] = "DATE(al.created_at) = ?"; $params[] = $filter_date; }
if ($filter_role) { $where[] = "u.role = ?"; $params[] = $filter_role; }

$where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

$logs = [];
$total = 0;
try {
    $total = $pdo->prepare("SELECT COUNT(*) FROM activity_logs al LEFT JOIN users u ON u.user_id = al.user_id $where_sql");
    $total->execute($params);
    $total = $total->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT al.*, u.username, u.role 
        FROM activity_logs al 
        LEFT JOIN users u ON u.user_id = al.user_id 
        $where_sql
        ORDER BY al.created_at DESC 
        LIMIT $per_page OFFSET $offset
    ");
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
} catch(PDOException $e) {}

$total_pages = ceil($total / $per_page);

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-list-alt" style="color:#8b0000;"></i> System Activity Logs
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">
                Full audit trail - <?php echo number_format($total); ?> total records
            </p>
        </div>
        <a href="index.php" class="btn btn-outline" style="border-color:#8b0000; color:#8b0000;">
            <i class="fas fa-shield-alt"></i> Back to Security
        </a>
    </div>

    <!-- Filters -->
    <div class="card" style="margin-bottom:25px;">
        <div class="card-body">
            <form method="GET" style="display:flex; gap:15px; flex-wrap:wrap; align-items:flex-end;">
                <div style="flex:1; min-width:150px;">
                    <label style="font-size:0.8rem; font-weight:700; color:#7F8C8D; display:block; margin-bottom:5px;">USERNAME</label>
                    <input type="text" name="user" value="<?php echo h($filter_user); ?>" placeholder="Filter by username..." class="form-control" style="font-size:0.85rem;">
                </div>
                <div style="flex:1; min-width:150px;">
                    <label style="font-size:0.8rem; font-weight:700; color:#7F8C8D; display:block; margin-bottom:5px;">ROLE</label>
                    <select name="role" class="form-control" style="font-size:0.85rem;">
                        <option value="">All Roles</option>
                        <option value="admin" <?php echo $filter_role==='admin'?'selected':''; ?>>Admin</option>
                        <option value="headteacher" <?php echo $filter_role==='headteacher'?'selected':''; ?>>Headteacher</option>
                        <option value="dos" <?php echo $filter_role==='dos'?'selected':''; ?>>DOS</option>
                        <option value="teacher" <?php echo $filter_role==='teacher'?'selected':''; ?>>Teacher</option>
                        <option value="student" <?php echo $filter_role==='student'?'selected':''; ?>>Student</option>
                    </select>
                </div>
                <div style="flex:1; min-width:150px;">
                    <label style="font-size:0.8rem; font-weight:700; color:#7F8C8D; display:block; margin-bottom:5px;">DATE</label>
                    <input type="date" name="date" value="<?php echo h($filter_date); ?>" class="form-control" style="font-size:0.85rem;">
                </div>
                <div>
                    <button type="submit" class="btn btn-primary" style="background:#8b0000; border-color:#8b0000;">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="logs.php" class="btn btn-outline" style="margin-left:8px;">Clear</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Logs Table -->
    <div class="card">
        <div class="card-body" style="padding:0; overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                <thead>
                    <tr style="background:#f8f9fa;">
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">#</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">User</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Action</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Description</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">IP Address</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:2px solid #eee;">Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="6" style="padding:40px; text-align:center; color:#7F8C8D;">
                            <i class="fas fa-history" style="font-size:2rem; opacity:0.2; display:block; margin-bottom:10px;"></i>
                            No activity logs found.
                        </td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $i => $log): ?>
                        <tr style="border-bottom:1px solid #f0f0f0;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='white'">
                            <td style="padding:10px 15px; color:#bdc3c7; font-size:0.75rem;"><?php echo $offset + $i + 1; ?></td>
                            <td style="padding:10px 15px;">
                                <div style="font-weight:700; color:#2C3E50; font-size:0.82rem;"><?php echo h($log['username'] ?? 'System'); ?></div>
                                <?php if ($log['role']): ?>
                                <div style="font-size:0.72rem; color:#7F8C8D; text-transform:uppercase;"><?php echo h($log['role']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td style="padding:10px 15px;">
                                <span style="background:#FFF5F5; color:#8b0000; padding:3px 10px; border-radius:20px; font-size:0.75rem; font-weight:700;">
                                    <?php echo h($log['action'] ?? '-'); ?>
                                </span>
                            </td>
                            <td style="padding:10px 15px; font-size:0.8rem; color:#555; max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                <?php echo h($log['description'] ?? '-'); ?>
                            </td>
                            <td style="padding:10px 15px; font-family:monospace; font-size:0.78rem; color:#7F8C8D;">
                                <?php echo h($log['ip_address'] ?? '-'); ?>
                            </td>
                            <td style="padding:10px 15px; font-size:0.78rem; color:#7F8C8D; white-space:nowrap;">
                                <?php echo date('d M Y H:i:s', strtotime($log['created_at'])); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="card-body" style="border-top:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:0.85rem; color:#7F8C8D;">
                Showing <?php echo $offset+1; ?>–<?php echo min($offset+$per_page, $total); ?> of <?php echo number_format($total); ?>
            </span>
            <div style="display:flex; gap:5px;">
                <?php for ($p = 1; $p <= min($total_pages, 10); $p++): ?>
                    <a href="?page=<?php echo $p; ?>&user=<?php echo urlencode($filter_user); ?>&date=<?php echo urlencode($filter_date); ?>&role=<?php echo urlencode($filter_role); ?>" 
                       style="padding:6px 12px; border-radius:5px; font-size:0.8rem; font-weight:600; text-decoration:none;
                              <?php echo $p == $page ? 'background:#8b0000; color:white;' : 'background:#f8f9fa; color:#2C3E50;'; ?>">
                        <?php echo $p; ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
