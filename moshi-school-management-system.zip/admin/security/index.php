<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Security Management";

// Handle POST actions
$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCSRF();
    
    $action = $_POST['action'] ?? '';
    $user_id = intval($_POST['user_id'] ?? 0);
    
    if ($action === 'lock' && $user_id > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET status='locked', locked_until = DATE_ADD(NOW(), INTERVAL 24 HOUR) WHERE user_id = ? AND role != 'admin'");
            $stmt->execute([$user_id]);
            $success_msg = "Account locked successfully.";
        } catch(PDOException $e) {
            $error_msg = "Error locking account.";
        }
    } elseif ($action === 'unlock' && $user_id > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET status='active', locked_until=NULL, failed_attempts=0 WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $success_msg = "Account unlocked successfully.";
        } catch(PDOException $e) {
            $error_msg = "Error unlocking account.";
        }
    } elseif ($action === 'reset_password' && $user_id > 0) {
        try {
            $new_password = password_hash(DEFAULT_PASSWORD, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password=?, failed_attempts=0, locked_until=NULL, status='active' WHERE user_id = ?");
            $stmt->execute([$new_password, $user_id]);
            $success_msg = "Password reset to default (" . DEFAULT_PASSWORD . ") successfully.";
        } catch(PDOException $e) {
            $error_msg = "Error resetting password.";
        }
    }
}

// Fetch all users with security info
$users = [];
try {
    $users = $pdo->query("
        SELECT u.user_id, u.username, u.email, u.role, u.status, 
               u.last_login, u.last_login_ip, u.failed_attempts, u.locked_until, u.created_at,
               CASE 
                   WHEN u.role IN ('teacher','dos','headteacher') THEN CONCAT(t.first_name, ' ', t.last_name)
                   ELSE u.username
               END as full_name
        FROM users u
        LEFT JOIN teachers t ON t.user_id = u.user_id
        ORDER BY u.failed_attempts DESC, u.last_login DESC
    ")->fetchAll();
} catch(PDOException $e) {}

// Security summary stats
$locked_count = 0;
$suspicious_count = 0;
$active_24h = 0;
$total_users = count($users);

foreach ($users as $u) {
    if ($u['status'] === 'locked') $locked_count++;
    if ($u['failed_attempts'] >= 3) $suspicious_count++;
    if ($u['last_login'] && strtotime($u['last_login']) >= strtotime('-24 hours')) $active_24h++;
}

// Recent activity logs
$logs = [];
try {
    $logs = $pdo->query("
        SELECT al.*, u.username, u.role 
        FROM activity_logs al 
        LEFT JOIN users u ON u.user_id = al.user_id 
        ORDER BY al.created_at DESC 
        LIMIT 20
    ")->fetchAll();
} catch(PDOException $e) {}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-shield-alt" style="color:#8b0000;"></i> Security Management
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">Monitor logins, manage account security & activity logs</p>
        </div>
        <div style="font-size:0.85rem; color:var(--secondary-text); background:#FFF5F5; padding:8px 15px; border-radius:8px; border:1px solid #8b0000;">
            <i class="fas fa-clock"></i> <?php echo date('d M Y, H:i'); ?>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div style="background:#d4edda; color:#155724; padding:12px 20px; border-radius:8px; border:1px solid #c3e6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-check-circle"></i> <?php echo h($success_msg); ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background:#f8d7da; color:#721c24; padding:12px 20px; border-radius:8px; border:1px solid #f5c6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-exclamation-triangle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Security Stats -->
    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:20px; margin-bottom:30px;">
        <div class="card" style="padding:20px; border-left:5px solid #8b0000; display:flex; align-items:center; gap:15px; margin-bottom:0;">
            <div style="background:#FFF5F5; width:50px; height:50px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.4rem; color:#8b0000;">
                <i class="fas fa-users"></i>
            </div>
            <div>
                <div style="font-size:0.75rem; color:#7F8C8D; font-weight:700; text-transform:uppercase;">Total Users</div>
                <div style="font-size:1.8rem; font-weight:900; color:#2C3E50;"><?php echo $total_users; ?></div>
            </div>
        </div>
        <div class="card" style="padding:20px; border-left:5px solid #27ae60; display:flex; align-items:center; gap:15px; margin-bottom:0;">
            <div style="background:#eafaf1; width:50px; height:50px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.4rem; color:#27ae60;">
                <i class="fas fa-user-check"></i>
            </div>
            <div>
                <div style="font-size:0.75rem; color:#7F8C8D; font-weight:700; text-transform:uppercase;">Active (24h)</div>
                <div style="font-size:1.8rem; font-weight:900; color:#2C3E50;"><?php echo $active_24h; ?></div>
            </div>
        </div>
        <div class="card" style="padding:20px; border-left:5px solid #e67e22; display:flex; align-items:center; gap:15px; margin-bottom:0;">
            <div style="background:#fef9e7; width:50px; height:50px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.4rem; color:#e67e22;">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div>
                <div style="font-size:0.75rem; color:#7F8C8D; font-weight:700; text-transform:uppercase;">Suspicious</div>
                <div style="font-size:1.8rem; font-weight:900; color:#2C3E50;"><?php echo $suspicious_count; ?></div>
            </div>
        </div>
        <div class="card" style="padding:20px; border-left:5px solid #e74c3c; display:flex; align-items:center; gap:15px; margin-bottom:0;">
            <div style="background:#fdedec; width:50px; height:50px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.4rem; color:#e74c3c;">
                <i class="fas fa-lock"></i>
            </div>
            <div>
                <div style="font-size:0.75rem; color:#7F8C8D; font-weight:700; text-transform:uppercase;">Locked</div>
                <div style="font-size:1.8rem; font-weight:900; color:#2C3E50;"><?php echo $locked_count; ?></div>
            </div>
        </div>
    </div>

    <!-- Main Grid -->
    <div style="display:grid; grid-template-columns:2fr 1fr; gap:25px;">
        <!-- Users Table -->
        <div class="card">
            <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
                <span><i class="fas fa-users-cog"></i> User Account Security</span>
                <input type="text" id="searchUsers" placeholder="Search user..." onkeyup="filterUsers()" style="padding:6px 12px; border:1px solid #ddd; border-radius:6px; font-size:0.85rem; outline:none;">
            </div>
            <div class="card-body" style="padding:0; overflow-x:auto;">
                <table id="usersTable" style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                    <thead>
                        <tr style="background:#f8f9fa;">
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">User</th>
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Role</th>
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Status</th>
                            <th style="padding:12px 15px; text-align:center; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Failed</th>
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Last Login</th>
                            <th style="padding:12px 15px; text-align:center; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): 
                            $isLocked = $u['status'] === 'locked';
                            $isSuspicious = $u['failed_attempts'] >= 3 && !$isLocked;
                            $rowBg = $isLocked ? '#fff8f8' : ($isSuspicious ? '#fffbf0' : '#fff');
                        ?>
                        <tr style="border-bottom:1px solid #f0f0f0; background:<?php echo $rowBg; ?>; transition:background 0.2s;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='<?php echo $rowBg; ?>'">
                            <td style="padding:12px 15px;">
                                <div style="font-weight:700; color:#2C3E50;"><?php echo h($u['full_name']); ?></div>
                                <div style="font-size:0.78rem; color:#7F8C8D;">@<?php echo h($u['username']); ?></div>
                            </td>
                            <td style="padding:12px 15px;">
                                <?php
                                $roleColors = ['admin'=>'#8b0000','headteacher'=>'#1a5276','dos'=>'#117a65','teacher'=>'#1e8449','student'=>'#7d6608','parent'=>'#6c3483'];
                                $roleColor = $roleColors[$u['role']] ?? '#555';
                                ?>
                                <span style="background:<?php echo $roleColor; ?>20; color:<?php echo $roleColor; ?>; padding:3px 10px; border-radius:20px; font-size:0.75rem; font-weight:700; text-transform:uppercase;"><?php echo ucfirst(h($u['role'])); ?></span>
                            </td>
                            <td style="padding:12px 15px;">
                                <?php if ($isLocked): ?>
                                    <span style="color:#e74c3c; font-weight:700; font-size:0.8rem;"><i class="fas fa-lock"></i> LOCKED</span>
                                <?php elseif ($u['status'] === 'active'): ?>
                                    <span style="color:#27ae60; font-weight:700; font-size:0.8rem;"><i class="fas fa-check-circle"></i> Active</span>
                                <?php else: ?>
                                    <span style="color:#7F8C8D; font-weight:700; font-size:0.8rem;"><i class="fas fa-minus-circle"></i> Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:12px 15px; text-align:center;">
                                <?php if ($u['failed_attempts'] >= 5): ?>
                                    <span style="color:#e74c3c; font-weight:900; font-size:1rem;"><?php echo $u['failed_attempts']; ?></span>
                                <?php elseif ($u['failed_attempts'] >= 3): ?>
                                    <span style="color:#e67e22; font-weight:700;"><?php echo $u['failed_attempts']; ?></span>
                                <?php else: ?>
                                    <span style="color:#7F8C8D;"><?php echo $u['failed_attempts']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:12px 15px; font-size:0.78rem; color:#7F8C8D;">
                                <?php echo $u['last_login'] ? date('d M y H:i', strtotime($u['last_login'])) : '<em>Never</em>'; ?>
                                <?php if ($u['last_login_ip']): ?>
                                    <div style="font-size:0.72rem; color:#bdc3c7;"><?php echo h($u['last_login_ip']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td style="padding:12px 15px; text-align:center;">
                                <?php if ($u['role'] !== 'admin'): ?>
                                <div style="display:flex; gap:5px; justify-content:center; flex-wrap:wrap;">
                                    <?php if ($isLocked): ?>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                            <input type="hidden" name="action" value="unlock">
                                            <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                            <button type="submit" title="Unlock Account" style="background:#27ae60; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer; font-size:0.75rem;"><i class="fas fa-lock-open"></i> Unlock</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Lock this account?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                            <input type="hidden" name="action" value="lock">
                                            <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                            <button type="submit" title="Lock Account" style="background:#e74c3c; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer; font-size:0.75rem;"><i class="fas fa-lock"></i> Lock</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Reset password to <?php echo DEFAULT_PASSWORD; ?>?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <input type="hidden" name="action" value="reset_password">
                                        <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                        <button type="submit" title="Reset Password" style="background:#8b0000; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer; font-size:0.75rem;"><i class="fas fa-key"></i> Reset</button>
                                    </form>
                                </div>
                                <?php else: ?>
                                    <span style="color:#bdc3c7; font-size:0.75rem;"><i class="fas fa-shield-alt"></i> Admin</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Activity Logs -->
        <div class="card">
            <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid #eee;">
                <i class="fas fa-history"></i> Recent Activity Logs
            </div>
            <div class="card-body" style="padding:0; max-height:600px; overflow-y:auto;">
                <?php if (empty($logs)): ?>
                    <div style="padding:30px; text-align:center; color:#7F8C8D;">
                        <i class="fas fa-history" style="font-size:2rem; opacity:0.2;"></i>
                        <p style="margin-top:10px;">No activity logs yet.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                    <div style="padding:12px 15px; border-bottom:1px solid #f5f5f5; display:flex; gap:12px; align-items:flex-start;">
                        <div style="background:#FFF5F5; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#8b0000; font-size:0.8rem; flex-shrink:0;">
                            <i class="fas fa-user"></i>
                        </div>
                        <div style="flex:1; min-width:0;">
                            <div style="font-weight:700; font-size:0.82rem; color:#2C3E50; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?php echo h($log['action'] ?? 'Action'); ?></div>
                            <div style="font-size:0.75rem; color:#7F8C8D; margin-top:2px;"><?php echo h($log['username'] ?? 'System'); ?></div>
                            <div style="font-size:0.72rem; color:#bdc3c7; margin-top:2px;"><?php echo date('d M y H:i', strtotime($log['created_at'])); ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="card-body" style="border-top:1px solid #eee;">
                <a href="logs.php" class="btn btn-outline" style="width:100%; text-align:center; font-size:0.85rem; border-color:#8b0000; color:#8b0000;">
                    <i class="fas fa-list"></i> View Full Logs
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function filterUsers() {
    const input = document.getElementById('searchUsers').value.toUpperCase();
    const rows = document.querySelectorAll('#usersTable tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toUpperCase();
        row.style.display = text.includes(input) ? '' : 'none';
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
