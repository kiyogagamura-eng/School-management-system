<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Edit Teacher";
$error = '';
$success = '';

if (!isset($_GET['id'])) {
    redirect('teachers.php', "Teacher ID required.");
}

$id = $_GET['id'];

// Fetch Teacher Data
try {
    $stmt = $pdo->prepare("SELECT t.*, u.username, u.email as u_email, u.phone as u_phone 
                          FROM teachers t 
                          JOIN users u ON t.user_id = u.user_id 
                          WHERE t.teacher_id = ?");
    $stmt->execute([$id]);
    $teacher = $stmt->fetch();

    if (!$teacher) {
        redirect('teachers.php', "Teacher not found.");
    }

    // NEW: Fetch Assigned Subjects
    $stmt = $pdo->prepare("
        SELECT cs.class_id, cs.subject_id, c.class_name, s.subject_name 
        FROM class_subjects cs
        JOIN classes c ON cs.class_id = c.class_id
        JOIN subjects s ON cs.subject_id = s.subject_id
        WHERE cs.teacher_id = ?
        ORDER BY c.class_name, s.subject_name
    ");
    $stmt->execute([$id]);
    $assigned_subjects = $stmt->fetchAll();

    // NEW: Fetch if they are Class Teacher
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE class_teacher_id = ?");
    $stmt->execute([$id]);
    $class_teacher_for = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // NEW: Fetch all subjects for the specialization dropdown
    $stmt_subj = $pdo->query("SELECT * FROM subjects ORDER BY subject_name");
    $subjects = $stmt_subj->fetchAll();

    // NEW: Fetch unique assigned class IDs for checkbox state
    $stmt_ac = $pdo->prepare("SELECT DISTINCT class_id FROM class_subjects WHERE teacher_id = ?");
    $stmt_ac->execute([$id]);
    $current_assigned_classes = $stmt_ac->fetchAll(PDO::FETCH_COLUMN);

    // NEW: Fetch all classes for rendering the checkbox grid
    $stmt_cl = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream");
    $classes = $stmt_cl->fetchAll();

} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_teacher'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $gender = $_POST['gender'];
    $phone = '+255' . trim($_POST['phone']);
    $email = trim($_POST['email']);
    $specialization = isset($_POST['specialization']) ? implode(', ', $_POST['specialization']) : '';
    $qualification = trim($_POST['qualification']);
    $staff_position = trim($_POST['staff_position'] ?: 'Teacher');
    $status = $_POST['status'];
    
    // NEW: Credential Fields
    $new_username = trim($_POST['username']);
    $new_password = $_POST['password']; // Note: field name in HTML is 'password' but logic below handles it

    try {
        // VALIDATION
        if (isset($_POST['specialization']) && count($_POST['specialization']) > 2) {
            throw new Exception("A teacher can only be assigned a maximum of 2 teaching subjects.");
        }
        if (!isValidName($first_name) || !isValidName($last_name)) {
            throw new Exception("Names must contain only letters (A-Z). Numbers and special characters are not allowed.");
        }
        if (!isValidTanzanianPhone($phone)) {
            throw new Exception("Invalid Phone Number. Use format +255XXXXXXXXX (e.g. +255711444501)");
        }
        if (!empty($new_password) && !isValidPasswordFormat($new_password)) {
            throw new Exception("Password must be alphanumeric (contain at least one letter and one number) e.g. machaka123");
        }

        $pdo->beginTransaction();

        // 1. Check Username Uniqueness (if changed)
        if ($new_username !== $teacher['username']) {
            $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?");
            $check->execute([$new_username, $teacher['user_id']]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Username '$new_username' is already taken.");
            }
            
            $stmt = $pdo->prepare("UPDATE users SET username = ? WHERE user_id = ?");
            $stmt->execute([$new_username, $teacher['user_id']]);
        }

        // 2. Update Password (if provided)
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->execute([$hashed_password, $teacher['user_id']]);
        }

        // 3. Update User email/phone
        $stmt = $pdo->prepare("UPDATE users SET email = ?, phone = ? WHERE user_id = ?");
        $stmt->execute([$email, $phone, $teacher['user_id']]);

        // 4. Implement Unique Position Logic (Only one DOS, Headmaster, etc.)
        $unique_positions = ['Headmaster', 'Deputy Headmaster', 'Director of Studies', 'Assistant Head (Academic)', 'Assistant Head (Admin)', 'Discipline Master'];
        
        if (in_array($staff_position, $unique_positions)) {
            // Find who else had this position
            $stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE staff_position = ? AND teacher_id != ?");
            $stmt->execute([$staff_position, $id]);
            $old_holders = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            if (!empty($old_holders)) {
                // Demote old holders to 'Teacher' position
                $stmt = $pdo->prepare("UPDATE teachers SET staff_position = 'Teacher' WHERE staff_position = ? AND teacher_id != ?");
                $stmt->execute([$staff_position, $id]);
                
                // Update their user roles to 'teacher'
                $placeholders = implode(',', array_fill(0, count($old_holders), '?'));
                $stmt = $pdo->prepare("UPDATE users SET role = 'teacher' WHERE user_id IN ($placeholders)");
                $stmt->execute($old_holders);
            }
        }

        // 5. Update Teacher Profile
        $stmt = $pdo->prepare("UPDATE teachers SET 
            first_name = ?, last_name = ?, gender = ?, phone = ?, 
            email = ?, specialization = ?, qualification = ?, staff_position = ?, status = ? 
            WHERE teacher_id = ?");
        $stmt->execute([
            $first_name, $last_name, $gender, $phone, 
            $email, $specialization, $qualification, $staff_position, $status, $id
        ]);

        // 6. SYNC USER ROLE (for current teacher)
        $system_role = 'teacher';
        if ($staff_position == 'Headmaster' || $staff_position == 'Deputy Headmaster') $system_role = 'headteacher';
        if ($staff_position == 'Director of Studies' || $staff_position == 'Assistant Head (Academic)') $system_role = 'dos';
        if ($staff_position == 'Discipline Master') $system_role = 'discipline';
        if ($staff_position == 'Assistant Head (Admin)') $system_role = 'admin';

        $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE user_id = ?");
        $stmt->execute([$system_role, $teacher['user_id']]);

        // 7. SYNC TEACHING CLASSES AND SUBJECTS IN class_subjects
        $teaching_classes = isset($_POST['teaching_classes']) ? $_POST['teaching_classes'] : [];
        $specialization_post = isset($_POST['specialization']) ? $_POST['specialization'] : [];
        
        // Clear all current assignments in class_subjects for this teacher
        $stmt_del = $pdo->prepare("DELETE FROM class_subjects WHERE teacher_id = ?");
        $stmt_del->execute([$id]);

        if (!empty($teaching_classes) && !empty($specialization_post)) {
            // Fetch subjects table to map names to IDs
            $stmt_subj = $pdo->query("SELECT subject_id, subject_name FROM subjects");
            $all_subjects = $stmt_subj->fetchAll();
            $subject_name_to_id = [];
            foreach ($all_subjects as $sub) {
                $subject_name_to_id[$sub['subject_name']] = $sub['subject_id'];
            }
            
            $selected_subject_ids = [];
            foreach ($specialization_post as $spec_name) {
                if (isset($subject_name_to_id[$spec_name])) {
                    $selected_subject_ids[] = $subject_name_to_id[$spec_name];
                }
            }
            
            if (!empty($selected_subject_ids)) {
                $stmt_cs = $pdo->prepare("INSERT INTO class_subjects (class_id, subject_id, teacher_id) VALUES (?, ?, ?)");
                foreach ($teaching_classes as $class_id) {
                    foreach ($selected_subject_ids as $sub_id) {
                        $stmt_cs->execute([$class_id, $sub_id, $id]);
                    }
                }
            }
        }

        $pdo->commit();
        redirect('edit-teacher.php?id='.$id, "Teacher records updated successfully.");
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = "Update failed: " . $e->getMessage();
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="teachers.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
        <div class="card-header">
            <h3 style="margin: 0;"><i class="fas fa-user-tie"></i> <?php echo $page_title; ?>: <?php echo h($teacher['first_name'] . ' ' . $teacher['last_name']); ?></h3>
        </div>
        <div class="card-body">
            <?php if ($error): ?><div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px;"><?php echo $error; ?></div><?php endif; ?>
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>Employee ID</label>
                        <input type="text" class="form-control" value="<?php echo h($teacher['employee_id']); ?>" readonly style="background: #f8f9fa;">
                    </div>
                    <div class="form-group">
                        <label>Username (Login)</label>
                        <input type="text" name="username" class="form-control" value="<?php echo h($teacher['username']); ?>" required>
                    </div>
                        <div class="form-group">
                            <label>New Password (Optional)</label>
                            <div style="display: flex; gap: 5px;">
                                <input type="password" name="password" id="new_password" class="form-control" placeholder="Leave blank to keep current">
                                <button type="button" class="btn btn-mini" onclick="document.getElementById('new_password').value='<?php echo DEFAULT_PASSWORD; ?>'; document.getElementById('new_password').type='text';" style="white-space: nowrap; height: auto;">
                                    <i class="fas fa-undo"></i> Reset to Default
                                </button>
                            </div>
                            <small style="color: var(--secondary-text);">System default: <b><?php echo DEFAULT_PASSWORD; ?></b></small>
                        </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="Active" <?php echo $teacher['status'] == 'Active' ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo $teacher['status'] == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <h4 style="margin: 30px 0 20px; color: var(--corporate-red); border-bottom: 1px solid #eee; padding-bottom: 10px;">Personal & Contact Info</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo h($teacher['first_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo h($teacher['last_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select name="gender" class="form-control">
                            <option value="Male" <?php echo $teacher['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo $teacher['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <div class="input-group">
                            <div class="input-prefix">+255</div>
                            <input type="text" name="phone" class="form-control input-with-prefix phone-input-9" 
                                   value="<?php echo h(str_replace('+255', '', $teacher['phone'])); ?>" required
                                   pattern="[0-9]{9}" 
                                   maxlength="9"
                                   placeholder="711444501"
                                   title="Enter the 9 digits after +255">
                        </div>
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Email Address</label>
                        <input type="email" name="email" class="form-control" value="<?php echo h($teacher['email']); ?>" required>
                    </div>
                </div>

                <h4 style="margin: 30px 0 20px; color: var(--corporate-red); border-bottom: 1px solid #eee; padding-bottom: 10px;">Professional Qualifications</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>Staff Role/Position <span style="color: red;">*</span></label>
                        <select name="staff_position" class="form-control" required style="border: 2px solid #940000;">
                            <option value="">-- Select Position --</option>
                            <optgroup label="School Leadership">
                                <option value="Headmaster" <?php echo $teacher['staff_position'] == 'Headmaster' ? 'selected' : ''; ?>>Headmaster</option>
                                <option value="Deputy Headmaster" <?php echo $teacher['staff_position'] == 'Deputy Headmaster' ? 'selected' : ''; ?>>Deputy Headmaster</option>
                                <option value="Discipline Master" <?php echo $teacher['staff_position'] == 'Discipline Master' ? 'selected' : ''; ?>>Discipline Master</option>
                            </optgroup>
                            <optgroup label="Academic Management">
                                <option value="Assistant Head (Academic)" <?php echo $teacher['staff_position'] == 'Assistant Head (Academic)' ? 'selected' : ''; ?>>Assistant Head (Academic)</option>
                                <option value="Director of Studies" <?php echo $teacher['staff_position'] == 'Director of Studies' ? 'selected' : ''; ?>>Director of Studies (DOS)</option>
                            </optgroup>
                            <optgroup label="Administrative">
                                <option value="Assistant Head (Admin)" <?php echo $teacher['staff_position'] == 'Assistant Head (Admin)' ? 'selected' : ''; ?>>Assistant Head (Admin)</option>
                            </optgroup>
                            <optgroup label="Teaching Staff">
                                <option value="Subject Head" <?php echo $teacher['staff_position'] == 'Subject Head' ? 'selected' : ''; ?>>Subject Head</option>
                                <option value="Class Teacher" <?php echo $teacher['staff_position'] == 'Class Teacher' ? 'selected' : ''; ?>>Class Teacher</option>
                                <option value="Teacher" <?php echo ($teacher['staff_position'] == 'Teacher' || empty($teacher['staff_position'])) ? 'selected' : ''; ?>>Teacher</option>
                            </optgroup>
                        </select>
                        <small style="color: #666; display: block; margin-top: 5px;">
                            <i class="fas fa-info-circle"></i> <strong>IMPORTANT:</strong> Changing position will automatically update user role and portal access!
                        </small>
                    </div>
                    <div class="form-group">
                        <label>Highest Qualification</label>
                        <input type="text" name="qualification" class="form-control" value="<?php echo h($teacher['qualification']); ?>" placeholder="e.g. Bachelor of Education">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Specialization (Subjects) <span class="text-red">*</span></label>
                        <div class="subject-selection-grid">
                            <?php 
                            $current_spec = array_map('trim', explode(',', $teacher['specialization']));
                            foreach($subjects as $sub): 
                                $is_checked = in_array($sub['subject_name'], $current_spec) ? 'checked' : '';
                            ?>
                                <label class="subject-item" id="subject-label-<?php echo $sub['subject_id']; ?>">
                                    <input type="checkbox" name="specialization[]" value="<?php echo h($sub['subject_name']); ?>" class="subject-checkbox" data-name="<?php echo h($sub['subject_name']); ?>" <?php echo $is_checked; ?>>
                                    <div class="subject-content">
                                        <div class="subject-name"><?php echo h($sub['subject_name']); ?></div>
                                        <div class="subject-status">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <div style="margin-top: 10px;">
                            <small style="color: var(--secondary-text); font-weight: 600;">Selected: <span id="selected-subjects-count" style="color: var(--corporate-red);"><?php echo count($current_spec); ?></span>/2 subjects</small>
                            <div id="selected-list" style="display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;">
                                <?php foreach($current_spec as $s_name): if(!empty($s_name)): ?>
                                    <span class="tag-subject"><?php echo h($s_name); ?></span>
                                <?php endif; endforeach; ?>
                            </div>
                        </div>
                        <style>
                            .subject-selection-grid {
                                display: grid;
                                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
                                gap: 10px;
                                max-height: 250px;
                                overflow-y: auto;
                                padding: 10px;
                                background: #f9f9f9;
                                border: 1px solid #ddd;
                                border-radius: 8px;
                            }
                            .subject-item {
                                position: relative;
                                cursor: pointer;
                            }
                            .subject-checkbox {
                                position: absolute;
                                opacity: 0;
                                cursor: pointer;
                            }
                            .subject-content {
                                padding: 12px 15px;
                                background: white;
                                border: 1px solid #eee;
                                border-radius: 8px;
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                transition: all 0.2s;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.02);
                            }
                            .subject-item:hover .subject-content {
                                border-color: var(--corporate-red);
                                transform: translateY(-1px);
                            }
                            .subject-checkbox:checked + .subject-content {
                                background: var(--soft-red);
                                border-color: var(--corporate-red);
                                box-shadow: 0 4px 8px rgba(148, 0, 0, 0.1);
                            }
                            .subject-name {
                                font-size: 0.85rem;
                                font-weight: 700;
                                color: #333;
                            }
                            .subject-status {
                                color: transparent;
                                font-size: 1rem;
                                transition: 0.2s;
                            }
                            .subject-checkbox:checked + .subject-content .subject-status {
                                color: var(--corporate-red);
                            }
                            .tag-subject {
                                background: var(--corporate-red);
                                color: white;
                                padding: 4px 10px;
                                border-radius: 4px;
                                font-size: 10px;
                                font-weight: 800;
                                text-transform: uppercase;
                            }
                        </style>
                    </div>
                    
                    <div class="form-group" style="grid-column: span 2; margin-top: 15px; margin-bottom: 10px;">
                        <label style="font-weight: 700;">Teaching Classes (Select all classes this teacher teaches) <span class="text-red">*</span></label>
                        <div class="class-selection-grid">
                            <?php foreach($classes as $c): 
                                $is_class_checked = in_array($c['class_id'], $current_assigned_classes) ? 'checked' : '';
                            ?>
                                <label class="class-item" id="class-label-<?php echo $c['class_id']; ?>">
                                    <input type="checkbox" name="teaching_classes[]" value="<?php echo $c['class_id']; ?>" class="class-checkbox" data-name="<?php echo h($c['class_name']); ?>" <?php echo $is_class_checked; ?>>
                                    <div class="class-content">
                                        <div class="class-name"><?php echo h($c['class_name']); ?></div>
                                        <div class="class-status">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <small style="color: var(--secondary-text); display: block; margin-top: 5px;">
                            <i class="fas fa-info-circle"></i> The teacher will automatically be assigned to teach their specialization subjects in these classes.
                        </small>
                        <style>
                            .class-selection-grid {
                                display: grid;
                                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                                gap: 10px;
                                max-height: 200px;
                                overflow-y: auto;
                                padding: 10px;
                                background: #f9f9f9;
                                border: 1px solid #ddd;
                                border-radius: 8px;
                            }
                            .class-item {
                                position: relative;
                                cursor: pointer;
                            }
                            .class-checkbox {
                                position: absolute;
                                opacity: 0;
                                cursor: pointer;
                            }
                            .class-content {
                                padding: 10px 15px;
                                background: white;
                                border: 1px solid #eee;
                                border-radius: 8px;
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                transition: all 0.2s;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.02);
                            }
                            .class-item:hover .class-content {
                                border-color: var(--corporate-red);
                                transform: translateY(-1px);
                            }
                            .class-checkbox:checked + .class-content {
                                background: var(--soft-red);
                                border-color: var(--corporate-red);
                                box-shadow: 0 4px 8px rgba(148, 0, 0, 0.1);
                            }
                            .class-name {
                                font-size: 0.85rem;
                                font-weight: 700;
                                color: #333;
                            }
                            .class-status {
                                color: transparent;
                                font-size: 1rem;
                                transition: 0.2s;
                            }
                            .class-checkbox:checked + .class-content .class-status {
                                color: var(--corporate-red);
                            }
                        </style>
                    </div>
                </div>

                <div style="margin-top: 40px;">
                    <button type="submit" name="update_teacher" class="btn btn-primary" style="padding: 12px 30px;">SAVE CHANGES</button>
                </div>
            </form>

            <h4 style="margin: 40px 0 20px; color: var(--corporate-red); border-bottom: 2px solid var(--accent-soft-red); padding-bottom: 10px;">Assigned Subjects & Classes</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                <div class="card" style="box-shadow: none; border: 1px solid #eee;">
                    <div class="card-header" style="font-size: 14px; background: #fafafa;">Subject Assignments</div>
                    <div class="card-body" style="padding: 0;">
                        <?php if (empty($assigned_subjects)): ?>
                            <p style="padding: 20px; color: var(--secondary-text); font-style: italic;">No subjects assigned via Subject Management.</p>
                        <?php else: ?>
                            <table class="table" style="margin: 0;">
                                <thead style="background: #f8f8f8;">
                                    <tr>
                                        <th>Class</th>
                                        <th>Subject</th>
                                        <th style="width: 50px;"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($assigned_subjects as $as): ?>
                                        <tr>
                                            <td><b><?php echo h($as['class_name']); ?></b></td>
                                            <td><?php echo h($as['subject_name']); ?></td>
                                            <td style="text-align: right;">
                                                <a href="javascript:void(0)" 
                                                   class="btn-delete-confirm" 
                                                   data-url="../subjects/remove_assignment.php?class_id=<?php echo $as['class_id']; ?>&subject_id=<?php echo $as['subject_id']; ?>&teacher_id=<?php echo $id; ?>" 
                                                   data-name="<?php echo h($as['subject_name']) . ' in ' . h($as['class_name']); ?>"
                                                   data-type="Assignment"
                                                   style="color: var(--corporate-red);"><i class="fas fa-times-circle"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <div style="padding: 15px; background: #fdfdfd; border-top: 1px solid #eee;">
                            <a href="../subjects/index.php" style="font-size: 13px; color: var(--corporate-red); text-decoration: none; font-weight: 700;"><i class="fas fa-external-link-alt"></i> Manage Assignments</a>
                        </div>
                    </div>
                </div>

                <div class="card" style="box-shadow: none; border: 1px solid #eee;">
                    <div class="card-header" style="font-size: 14px; background: #fafafa;">Class Teacher Role</div>
                    <div class="card-body">
                        <?php if (empty($class_teacher_for)): ?>
                            <p style="color: var(--secondary-text); font-style: italic;">Not assigned as a Class Teacher.</p>
                        <?php else: ?>
                            <ul style="list-style: none; padding: 0;">
                                <?php foreach ($class_teacher_for as $cname): ?>
                                    <li style="padding: 10px; background: #f8f9fa; border-radius: 5px; margin-bottom: 5px; font-weight: 700; color: var(--corporate-red);">
                                        <i class="fas fa-chalkboard-teacher"></i> Class Teacher: <?php echo h($cname); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                        <div style="padding: 15px 0 0;">
                            <a href="../classes/index.php" style="font-size: 13px; color: var(--corporate-red); text-decoration: none; font-weight: 700;"><i class="fas fa-external-link-alt"></i> Manage Classes</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Handle Subject Selection Checkboxes
const checkboxes = document.querySelectorAll('.subject-checkbox');
const countSpan = document.getElementById('selected-subjects-count');
const selectedList = document.getElementById('selected-list');

checkboxes.forEach(cb => {
    cb.addEventListener('change', function() {
        const selected = document.querySelectorAll('.subject-checkbox:checked');
        
        if (selected.length > 2) {
            this.checked = false;
            alert("A teacher can only be assigned a maximum of 2 subjects.");
            return;
        }

        // Update count
        countSpan.textContent = selected.length;

        // Update tags list
        selectedList.innerHTML = '';
        selected.forEach(s => {
            const tag = document.createElement('span');
            tag.className = 'tag-subject';
            tag.textContent = s.dataset.name;
            selectedList.appendChild(tag);
        });
    });
});
</script>

<?php require_once '../../includes/footer.php'; ?>
