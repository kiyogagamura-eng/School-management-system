<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Parents Management";
require_once '../../includes/header.php';

// Fetch all parents and their linked students
try {
    $stmt = $pdo->query("
        SELECT p.*, s.first_name as std_first, s.last_name as std_last, c.class_name 
        FROM parents p
        LEFT JOIN students s ON p.student_id = s.student_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        ORDER BY p.parent_name ASC
    ");
    $parents = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error fetching parents: " . $e->getMessage());
}
?>

<div class="fade-in">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 style="margin: 0;"><i class="fas fa-user-friends"></i> Parents Directory</h2>
        <div>
            <a href="index.php" class="btn btn-outline" style="margin-right: 10px;"><i class="fas fa-arrow-left"></i> Back to Hub</a>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body" style="overflow-x: auto;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Parent Name</th>
                        <th>Phone Number</th>
                        <th>Linked Student</th>
                        <th>Class</th>
                        <th>SMS Status</th>
                        <th>Verification</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($parents)): ?>
                        <tr><td colspan="7" style="text-align: center;">No parent records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($parents as $parent): ?>
                            <tr>
                                <td><strong><?php echo h($parent['parent_name']); ?></strong></td>
                                <td><?php echo h($parent['parent_phone']); ?></td>
                                <td>
                                    <?php if ($parent['std_first']): ?>
                                        <a href="student-profile.php?id=<?php echo $parent['student_id']; ?>"><?php echo h($parent['std_first'] . ' ' . $parent['std_last']); ?></a>
                                    <?php else: ?>
                                        <span style="color: #999;">Not Linked</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo h($parent['class_name'] ?? '-'); ?></td>
                                <td>
                                    <?php if ($parent['sms_enabled']): ?>
                                        <span class="badge" style="background: rgba(46, 204, 113, 0.1); color: #2ecc71;">Enabled</span>
                                    <?php else: ?>
                                        <span class="badge" style="background: rgba(231, 76, 60, 0.1); color: #e74c3c;">Disabled</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($parent['verified']): ?>
                                        <span class="badge" style="background: rgba(52, 152, 219, 0.1); color: #3498db;"><i class="fas fa-check-circle"></i> Verified</span>
                                    <?php else: ?>
                                        <span class="badge" style="background: rgba(243, 156, 18, 0.1); color: #f39c12;">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 5px;">
                                        <button class="btn btn-outline" style="padding: 5px 10px; font-size: 0.8rem;" onclick="alert('Feature coming soon')"><i class="fas fa-edit"></i> Edit</button>
                                        <a href="javascript:void(0)" 
                                           class="btn-delete-confirm" 
                                           data-url="delete-parent.php?id=<?php echo $parent['parent_id']; ?>" 
                                           data-name="<?php echo h($parent['parent_name']); ?>"
                                           data-type="Parent"
                                           style="color: var(--corporate-red); padding: 5px 10px; border: 1px solid #eee; border-radius: 4px; display: flex; align-items: center; justify-content: center;"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.data-table {
    width: 100%;
    border-collapse: collapse;
}
.data-table th, .data-table td {
    padding: 15px;
    border-bottom: 1px solid #eee;
    text-align: left;
}
.data-table th {
    background: #f8f9fa;
    color: var(--secondary-text);
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.8rem;
}
.data-table tbody tr:hover {
    background: rgba(0,0,0,0.01);
}
</style>

<?php require_once '../../includes/footer.php'; ?>
