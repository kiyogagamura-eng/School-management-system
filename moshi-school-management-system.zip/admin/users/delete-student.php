<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    redirect('students.php', "Student ID required for deletion.");
}

$id = $_GET['id'];

try {
    $pdo->beginTransaction();

    // 1. Get User ID
    $stmt = $pdo->prepare("SELECT user_id FROM students WHERE student_id = ?");
    $stmt->execute([$id]);
    $user_id = $stmt->fetchColumn();

    if ($user_id) {
        // 2. Cascade deletion (In a real DB we'd have ON DELETE CASCADE)
        // Manual cleanup to be safe
        $pdo->prepare("DELETE FROM attendance WHERE student_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM results WHERE student_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM parents WHERE student_id = ?")->execute([$id]);
        
        // 3. Delete Student Profile
        $pdo->prepare("DELETE FROM students WHERE student_id = ?")->execute([$id]);
        
        // 4. Delete User Account
        $pdo->prepare("DELETE FROM users WHERE user_id = ?")->execute([$user_id]);

        $pdo->commit();
        redirect('students.php', "Student records and associated user account have been permanently deleted.");
    } else {
        $pdo->rollBack();
        redirect('students.php', "Student not found or already deleted.", "error");
    }
} catch (PDOException $e) {
    $pdo->rollBack();
    redirect('students.php', "Deletion failed: " . $e->getMessage(), "error");
}
?>
