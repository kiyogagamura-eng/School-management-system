<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    redirect('parents.php', "Parent ID required for deletion.");
}

$id = $_GET['id'];

try {
    $stmt = $pdo->prepare("DELETE FROM parents WHERE parent_id = ?");
    $stmt->execute([$id]);

    redirect('parents.php', "Parent record deleted successfully.");
} catch (PDOException $e) {
    redirect('parents.php', "Deletion failed: " . $e->getMessage(), "error");
}
