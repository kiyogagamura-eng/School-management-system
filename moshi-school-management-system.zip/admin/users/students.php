<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Student Management";

// Filters
$search = $_GET['search'] ?? '';
$class_id = $_GET['class_id'] ?? '';
$status = $_GET['status'] ?? '';

// Build Query
$query = "SELECT s.*, c.class_name, u.last_login 
          FROM students s 
          LEFT JOIN classes c ON s.class_id = c.class_id 
          LEFT JOIN users u ON s.user_id = u.user_id 
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_number LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($class_id)) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_id;
}

if (!empty($status)) {
    $query .= " AND s.status = ?";
    $params[] = $status;
}

$query .= " ORDER BY s.first_name ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
    
    // Fetch classes for filter
    $classes = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY class_name ASC")->fetchAll();

    // Stats
    $total_students = count($students);
    $male_count = 0;
    $female_count = 0;
    foreach ($students as $s) {
        if (strtolower($s['gender'] ?? '') == 'male') $male_count++;
        if (strtolower($s['gender'] ?? '') == 'female') $female_count++;
    }
} catch (PDOException $e) {
    $students = [];
    $classes = [];
}
?>
<?php
require_once '../../includes/header.php';
?>
<div class="main-content-inner">
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-user-graduate"></i> <?php echo $page_title; ?></h2>
            <p style="color: var(--secondary-text); margin-top: 5px;">Manage student records and admissions.</p>
        </div>
        <div style="display: flex; gap: 10px;">
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="add-student.php" class="btn btn-primary" style="background: #940000; border-color: #940000; font-weight: 700;"><i class="fas fa-plus"></i> Add New Student</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="dashboard-grid">
        <div class="card" style="padding: 20px; text-align: center; border-left: 5px solid var(--corporate-red); margin-bottom: 0;">
            <div style="font-size: 0.8rem; color: var(--secondary-text); font-weight: 700; text-transform: uppercase;">Total Students</div>
            <div style="font-size: 2rem; font-weight: 700; color: var(--corporate-red);"><?php echo $total_students; ?></div>
        </div>
        <div class="card" style="padding: 20px; text-align: center; border-left: 5px solid #1e293b; margin-bottom: 0;">
            <div style="font-size: 0.8rem; color: var(--secondary-text); font-weight: 700; text-transform: uppercase;">Male</div>
            <div style="font-size: 2rem; font-weight: 700; color: #1e293b;"><?php echo $male_count; ?></div>
        </div>
        <div class="card" style="padding: 20px; text-align: center; border-left: 5px solid #940000; margin-bottom: 0;">
            <div style="font-size: 0.8rem; color: var(--secondary-text); font-weight: 700; text-transform: uppercase;">Female</div>
            <div style="font-size: 2rem; font-weight: 700; color: #940000;"><?php echo $female_count; ?></div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-body">
            <form method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                    <label style="display: block; margin-bottom: 5px; font-size: 0.8rem; font-weight: 700;">Search Name/Adm. No</label>
                    <input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Search..." style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="width: 150px;">
                    <label style="display: block; margin-bottom: 5px; font-size: 0.8rem; font-weight: 700;">Class</label>
                    <select name="class_id" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['class_id']; ?>" <?php echo $class_id == $c['class_id'] ? 'selected' : ''; ?>>
                                <?php echo h($c['class_name'] ?? ''); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="width: 150px;">
                    <label style="display: block; margin-bottom: 5px; font-size: 0.8rem; font-weight: 700;">Status</label>
                    <select name="status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">All Status</option>
                        <option value="Active" <?php echo $status == 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Graduated" <?php echo $status == 'Graduated' ? 'selected' : ''; ?>>Graduated</option>
                        <option value="Transferred" <?php echo $status == 'Transferred' ? 'selected' : ''; ?>>Transferred</option>
                        <option value="Inactive" <?php echo $status == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div style="display: flex; gap: 5px;">
                    <button type="submit" class="btn btn-primary" style="padding: 10px 20px; background: #940000; border-color: #940000; font-weight: 700;"><i class="fas fa-search"></i> Filter</button>
                    <button type="button" class="btn btn-outline" style="padding: 10px 20px;" onclick="window.location.href='students.php';">Reset</button>
                </div>
            </form>
        </div>
    </div>

            <div class="card">
                <div class="card-header">Student Records</div>
                <div class="card-body table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Admission No</th>
                                <th>Full Name</th>
                                <th>Gender</th>
                                <th>Class</th>
                                <th>Parent Contact</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($students)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; color: var(--secondary-text);">No students found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($students as $student): ?>
                                    <tr>
                                        <td><?php echo h($student['admission_number']); ?></td>
                                        <td style="font-weight: 700;">
                                            <?php echo h($student['first_name'] . ' ' . $student['last_name']); ?>
                                        </td>
                                        <td><?php echo $student['gender']; ?></td>
                                        <td><?php echo h($student['class_name'] ?? 'Not Assigned'); ?></td>
                                        <td><?php echo h($student['parent_phone']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $student['status'] == 'Active' ? 'badge-active' : 'badge-inactive'; ?>">
                                                <?php echo $student['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="student-profile.php?id=<?php echo $student['student_id']; ?>" title="Profile" style="margin-right: 10px; color: #1e293b;"><i class="fas fa-eye"></i></a>
                                            <a href="edit-student.php?id=<?php echo $student['student_id']; ?>" title="Edit" style="margin-right: 10px; color: #64748b;"><i class="fas fa-edit"></i></a>
                                            <a href="javascript:void(0)" 
                                               class="btn-delete-confirm"
                                               data-url="delete-student.php?id=<?php echo $student['student_id']; ?>" 
                                               data-name="<?php echo h($student['first_name'] . ' ' . $student['last_name']); ?>"
                                               data-type="Student"
                                               title="Delete" 
                                               style="color: var(--corporate-red);">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
