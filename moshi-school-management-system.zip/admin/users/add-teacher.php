<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Add New Teacher";
$error = '';
$success = '';

// Fetch all subjects for the specialization dropdown
$stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name");
$subjects = $stmt->fetchAll();

// Fetch all classes for the class teacher assignment
$stmt = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream");
$classes = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $employee_id = trim($_POST['employee_id']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = trim($_POST['email']);
    $phone = '+255' . trim($_POST['phone']);
    $qualification = trim($_POST['qualification']);
    $specialization = isset($_POST['specialization']) ? implode(', ', $_POST['specialization']) : '';
    $staff_position = trim($_POST['staff_position'] ?: 'Teacher');
    $class_teacher_for = !empty($_POST['class_teacher_for']) ? $_POST['class_teacher_for'] : null;
    $hire_date = $_POST['hire_date'];
    $address = trim($_POST['address']);

    // Custom credentials
    $username = !empty($_POST['username']) ? trim($_POST['username']) : strtolower($employee_id);
    $password_raw = (!empty($_POST['password']) && $_POST['password'] !== DEFAULT_PASSWORD) ? $_POST['password'] : DEFAULT_PASSWORD;

    // VALIDATION
    if (isset($_POST['specialization']) && count($_POST['specialization']) > 2) {
        $error = "A teacher can only be assigned a maximum of 2 teaching subjects.";
    } elseif (!isValidName($first_name) || !isValidName($last_name) || !isValidName($middle_name)) {
        $error = "Names must contain only letters (A-Z). Numbers and special characters are not allowed.";
    } elseif (!isValidTanzanianPhone($phone)) {
        $error = "Invalid Phone Number. Use format +255XXXXXXXXX (e.g. +255711444501)";
    } elseif (!isValidPasswordFormat($password_raw)) {
        $error = "Password must be alphanumeric (contain at least one letter and one number) e.g. machaka123";
    } else {
        $password = password_hash($password_raw, PASSWORD_BCRYPT);
        
        // Check uniqueness
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $error = "A teacher with this Employee ID (username) already exists.";
        } else {
            try {
                $pdo->beginTransaction();

                // 0. Implement Unique Position Logic
                $unique_positions = ['Headmaster', 'Deputy Headmaster', 'Director of Studies', 'Assistant Head (Academic)', 'Assistant Head (Admin)', 'Discipline Master'];
                
                if (in_array($staff_position, $unique_positions)) {
                    $stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE staff_position = ?");
                    $stmt->execute([$staff_position]);
                    $old_holders = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    if (!empty($old_holders)) {
                        $stmt = $pdo->prepare("UPDATE teachers SET staff_position = 'Teacher' WHERE staff_position = ?");
                        $stmt->execute([$staff_position]);
                        
                        $placeholders = implode(',', array_fill(0, count($old_holders), '?'));
                        $stmt = $pdo->prepare("UPDATE users SET role = 'teacher' WHERE user_id IN ($placeholders)");
                        $stmt->execute($old_holders);
                    }
                }

                $system_role = 'teacher';
                if ($staff_position == 'Headmaster' || $staff_position == 'Deputy Headmaster') $system_role = 'headteacher';
                if ($staff_position == 'Director of Studies' || $staff_position == 'Assistant Head (Academic)') $system_role = 'dos';
                if ($staff_position == 'Discipline Master') $system_role = 'discipline';
                if ($staff_position == 'Assistant Head (Admin)') $system_role = 'admin';

                // 1. Create User
                $stmt = $pdo->prepare("INSERT INTO users (username, password, email, phone, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$username, $password, $email, $phone, $system_role]);
                $user_id = $pdo->lastInsertId();

                // 2. Create Teacher Profile
                $stmt = $pdo->prepare("INSERT INTO teachers (user_id, employee_id, first_name, middle_name, last_name, gender, date_of_birth, phone, email, qualification, specialization, staff_position, hire_date, address, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')");
                $stmt->execute([
                    $user_id, $employee_id, $first_name, $middle_name, $last_name, 
                    $gender, $dob, $phone, $email, $qualification, 
                    $specialization, $staff_position, $hire_date, $address
                ]);
                $teacher_id = $pdo->lastInsertId();

                // 3. Class Teacher
                if ($class_teacher_for) {
                    $stmt = $pdo->prepare("UPDATE classes SET class_teacher_id = ? WHERE class_id = ?");
                    $stmt->execute([$teacher_id, $class_teacher_for]);
                }

                // 4. Auto assign class subjects
                $teaching_classes = isset($_POST['teaching_classes']) ? $_POST['teaching_classes'] : [];
                $specialization_post = isset($_POST['specialization']) ? $_POST['specialization'] : [];
                if (!empty($teaching_classes) && !empty($specialization_post)) {
                    $subject_name_to_id = [];
                    foreach ($subjects as $sub) {
                        $subject_name_to_id[$sub['subject_name']] = $sub['subject_id'];
                    }
                    
                    $selected_subject_ids = [];
                    foreach ($specialization_post as $spec_name) {
                        if (isset($subject_name_to_id[$spec_name])) {
                            $selected_subject_ids[] = $subject_name_to_id[$spec_name];
                        }
                    }
                    
                    if (!empty($selected_subject_ids)) {
                        $stmt_cs = $pdo->prepare("INSERT INTO class_subjects (class_id, subject_id, teacher_id) VALUES (?, ?, ?)");
                        foreach ($teaching_classes as $class_id) {
                            foreach ($selected_subject_ids as $sub_id) {
                                $stmt_cs->execute([$class_id, $sub_id, $teacher_id]);
                            }
                        }
                    }
                }

                // 5. Trigger Real-Time Notification to Headteacher
                $admin_name = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';
                $notif_msg = "Mtumiaji mpya $first_name $last_name (Role: $staff_position) amesajiliwa na $admin_name.";
                createNotification('headteacher', null, $notif_msg, BASE_URL . 'admin/users/teachers.php');

                $pdo->commit();
                redirect('teachers.php', "Mwalimu $first_name $last_name amesajiliwa. Password yake ya kuingia: <strong>$password_raw</strong> — Tafadhali ambie abadilishe kwenye profile yake.");
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Database Error: " . $e->getMessage();
            }
        }
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner" style="max-width: 1200px; margin: 0 auto; width: 100%;">
    <div style="margin-bottom: 20px;">
        <a href="teachers.php" style="color: var(--secondary-text); font-weight: 700; text-decoration: none;"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red); border-radius: 10px; overflow: hidden; background: #FFF;">
        <div class="card-header" style="background: var(--header-gradient); padding: 20px 25px;">
            <h3 style="margin: 0; color: #8b0000; font-weight: 800;"><i class="fas fa-user-tie"></i> <?php echo $page_title; ?></h3>
        </div>
        <div class="card-body" style="padding: 30px;">
            <?php if ($error): ?>
                <div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 25px; border-left: 4px solid var(--corporate-red); font-weight: 700;">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <!-- Section 1 -->
                <h4 style="margin-top: 0; color: #8b0000; border-bottom: 1.5px solid rgba(139,0,0,0.1); padding-bottom: 10px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">Personal Information</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">First Name <span style="color:red;">*</span></label>
                        <input type="text" name="first_name" class="form-control" required placeholder="e.g. John" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Middle Name</label>
                        <input type="text" name="middle_name" class="form-control" placeholder="e.g. Peter" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Last Name <span style="color:red;">*</span></label>
                        <input type="text" name="last_name" class="form-control" required placeholder="e.g. Mushi" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Employee ID / Username <span style="color:red;">*</span></label>
                        <input type="text" name="employee_id" class="form-control" required placeholder="e.g. T-101" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Gender <span style="color:red;">*</span></label>
                        <select name="gender" class="form-control" required style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7; height: auto; background: white;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" style="padding: 9px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Login Username <span style="color:red;">*</span></label>
                        <input type="text" name="username" id="username_field" class="form-control" required placeholder="Default: employee id" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Initial username for portal login</small>
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Initial Password <span style="color:red;">*</span></label>
                        <input type="text" name="password" class="form-control" value="<?php echo DEFAULT_PASSWORD; ?>" placeholder="e.g. moshi123" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Default: <strong><?php echo DEFAULT_PASSWORD; ?></strong>. Waweza kubadilisha hapa.</small>
                    </div>
                </div>

                <!-- Section 2 -->
                <h4 style="margin-top: 30px; color: #8b0000; border-bottom: 1.5px solid rgba(139,0,0,0.1); padding-bottom: 10px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">Contact & Professional Details</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Phone Number <span style="color:red;">*</span></label>
                        <div class="input-group" style="display: flex;">
                            <div class="input-prefix" style="background: #FFF5F5; border: 1px solid #BDC3C7; border-right: none; display: flex; align-items: center; justify-content: center; padding: 0 15px; border-top-left-radius: 6px; border-bottom-left-radius: 6px; font-weight: 700; color: #8b0000;">+255</div>
                            <input type="text" name="phone" class="form-control input-with-prefix phone-input-9" required 
                                   pattern="[0-9]{9}" 
                                   maxlength="9"
                                   placeholder="711444501"
                                   title="Enter the 9 digits after +255"
                                   style="padding: 10px 12px; border-top-left-radius: 0; border-bottom-left-radius: 0; border-top-right-radius: 6px; border-bottom-right-radius: 6px; border: 1px solid #BDC3C7; flex: 1;">
                        </div>
                    </div>
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="font-weight: 700; color: #2C3E50;">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="teacher@moshi.sc.tz" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="font-weight: 700; color: #2C3E50;">Qualifications</label>
                        <input type="text" name="qualification" class="form-control" placeholder="e.g. Bachelor of Education" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Staff Role/Position <span style="color: red;">*</span></label>
                        <select name="staff_position" class="form-control" required style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7; height: auto; background: white;">
                            <option value="">-- Select Position --</option>
                            <optgroup label="School Leadership">
                                <option value="Headmaster">Headmaster</option>
                                <option value="Deputy Headmaster">Deputy Headmaster</option>
                                <option value="Discipline Master">Discipline Master</option>
                            </optgroup>
                            <optgroup label="Academic Management">
                                <option value="Assistant Head (Academic)">Assistant Head (Academic)</option>
                                <option value="Director of Studies">Director of Studies (DOS)</option>
                            </optgroup>
                            <optgroup label="Administrative">
                                <option value="Assistant Head (Admin)">Assistant Head (Admin)</option>
                            </optgroup>
                            <optgroup label="Teaching Staff">
                                <option value="Subject Head">Subject Head</option>
                                <option value="Class Teacher">Class Teacher</option>
                                <option value="Teacher" selected>Teacher</option>
                            </optgroup>
                        </select>
                        <small style="color: #666; display: block; margin-top: 5px;"><i class="fas fa-info-circle"></i> Determines portal access</small>
                    </div>
                    
                    <!-- Specialization Grid (Widespread Span) -->
                    <div class="form-group" style="grid-column: 1 / -1; margin-top: 10px;">
                        <label style="font-weight: 700; color: #2C3E50;">Teaching Subjects (Specialization) <span style="color:red;">*</span></label>
                        <div class="subject-selection-grid">
                            <?php foreach($subjects as $sub): ?>
                                <label class="subject-item" id="subject-label-<?php echo $sub['subject_id']; ?>">
                                    <input type="checkbox" name="specialization[]" value="<?php echo h($sub['subject_name']); ?>" class="subject-checkbox" data-name="<?php echo h($sub['subject_name']); ?>">
                                    <div class="subject-content">
                                        <div class="subject-name"><?php echo h($sub['subject_name']); ?></div>
                                        <div class="subject-status">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <div style="margin-top: 10px;">
                            <small style="color: var(--secondary-text); font-weight: 600;">Selected: <span id="selected-subjects-count" style="color: #8b0000;">0</span>/2 subjects</small>
                            <div id="selected-list" style="display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;"></div>
                        </div>
                        <style>
                            .subject-selection-grid {
                                display: grid;
                                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
                                gap: 10px;
                                max-height: 250px;
                                overflow-y: auto;
                                padding: 10px;
                                background: #f9f9f9;
                                border: 1px solid #ddd;
                                border-radius: 8px;
                            }
                            .subject-item {
                                position: relative;
                                cursor: pointer;
                            }
                            .subject-checkbox {
                                position: absolute;
                                opacity: 0;
                                cursor: pointer;
                            }
                            .subject-content {
                                padding: 12px 15px;
                                background: white;
                                border: 1px solid #eee;
                                border-radius: 8px;
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                transition: all 0.2s;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.02);
                            }
                            .subject-item:hover .subject-content {
                                border-color: #8b0000;
                                transform: translateY(-1px);
                            }
                            .subject-checkbox:checked + .subject-content {
                                background: #FFF5F5;
                                border-color: #8b0000;
                                box-shadow: 0 4px 8px rgba(139, 0, 0, 0.1);
                            }
                            .subject-name {
                                font-size: 0.85rem;
                                font-weight: 700;
                                color: #333;
                            }
                            .subject-status {
                                color: transparent;
                                font-size: 1rem;
                                transition: 0.2s;
                            }
                            .subject-checkbox:checked + .subject-content .subject-status {
                                color: #8b0000;
                            }
                            .tag-subject {
                                background: #8b0000;
                                color: white;
                                padding: 4px 10px;
                                border-radius: 4px;
                                font-size: 10px;
                                font-weight: 800;
                                text-transform: uppercase;
                            }
                        </style>
                    </div>

                    <!-- Close Div Fix -> Nesting issue solved here -->
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Assign as Class Teacher (Optional)</label>
                        <select name="class_teacher_for" class="form-control" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7; background: white; height: auto;">
                            <option value="">-- Select Class --</option>
                            <?php foreach($classes as $c): ?>
                                <option value="<?php echo $c['class_id']; ?>"><?php echo h($c['class_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Leave empty if not a class teacher</small>
                    </div>
                    
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Hire Date</label>
                        <input type="date" name="hire_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" style="padding: 9px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    
                    <!-- Classes selection Grid (Widespread Span) -->
                    <div class="form-group" style="grid-column: 1 / -1; margin-top: 15px; margin-bottom: 10px;">
                        <label style="font-weight: 700; color: #2C3E50;">Teaching Classes (Select all classes this teacher teaches) <span style="color:red;">*</span></label>
                        <div class="class-selection-grid">
                            <?php foreach($classes as $c): ?>
                                <label class="class-item" id="class-label-<?php echo $c['class_id']; ?>">
                                    <input type="checkbox" name="teaching_classes[]" value="<?php echo $c['class_id']; ?>" class="class-checkbox" data-name="<?php echo h($c['class_name']); ?>">
                                    <div class="class-content">
                                        <div class="class-name"><?php echo h($c['class_name']); ?></div>
                                        <div class="class-status">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <small style="color: var(--secondary-text); display: block; margin-top: 5px;">
                            <i class="fas fa-info-circle"></i> The teacher will automatically be assigned to teach specialization subjects in these classes.
                        </small>
                        <style>
                            .class-selection-grid {
                                display: grid;
                                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                                gap: 10px;
                                max-height: 200px;
                                overflow-y: auto;
                                padding: 10px;
                                background: #f9f9f9;
                                border: 1px solid #ddd;
                                border-radius: 8px;
                            }
                            .class-item {
                                position: relative;
                                cursor: pointer;
                            }
                            .class-checkbox {
                                position: absolute;
                                opacity: 0;
                                cursor: pointer;
                            }
                            .class-content {
                                padding: 10px 15px;
                                background: white;
                                border: 1px solid #eee;
                                border-radius: 8px;
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                transition: all 0.2s;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.02);
                            }
                            .class-item:hover .class-content {
                                border-color: #8b0000;
                                transform: translateY(-1px);
                            }
                            .class-checkbox:checked + .class-content {
                                background: #FFF5F5;
                                border-color: #8b0000;
                                box-shadow: 0 4px 8px rgba(139, 0, 0, 0.1);
                            }
                            .class-name {
                                font-size: 0.85rem;
                                font-weight: 700;
                                color: #333;
                            }
                            .class-status {
                                color: transparent;
                                font-size: 1rem;
                                transition: 0.2s;
                            }
                            .class-checkbox:checked + .class-content .class-status {
                                color: #8b0000;
                            }
                        </style>
                    </div>
                    
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="font-weight: 700; color: #2C3E50;">Address</label>
                        <input type="text" name="address" class="form-control" placeholder="Residential Address" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                </div>

                <div style="margin-top: 40px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; padding: 12px; background: #8b0000; border-color: #8b0000; font-weight: 700; border-radius: 6px;">REGISTER TEACHER</button>
                    <a href="teachers.php" class="btn btn-outline" style="flex: 1; padding: 12px; text-align: center; border-radius: 6px; font-weight: 700; text-decoration: none; display: flex; justify-content: center; align-items: center; border: 1px solid #BDC3C7; color: #2C3E50;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Auto-populate username field when Employee ID changes
document.querySelector('input[name="employee_id"]').addEventListener('input', function() {
    const userField = document.getElementById('username_field');
    if (userField && !userField.dataset.edited) {
        userField.value = this.value.toLowerCase().replace(/[^a-z0-9_-]/g, '');
    }
});
document.getElementById('username_field').addEventListener('input', function() {
    this.dataset.edited = true;
});

// Handle Subject Selection Checkboxes
const checkboxes = document.querySelectorAll('.subject-checkbox');
const countSpan = document.getElementById('selected-subjects-count');
const selectedList = document.getElementById('selected-list');

checkboxes.forEach(cb => {
    cb.addEventListener('change', function() {
        const selected = document.querySelectorAll('.subject-checkbox:checked');
        
        if (selected.length > 2) {
            this.checked = false;
            alert("A teacher can only be assigned a maximum of 2 subjects.");
            return;
        }

        countSpan.textContent = selected.length;

        selectedList.innerHTML = '';
        selected.forEach(s => {
            const tag = document.createElement('span');
            tag.className = 'tag-subject';
            tag.textContent = s.dataset.name;
            selectedList.appendChild(tag);
        });
    });
});
</script>

<?php require_once '../../includes/footer.php'; ?>
