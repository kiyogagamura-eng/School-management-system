<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    redirect('teachers.php', "Teacher ID required for deletion.");
}

$id = $_GET['id'];

try {
    $pdo->beginTransaction();

    // 1. Get User ID
    $stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE teacher_id = ?");
    $stmt->execute([$id]);
    $user_id = $stmt->fetchColumn();

    if ($user_id) {
        // 2. Handle dependencies
        // Clear class teacher assignments
        $pdo->prepare("UPDATE classes SET class_teacher_id = NULL WHERE class_teacher_id = ?")->execute([$id]);
        
        // Clear subject assignments
        $pdo->prepare("UPDATE class_subjects SET teacher_id = NULL WHERE teacher_id = ?")->execute([$id]);
        
        // Mark attendance as marked by system (optional, or delete)
        // Here we keep them but it might cause issues if teacher_id is mandatory. 
        // Let's check table... it was (int(11)). 
        // We'll set it to a fallback admin or just keep it 0 if allowed.
        // For simplicity in this school system, we'll keep audit but unpollute user table.
        
        // 3. Delete Teacher Profile
        $pdo->prepare("DELETE FROM teachers WHERE teacher_id = ?")->execute([$id]);
        
        // 4. Delete User Account
        $pdo->prepare("DELETE FROM users WHERE user_id = ?")->execute([$user_id]);

        $pdo->commit();
        redirect('teachers.php', "Teacher records and associated account have been permanently deleted.");
    } else {
        $pdo->rollBack();
        redirect('teachers.php', "Teacher not found or already deleted.", "error");
    }
} catch (PDOException $e) {
    $pdo->rollBack();
    redirect('teachers.php', "Deletion failed: " . $e->getMessage(), "error");
}
?>
