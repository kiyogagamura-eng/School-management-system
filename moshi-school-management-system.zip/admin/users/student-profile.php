<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    redirect('students.php', "Student ID required.");
}

$id = $_GET['id'];

// Fetch Student Data with Class and Attendance Stats
try {
    $stmt = $pdo->prepare("SELECT s.*, c.class_name, u.username, u.last_login 
                          FROM students s 
                          JOIN users u ON s.user_id = u.user_id 
                          LEFT JOIN classes c ON s.class_id = c.class_id
                          WHERE s.student_id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();

    if (!$student) {
        redirect('students.php', "Student not found.");
    }

    // ── Real Attendance Stats from DB ──
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_days,
            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_days,
            SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_days
        FROM attendance 
        WHERE student_id = ?
    ");
    $stmt->execute([$id]);
    $att_data = $stmt->fetch();
    $attendance_pct = ($att_data['total_days'] > 0) 
        ? round((($att_data['present_days'] + $att_data['late_days']) / $att_data['total_days']) * 100, 1) 
        : 0;

    // ── Real Average Marks from Published Results ──
    $stmt = $pdo->prepare("
        SELECT AVG(r.marks_obtained) as avg_marks
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        WHERE r.student_id = ? AND r.status = 'published'
    ");
    $stmt->execute([$id]);
    $avg_row = $stmt->fetch();
    $avg_marks = $avg_row['avg_marks'] !== null ? round($avg_row['avg_marks'], 1) : null;

    // ── Real Class Rank (based on latest published exam average) ──
    $class_rank = null;
    $total_in_class = 0;
    if ($student['class_id']) {
        // Get all students in the same class ranked by their overall average
        $stmt = $pdo->prepare("
            SELECT r.student_id, AVG(r.marks_obtained) as avg_marks
            FROM results r
            JOIN exams e ON r.exam_id = e.exam_id
            WHERE r.class_id = ? AND r.status = 'published'
            GROUP BY r.student_id
            ORDER BY avg_marks DESC
        ");
        $stmt->execute([$student['class_id']]);
        $rankings = $stmt->fetchAll();
        $total_in_class = count($rankings);
        foreach ($rankings as $idx => $rank_row) {
            if ($rank_row['student_id'] == $id) {
                $class_rank = $idx + 1;
                break;
            }
        }
    }

    // ── Recent Exam Results ──
    $stmt = $pdo->prepare("
        SELECT r.marks_obtained, r.grade, e.exam_name, e.exam_date, sub.subject_name
        FROM results r
        JOIN exams e ON r.exam_id = e.exam_id
        JOIN subjects sub ON r.subject_id = sub.subject_id
        WHERE r.student_id = ? AND r.status = 'published'
        ORDER BY e.exam_date DESC LIMIT 5
    ");
    $stmt->execute([$id]);
    $recent_results = $stmt->fetchAll();

    // ── Discipline Records Count ──
    $discipline_count = 0;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM discipline_records WHERE student_id = ?");
        $stmt->execute([$id]);
        $discipline_count = $stmt->fetchColumn();
    } catch (PDOException $e) {
        // Table may not exist yet
    }

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Attendance color logic
$att_color = '#94a3b8'; // grey for 0/no data
if ($att_data['total_days'] > 0) {
    if ($attendance_pct >= 80) $att_color = '#16a34a';      // green
    elseif ($attendance_pct >= 60) $att_color = '#f59e0b';   // amber
    else $att_color = '#dc2626';                              // red
}

$page_title = "Student Profile: " . h($student['first_name']);
require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px;">
        <a href="students.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to List</a>
        <a href="edit-student.php?id=<?php echo $id; ?>" class="btn btn-primary"><i class="fas fa-edit"></i> Edit Profile</a>
    </div>

    <div style="display: grid; grid-template-columns: 300px 1fr; gap: 30px;">
        <!-- Sidebar / Photo -->
        <div>
            <div class="card shadow-premium" style="text-align: center; padding: 30px;">
                <div style="width: 150px; height: 150px; background: #eee; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; font-size: 4rem; color: #ccc;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h3 style="margin: 0; color: #333;"><?php echo h($student['first_name'] . ' ' . $student['last_name']); ?></h3>
                <p style="color: var(--corporate-red); font-weight: 700; margin: 5px 0;"><?php echo h($student['admission_number']); ?></p>
                <span class="badge <?php echo $student['status'] == 'Active' ? 'badge-active' : 'badge-inactive'; ?>">
                    <?php echo $student['status']; ?>
                </span>
                
                <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; text-align: left;">
                    <div style="margin-bottom: 10px;">
                        <small style="display: block; color: var(--secondary-text);">Current Class</small>
                        <strong><?php echo h($student['class_name'] ?? 'Not Assigned'); ?></strong>
                    </div>
                    <div>
                        <small style="display: block; color: var(--secondary-text);">Last Login</small>
                        <strong><?php echo $student['last_login'] ? date('d M Y H:i', strtotime($student['last_login'])) : 'Never'; ?></strong>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top: 20px;">
                <div class="card-header">Academic Snapshot</div>
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span>Attendance</span>
                        <strong style="color: <?php echo $att_color; ?>;">
                            <?php echo $att_data['total_days'] > 0 ? $attendance_pct . '%' : '<span style="color:#94a3b8;">N/A</span>'; ?>
                        </strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <span>Avg Marks</span>
                        <strong style="color: <?php echo $avg_marks !== null ? ($avg_marks >= 60 ? '#16a34a' : ($avg_marks >= 40 ? '#f59e0b' : '#dc2626')) : '#94a3b8'; ?>;">
                            <?php echo $avg_marks !== null ? $avg_marks . '%' : 'N/A'; ?>
                        </strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Class Rank</span>
                        <strong style="color: var(--corporate-red);">
                            <?php echo $class_rank !== null ? $class_rank . '/' . $total_in_class : 'N/A'; ?>
                        </strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div>
            <div class="card shadow-premium">
                <div class="card-header">Personal Information</div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <div>
                            <small style="color: var(--secondary-text);">Full Name</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo h($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']); ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Gender</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo $student['gender']; ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Date of Birth</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo $student['date_of_birth'] ? date('d M Y', strtotime($student['date_of_birth'])) : 'N/A'; ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Enrollment Date</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo date('d M Y', strtotime($student['enrollment_date'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-premium" style="margin-top: 30px;">
                <div class="card-header">Parent / Guardian Details</div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <div>
                            <small style="color: var(--secondary-text);">Guardian Name</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo h($student['parent_name']); ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Contact Phone</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0; color: #3498db;"><?php echo h($student['parent_phone']); ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Email Address</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo h($student['parent_email'] ?: 'No email provided'); ?></p>
                        </div>
                        <div>
                            <small style="color: var(--secondary-text);">Residential Address</small>
                            <p style="font-weight: 700; font-size: 1.1rem; margin: 5px 0;"><?php echo h($student['address']); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Attendance Breakdown -->
            <div class="card shadow-premium" style="margin-top: 30px;">
                <div class="card-header"><i class="fas fa-calendar-check" style="color: var(--corporate-red); margin-right: 8px;"></i> Attendance Breakdown</div>
                <div class="card-body">
                    <?php if ($att_data['total_days'] > 0): ?>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; text-align: center;">
                        <div style="background: #f0fdf4; border-radius: 10px; padding: 15px;">
                            <div style="font-size: 1.8rem; font-weight: 800; color: #16a34a;"><?php echo $att_data['present_days']; ?></div>
                            <small style="color: #64748b; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Present</small>
                        </div>
                        <div style="background: #fef2f2; border-radius: 10px; padding: 15px;">
                            <div style="font-size: 1.8rem; font-weight: 800; color: #dc2626;"><?php echo $att_data['absent_days']; ?></div>
                            <small style="color: #64748b; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Absent</small>
                        </div>
                        <div style="background: #fffbeb; border-radius: 10px; padding: 15px;">
                            <div style="font-size: 1.8rem; font-weight: 800; color: #f59e0b;"><?php echo $att_data['late_days']; ?></div>
                            <small style="color: #64748b; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Late</small>
                        </div>
                        <div style="background: #f1f5f9; border-radius: 10px; padding: 15px;">
                            <div style="font-size: 1.8rem; font-weight: 800; color: #334155;"><?php echo $att_data['total_days']; ?></div>
                            <small style="color: #64748b; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Total Sessions</small>
                        </div>
                    </div>
                    <!-- Attendance progress bar -->
                    <div style="margin-top: 15px; background: #f1f5f9; border-radius: 8px; height: 10px; overflow: hidden;">
                        <div style="width: <?php echo $attendance_pct; ?>%; height: 100%; background: <?php echo $att_color; ?>; border-radius: 8px; transition: width 0.5s;"></div>
                    </div>
                    <div style="text-align: right; margin-top: 5px; font-size: 0.8rem; color: var(--secondary-text);">
                        Overall: <strong style="color: <?php echo $att_color; ?>;"><?php echo $attendance_pct; ?>%</strong>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; color: #94a3b8; padding: 30px 0;">
                        <i class="fas fa-calendar-times" style="font-size: 2rem; margin-bottom: 10px; display: block;"></i>
                        No attendance records found for this student yet.
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Exam Results -->
            <div class="card shadow-premium" style="margin-top: 30px;">
                <div class="card-header"><i class="fas fa-chart-line" style="color: var(--corporate-red); margin-right: 8px;"></i> Recent Exam Results (Published)</div>
                <div class="card-body">
                    <?php if ($recent_results): ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 2px solid #f0f0f0;">
                                <th style="text-align: left; padding: 10px 0; color: var(--secondary-text); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">Exam</th>
                                <th style="text-align: left; padding: 10px 0; color: var(--secondary-text); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">Subject</th>
                                <th style="text-align: center; padding: 10px 0; color: var(--secondary-text); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">Marks</th>
                                <th style="text-align: center; padding: 10px 0; color: var(--secondary-text); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_results as $res): 
                                $grade_letter = substr($res['grade'] ?? 'F', 0, 1);
                                $grade_colors = [
                                    'A' => ['bg' => '#f0fdf4', 'color' => '#16a34a'],
                                    'B' => ['bg' => '#eff6ff', 'color' => '#2563eb'],
                                    'C' => ['bg' => '#fffbeb', 'color' => '#d97706'],
                                    'D' => ['bg' => '#f1f5f9', 'color' => '#64748b'],
                                    'E' => ['bg' => '#fef2f2', 'color' => '#dc2626'],
                                    'F' => ['bg' => '#fef2f2', 'color' => '#dc2626'],
                                ];
                                $gc = $grade_colors[$grade_letter] ?? $grade_colors['F'];
                            ?>
                            <tr style="border-bottom: 1px dashed #f0f0f0;">
                                <td style="padding: 12px 0;">
                                    <div style="font-weight: 700; color: var(--primary-text); font-size: 0.9rem;"><?php echo h($res['exam_name']); ?></div>
                                    <div style="font-size: 0.75rem; color: var(--secondary-text);"><?php echo $res['exam_date'] ? date('d M Y', strtotime($res['exam_date'])) : ''; ?></div>
                                </td>
                                <td style="padding: 12px 0; font-size: 0.9rem;"><?php echo h($res['subject_name']); ?></td>
                                <td style="padding: 12px 0; text-align: center; font-weight: 800; font-size: 1.1rem; color: var(--corporate-red);">
                                    <?php echo $res['marks_obtained']; ?>
                                </td>
                                <td style="padding: 12px 0; text-align: center;">
                                    <span style="background: <?php echo $gc['bg']; ?>; color: <?php echo $gc['color']; ?>; padding: 4px 12px; border-radius: 6px; font-weight: 700; font-size: 0.85rem;">
                                        <?php echo $res['grade']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="text-align: center; color: #94a3b8; padding: 30px 0;">
                        <i class="fas fa-clipboard-list" style="font-size: 2rem; margin-bottom: 10px; display: block;"></i>
                        No published exam results found for this student yet.
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>

