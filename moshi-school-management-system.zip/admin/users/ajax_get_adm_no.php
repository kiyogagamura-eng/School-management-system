<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

if (isset($_GET['class_id'])) {
    echo generateAdmissionNumber($_GET['class_id']);
} else {
    echo "STD-ERR-000";
}
?>
