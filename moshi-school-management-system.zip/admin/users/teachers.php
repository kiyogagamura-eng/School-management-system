<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Teacher Management";

// Handle Deactivation/Reactivation if needed
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'] == 'deactivate' ? 'Inactive' : 'Active';
    $stmt = $pdo->prepare("UPDATE teachers SET status = ? WHERE teacher_id = ?");
    $stmt->execute([$action, $id]);
    redirect('teachers.php', "Teacher status updated successfully.");
}

// Filters
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

// Build Query
$query = "SELECT t.*, u.username, u.role, u.last_login 
          FROM teachers t 
          LEFT JOIN users u ON t.user_id = u.user_id 
          WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (t.first_name LIKE ? OR t.last_name LIKE ? OR t.employee_id LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status)) {
    $query .= " AND t.status = ?";
    $params[] = $status;
}

$query .= " ORDER BY t.first_name ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
}

require_once '../../includes/header.php';
?>
<div class="main-content-inner">
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-chalkboard-teacher"></i> <?php echo $page_title; ?></h2>
            <p style="color: var(--secondary-text); margin-top: 5px;">Manage teaching staff and assignments.</p>
        </div>
        <div style="display: flex; gap: 10px;">
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="add-teacher.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Teacher</a>
            <?php endif; ?>
        </div>
    </div>

            <?php if (isset($_SESSION['flash_message'])): ?>
                <div style="background: #fff; border-left: 5px solid var(--corporate-red); padding: 15px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                </div>
            <?php endif; ?>

    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-body">
            <form method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                    <label style="display: block; margin-bottom: 5px; font-size: 0.8rem; font-weight: 700;">Search Name/Employee ID</label>
                    <input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Search..." style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="width: 150px;">
                    <label style="display: block; margin-bottom: 5px; font-size: 0.8rem; font-weight: 700;">Status</label>
                    <select name="status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">All Status</option>
                        <option value="Active" <?php echo $status == 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo $status == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div style="display: flex; gap: 5px;">
                    <button type="submit" class="btn btn-primary" style="padding: 10px 20px;"><i class="fas fa-search"></i> Filter</button>
                    <button type="button" class="btn btn-outline" style="padding: 10px 20px;" onclick="window.location.href='teachers.php';">Reset</button>
                </div>
            </form>
        </div>
    </div>

            <div class="card">
                <div class="card-header">Existing Teachers</div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Employee ID</th>
                                <th>System Role</th>
                                <th>Specialization</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($teachers)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; color: var(--secondary-text);">No teachers found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($teachers as $teacher): ?>
                                    <tr>
                                        <td style="font-weight: 700;">
                                            <?php echo h($teacher['first_name'] . ' ' . $teacher['last_name']); ?>
                                        </td>
                                        <td><?php echo h($teacher['employee_id']); ?></td>
                                        <td>
                                            <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: <?php echo $teacher['role'] == 'dos' ? '#8b0000' : ($teacher['role'] == 'discipline' ? '#ef6c00' : '#7f8c8d'); ?>;">
                                                <?php echo h($teacher['role']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo h($teacher['specialization']); ?></td>
                                        <td><?php echo h($teacher['phone']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $teacher['status'] == 'Active' ? 'badge-active' : 'badge-inactive'; ?>">
                                                <?php echo $teacher['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="edit-teacher.php?id=<?php echo $teacher['teacher_id']; ?>" title="Edit" style="margin-right: 10px; color: #3498db;"><i class="fas fa-edit"></i></a>
                                            <?php if ($teacher['status'] == 'Active'): ?>
                                                <a href="teachers.php?action=deactivate&id=<?php echo $teacher['teacher_id']; ?>" title="Deactivate" style="margin-right: 10px; color: #f39c12;"><i class="fas fa-user-slash"></i></a>
                                            <?php else: ?>
                                                <a href="teachers.php?action=activate&id=<?php echo $teacher['teacher_id']; ?>" title="Activate" style="margin-right: 10px; color: #2ecc71;"><i class="fas fa-user-check"></i></a>
                                            <?php endif; ?>
                                            <a href="javascript:void(0)" 
                                               class="btn-delete-confirm"
                                               data-url="delete-teacher.php?id=<?php echo $teacher['teacher_id']; ?>" 
                                               data-name="<?php echo h($teacher['first_name'] . ' ' . $teacher['last_name']); ?>"
                                               data-type="Teacher"
                                               title="Delete" 
                                               style="color: var(--corporate-red);">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
