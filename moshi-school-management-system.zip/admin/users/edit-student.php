<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Edit Student";
$error = '';
$success = '';

if (!isset($_GET['id'])) {
    redirect('students.php', "Student ID required.");
}

$id = $_GET['id'];

// Fetch Student Data
try {
    $stmt = $pdo->prepare("SELECT s.*, u.username, u.email as u_email, u.phone as u_phone 
                          FROM students s 
                          JOIN users u ON s.user_id = u.user_id 
                          WHERE s.student_id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();

    if (!$student) {
        redirect('students.php', "Student not found.");
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Fetch classes for dropdown
$classes = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY class_name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_student'])) {
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $class_id = !empty($_POST['class_id']) ? $_POST['class_id'] : null;
    $status = $_POST['status'];
    
    $parent_name = trim($_POST['parent_name']);
    $parent_phone = '+255' . trim($_POST['parent_phone']);
    $parent_email = trim($_POST['parent_email']);
    $address = trim($_POST['address']);

    // NEW: Credential Fields
    $new_username = trim($_POST['username']);
    $new_password = $_POST['new_password'];

    try {
        // VALIDATION
        if (!isValidName($first_name) || !isValidName($last_name) || !isValidName($middle_name)) {
            throw new Exception("Student names must contain only letters (A-Z). Numbers and special characters are not allowed.");
        }
        if (!isValidName($parent_name)) {
            throw new Exception("Parent/Guardian name must contain only letters (A-Z). Numbers and special characters are not allowed.");
        }
        if (!isValidTanzanianPhone($parent_phone)) {
            throw new Exception("Invalid Parent Phone. Use format +255XXXXXXXXX");
        }
        if (!empty($new_password) && !isValidPasswordFormat($new_password)) {
            throw new Exception("Password must be alphanumeric (contain at least one letter and one number) e.g. machaka123");
        }

        $pdo->beginTransaction();

        // 1. Check Username Uniqueness (if changed)
        if ($new_username !== $student['username']) {
            $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?");
            $check->execute([$new_username, $student['user_id']]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Username '$new_username' is already taken.");
            }
            
            $stmt = $pdo->prepare("UPDATE users SET username = ? WHERE user_id = ?");
            $stmt->execute([$new_username, $student['user_id']]);
        }

        // 2. Update Password (if provided)
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->execute([$hashed_password, $student['user_id']]);
        }

        // 3. Update Student Profile
        $stmt = $pdo->prepare("UPDATE students SET 
            first_name = ?, middle_name = ?, last_name = ?, gender = ?, 
            date_of_birth = ?, class_id = ?, parent_name = ?, parent_phone = ?, 
            parent_email = ?, address = ?, status = ? 
            WHERE student_id = ?");
        $stmt->execute([
            $first_name, $middle_name, $last_name, $gender, 
            $dob, $class_id, $parent_name, $parent_phone, 
            $parent_email, $address, $status, $id
        ]);

        // 2. Update Parent Record
        $stmt = $pdo->prepare("UPDATE parents SET parent_name = ?, parent_phone = ?, parent_email = ? WHERE student_id = ?");
        $stmt->execute([$parent_name, $parent_phone, $parent_email, $id]);

        $pdo->commit();
        redirect('edit-student.php?id='.$id, "Student records updated successfully.");
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = "Update failed: " . $e->getMessage();
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="margin-bottom: 20px;">
        <a href="students.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
        <div class="card-header">
            <h3 style="margin: 0;"><i class="fas fa-user-edit"></i> <?php echo $page_title; ?>: <?php echo h($student['first_name'] . ' ' . $student['last_name']); ?></h3>
        </div>
        <div class="card-body">
            <?php if ($error): ?><div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px;"><?php echo $error; ?></div><?php endif; ?>
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>Admission No</label>
                        <input type="text" class="form-control" value="<?php echo h($student['admission_number']); ?>" readonly style="background: #f8f9fa;">
                    </div>
                    <div class="form-group">
                        <label>Username (Login)</label>
                        <input type="text" name="username" class="form-control" value="<?php echo h($student['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>New Password (Optional)</label>
                        <div style="display: flex; gap: 5px;">
                            <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Leave blank to keep current">
                            <button type="button" class="btn btn-mini" onclick="document.getElementById('new_password').value='<?php echo DEFAULT_PASSWORD; ?>'; document.getElementById('new_password').type='text';" style="white-space: nowrap; height: auto;">
                                <i class="fas fa-undo"></i> Reset to Default
                            </button>
                        </div>
                        <small style="color: var(--secondary-text);">System default: <b><?php echo DEFAULT_PASSWORD; ?></b></small>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="Active" <?php echo $student['status'] == 'Active' ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo $student['status'] == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="Graduated" <?php echo $student['status'] == 'Graduated' ? 'selected' : ''; ?>>Graduated</option>
                            <option value="Transferred" <?php echo $student['status'] == 'Transferred' ? 'selected' : ''; ?>>Transferred</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Current Class</label>
                        <select name="class_id" class="form-control">
<?php // Rest of code... ?>
                            <option value="">Not Assigned</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?php echo $c['class_id']; ?>" <?php echo $student['class_id'] == $c['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo h($c['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <h4 style="margin: 30px 0 20px; color: var(--corporate-red); border-bottom: 1px solid #eee; padding-bottom: 10px;">Personal Details</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo h($student['first_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" class="form-control" value="<?php echo h($student['middle_name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo h($student['last_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select name="gender" class="form-control">
                            <option value="Male" <?php echo $student['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo $student['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date of Birth</label>
                        <input type="date" name="dob" class="form-control" value="<?php echo $student['date_of_birth']; ?>">
                    </div>
                </div>

                <h4 style="margin: 30px 0 20px; color: var(--corporate-red); border-bottom: 1px solid #eee; padding-bottom: 10px;">Parental Information</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Parent Name</label>
                        <input type="text" name="parent_name" class="form-control" value="<?php echo h($student['parent_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Parent Phone</label>
                        <div class="input-group">
                            <div class="input-prefix">+255</div>
                            <input type="text" name="parent_phone" class="form-control input-with-prefix phone-input-9" 
                                   value="<?php echo h(str_replace('+255', '', $student['parent_phone'])); ?>" required
                                   pattern="[0-9]{9}"
                                   maxlength="9"
                                   placeholder="712345678"
                                   title="Enter the 9 digits after +255">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Parent Email</label>
                        <input type="email" name="parent_email" class="form-control" value="<?php echo h($student['parent_email']); ?>">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Home Address</label>
                        <input type="text" name="address" class="form-control" value="<?php echo h($student['address']); ?>">
                    </div>
                </div>

                <div style="margin-top: 40px;">
                    <button type="submit" name="update_student" class="btn btn-primary" style="padding: 12px 30px;">SAVE CHANGES</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
