<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Add New Student";

$error = '';
$success = '';

// Fetch classes for dropdown
try {
    $stmt = $pdo->query("SELECT class_id, class_name FROM classes ORDER BY class_name ASC");
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $admission_number = trim($_POST['admission_number']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $class_id = !empty($_POST['class_id']) ? $_POST['class_id'] : null;
    
    $parent_name = trim($_POST['parent_name']);
    $parent_phone = '+255' . trim($_POST['parent_phone']);
    $parent_email = trim($_POST['parent_email']);
    $address = trim($_POST['address']);
    $enrollment_date = $_POST['enrollment_date'];

    // Custom credentials
    $username = !empty($_POST['username']) ? trim($_POST['username']) : strtolower($admission_number);
    $password_raw = (!empty($_POST['password']) && $_POST['password'] !== DEFAULT_PASSWORD) ? $_POST['password'] : DEFAULT_PASSWORD;

    // VALIDATION
    if (!isValidName($first_name) || !isValidName($last_name) || !isValidName($middle_name)) {
        $error = "Student names must contain only letters (A-Z). Numbers and special characters are not allowed.";
    } elseif (!isValidName($parent_name)) {
        $error = "Parent/Guardian name must contain only letters (A-Z). Numbers and special characters are not allowed.";
    } elseif (!isValidTanzanianPhone($parent_phone)) {
        $error = "Invalid Parent Phone. Use format +255XXXXXXXXX (e.g. +255712345678)";
    } elseif (!isValidPasswordFormat($password_raw)) {
        $error = "Password must be alphanumeric (contain at least one letter and one number) e.g. machaka123";
    } else {
        $password = password_hash($password_raw, PASSWORD_BCRYPT);
        
        // Check uniqueness
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $error = "A student with this Admission Number already exists.";
        } else {
            try {
                $pdo->beginTransaction();

                // 1. Create User
                $stmt = $pdo->prepare("INSERT INTO users (username, password, email, phone, role) VALUES (?, ?, ?, ?, 'student')");
                $stmt->execute([$username, $password, $parent_email, $parent_phone]);
                $user_id = $pdo->lastInsertId();

                // 2. Create Student Profile
                $stmt = $pdo->prepare("INSERT INTO students (user_id, admission_number, first_name, middle_name, last_name, gender, date_of_birth, class_id, parent_name, parent_phone, parent_email, address, enrollment_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $user_id, $admission_number, $first_name, $middle_name, $last_name, 
                    $gender, $dob, $class_id, $parent_name, $parent_phone, 
                    $parent_email, $address, $enrollment_date
                ]);
                $student_id = $pdo->lastInsertId();

                // 3. Create Parent Record (for SMS tracking)
                $stmt = $pdo->prepare("INSERT INTO parents (student_id, parent_name, parent_phone, parent_email) VALUES (?, ?, ?, ?)");
                $stmt->execute([$student_id, $parent_name, $parent_phone, $parent_email]);

                // 4. In-App Notification to Class Teacher
                if ($class_id) {
                    $class_teacher_stmt = $pdo->prepare("SELECT class_teacher_id FROM classes WHERE class_id = ?");
                    $class_teacher_stmt->execute([$class_id]);
                    $class_teacher_id = $class_teacher_stmt->fetchColumn();
                    if ($class_teacher_id) {
                        $teacher_user_stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE teacher_id = ?");
                        $teacher_user_stmt->execute([$class_teacher_id]);
                        $teacher_user_id = $teacher_user_stmt->fetchColumn();
                        if ($teacher_user_id) {
                            $stmt_class = $pdo->prepare("SELECT class_name FROM classes WHERE class_id = ?");
                            $stmt_class->execute([$class_id]);
                            $cl_name = $stmt_class->fetchColumn();
                            createNotification(null, $teacher_user_id, "Mwanafunzi mpya $first_name $last_name ameongezwa kwenye darasa lako ($cl_name). Tafadhali kagua taarifa zake na sasisha mahudhurio.", BASE_URL . 'teacher/students/index.php');
                        }
                    }
                }

                $pdo->commit();
                redirect('students.php', "Mwanafunzi $first_name $last_name amesajiliwa. Password ya kuingia: <strong>$password_raw</strong> — Tafadhali abadilishe kwenye profile yake.");
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Error adding student: " . $e->getMessage();
            }
        }
    }
}
?>
<?php
require_once '../../includes/header.php';
?>

<div class="main-content-inner" style="max-width: 1200px; margin: 0 auto; width: 100%;">
    <div style="margin-bottom: 20px;">
        <a href="students.php" style="color: var(--secondary-text); font-weight: 700; text-decoration: none;"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>

    <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red); border-radius: 10px; overflow: hidden; background: #FFF;">
        <div class="card-header" style="background: var(--header-gradient); padding: 20px 25px;">
            <h3 style="margin: 0; color: #8b0000; font-weight: 800;"><i class="fas fa-user-graduate"></i> <?php echo $page_title; ?></h3>
        </div>
        <div class="card-body" style="padding: 30px;">
            <?php if ($error): ?>
                <div class="error-msg" style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 25px; border-left: 4px solid var(--corporate-red); font-weight: 700;">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <h4 style="margin-top: 0; color: #8b0000; border-bottom: 1.5px solid rgba(139,0,0,0.1); padding-bottom: 10px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">Personal Information</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">First Name <span class style="color:red;">*</span></label>
                        <input type="text" name="first_name" class="form-control" required placeholder="John" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Middle Name</label>
                        <input type="text" name="middle_name" class="form-control" placeholder="Peter" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Last Name <span class style="color:red;">*</span></label>
                        <input type="text" name="last_name" class="form-control" required placeholder="Mushi" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Admission No <span class style="color:red;">*</span></label>
                        <input type="text" name="admission_number" id="admission_number" class="form-control" required placeholder="Select class to auto-generate" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Auto-generated or custom code</small>
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Gender <span class style="color:red;">*</span></label>
                        <select name="gender" class="form-control" required style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7; height: auto; background: white;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" style="padding: 9px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Assigned Class</label>
                        <select name="class_id" class="form-control" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7; height: auto; background: white;">
                            <option value="">Select Class...</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>"><?php echo $class['class_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Enrollment Date</label>
                        <input type="date" name="enrollment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" style="padding: 9px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Login Username <span class style="color:red;">*</span></label>
                        <input type="text" name="username" id="username_field" class="form-control" required placeholder="Default: admission no" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Initial student login username</small>
                    </div>
                    <div class="form-group" id="pass_group">
                        <label style="font-weight: 700; color: #2C3E50;">Initial Password <span class style="color:red;">*</span></label>
                        <input type="text" name="password" class="form-control" value="<?php echo DEFAULT_PASSWORD; ?>" placeholder="e.g. moshi123" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                        <small style="color: var(--secondary-text); display: block; margin-top: 4px;">Default: <strong><?php echo DEFAULT_PASSWORD; ?></strong>. Waweza kubadilisha hapa.</small>
                    </div>
                </div>

                <h4 style="margin-top: 30px; color: #8b0000; border-bottom: 1.5px solid rgba(139,0,0,0.1); padding-bottom: 10px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">Parent / Guardian Details</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Parent/Guardian Name <span class style="color:red;">*</span></label>
                        <input type="text" name="parent_name" class="form-control" required placeholder="Salim Mushi" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group">
                        <label style="font-weight: 700; color: #2C3E50;">Parent Phone (for SMS) <span class style="color:red;">*</span></label>
                        <div class="input-group" style="display: flex;">
                            <div class="input-prefix" style="background: #FFF5F5; border: 1px solid #BDC3C7; border-right: none; display: flex; align-items: center; justify-content: center; padding: 0 15px; border-top-left-radius: 6px; border-bottom-left-radius: 6px; font-weight: 700; color: #8b0000;">+255</div>
                            <input type="text" name="parent_phone" class="form-control input-with-prefix phone-input-9" required 
                                   pattern="[0-9]{9}"
                                   maxlength="9"
                                   placeholder="712345678"
                                   title="Enter the 9 digits after +255"
                                   style="padding: 10px 12px; border-top-left-radius: 0; border-bottom-left-radius: 0; border-top-right-radius: 6px; border-bottom-right-radius: 6px; border: 1px solid #BDC3C7; flex: 1;">
                        </div>
                    </div>
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="font-weight: 700; color: #2C3E50;">Parent Email</label>
                        <input type="email" name="parent_email" class="form-control" placeholder="parent@example.com" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="font-weight: 700; color: #2C3E50;">Residential Address</label>
                        <input type="text" name="address" class="form-control" placeholder="Moshi, Kilimanjaro" style="padding: 10px 12px; border-radius: 6px; border: 1px solid #BDC3C7;">
                    </div>
                </div>

                <div style="margin-top: 40px; display: flex; gap: 15px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; padding: 12px; background: #8b0000; border-color: #8b0000; font-weight: 700; border-radius: 6px;">REGISTER STUDENT</button>
                    <a href="students.php" class="btn btn-outline" style="flex: 1; padding: 12px; text-align: center; border-radius: 6px; font-weight: 700; text-decoration: none; display: flex; justify-content: center; align-items: center; border: 1px solid #BDC3C7; color: #2C3E50;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function fetchAdmissionNumber() {
    const classId = document.querySelector('select[name="class_id"]').value;
    const admField = document.querySelector('input[name="admission_number"]');
    
    if (classId) {
        fetch(`ajax_get_adm_no.php?class_id=${classId}`)
            .then(response => response.text())
            .then(data => {
                admField.value = data;
                admField.style.backgroundColor = '#fff9c4';
                setTimeout(() => admField.style.backgroundColor = '', 1000);
            });
    }
}

document.querySelector('select[name="class_id"]').addEventListener('change', fetchAdmissionNumber);

// Auto-populate username field when Admission Number changes
document.getElementById('admission_number').addEventListener('input', function() {
    const userField = document.getElementById('username_field');
    if (userField && !userField.dataset.edited) {
        userField.value = this.value.toLowerCase().replace(/[^a-z0-9_-]/g, '');
    }
});
document.getElementById('username_field').addEventListener('input', function() {
    this.dataset.edited = true;
});
</script>

<?php require_once '../../includes/footer.php'; ?>
