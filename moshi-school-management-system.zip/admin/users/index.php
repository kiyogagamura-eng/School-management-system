<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "User Management";
require_once '../../includes/header.php';
?>

<div class="fade-in">
    <div class="page-header" style="border-radius: 12px; margin-bottom: 30px;">
        <h2 style="margin: 0;"><i class="fas fa-users-cog"></i> User Management Hub</h2>
        <p style="color: var(--secondary-text); margin-top: 5px;">Select a user category to manage profiles and access.</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 20px;">
        <!-- Teachers Card -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid #940000; background: #FFFFFF;">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="background: #FFF5F5; width: 80px; height: 80px; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; margin-bottom: 20px; font-size: 2.5rem; color: #940000; border: 2px solid #940000;">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <h3 style="color: #2C3E50; font-weight: 800;">Teachers</h3>
                <p style="color: #7F8C8D; margin-bottom: 30px; line-height: 1.6; min-height: 50px;">Manage teaching staff, profiles, and subject assignments.</p>
                <div style="display: flex; flex-direction: column; gap: 10px; justify-content: center;">
                    <a href="teachers.php" class="btn btn-primary" style="background: #940000; border-color: #940000; padding: 10px 20px;"><i class="fas fa-list"></i> View All Teachers</a>
                    <a href="add-teacher.php" class="btn btn-outline" style="background: #FFF5F5; border-color: #940000; color: #940000; padding: 10px 20px; font-weight: 700;"><i class="fas fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>

        <!-- Students Card -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid #940000; background: #FFFFFF;">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="background: #FFF5F5; width: 80px; height: 80px; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; margin-bottom: 20px; font-size: 2.5rem; color: #940000; border: 2px solid #940000;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h3 style="color: #2C3E50; font-weight: 800;">Students</h3>
                <p style="color: #7F8C8D; margin-bottom: 30px; line-height: 1.6; min-height: 50px;">Manage student records, enrollment, and class assignments.</p>
                <div style="display: flex; flex-direction: column; gap: 10px; justify-content: center;">
                    <a href="students.php" class="btn btn-primary" style="background: #940000; border-color: #940000; padding: 10px 20px;"><i class="fas fa-list"></i> View All Students</a>
                    <a href="add-student.php" class="btn btn-outline" style="background: #FFF5F5; border-color: #940000; color: #940000; padding: 10px 20px; font-weight: 700;"><i class="fas fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>

        <!-- Parents Card -->
        <div class="card shadow-premium" style="transition: transform 0.3s ease; border-top: 4px solid #940000; background: #FFFFFF;">
            <div class="card-body" style="text-align: center; padding: 40px 20px;">
                <div style="background: #FFF5F5; width: 80px; height: 80px; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; margin-bottom: 20px; font-size: 2.5rem; color: #940000; border: 2px solid #940000;">
                    <i class="fas fa-user-friends"></i>
                </div>
                <h3 style="color: #2C3E50; font-weight: 800;">Parents</h3>
                <p style="color: #7F8C8D; margin-bottom: 30px; line-height: 1.6; min-height: 50px;">Manage parent contacts, SMS preferences, and linked students.</p>
                <div style="display: flex; flex-direction: column; gap: 10px; justify-content: center;">
                    <a href="parents.php" class="btn btn-primary" style="background: #940000; border-color: #940000; padding: 10px 20px;"><i class="fas fa-list"></i> View All Parents</a>
                    <a href="#" class="btn btn-outline" style="background: #FFF5F5; border-color: #940000; color: #940000; padding: 10px 20px; font-weight: 700;" onclick="alert('Note: Parents are registered and linked when adding students.')"><i class="fas fa-info-circle"></i> Info</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
