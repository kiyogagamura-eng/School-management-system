<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Database Management";

$success_msg = '';
$error_msg = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCSRF();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'optimize') {
        try {
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($tables as $table) {
                $pdo->query("OPTIMIZE TABLE `$table`");
            }
            $success_msg = "All database tables optimized successfully!";
            logActivity($_SESSION['user_id'], 'db_optimize', 'Optimized all database tables');
        } catch(PDOException $e) {
            $error_msg = "Optimization failed: " . $e->getMessage();
        }
    } elseif ($action === 'cleanup_logs') {
        try {
            // Keep logs of last 30 days, clean older ones
            $stmt = $pdo->prepare("DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $stmt->execute();
            $deleted = $stmt->rowCount();
            $success_msg = "Cleanup completed. Deleted $deleted activity log entries older than 30 days.";
            logActivity($_SESSION['user_id'], 'db_cleanup', "Cleaned up old activity logs. Deleted $deleted rows.");
        } catch(PDOException $e) {
            $error_msg = "Cleanup failed: " . $e->getMessage();
        }
    } elseif ($action === 'cleanup_expired_sessions') {
        try {
            // Clean expired parent sessions
            $stmt = $pdo->prepare("DELETE FROM parent_sessions WHERE expires_at < NOW()");
            $stmt->execute();
            $deleted = $stmt->rowCount();
            $success_msg = "Cleanup completed. Deleted $deleted expired parent portal sessions.";
            logActivity($_SESSION['user_id'], 'db_cleanup', "Cleaned up expired parent sessions. Deleted $deleted rows.");
        } catch(PDOException $e) {
            $error_msg = "Cleanup failed: " . $e->getMessage();
        }
    }
}

// Fetch database stats & tables
$tables_info = [];
$total_size_kb = 0;
try {
    $stmt = $pdo->prepare("
        SELECT 
            table_name AS `Table`,
            round(((data_length + index_length) / 1024), 2) AS `Size`,
            table_rows AS `Rows`
        FROM information_schema.TABLES
        WHERE table_schema = ?
    ");
    $stmt->execute([DB_NAME]);
    $tables_info = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($tables_info as $t) {
        $total_size_kb += $t['Size'];
    }
} catch(PDOException $e) {}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-server" style="color:#8b0000;"></i> Database Maintenance & Health
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">Optimize DB storage, clean up logs, and review detailed table storage stats.</p>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div style="background:#d4edda; color:#155724; padding:12px 20px; border-radius:8px; border:1px solid #c3e6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-check-circle"></i> <?php echo $success_msg; ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background:#f8d7da; color:#721c24; padding:12px 20px; border-radius:8px; border:1px solid #f5c6cb; margin-bottom:20px; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-exclamation-triangle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns:1fr 2fr; gap:25px;">
        
        <!-- Maintenance Tools -->
        <div style="display:flex; flex-direction:column; gap:20px;">
            <div class="card" style="border-top:4px solid #8b0000;">
                <div class="card-header" style="background:#FFF5F5; color:#8b0000;">
                    <i class="fas fa-tools"></i> Optimization & Cleanup
                </div>
                <div class="card-body" style="display:flex; flex-direction:column; gap:15px;">
                    <div>
                        <h4 style="margin:0 0 5px; color:#2C3E50; font-size:0.95rem;">Table Optimization</h4>
                        <p style="color:#7F8C8D; font-size:0.8rem; margin-bottom:12px; line-height:1.4;">Defragment tables, reclaim unused space, and update index statistics for faster queries.</p>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="action" value="optimize">
                            <button type="submit" class="btn btn-primary" style="background:#8b0000; border-color:#8b0000; font-size:0.8rem; width:100%;">
                                <i class="fas fa-redo"></i> Optimize Tables Now
                            </button>
                        </form>
                    </div>
                    
                    <hr style="border:0; border-top:1px solid #efefef; margin:5px 0;">

                    <div>
                        <h4 style="margin:0 0 5px; color:#2C3E50; font-size:0.95rem;">Clean activity logs</h4>
                        <p style="color:#7F8C8D; font-size:0.8rem; margin-bottom:12px; line-height:1.4;">Deletes activity logs that are older than 30 days to free up database storage.</p>
                        <form method="POST" onsubmit="return confirm('Ensure you have a backup. Clear logs older than 30 days?');">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="action" value="cleanup_logs">
                            <button type="submit" class="btn btn-outline" style="border-color:#e74c3c; color:#e74c3c; font-size:0.8rem; width:100%;">
                                <i class="fas fa-trash-alt"></i> Prune Old Activity Logs
                            </button>
                        </form>
                    </div>

                    <hr style="border:0; border-top:1px solid #efefef; margin:5px 0;">

                    <div>
                        <h4 style="margin:0 0 5px; color:#2C3E50; font-size:0.95rem;">Expired Sessions Cleanup</h4>
                        <p style="color:#7F8C8D; font-size:0.8rem; margin-bottom:12px; line-height:1.4;">Removes expired Parent OTP sessions from the <code>parent_sessions</code> table.</p>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="action" value="cleanup_expired_sessions">
                            <button type="submit" class="btn btn-outline" style="border-color:#8b0000; color:#8b0000; font-size:0.8rem; width:100%;">
                                <i class="fas fa-broom"></i> Prune Expired Parent Sessions
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Table Statistics -->
        <div class="card">
            <div class="card-header" style="background:#FFF5F5; color:#8b0000; display:flex; justify-content:space-between; align-items:center;">
                <span><i class="fas fa-database"></i> Database Table Breakdown</span>
                <span class="badge" style="background:#8b0000; color:white; padding:5px 10px; border-radius:20px; font-size:0.8rem; font-weight:700;">
                    Total Size: <?php echo number_format($total_size_kb / 1024, 2); ?> MB
                </span>
            </div>
            <div class="card-body" style="padding:0; overflow-x:auto;">
                <table style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                    <thead>
                        <tr style="background:#f8f9fa;">
                            <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Table Name</th>
                            <th style="padding:12px 15px; text-align:right; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Rows Count</th>
                            <th style="padding:12px 15px; text-align:right; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.75rem; border-bottom:2px solid #eee;">Size (KB)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($tables_info)): ?>
                            <tr>
                                <td colspan="3" style="padding:20px; text-align:center; color:#7F8C8D;">No tables detected.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($tables_info as $t): ?>
                            <tr style="border-bottom:1px solid #f0f0f0;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='white'">
                                <td style="padding:12px 15px; font-weight:700; color:#2C3E50; font-family:monospace;">
                                    <?php echo h($t['Table']); ?>
                                </td>
                                <td style="padding:12px 15px; text-align:right; color:#2c3e50; font-weight:600;">
                                    <?php echo number_format($t['Rows']); ?>
                                </td>
                                <td style="padding:12px 15px; text-align:right; color:#8b0000; font-weight:800;">
                                    <?php echo number_format($t['Size'], 2); ?> KB
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
