<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$class_id = $_GET['class_id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT s.subject_id, s.subject_name 
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.class_id = ?
");
$stmt->execute([$class_id]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
