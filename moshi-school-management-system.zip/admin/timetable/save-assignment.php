<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$class_id = $_POST['class_id'] ?? 0;
$subject_id = $_POST['subject_id'] ?? 0;
$teacher_id = $_POST['teacher_id'] ?? 0;
$day = $_POST['day'] ?? '';
$period = $_POST['period'] ?? 0;
$start = $_POST['start'] ?? '';
$end = $_POST['end'] ?? '';

if (!$class_id || !$subject_id || !$teacher_id || !$day || !$period) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    // Delete existing assignment for this slot/class if any
    $stmt = $pdo->prepare("DELETE FROM timetables WHERE class_id = ? AND day_of_week = ? AND period_number = ?");
    $stmt->execute([$class_id, $day, $period]);

    // Insert new assignment
    $stmt = $pdo->prepare("
        INSERT INTO timetables (class_id, subject_id, teacher_id, day_of_week, period_number, start_time, end_time, is_break) 
        VALUES (?, ?, ?, ?, ?, ?, ?, 0)
    ");
    $stmt->execute([$class_id, $subject_id, $teacher_id, $day, $period, $start, $end]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
