<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$teacher_id = $_GET['teacher_id'] ?? 0;
$day = $_GET['day'] ?? '';
$period = $_GET['period'] ?? 0;

if (!$teacher_id || !$day || !$period) {
    echo json_encode(['conflict' => false]);
    exit;
}

// Check if teacher is already assigned to a DIFFERENT class at the same time
$stmt = $pdo->prepare("
    SELECT t.*, c.class_name 
    FROM timetables t
    JOIN classes c ON t.class_id = c.class_id
    WHERE t.teacher_id = ? 
    AND t.day_of_week = ? 
    AND t.period_number = ?
");
$stmt->execute([$teacher_id, $day, $period]);
$conflict = $stmt->fetch();

if ($conflict) {
    echo json_encode([
        'conflict' => true, 
        'class_name' => $conflict['class_name']
    ]);
} else {
    echo json_encode(['conflict' => false]);
}
