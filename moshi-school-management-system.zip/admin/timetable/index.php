<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$page_title = "Manage Timetable";

$selected_class = $_GET['class_id'] ?? null;
$classes = $pdo->query("SELECT * FROM classes ORDER BY form_level, stream")->fetchAll();

// Fetch periods
$periods = $pdo->query("SELECT * FROM timetables WHERE is_break = 1 OR (class_id IS NOT NULL) GROUP BY period_number, start_time, end_time ORDER BY start_time ASC")->fetchAll();
// If no periods exist, let's create some defaults
if (empty($periods)) {
    // Seed default periods if empty
    $defaults = [
        ['08:00', '10:00', 1, 0, ''],
        ['10:00', '10:30', 1.5, 1, 'Short Break'],
        ['10:30', '12:30', 2, 0, ''],
        ['12:30', '13:30', 2.5, 1, 'Lunch Break'],
        ['13:30', '15:30', 3, 0, '']
    ];
    foreach ($defaults as $d) {
        $stmt = $pdo->prepare("INSERT INTO timetables (day_of_week, start_time, end_time, period_number, is_break, break_name) VALUES (?,?,?,?,?,?)");
        foreach (['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as $day) {
            $stmt->execute([$day, $d[0], $d[1], $d[2], $d[3], $d[4]]);
        }
    }
    $periods = $pdo->query("SELECT DISTINCT period_number, start_time, end_time, is_break, break_name FROM timetables ORDER BY start_time ASC")->fetchAll();
} else {
    $periods = $pdo->query("SELECT DISTINCT period_number, start_time, end_time, is_break, break_name FROM timetables ORDER BY start_time ASC")->fetchAll();
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

// Fetch current schedule for selected class
$schedule = [];
if ($selected_class) {
    $stmt = $pdo->prepare("SELECT * FROM timetables WHERE class_id = ?");
    $stmt->execute([$selected_class]);
    $entries = $stmt->fetchAll();
    foreach ($entries as $e) {
        $schedule[$e['day_of_week']][$e['period_number']] = $e;
    }
}

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-calendar-alt" style="color: var(--corporate-red);"></i> Smart Timetable Planner</h2>
            <p style="color: var(--secondary-text);">Manage class schedules and prevent teacher conflicts.</p>
        </div>
        <div style="display: flex; gap: 10px;">
            <select onchange="window.location.href='?class_id='+this.value" class="form-control" style="width: 200px;">
                <option value="">Select Class...</option>
                <?php foreach ($classes as $c): ?>
                    <option value="<?php echo $c['class_id']; ?>" <?php echo $selected_class == $c['class_id'] ? 'selected' : ''; ?>>
                        <?php echo h($c['class_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <?php if (!$selected_class): ?>
        <div class="card" style="text-align: center; padding: 60px;">
            <i class="fas fa-arrow-up" style="font-size: 3rem; color: #ddd; margin-bottom: 20px;"></i>
            <h3>Please select a class to start planning.</h3>
        </div>
    <?php else: ?>
        <div class="card shadow-premium" style="overflow-x: auto;">
            <table class="table table-bordered" style="margin: 0; min-width: 1000px;">
                <thead>
                    <tr style="background: #ffffff; color: var(--corporate-red);">
                        <th style="width: 120px; color: var(--corporate-red); font-weight: 900; text-transform: uppercase; font-family: 'Inter', sans-serif !important; border-bottom: 3px solid var(--corporate-red);">Day / Period</th>
                        <?php foreach ($periods as $p): ?>
                            <th style="text-align: center; color: var(--corporate-red); font-weight: 900; border: none; border-bottom: 3px solid var(--corporate-red); font-family: 'Inter', sans-serif !important;">
                                <div style="font-size: 0.8rem;"><?php echo date('H:i', strtotime($p['start_time'])); ?> - <?php echo date('H:i', strtotime($p['end_time'])); ?></div>
                                <div style="font-size: 0.65rem; color: #888; font-weight: 500;"><?php echo $p['is_break'] ? $p['break_name'] : 'Period ' . floor($p['period_number']); ?></div>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($days as $day): ?>
                        <tr>
                            <td style="font-weight: 900; background: #fdfdfd; vertical-align: middle; color: var(--corporate-red); text-transform: uppercase; border-right: 3px solid var(--corporate-red); font-family: 'Inter', sans-serif !important;"><?php echo $day; ?></td>
                            <?php foreach ($periods as $p): 
                                $is_break = $p['is_break'];
                                $p_num = $p['period_number'];
                                $entry = $schedule[$day][$p_num] ?? null;
                            ?>
                                <td style="padding: 5px; height: 100px; vertical-align: top; <?php echo $is_break ? 'background: #f1f3f4;' : ''; ?>">
                                    <?php if ($is_break): ?>
                                        <div style="height: 100%; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; color: #999; font-weight: 700;">
                                            BREAK
                                        </div>
                                    <?php else: ?>
                                        <div id="slot-<?php echo $day; ?>-<?php echo $p_num; ?>" class="timetable-slot" 
                                             onclick="openPlanner('<?php echo $day; ?>', '<?php echo $p_num; ?>', '<?php echo $p['start_time']; ?>', '<?php echo $p['end_time']; ?>')"
                                             style="height: 100%; cursor: pointer; border: 1px dashed #ddd; border-radius: 4px; padding: 5px; transition: 0.3s;">
                                            <?php if ($entry): ?>
                                                <div style="background: var(--accent-soft-red); border-left: 3px solid var(--corporate-red); padding: 5px; border-radius: 3px;">
                                                    <div style="font-weight: 700; font-size: 0.75rem; color: var(--corporate-red);"><?php echo h($entry['subject_id']); // We will show name later ?></div>
                                                    <div style="font-size: 0.65rem; color: #555;">Teacher ID: <?php echo h($entry['teacher_id']); ?></div>
                                                </div>
                                            <?php else: ?>
                                                <div style="color: #ccc; font-size: 0.7rem; text-align: center; margin-top: 25px;">+ Assign</div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Modal for Assignment -->
<div id="plannerModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center;">
    <div class="card" style="width: 400px; margin: 0; animation: slideDown 0.3s;">
        <div class="card-header"><i class="fas fa-plus"></i> Assign Period</div>
        <div class="card-body">
            <form id="plannerForm">
                <input type="hidden" name="day" id="modal_day">
                <input type="hidden" name="period" id="modal_period">
                <input type="hidden" name="start" id="modal_start">
                <input type="hidden" name="end" id="modal_end">
                <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">

                <div class="form-group">
                    <label>Select Subject</label>
                    <select name="subject_id" class="form-control" required>
                        <!-- To be filled via AJAX or preloaded -->
                    </select>
                </div>
                <div class="form-group">
                    <label>Select Teacher</label>
                    <select name="teacher_id" class="form-control" required onchange="checkConflict()">
                        <!-- To be filled -->
                    </select>
                    <small id="conflict-msg" style="display:none; color: #e74c3c; font-weight: 700; margin-top: 5px;"></small>
                </div>
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="button" onclick="closePlanner()" class="btn btn-outline" style="flex:1;">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="flex:1;">Save Assignment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openPlanner(day, period, start, end) {
    document.getElementById('modal_day').value = day;
    document.getElementById('modal_period').value = period;
    document.getElementById('modal_start').value = start;
    document.getElementById('modal_end').value = end;
    
    // Load subjects for this class
    fetch(`get-class-subjects.php?class_id=<?php echo $selected_class; ?>`)
        .then(r => r.json())
        .then(data => {
            let html = '<option value="">Choose Subject...</option>';
            data.forEach(s => {
                html += `<option value="${s.subject_id}">${s.subject_name}</option>`;
            });
            document.querySelector('select[name="subject_id"]').innerHTML = html;
        });

    // Load all teachers
    fetch(`get-all-teachers.php`)
        .then(r => r.json())
        .then(data => {
            let html = '<option value="">Choose Teacher...</option>';
            data.forEach(t => {
                html += `<option value="${t.teacher_id}">${t.first_name} ${t.last_name}</option>`;
            });
            document.querySelector('select[name="teacher_id"]').innerHTML = html;
        });

    document.getElementById('plannerModal').style.display = 'flex';
}

function closePlanner() {
    document.getElementById('plannerModal').style.display = 'none';
}

function checkConflict() {
    const teacherId = document.querySelector('select[name="teacher_id"]').value;
    const day = document.getElementById('modal_day').value;
    const period = document.getElementById('modal_period').value;
    const msg = document.getElementById('conflict-msg');

    if (!teacherId) return;

    fetch(`check-conflict.php?teacher_id=${teacherId}&day=${day}&period=${period}`)
        .then(r => r.json())
        .then(data => {
            if (data.conflict) {
                msg.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Conflict: This teacher is already teaching ${data.class_name} at this time!`;
                msg.style.display = 'block';
            } else {
                msg.style.display = 'none';
            }
        });
}

document.getElementById('plannerForm').onsubmit = function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('save-assignment.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.error);
        }
    });
};
</script>

<?php require_once '../../includes/footer.php'; ?>
