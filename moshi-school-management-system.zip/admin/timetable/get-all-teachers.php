<?php
require_once '../../includes/bootstrap.php';
requireRole(['admin', 'headteacher', 'dos']);

$stmt = $pdo->query("SELECT teacher_id, first_name, last_name FROM teachers WHERE status = 'Active'");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
