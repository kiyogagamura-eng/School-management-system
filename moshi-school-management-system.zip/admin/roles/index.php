<?php
require_once '../../includes/bootstrap.php';
requireRole('admin');

$page_title = "Role & Permission Management";

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCSRF();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'change_role') {
        $user_id = intval($_POST['user_id'] ?? 0);
        $new_role = $_POST['new_role'] ?? '';
        $allowed_roles = ['headteacher','dos','teacher'];
        
        if ($user_id > 0 && in_array($new_role, $allowed_roles)) {
            try {
                $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE user_id = ? AND role != 'admin'");
                $stmt->execute([$new_role, $user_id]);
                $success_msg = "Role updated successfully!";
                logActivity($_SESSION['user_id'], 'role_change', "Changed role of user ID $user_id to $new_role");
            } catch(PDOException $e) {
                $error_msg = "Error updating role.";
            }
        }
    }
}

// Fetch all staff users (admin, headteacher, dos, teacher)
$users_by_role = [];
$all_users = [];
try {
    $all_users = $pdo->query("
        SELECT u.user_id, u.username, u.email, u.role, u.status, u.last_login,
               COALESCE(CONCAT(t.first_name,' ',t.last_name), u.username) as full_name
        FROM users u
        LEFT JOIN teachers t ON t.user_id = u.user_id
        WHERE u.role IN ('admin', 'headteacher', 'dos', 'teacher')
        ORDER BY u.role, u.username
    ")->fetchAll();
    
    foreach ($all_users as $u) {
        $users_by_role[$u['role']][] = $u;
    }
} catch(PDOException $e) {}

$role_info = [
    'admin'       => ['label'=>'System Administrator', 'color'=>'#8b0000', 'icon'=>'fa-user-shield', 'desc'=>'Full system access - manages all users, settings & security'],
    'headteacher' => ['label'=>'Headteacher', 'color'=>'#8b0000', 'icon'=>'fa-user-tie', 'desc'=>'School management, staff overview, reports & communication'],
    'dos'         => ['label'=>'Academic Master (DOS)', 'color'=>'#8b0000', 'icon'=>'fa-graduation-cap', 'desc'=>'Classes, subjects, timetables, results monitoring & publishing'],
    'teacher'     => ['label'=>'Teacher', 'color'=>'#8b0000', 'icon'=>'fa-chalkboard-teacher', 'desc'=>'Attendance, results entry, study materials for assigned classes'],
];

require_once '../../includes/header.php';
?>

<div class="main-content-inner">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
        <div>
            <h2 style="margin:0; display:flex; align-items:center; gap:10px;">
                <i class="fas fa-user-tag" style="color:#8b0000;"></i> Role & Permission Management
            </h2>
            <p style="color:var(--secondary-text); margin-top:5px; font-size:0.9rem;">Manage school staff/leadership roles and system access levels</p>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div style="background:#FFF5F5; color:#8b0000; padding:12px 20px; border-radius:8px; border:1px solid rgba(139,0,0,0.15); margin-bottom:20px; display:flex; align-items:center; gap:10px; font-weight:700;">
            <i class="fas fa-check-circle"></i> <?php echo h($success_msg); ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background:#FFF5F5; color:#8b0000; padding:12px 20px; border-radius:8px; border:1px solid rgba(139,0,0,0.15); margin-bottom:20px; display:flex; align-items:center; gap:10px; font-weight:700;">
            <i class="fas fa-exclamation-triangle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Role Overview Cards -->
    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:20px; margin-bottom:30px;">
        <?php foreach ($role_info as $role => $info): 
            $count = count($users_by_role[$role] ?? []);
        ?>
        <div class="card" style="padding:20px; border-left:5px solid <?php echo $info['color']; ?>; margin-bottom:0; background:white; border-radius:8px;">
            <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
                <div style="background:#FFF5F5; width:40px; height:40px; display:flex; justify-content:center; align-items:center; border-radius:50%; border:1px solid rgba(139,0,0,0.15);">
                    <i class="fas <?php echo $info['icon']; ?>" style="color:<?php echo $info['color']; ?>; font-size:1.1rem;"></i>
                </div>
                <div>
                    <div style="font-weight:900; font-size:1.3rem; color:#2C3E50; line-height:1;"><?php echo $count; ?></div>
                    <div style="font-size:0.75rem; font-weight:700; color:#7F8C8D; text-transform:uppercase; margin-top:2px;"><?php echo $info['label']; ?></div>
                </div>
            </div>
            <p style="font-size:0.75rem; color:#7F8C8D; margin:0; line-height:1.4;"><?php echo $info['desc']; ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Users Role Management Table -->
    <div class="card" style="border-radius:8px; border:none; overflow:hidden;">
        <div class="card-header" style="background:#FFF5F5; color:#8b0000; border-bottom:1px solid rgba(139,0,0,0.15); display:flex; justify-content:space-between; align-items:center; padding:15px 20px;">
            <span style="font-weight:800;"><i class="fas fa-exchange-alt"></i> Change Staff Roles</span>
            <input type="text" id="searchRoles" placeholder="Search staff user..." onkeyup="filterRoles()" style="padding:6px 12px; border:1px solid #ddd; border-radius:6px; font-size:0.85rem; outline:none;">
        </div>
        <div class="card-body" style="padding:0; overflow-x:auto;">
            <table id="rolesTable" style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                <thead>
                    <tr style="background:#f8f9fa;">
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">User</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">Email</th>
                        <th style="padding:12px 15px; text-align:center; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">Current Role</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">Status</th>
                        <th style="padding:12px 15px; text-align:left; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">Last Login</th>
                        <th style="padding:12px 15px; text-align:center; font-weight:700; color:#7F8C8D; text-transform:uppercase; font-size:0.72rem; border-bottom:1px solid #eee;">Change Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_users as $u): ?>
                    <tr style="border-bottom:1px solid #f0f0f0;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='white'">
                        <td style="padding:12px 15px;">
                            <div style="font-weight:700; color:#2C3E50;"><?php echo h($u['full_name']); ?></div>
                            <div style="font-size:0.75rem; color:#7F8C8D;">@<?php echo h($u['username']); ?></div>
                        </td>
                        <td style="padding:12px 15px; font-size:0.82rem; color:#7F8C8D;"><?php echo h($u['email'] ?? '-'); ?></td>
                        <td style="padding:12px 15px; text-align:center;">
                            <?php 
                            $ri = $role_info[$u['role']] ?? ['color'=>'#555','label'=>$u['role'],'icon'=>'fa-user'];
                            ?>
                            <span style="background:#FFF5F5; color:#8b0000; padding:4px 12px; border-radius:4px; font-size:0.75rem; font-weight:700; text-transform:uppercase; display:inline-flex; align-items:center; gap:5px; border:1px solid rgba(139,0,0,0.1);">
                                <i class="fas <?php echo $ri['icon']; ?>"></i>
                                <?php echo ucfirst(h($u['role'])); ?>
                            </span>
                        </td>
                        <td style="padding:12px 15px;">
                            <?php if ($u['status'] === 'active'): ?>
                                <span style="color:#2C3E50; font-weight:700; font-size:0.8rem;"><i class="fas fa-circle" style="font-size:0.5rem; color:#8b0000; margin-right:4px;"></i> Active</span>
                            <?php elseif ($u['status'] === 'locked'): ?>
                                <span style="color:#8b0000; font-weight:700; font-size:0.8rem;"><i class="fas fa-lock" style="font-size:0.7rem; margin-right:4px;"></i> Locked</span>
                            <?php else: ?>
                                <span style="color:#7F8C8D; font-weight:700; font-size:0.8rem;">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:12px 15px; font-size:0.78rem; color:#7F8C8D;">
                            <?php echo $u['last_login'] ? date('d M Y', strtotime($u['last_login'])) : 'Never'; ?>
                        </td>
                        <td style="padding:12px 15px; text-align:center;">
                            <?php if ($u['role'] === 'admin'): ?>
                                <span style="color:#bdc3c7; font-size:0.75rem;"><i class="fas fa-shield-alt"></i> Protected</span>
                            <?php else: ?>
                            <form method="POST" style="display:flex; gap:8px; align-items:center; justify-content:center;" onsubmit="return confirm('Change role for <?php echo h($u['username']); ?>?');">
                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                <input type="hidden" name="action" value="change_role">
                                <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                <select name="new_role" style="padding:5px 10px; border:1px solid #ddd; border-radius:5px; font-size:0.8rem; color:#2C3E50; outline:none; background:white;">
                                    <?php foreach (['headteacher','dos','teacher'] as $r): ?>
                                    <option value="<?php echo $r; ?>" <?php echo $u['role']===$r?'selected':''; ?>>
                                        <?php echo ucfirst($r); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" style="background:#8b0000; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.78rem; font-weight:700;">
                                    <i class="fas fa-check"></i> Apply
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function filterRoles() {
    const input = document.getElementById('searchRoles').value.toUpperCase();
    const rows = document.querySelectorAll('#rolesTable tbody tr');
    rows.forEach(row => {
        row.style.display = row.textContent.toUpperCase().includes(input) ? '' : 'none';
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
