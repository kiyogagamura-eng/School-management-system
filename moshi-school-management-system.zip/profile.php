<?php
require_once 'includes/bootstrap.php';
requireLogin();

$page_title = "My Profile";
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$user_data = [];
$error = '';
$success = '';

// Fetch user data with role-specific details
try {
    if ($role == 'teacher') {
        $stmt = $pdo->prepare("SELECT u.*, t.first_name, t.last_name, t.qualification FROM users u LEFT JOIN teachers t ON u.user_id = t.user_id WHERE u.user_id = ?");
    } elseif ($role == 'student') {
        $stmt = $pdo->prepare("SELECT u.*, s.first_name, s.last_name FROM users u LEFT JOIN students s ON u.user_id = s.user_id WHERE u.user_id = ?");
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    }
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    // Fallback names if not in role tables
    if (empty($user_data['first_name'])) $user_data['first_name'] = '';
    if (empty($user_data['last_name'])) $user_data['last_name'] = '';
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $username_new = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = !empty($_POST['phone']) ? '+255' . trim($_POST['phone']) : '';
    $qualification = trim($_POST['qualification'] ?? '');
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    try {
        // VALIDATION
        if (!isValidName($first_name) || !isValidName($last_name)) {
            throw new Exception("Names must contain only letters (A-Z). Numbers and special characters are not allowed.");
        }
        if (!empty($phone) && !isValidTanzanianPhone($phone)) {
            throw new Exception("Invalid Phone Number. Use format +255XXXXXXXXX");
        }
        if (!empty($new_pass) && !isValidPasswordFormat($new_pass)) {
            throw new Exception("Password must be alphanumeric (contain at least one letter and one number) e.g. machaka123");
        }

        $pdo->beginTransaction();

        // 1. Update users table (Base info)
        // Check if username changed and if it's unique
        if ($username_new !== $user_data['username']) {
            $st_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?");
            $st_check->execute([$username_new, $user_id]);
            if ($st_check->fetchColumn() > 0) {
                throw new Exception("Username '$username_new' is already taken.");
            }
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, phone = ? WHERE user_id = ?");
            $stmt->execute([$username_new, $email, $phone, $user_id]);
            $_SESSION['username'] = $username_new; // Update session
        } else {
            $stmt = $pdo->prepare("UPDATE users SET email = ?, phone = ? WHERE user_id = ?");
            $stmt->execute([$email, $phone, $user_id]);
        }
        
        // 2. Update Role Table
        if ($role == 'teacher') {
            $stmt = $pdo->prepare("UPDATE teachers SET first_name = ?, last_name = ?, email = ?, phone = ?, qualification = ? WHERE user_id = ?");
            $stmt->execute([$first_name, $last_name, $email, $phone, $qualification, $user_id]);
        } elseif ($role == 'student') {
            $stmt = $pdo->prepare("UPDATE students SET first_name = ?, last_name = ? WHERE user_id = ?");
            $stmt->execute([$first_name, $last_name, $user_id]);
        }

        // 3. Handle Image Upload
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $filename = $_FILES['profile_image']['name'];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($ext, $allowed)) {
                $new_filename = "user_" . $user_id . "_" . time() . "." . $ext;
                $upload_path = "assets/uploads/profiles/" . $new_filename;
                
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                    // Delete old image if not default.png
                    if ($user_data['profile_pic'] && $user_data['profile_pic'] !== 'default.png') {
                        @unlink("assets/uploads/profiles/" . $user_data['profile_pic']);
                    }
                    
                    $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE user_id = ?");
                    $stmt->execute([$new_filename, $user_id]);
                    $_SESSION['profile_pic'] = $new_filename; 
                }
            } else {
                $error = "Invalid image format.";
            }
        }

        // 4. Update password if provided
        if (!empty($new_pass)) {
            if ($new_pass !== $confirm_pass) {
                $error = "Passwords do not match.";
            } else {
                $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $stmt->execute([$hashed, $user_id]);
            }
        }

        if (!$error) {
            $pdo->commit();
            $success = "Profile updated successfully.";
            // Refresh data
            if ($role == 'teacher') {
                $stmt = $pdo->prepare("SELECT u.*, t.first_name, t.last_name, t.qualification FROM users u LEFT JOIN teachers t ON u.user_id = t.user_id WHERE u.user_id = ?");
            } elseif ($role == 'student') {
                $stmt = $pdo->prepare("SELECT u.*, s.first_name, s.last_name FROM users u LEFT JOIN students s ON u.user_id = s.user_id WHERE u.user_id = ?");
            } else {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
            }
            $stmt->execute([$user_id]);
            $user_data = $stmt->fetch();
        } else {
            $pdo->rollBack();
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = "Error updating profile: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: #f8f9fa;">
    <div style="max-width: 800px; margin: 40px auto; padding: 20px;">
        <div style="margin-bottom: 20px;">
            <a href="<?php echo BASE_URL . $role; ?>/dashboard.php" style="color: var(--secondary-text); font-weight: 700;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>

        <div class="card shadow-premium" style="border-top: 5px solid var(--corporate-red);">
            <div class="card-header" style="background: var(--header-gradient);">
                <h3 style="margin: 0;"><i class="fas fa-user-circle"></i> User Profile Management</h3>
            </div>
            <div class="card-body">
                <div style="text-align: center; margin-bottom: 30px;">
                    <div style="width: 100px; height: 100px; background: white; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: var(--corporate-red); border: 2px solid var(--corporate-red); overflow: hidden;">
                        <img src="<?php echo BASE_URL; ?>assets/uploads/profiles/default.png" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($user_data['username']); ?>&background=940000&color=fff'">
                    </div>
                    <h3 style="margin: 0;"><?php echo h($user_data['username']); ?></h3>
                    <span class="badge" style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 5px 15px; border-radius: 20px; font-weight: 700;"><?php echo strtoupper($role); ?></span>
                </div>

                <?php if ($success): ?><div style="background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 5px; margin-bottom: 20px;"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div><?php endif; ?>
                <?php if ($error): ?><div style="background: var(--accent-soft-red); color: var(--corporate-red); padding: 15px; border-radius: 5px; margin-bottom: 20px;"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div><?php endif; ?>

                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group" style="margin-bottom: 25px;">
                        <label><i class="fas fa-camera"></i> Change Profile Picture</label>
                        <input type="file" name="profile_image" class="form-control" accept="image/*" style="padding: 10px;">
                        <small style="color: var(--secondary-text);">Supported formats: JPG, PNG, GIF (Max 2MB)</small>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="first_name" class="form-control" value="<?php echo h($user_data['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?php echo h($user_data['last_name']); ?>" required>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label><i class="fas fa-user-tag"></i> Login Username (Unique)</label>
                        <input type="text" name="username" class="form-control" value="<?php echo h($user_data['username']); ?>" required>
                        <small style="color: var(--secondary-text);">This is what you use to login.</small>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" class="form-control" value="<?php echo h($user_data['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <div class="input-group">
                                <div class="input-prefix">+255</div>
                                <input type="text" name="phone" id="profile_phone" class="form-control input-with-prefix phone-input-9" 
                                       value="<?php echo h(str_replace('+255', '', $user_data['phone'])); ?>"
                                       pattern="[0-9]{9}"
                                       maxlength="9"
                                       placeholder="711444501"
                                       title="Enter the 9 digits after +255">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Professional Qualification (Master/Bachelor/Education etc.)</label>
                        <input type="text" name="qualification" class="form-control" value="<?php echo h($user_data['qualification']); ?>" placeholder="e.g. Master of Education, Bachelor of Science">
                    </div>

                    <h4 style="border-bottom: 1px solid #eee; padding-bottom: 10px; margin: 30px 0 20px; color: var(--corporate-red);">Security Settings</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current">
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 30px; font-weight: 700; letter-spacing: 1px;">SAVE CHANGES</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
