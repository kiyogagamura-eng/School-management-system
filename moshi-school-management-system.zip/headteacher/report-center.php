<?php
require_once '../includes/bootstrap.php';
requireRole(['headteacher', 'admin']);

$page_title = "Reports & Analytics Center";
require_once '../includes/header.php';
?>

<style>
    .report-center-container {
        padding: 30px;
        background: #f8fafc;
        min-height: 100vh;
    }
    
    .report-card {
        background: white;
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        text-decoration: none;
        color: #1e293b;
        transition: all 0.3s ease;
        border-bottom: 4px solid transparent;
        height: 100%;
    }
    
    .report-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(148, 0, 0, 0.15);
        border-bottom: 4px solid #940000;
        color: #940000;
    }
    
    .report-icon {
        width: 70px;
        height: 70px;
        background: #fff5f5;
        color: #940000;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        margin-bottom: 20px;
        transition: all 0.3s;
    }
    
    .report-card:hover .report-icon {
        background: #940000;
        color: white;
    }
    
    .report-title {
        font-weight: 800;
        font-size: 1.15rem;
        margin-bottom: 10px;
    }
    
    .report-desc {
        font-size: 0.85rem;
        color: #64748b;
        line-height: 1.5;
        font-weight: 500;
    }

    .header-banner {
        background: linear-gradient(135deg, #1e293b, #0f172a);
        color: white;
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
        display: flex;
        align-items: center;
        gap: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid rgba(255, 215, 0, 0.1);
    }
</style>

<div class="report-center-container">
    
    <div class="header-banner">
        <div style="background: rgba(255, 215, 0, 0.1); padding: 15px; border-radius: 12px; color: #ffd700; font-size: 2rem;">
            <i class="fas fa-chart-pie"></i>
        </div>
        <div>
            <h3 style="margin: 0; font-weight: 900; letter-spacing: 0.5px; color: #fff;">Executive Reports Center</h3>
            <p style="margin: 5px 0 0; color: #94a3b8; font-size: 0.95rem;">Access all analytical, academic, and demographic insights across the institution.</p>
        </div>
    </div>

    <div class="row">
        <!-- School Stats -->
        <div class="col-md-3 mb-4">
            <a href="<?php echo BASE_URL; ?>admin/results/school-stats.php" class="report-card">
                <div class="report-icon">
                    <i class="fas fa-school"></i>
                </div>
                <div class="report-title">Overall School Stats</div>
                <div class="report-desc">Analyze total enrollments, gender distribution, pass rates, and general division metrics across the entire school.</div>
            </a>
        </div>
        
        <!-- Class Stats -->
        <div class="col-md-3 mb-4">
            <a href="<?php echo BASE_URL; ?>admin/results/class-stats.php" class="report-card">
                <div class="report-icon">
                    <i class="fas fa-users-class"></i>
                </div>
                <div class="report-title">Class Performance</div>
                <div class="report-desc">Review academic performance, rankings, and average GPA broken down by specific forms and streams.</div>
            </a>
        </div>

        <!-- Subject Stats -->
        <div class="col-md-3 mb-4">
            <a href="<?php echo BASE_URL; ?>admin/results/subject-stats.php" class="report-card">
                <div class="report-icon">
                    <i class="fas fa-book-open"></i>
                </div>
                <div class="report-title">Subject Analytics</div>
                <div class="report-desc">View insights on individual subject pass rates, highest grades, and comparative teacher performance.</div>
            </a>
        </div>

        <!-- Individual Report Cards -->
        <div class="col-md-3 mb-4">
            <a href="<?php echo BASE_URL; ?>admin/results/student-report.php" class="report-card">
                <div class="report-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="report-title">Individual Reports</div>
                <div class="report-desc">Search and view specific student's terminal report cards, continuous assessments, and academic tracking.</div>
            </a>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
