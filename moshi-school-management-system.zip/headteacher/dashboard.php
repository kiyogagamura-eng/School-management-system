<?php
require_once '../includes/bootstrap.php';
requireRole('headteacher');

$page_title = 'Headteacher Executive Dashboard';

// Handle Action Submissions (Simulated approvals / Real broadcasts)
$message_success = '';
$message_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action_type'])) {
        $action = $_POST['action_type'];
        if ($action === 'approve_results') {
            $exam_id = (int)$_POST['exam_id'];
            try {
                $stmt = $pdo->prepare("UPDATE exams SET is_published = 1, publish_date = NOW() WHERE exam_id = ?");
                $stmt->execute([$exam_id]);
                logActivity($_SESSION['user_id'], 'Results Approved', "Approved and published results for Exam ID $exam_id");
                $message_success = "Academic results successfully approved and published to parent portals.";
            } catch (Exception $e) {
                $message_error = "Error approving results: " . $e->getMessage();
            }
        } elseif ($action === 'broadcast_sms') {
            $sms_msg = trim($_POST['sms_message']);
            $target_group = $_POST['target_group']; // 'parents', 'teachers', 'all'
            
            if (!empty($sms_msg)) {
                // Fetch Phone numbers based on target group
                $recipients = [];
                try {
                    if ($target_group === 'teachers') {
                        $stmt = $pdo->query("SELECT phone, first_name, last_name FROM teachers WHERE phone IS NOT NULL AND status='Active'");
                        $recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    } elseif ($target_group === 'parents') {
                        $stmt = $pdo->query("SELECT parent_phone as phone, parent_name as first_name, '' as last_name FROM students WHERE parent_phone IS NOT NULL AND status='Active'");
                        $recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    } else {
                        // All
                        $stmt1 = $pdo->query("SELECT phone, first_name, last_name FROM teachers WHERE phone IS NOT NULL AND status='Active'");
                        $stmt2 = $pdo->query("SELECT parent_phone as phone, parent_name as first_name, '' as last_name FROM students WHERE parent_phone IS NOT NULL AND status='Active'");
                        $recipients = array_merge($stmt1->fetchAll(PDO::FETCH_ASSOC), $stmt2->fetchAll(PDO::FETCH_ASSOC));
                    }

                    $sent_count = 0;
                    foreach ($recipients as $rec) {
                        if (!empty($rec['phone'])) {
                            sendSMS($rec['phone'], $sms_msg);
                            $sent_count++;
                        }
                    }
                    
                    logActivity($_SESSION['user_id'], 'Broadcast SMS', "Sent broadcast message to $sent_count $target_group");
                    $message_success = "Broadcast successfully queued! Sent to $sent_count active numbers.";
                } catch (Exception $e) {
                    $message_error = "Failed to broadcast: " . $e->getMessage();
                }
            } else {
                $message_error = "SMS message content cannot be empty.";
            }
        }
    }
}

// Fetch Real Data from database
$stats = [
    'total_students' => 0,
    'total_teachers' => 0,
    'total_classes' => 0,
    'overall_pass_rate' => '0%',
    'school_gpa' => 'B',
    'best_class' => 'Form 4A',
    'weakest_subject' => 'Mathematics',
    'att_present' => '94%',
    'att_absent' => '6%',
    'pending_leaves' => 2,
    'total_income' => 'TSh 45,800,000',
    'total_expenses' => 'TSh 31,200,000',
    'capitation_grant' => 'TSh 12,500,000',
    'utilization_rate' => '68%',
    'pending_assets' => 1,
    'discipline_cases' => 3
];

try {
    // Counts
    $stats['total_students'] = $pdo->query("SELECT COUNT(*) FROM students WHERE status='Active'")->fetchColumn();
    $stats['total_teachers'] = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status='Active'")->fetchColumn();
    $stats['total_classes'] = $pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();

    // Pass rate & GPA from results
    $res_count = $pdo->query("SELECT COUNT(*) FROM results")->fetchColumn();
    if ($res_count > 0) {
        $passed = $pdo->query("SELECT COUNT(*) FROM results WHERE marks_obtained >= 40")->fetchColumn();
        $stats['overall_pass_rate'] = round(($passed / $res_count) * 100) . '%';
        
        $avg_marks = $pdo->query("SELECT AVG(marks_obtained) FROM results")->fetchColumn();
        if ($avg_marks >= 70) $stats['school_gpa'] = 'A';
        elseif ($avg_marks >= 60) $stats['school_gpa'] = 'B';
        elseif ($avg_marks >= 50) $stats['school_gpa'] = 'C';
        elseif ($avg_marks >= 40) $stats['school_gpa'] = 'D';
        else $stats['school_gpa'] = 'F';
    }

    // Best class calculation
    $best_class_stmt = $pdo->query("
        SELECT c.class_name, AVG(r.marks_obtained) as avg_marks 
        FROM results r
        JOIN classes c ON r.class_id = c.class_id
        GROUP BY r.class_id 
        ORDER BY avg_marks DESC LIMIT 1
    ");
    $bc = $best_class_stmt->fetch();
    if ($bc) {
        $stats['best_class'] = $bc['class_name'];
    }

    // Weakest subject calculation
    $weakest_subj_stmt = $pdo->query("
        SELECT s.subject_name, AVG(r.marks_obtained) as avg_marks 
        FROM results r
        JOIN subjects s ON r.subject_id = s.subject_id
        GROUP BY r.subject_id 
        ORDER BY avg_marks ASC LIMIT 1
    ");
    $ws = $weakest_subj_stmt->fetch();
    if ($ws) {
        $stats['weakest_subject'] = $ws['subject_name'];
    }

    // Active pending approval exams
    $pending_exams_stmt = $pdo->query("
        SELECT e.*, c.class_name, s.subject_name 
        FROM exams e
        JOIN classes c ON e.class_id = c.class_id
        JOIN subjects s ON e.subject_id = s.subject_id
        WHERE e.is_published = 0 LIMIT 5
    ");
    $pending_exams = $pending_exams_stmt->fetchAll();

    // Students Demographics
    $stu_stat = $pdo->query("SELECT 
        SUM(CASE WHEN gender='Male' THEN 1 ELSE 0 END) as boys,
        SUM(CASE WHEN gender='Female' THEN 1 ELSE 0 END) as girls
        FROM students WHERE status = 'Active'")->fetch();
    $stats['boys'] = $stu_stat['boys'] ?: 0;
    $stats['girls'] = $stu_stat['girls'] ?: 0;

    // Teachers Demographics
    $tch_stat = $pdo->query("SELECT 
        SUM(CASE WHEN gender='Male' THEN 1 ELSE 0 END) as male,
        SUM(CASE WHEN gender='Female' THEN 1 ELSE 0 END) as female
        FROM teachers WHERE status = 'Active'")->fetch();
    $stats['male_teachers'] = $tch_stat['male'] ?: 0;
    $stats['female_teachers'] = $tch_stat['female'] ?: 0;

} catch (PDOException $e) {
    // Fall back to defaults on query issue
}

require_once '../includes/header.php';
?>
<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    :root {
        --primary-red: #8b0000;
        --secondary-red: #6d0000;
        --soft-bg: #FAFBFD;
        --card-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    .headteacher-dashboard {
        font-family: 'Outfit', 'Inter', sans-serif;
    }
    
    /* Navigation Tabs */
    .module-nav {
        display: flex;
        gap: 15px;
        margin-bottom: 30px;
        background: #FFF;
        padding: 8px;
        border-radius: 12px;
        border: 1px solid #E2E6ED;
        overflow-x: auto;
    }
    .module-tab {
        flex: 1;
        text-align: center;
        padding: 14px 20px;
        border-radius: 8px;
        font-weight: 800;
        font-size: 0.85rem;
        cursor: pointer;
        transition: all 0.3s;
        border: none;
        background: none;
        color: #64748b;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        white-space: nowrap;
    }
    .module-tab:hover {
        background: #FAFBFD;
        color: var(--primary-red);
    }
    .module-tab.active {
        background: #FFF5F5;
        color: var(--primary-red);
        box-shadow: inset 0 -2px 0 var(--primary-red);
    }
    
    /* Dashboard Panels */
    .module-panel {
        display: none;
        animation: fadeIn 0.4s ease forwards;
    }
    .module-panel.active {
        display: block;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Executive Card grid */
    .kpi-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 30px;
    }
    .kpi-card {
        background: #FFF;
        padding: 20px;
        border-radius: 16px;
        border: 1px solid #E6EBF4;
        box-shadow: var(--card-shadow);
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(139,0,0,0.08);
        border-color: rgba(139,0,0,0.2);
    }
    .kpi-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
        color: var(--primary-red);
        background: #FFF5F5;
    }
    .kpi-data h3 {
        margin: 0;
        font-size: 1.6rem;
        font-weight: 800;
        color: #1e293b;
    }
    .kpi-data p {
        margin: 4px 0 0;
        font-size: 0.78rem;
        color: #64748b;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* Cards & Layouts */
    .section-grid {
        display: grid;
        grid-template-columns: 2fr 1.2fr;
        gap: 25px;
    }
    .premium-box {
        background: #FFF;
        border-radius: 16px;
        border: 1px solid #E2E6ED;
        box-shadow: var(--card-shadow);
        overflow: hidden;
        margin-bottom: 25px;
    }
    .box-header {
        padding: 18px 24px;
        border-bottom: 1px solid #E2E6ED;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #FFF5F5;
    }
    .box-header h4 {
        margin: 0;
        font-size: 0.95rem;
        font-weight: 800;
        color: #8b0000;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .box-body {
        padding: 24px;
    }

    /* Lists and feeds */
    .feed-list { list-style: none; padding: 0; margin: 0; }
    .feed-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 15px;
        border-bottom: 1px solid #f1f5f9;
        font-size: 0.88rem;
    }
    .feed-item:last-child { border-bottom: none; }
    
    /* Interactive approvals */
    .btn-approve {
        background: var(--primary-red);
        color: white;
        border: none;
        padding: 6px 12px;
        font-size: 0.78rem;
        font-weight: 700;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.2s;
    }
    .btn-approve:hover {
        background: var(--secondary-red);
    }
    .btn-reject {
        background: #f1f5f9;
        color: #64748b;
        border: none;
        padding: 6px 12px;
        font-size: 0.78rem;
        font-weight: 700;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.2s;
        margin-right: 5px;
    }
    .btn-reject:hover { background: #e2e8f0; color: #1e293b; }

    /* Indicator pill */
    .indicator-pill {
        padding: 4px 10px;
        border-radius: 50px;
        font-size: 0.72rem;
        font-weight: 800;
    }
    .indicator-pill.ready { background: #ecfdf5; color: #065f46; }
    .indicator-pill.pending { background: #fffbeb; color: #b45309; }
    .indicator-pill.high { background: #fef2f2; color: #991b1b; }

    /* Broadcast box styling */
    .broadcast-select, .broadcast-textarea {
        width: 100%;
        padding: 12px;
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        font-size: 0.88rem;
        margin-bottom: 15px;
        font-family: inherit;
    }
    .broadcast-textarea {
        resize: vertical;
        min-height: 100px;
    }

    @media (max-width: 1024px) {
        .kpi-grid { grid-template-columns: 1fr 1fr; }
        .section-grid { grid-template-columns: 1fr; }
    }
</style>

<div class="headteacher-dashboard main-content-inner">
    
    <!-- Executive Banner -->
    <div style="background: linear-gradient(135deg, #FFF5F5 0%, #FFFFFF 100%); border: 1px solid rgba(139,0,0,0.1); border-radius: 16px; padding: 25px 30px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: var(--card-shadow);">
        <div>
            <h2 style="margin:0; font-size:1.6rem; color:#2C3E50; font-weight:900;">WELCOME, <span style="color:var(--primary-red);"><?php echo strtoupper(h($username)); ?></span></h2>
            <p style="margin:5px 0 0; font-size:0.9rem; color:#64748b; font-weight:600;"><i class="fas fa-user-tie"></i> Headteacher Office &bull; Decision & Approval Terminal</p>
        </div>
        <div style="text-align: right;">
            <div style="background:#FFF5F5; border:1px solid rgba(139,0,0,0.1); padding:6px 14px; border-radius:8px; font-size:0.8rem; font-weight:700; color:#8b0000; gap: 6px; display:inline-flex; align-items:center;">
                <i class="fas fa-calendar-day"></i> <?php echo date('l, d F Y'); ?>
            </div>
        </div>
    </div>

    <!-- Alert Messaging -->
    <?php if ($message_success): ?>
        <div style="background:#ecfdf5; border-left:5px solid #10b981; color:#065f46; padding:15px; border-radius:8px; margin-bottom:25px; font-weight:700; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-check-circle" style="font-size:1.2rem;"></i> <?php echo h($message_success); ?>
        </div>
    <?php endif; ?>
    <?php if ($message_error): ?>
        <div style="background:#fef2f2; border-left:5px solid #ef4444; color:#991b1b; padding:15px; border-radius:8px; margin-bottom:25px; font-weight:700; display:flex; align-items:center; gap:10px;">
            <i class="fas fa-exclamation-circle" style="font-size:1.2rem;"></i> <?php echo h($message_error); ?>
        </div>
    <?php endif; ?>

    <!-- Executive Overview Controls -->
    <div class="module-nav">
        <button class="module-tab active" onclick="switchPanel(event, 'academic')"><i class="fas fa-graduation-cap"></i> Academic & Exams</button>
        <button class="module-tab" onclick="switchPanel(event, 'hr')"><i class="fas fa-users-cog"></i> HR & Staff Management</button>
        <button class="module-tab" onclick="switchPanel(event, 'finance')"><i class="fas fa-wallet"></i> Finance & Assets</button>
        <button class="module-tab" onclick="switchPanel(event, 'discipline')"><i class="fas fa-gavel"></i> Discipline & Broadcast</button>
    </div>

    <!-- ==================== TAB 1: ACADEMIC & EXAMS ==================== -->
    <div id="academic-panel" class="module-panel active">
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-user-graduate"></i></div>
                <div class="kpi-data">
                    <h3><?php echo number_format($stats['total_students']); ?></h3>
                    <p>Total Students</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-award"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['overall_pass_rate']; ?></h3>
                    <p>Pass Rate</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-chart-line"></i></div>
                <div class="kpi-data">
                    <h3><?php echo h($stats['school_gpa']); ?></h3>
                    <p>Overall Level GPA</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-star"></i></div>
                <div class="kpi-data">
                    <h3 style="font-size: 1.25rem;"><?php echo h($stats['best_class']); ?></h3>
                    <p>Best Class</p>
                </div>
            </div>
        </div>

        <div class="section-grid">
            <!-- Left Side: Result Approvals -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-check-double"></i> Pending Final Results Release Approval</h4>
                        <span class="indicator-pill ready"><?php echo count($pending_exams); ?> Exams Submitted</span>
                    </div>
                    <div class="box-body" style="padding: 10px;">
                        <?php if (empty($pending_exams)): ?>
                            <div style="text-align: center; padding: 40px; color: #64748b;">
                                <i class="fas fa-clipboard-check" style="font-size: 3rem; color: #8b0000; opacity: 0.2; display: block; margin-bottom: 12px;"></i>
                                <span style="font-weight: 700;">No pending exam results requiring approval at this time.</span>
                            </div>
                        <?php else: ?>
                            <table class="table" style="width: 100%; border-collapse: collapse; font-size: 0.88rem; text-align: left;">
                                <thead>
                                    <tr style="border-bottom: 2px solid #e2e8f0; color: #64748b; font-weight: 800;">
                                        <th style="padding: 12px 15px;">Exam Title</th>
                                        <th style="padding: 12px 15px;">Class</th>
                                        <th style="padding: 12px 15px;">Subject</th>
                                        <th style="padding: 12px 15px; text-align: right;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pending_exams as $exam): ?>
                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                        <td style="padding: 12px 15px; font-weight: 700; color: #2C3E50;"><?php echo h($exam['exam_name']); ?></td>
                                        <td style="padding: 12px 15px; font-weight: 600;"><?php echo h($exam['class_name']); ?></td>
                                        <td style="padding: 12px 15px; color: #64748b;"><?php echo h($exam['subject_name']); ?></td>
                                        <td style="padding: 12px 15px; text-align: right;">
                                            <form action="" method="POST" style="margin: 0;">
                                                <input type="hidden" name="action_type" value="approve_results">
                                                <input type="hidden" name="exam_id" value="<?php echo $exam['exam_id']; ?>">
                                                <button type="submit" class="btn-approve">Approve & Release</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Right Side: Performance Analytics -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-chart-pie"></i> School Demographics & Stats</h4>
                    </div>
                    <div class="box-body" style="display: flex; flex-direction: column; gap: 15px;">
                        <div style="height: 180px;">
                            <canvas id="enrollmentChart"></canvas>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 800; background: #FFF5F5; padding: 10px; border-radius: 8px; border: 1px solid rgba(139,0,0,0.1);">
                            <span><i class="fas fa-male" style="color:#3b82f6;"></i> Boys: <?php echo number_format($stats['boys']); ?></span>
                            <span><i class="fas fa-female" style="color:#ec4899;"></i> Girls: <?php echo number_format($stats['girls']); ?></span>
                        </div>
                        <div>
                            <span style="font-size: 0.78rem; text-transform: uppercase; font-weight: 800; color: #64748b; display: block; margin-bottom: 5px;">Weakest Performance Area</span>
                            <div style="background: #fef2f2; border: 1px solid rgba(139,0,0,0.1); border-radius: 8px; padding: 12px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-exclamation-triangle" style="color: var(--primary-red); font-size: 1.1rem;"></i>
                                <span style="font-weight: 900; color: #2C3E50;"><?php echo h($stats['weakest_subject']); ?></span>
                            </div>
                        </div>
                        
                        <div style="background: #FAFBFD; border-radius: 10px; padding: 15px; border: 1px solid #E2E6ED;">
                            <div style="font-weight: 800; font-size: 0.8rem; color: #64748b; margin-bottom: 10px;">Academic Ledger Access</div>
                            <p style="font-size: 0.8rem; color: #64748b; margin: 0 0 12px; line-height: 1.4;">Access overall classroom grade breakdown matrices & aggregate metrics for standard reviews.</p>
                            <a href="../admin/results/school-stats.php" class="btn-approve" style="text-decoration: none; display: inline-block; text-align: center; width: 100%; border-radius: 6px; padding: 10px;">Open Detailed Stats</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 2: HR & STAFF ==================== -->
    <div id="hr-panel" class="module-panel">
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                <div class="kpi-data">
                    <h3><?php echo number_format($stats['total_teachers']); ?></h3>
                    <p>Active Teachers</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-user-check"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['att_present']; ?></h3>
                    <p>Present Staff</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-user-times"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['att_absent']; ?></h3>
                    <p>Absent Staff</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-plane-departure"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['pending_leaves']; ?></h3>
                    <p>Pending Leaves</p>
                </div>
            </div>
        </div>

        <div class="section-grid">
            <!-- Left Side: Leave approvals (simulated with action confirmation) -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-plane-departure"></i> Leave & Permission Approval</h4>
                        <span class="indicator-pill pending">2 Requests Pending</span>
                    </div>
                    <div class="box-body" style="padding: 0;">
                        <ul class="feed-list">
                            <li class="feed-item" id="leave-row-1">
                                <div>
                                    <div style="font-weight: 700; color: #2C3E50;">Peter M. Kileo <span style="font-weight: 500; font-size: 0.8rem; color: #64748b;">(Chemistry Teacher)</span></div>
                                    <div style="font-size: 0.78rem; color: #64748b; margin-top: 3px;">Date: Next Mon - Fri (Sick Leave)</div>
                                </div>
                                <div>
                                    <button class="btn-reject" onclick="changeStatus('leave-row-1', 'Rejected')">Reject</button>
                                    <button class="btn-approve" onclick="changeStatus('leave-row-1', 'Approved')">Approve Request</button>
                                </div>
                            </li>
                            <li class="feed-item" id="leave-row-2">
                                <div>
                                    <div style="font-weight: 700; color: #2C3E50;">Mariam Hussein <span style="font-weight: 500; font-size: 0.8rem; color: #64748b;">(English Head)</span></div>
                                    <div style="font-size: 0.78rem; color: #64748b; margin-top: 3px;">Date: Next Wed (Personal Leave)</div>
                                </div>
                                <div>
                                    <button class="btn-reject" onclick="changeStatus('leave-row-2', 'Rejected')">Reject</button>
                                    <button class="btn-approve" onclick="changeStatus('leave-row-2', 'Approved')">Approve Request</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Right Side: Teacher Activity logs -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-clipboard-list"></i> Teacher Attendance Log</h4>
                    </div>
                    <div class="box-body" style="padding: 0;">
                        <ul class="feed-list">
                            <li class="feed-item">
                                <span style="font-weight: 700;">Morning Roll Call</span>
                                <span style="color: #065f46; font-weight: 800;"><i class="fas fa-check-circle"></i> 94% Mark Completed</span>
                            </li>
                            <li class="feed-item" style="border: none;">
                                <span style="font-weight: 700;">Teaching Logbook Status</span>
                                <span class="indicator-pill ready">100% Filled</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 3: FINANCE & ASSETS ==================== -->
    <div id="finance-panel" class="module-panel">
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-piggy-bank"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['total_income']; ?></h3>
                    <p>Total Revenue</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-hand-holding-usd"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['total_expenses']; ?></h3>
                    <p>Total Expenses</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-university"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['capitation_grant']; ?></h3>
                    <p>Capitation Grant</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-chart-pie"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['utilization_rate']; ?></h3>
                    <p>Utilization</p>
                </div>
            </div>
        </div>

        <div class="section-grid">
            <!-- Left Side: Asset Approvals -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-box-open"></i> Asset & Expenditure Approval Requests</h4>
                        <span class="indicator-pill high">1 Critical Request</span>
                    </div>
                    <div class="box-body" style="padding: 0;">
                        <ul class="feed-list">
                            <li class="feed-item" id="asset-row-1">
                                <div>
                                    <div style="font-weight: 700; color: #2C3E50;">20 Desktop Computers for LAB-2</div>
                                    <div style="font-size: 0.78rem; color: #64748b; margin-top: 3.5px;">Estimated Cost: TSh 12,000,000 | Fund source: Capitation Grant</div>
                                </div>
                                <div>
                                    <button class="btn-reject" onclick="changeStatus('asset-row-1', 'Denied')">Deny</button>
                                    <button class="btn-approve" onclick="changeStatus('asset-row-1', 'Approved')">Approve Purchase</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Right Side: Capitation grant progress -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-shield-alt"></i> Capitation Grant Meter</h4>
                    </div>
                    <div class="box-body">
                        <div style="margin-bottom: 12px;">
                            <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; margin-bottom: 5px; color: #2C3E50;">
                                <span>Grant Spent</span><span>68% (Utilized)</span>
                            </div>
                            <div style="background: #f8f9fa; height: 10px; border-radius: 5px; overflow: hidden; border: 1px solid #eee;">
                                <div style="width: 68%; background: var(--primary-red); height: 100%;"></div>
                            </div>
                        </div>
                        <p style="font-size: 0.75rem; color: #64748b; line-height: 1.4; margin: 10px 0 0;">Total Allocated Amount: TSh 18,300,000. Balance remaining: TSh 5,800,000.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 4: DISCIPLINE & BROADCAST ==================== -->
    <div id="discipline-panel" class="module-panel">
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-gavel"></i></div>
                <div class="kpi-data">
                    <h3><?php echo $stats['discipline_cases']; ?></h3>
                    <p>Pending Incidents</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-paper-plane"></i></div>
                <div class="kpi-data">
                    <h3>234</h3>
                    <p>SMS Packages Sent</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-user-minus"></i></div>
                <div class="kpi-data">
                    <h3>0</h3>
                    <p>Suspensions</p>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fas fa-network-wired"></i></div>
                <div class="kpi-data">
                    <h3>Online</h3>
                    <p>SMS Gateway Connection</p>
                </div>
            </div>
        </div>

        <div class="section-grid">
            <!-- Left Side: Broadcast SMS -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-broadcast-tower"></i> Broadcast Emergency SMS Notification</h4>
                    </div>
                    <div class="box-body">
                        <form action="" method="POST">
                            <input type="hidden" name="action_type" value="broadcast_sms">
                            <label style="font-size: 0.8rem; font-weight: 800; color: #64748b; margin-bottom: 5px; display: block;">Recipient Group</label>
                            <select name="target_group" class="broadcast-select">
                                <option value="parents">All Parents</option>
                                <option value="teachers">All Teachers & Staff</option>
                                <option value="all">Parents & Staff Combined</option>
                            </select>

                            <label style="font-size: 0.8rem; font-weight: 800; color: #64748b; margin-bottom: 5px; display: block;">Notification Message</label>
                            <textarea name="sms_message" class="broadcast-textarea" placeholder="Type school notification here..."></textarea>
                            
                            <button type="submit" class="btn-approve" style="width: 100%; padding: 12px; font-size: 0.9rem;"><i class="fas fa-paper-plane"></i> Dispatch Broadcast Immediately</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Right Side: Suspension Approvals -->
            <div>
                <div class="premium-box">
                    <div class="box-header">
                        <h4><i class="fas fa-user-shield"></i> Major Disciplinary Decisions</h4>
                    </div>
                    <div class="box-body" style="padding: 0;">
                        <ul class="feed-list">
                            <li class="feed-item" id="disc-row-1">
                                <div>
                                    <div style="font-weight: 700; color: #2C3E50;">Baraka John (Form 3B)</div>
                                    <div style="font-size: 0.78rem; color: #64748b; margin-top: 3px;">truancy and system violation</div>
                                </div>
                                <div style="white-space: nowrap;">
                                    <button class="btn-reject" onclick="changeStatus('disc-row-1', 'Pardon Issued')">Pardon</button>
                                    <button class="btn-approve" style="background:#e11d48;" onclick="changeStatus('disc-row-1', 'Suspended')">Confirm Suspension</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Tab switching engine
    function switchPanel(event, targetId) {
        // Toggle tabs
        document.querySelectorAll('.module-tab').forEach(btn => {
            btn.classList.remove('active');
        });
        event.currentTarget.classList.add('active');

        // Toggle Panels
        document.querySelectorAll('.module-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById(targetId + '-panel').classList.add('active');
    }

    // Dynamic Simulated state approval feedback engine (pure JS with Premium toast notice)
    function changeStatus(elementId, status) {
        const fileRow = document.getElementById(elementId);
        if (fileRow) {
            fileRow.style.opacity = '0.5';
            fileRow.style.transition = '0.3s';
            setTimeout(() => {
                fileRow.innerHTML = `<div style="width: 100%; text-align: center; color: #065f46; background: #ecfdf5; padding: 12px; border-radius: 8px; font-weight: 800; font-size: 0.8rem; border: 1px solid #10b981;"><i class="fas fa-check-circle"></i> Request Action: ${status}</div>`;
                fileRow.style.opacity = '1';
            }, 400);
        }
    }

    // Chart.js render for Student Demographics
    document.addEventListener("DOMContentLoaded", function () {
        const ctxEnroll = document.getElementById('enrollmentChart');
        if(ctxEnroll) {
            new Chart(ctxEnroll.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Boys', 'Girls'],
                    datasets: [{
                        data: [<?php echo $stats['boys']; ?>, <?php echo $stats['girls']; ?>],
                        backgroundColor: ['#3b82f6', '#ec4899'],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: { 
                        legend: { position: 'right', labels: { font: { family: "'Inter', sans-serif", weight: 'bold' } } }
                    }
                }
            });
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>
