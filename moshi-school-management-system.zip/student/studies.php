<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "Study Materials";

// Fetch student's class
$stmt = $pdo->prepare("SELECT class_id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$class_id = $stmt->fetchColumn();

// Fetch study materials for this class
try {
    $stmt = $pdo->prepare("
        SELECT m.*, s.subject_name, t.first_name, t.last_name 
        FROM study_materials m
        JOIN subjects s ON m.subject_id = s.subject_id
        JOIN teachers t ON m.teacher_id = t.teacher_id
        WHERE m.class_id = ?
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$class_id]);
    $materials = $stmt->fetchAll();
} catch (PDOException $e) {
    $materials = [];
}
?>
<?php require_once '../includes/header.php'; ?>

<style>
    .studies-page { max-width: 1200px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .studies-hero {
        background: #0f172a;
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 35px;
        color: #cbd5e1;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .studies-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #d4af37 !important; }
    .studies-hero-sub { color: #94a3b8; font-size: 0.95rem; font-weight: 500; }

    .material-card {
        background: #0f172a;
        border-radius: 16px;
        padding: 0;
        display: flex;
        flex-direction: column;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        border: 1px solid rgba(212, 175, 55, 0.08);
        border-left: 6px solid #d4af37;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .material-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--hover-shadow);
        border-color: rgba(212, 175, 55, 0.2);
    }
    
    .material-badge {
        background: rgba(212, 175, 55, 0.1);
        color: #d4af37;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1px;
    }
    
    .material-download-footer {
        background: #111a2e;
        padding: 12px;
        text-align: center;
        color: #94a3b8;
        font-weight: 700;
        font-size: 11px;
        border-top: 1px solid rgba(212, 175, 55, 0.08);
        transition: all 0.3s;
    }
    .material-card:hover .material-download-footer {
        background: #d4af37;
        color: #0b0f19;
    }
</style>

<div class="studies-page">
    <div class="studies-hero no-print">
        <h1 class="studies-hero-title"><i class="fas fa-book-open"></i> <?php echo strtoupper($page_title); ?></h1>
        <p class="studies-hero-sub">Access notes, assignments, and reference materials uploaded by your subject teachers.</p>
    </div>

    <?php if (empty($materials)): ?>
        <div class="card" style="text-align: center; padding: 100px 40px; border-radius: 24px; border: 1px dashed rgba(212, 175, 55, 0.2); background: #0f172a;">
            <i class="fas fa-folder-open" style="font-size: 4rem; color: #64748b; margin-bottom: 20px;"></i>
            <h2 style="color: #d4af37; font-weight: 900;">NO MATERIALS AVAILABLE</h2>
            <p style="color: #94a3b8;">Your teachers haven't uploaded any study materials for your class yet. Check back soon!</p>
        </div>
    <?php else: ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px;">
            <?php foreach ($materials as $m): ?>
                <div class="material-card" onclick="window.open('<?php echo BASE_URL; ?>assets/uploads/materials/<?php echo $m['file_path']; ?>')">
                    <div style="padding: 25px;">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
                            <span class="material-badge">
                                <?php echo strtoupper(h($m['material_type'])); ?>
                            </span>
                            <i class="fas fa-file-pdf" style="font-size: 1.8rem; color: #d4af37; opacity: 0.8;"></i>
                        </div>
                        <h3 style="margin: 0 0 10px; color: #f8fafc; font-size: 1.1rem; min-height: 2.4em; overflow: hidden; font-weight: 800; line-height: 1.4;"><?php echo h($m['title']); ?></h3>
                        <div style="font-weight: 700; color: #d4af37; font-size: 13px; margin-bottom: 15px; border-bottom: 1px solid rgba(212, 175, 55, 0.08); padding-bottom: 10px;">
                            <i class="fas fa-book"></i> <?php echo h($m['subject_name']); ?>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #94a3b8; font-weight: 600;">
                            <div><i class="fas fa-user-tie"></i> Teacher <?php echo h($m['last_name']); ?></div>
                            <div><i class="fas fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($m['created_at'])); ?></div>
                        </div>
                    </div>
                    <div class="material-download-footer">
                        <i class="fas fa-download"></i> CLICK TO DOWNLOAD MATERIAL
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
