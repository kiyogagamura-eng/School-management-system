<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "My Academic Schedule";

// 1. Fetch Student Context
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s JOIN classes c ON s.class_id = c.class_id WHERE s.user_id = ?");
$stmt->execute([$user_id]);
$student = $stmt->fetch();
$class_id = $student['class_id'];

// 2. Fetch Working Days and Periods
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$stmt = $pdo->prepare("SELECT DISTINCT period_number, start_time, end_time, is_break, break_name FROM timetables ORDER BY start_time ASC");
$stmt->execute();
$all_periods = $stmt->fetchAll();

// 3. Fetch Class Timetable Entries
$stmt = $pdo->prepare("
    SELECT t.*, s.subject_name, s.subject_code, tc.first_name, tc.last_name as teacher_name
    FROM timetables t
    LEFT JOIN subjects s ON t.subject_id = s.subject_id
    LEFT JOIN teachers tc ON t.teacher_id = tc.teacher_id
    WHERE t.class_id = ? OR t.is_break = 1
    ORDER BY t.start_time ASC
");
$stmt->execute([$class_id]);
$timetable_entries = $stmt->fetchAll();

// Organize entries
$schedule = [];
$today_entries = [];
$current_day = date('l');
$current_time = date('H:i:s');

foreach ($timetable_entries as $entry) {
    $schedule[$entry['day_of_week']][$entry['period_number']] = $entry;
    if ($entry['day_of_week'] === $current_day) {
        $today_entries[] = $entry;
    }
}

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/main.css">
<style>
    :root {
        --primary-gold: #d4af37;
        --soft-gold: rgba(212, 175, 55, 0.08);
        --border-color: rgba(212, 175, 55, 0.08);
    }
    
    .st-page { max-width: 1100px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Header */
    .st-hero {
        background: #0f172a;
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 35px;
        color: #cbd5e1;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .st-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #d4af37 !important; }
    .st-hero-sub { color: #94a3b8; font-size: 0.95rem; font-weight: 500; }
    .st-hero-sub b { color: #f8fafc; }
    
    /* Tabs */
    .st-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 30px;
        background: #0b0f19;
        padding: 6px;
        border-radius: 16px;
        width: fit-content;
        border: 1px solid rgba(212, 175, 55, 0.1);
    }
    .st-tab {
        padding: 12px 24px;
        border-radius: 12px;
        font-weight: 800;
        font-size: 0.85rem;
        cursor: pointer;
        transition: all 0.3s;
        border: none;
        color: #94a3b8;
        background: transparent;
    }
    .st-tab.active {
        background: #d4af37;
        color: #0b0f19;
        box-shadow: 0 4px 12px rgba(212, 175, 55, 0.2);
    }

    /* Today's Timeline */
    .st-timeline {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    .st-time-card {
        background: #0f172a;
        border-radius: 20px;
        padding: 25px;
        display: grid;
        grid-template-columns: 120px 1fr auto;
        align-items: center;
        gap: 20px;
        border: 1px solid rgba(212, 175, 55, 0.08);
        box-shadow: var(--card-shadow);
        transition: all 0.3s;
        position: relative;
    }
    .st-time-card:hover { transform: translateX(6px); border-color: rgba(212, 175, 55, 0.2); }
    .st-time-card.current {
        border-left: 5px solid #d4af37;
        background: rgba(212, 175, 55, 0.04);
    }
    .st-time-card.break {
        background: rgba(255, 255, 255, 0.01);
        border: 1px dashed rgba(212, 175, 55, 0.15);
    }
    
    .st-time-box { text-align: right; border-right: 2px solid rgba(212, 175, 55, 0.1); padding-right: 20px; }
    .st-time-start { font-size: 1.1rem; font-weight: 900; color: #f8fafc; display: block; }
    .st-time-end { font-size: 0.8rem; color: #d4af37; font-weight: 600; }
    
    .st-info-box h3 { font-size: 1.1rem; font-weight: 900; color: #d4af37; margin: 0 0 5px; }
    .st-info-box p { font-size: 0.95rem; color: #cbd5e1; margin: 0; font-weight: 500; }
    
    .st-room-badge {
        background: #111a2e;
        color: #94a3b8;
        padding: 8px 16px;
        border-radius: 12px;
        font-weight: 800;
        font-size: 0.75rem;
        border: 1px solid rgba(212, 175, 55, 0.08);
    }
    .st-now-badge {
        position: absolute;
        top: -10px;
        right: 20px;
        background: #d4af37;
        color: #0b0f19;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.65rem;
        font-weight: 900;
        letter-spacing: 1px;
    }

    /* Grid View */
    .st-grid-container {
        background: #0f172a;
        border-radius: 20px;
        overflow-x: auto;
        border: 1px solid rgba(212, 175, 55, 0.08);
        box-shadow: var(--card-shadow);
    }
    .st-grid { width: 100%; border-collapse: collapse; min-width: 900px; }
    .st-grid th {
        background: #111a2e;
        padding: 20px;
        text-align: left;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: #d4af37;
        font-weight: 800;
        border-bottom: 2px solid rgba(212, 175, 55, 0.1);
    }
    .st-grid td { padding: 15px; border-bottom: 1px solid rgba(212, 175, 55, 0.05); }
    .st-day-label { font-weight: 900; color: #d4af37; font-size: 0.9rem; width: 120px; }
    
    .st-slot {
        background: rgba(255, 255, 255, 0.01);
        border-radius: 12px;
        padding: 12px;
        height: 100%;
        min-height: 80px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border: 1px solid rgba(212, 175, 55, 0.05);
    }
    .st-slot.active { background: rgba(212, 175, 55, 0.05); border-color: rgba(212, 175, 55, 0.15); }
    .st-slot.break { background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(212, 175, 55, 0.1); text-align: center; color: #cbd5e1; }
    .st-slot-sub { font-weight: 800; color: #f8fafc; font-size: 0.85rem; margin-bottom: 2px; }
    .st-slot-teacher { font-size: 0.7rem; color: #94a3b8; font-weight: 600; }

    .hidden { display: none; }

    @media (max-width: 768px) {
        .st-time-card { grid-template-columns: 1fr; text-align: center; }
        .st-time-box { border-right: none; border-bottom: 2px solid rgba(212, 175, 55, 0.1); padding: 0 0 15px; text-align: center; }
        .st-time-card:hover { transform: none; }
    }
</style>

<div class="st-page">
    <div class="st-hero no-print">
        <div class="st-hero-title">📅 ACADEMIC SCHEDULE</div>
        <div class="st-hero-sub">Class: <b><?php echo h($student['class_name']); ?></b> &bull; Enrollment: <b><?php echo h($student['admission_number']); ?></b></div>
    </div>

    <div class="st-tabs no-print">
        <button class="st-tab active" onclick="switchTab('today', this)">TODAY'S VIEW</button>
        <button class="st-tab" onclick="switchTab('week', this)">FULL WEEK GRID</button>
    </div>

    <!-- Today's View -->
    <div id="tab-today" class="st-timeline fade-in">
        <?php if (empty($today_entries)): ?>
            <div style="text-align: center; padding: 60px; color: #94a3b8;">
                <i class="fas fa-calendar-day" style="font-size: 3rem; margin-bottom: 15px; color: #64748b;"></i>
                <p>No classes scheduled for today.</p>
            </div>
        <?php else: ?>
            <?php foreach ($today_entries as $entry): 
                $start = date('H:i', strtotime($entry['start_time']));
                $end = date('H:i', strtotime($entry['end_time']));
                $is_now = ($current_time >= $entry['start_time'] && $current_time <= $entry['end_time']);
                $is_break = $entry['is_break'];
            ?>
                <div class="st-time-card <?php echo $is_now ? 'current' : ''; ?> <?php echo $is_break ? 'break' : ''; ?>">
                    <?php if ($is_now): ?><span class="st-now-badge">HAPPENING NOW</span><?php endif; ?>
                    
                    <div class="st-time-box">
                        <span class="st-time-start"><?php echo $start; ?></span>
                        <span class="st-time-end"><?php echo $end; ?></span>
                    </div>

                    <div class="st-info-box">
                        <?php if ($is_break): ?>
                            <h3>☕ <?php echo strtoupper($entry['break_name']); ?></h3>
                            <p>Rest and recharge for the next session.</p>
                        <?php else: ?>
                            <h3><?php echo h($entry['subject_name']); ?></h3>
                            <p><i class="fas fa-user-tie"></i> Taught by <b><?php echo h($entry['first_name'] . ' ' . $entry['teacher_name']); ?></b></p>
                        <?php endif; ?>
                    </div>

                    <span class="st-room-badge"><i class="fas fa-door-open"></i> <?php echo h($entry['room'] ?? 'TBA'); ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Full Week View -->
    <div id="tab-week" class="st-grid-container fade-in hidden">
        <table class="st-grid">
            <thead>
                <tr>
                    <th>Day</th>
                    <?php foreach ($all_periods as $p): ?>
                        <th style="text-align: center;">
                            <?php echo date('H:i', strtotime($p['start_time'])); ?><br>
                            <small style="opacity: 0.6;"><?php echo date('H:i', strtotime($p['end_time'])); ?></small>
                        </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($days as $day): ?>
                    <tr>
                        <td class="st-day-label"><?php echo strtoupper($day); ?></td>
                        <?php foreach ($all_periods as $p): 
                            $entry = $schedule[$day][$p['period_number']] ?? null;
                            $is_break = $p['is_break'];
                        ?>
                            <td>
                                <?php if ($is_break): ?>
                                    <div class="st-slot break">☕</div>
                                <?php elseif ($entry): ?>
                                    <div class="st-slot <?php echo ($day === $current_day) ? 'active' : ''; ?>">
                                        <div class="st-slot-sub"><?php echo h($entry['subject_code']); ?></div>
                                        <div class="st-slot-teacher"><?php echo h($entry['teacher_name']); ?></div>
                                    </div>
                                <?php else: ?>
                                    <div class="st-slot" style="opacity: 0.3; border-style: dashed;"></div>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Quick Legend / Info -->
    <div style="margin-top: 40px; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;" class="no-print">
        <div style="background: #0f172a; padding: 25px; border-radius: 20px; border: 1px solid rgba(212, 175, 55, 0.08); box-shadow: var(--card-shadow);">
            <h4 style="font-size: 0.9rem; font-weight: 800; color: #d4af37; margin-bottom: 15px;"><i class="fas fa-lightbulb" style="color: #d4af37;"></i> PRO TIP</h4>
            <p style="font-size: 0.8rem; color: #cbd5e1; line-height: 1.6; margin: 0;">You can click the <b>Print</b> button below to save a physical copy of your weekly schedule for your locker or home.</p>
        </div>
        <div style="display: flex; align-items: center; justify-content: center;">
            <button onclick="window.print()" style="background: #d4af37; border: none; color: #0b0f19; padding: 15px 40px; border-radius: 50px; font-weight: 800; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 15px rgba(212, 175, 55, 0.15);">
                <i class="fas fa-print"></i> PRINT FULL TIMETABLE
            </button>
        </div>
    </div>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item active">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<script>
    function switchTab(tab, btn) {
        // Update buttons
        document.querySelectorAll('.st-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Update content
        document.getElementById('tab-today').classList.add('hidden');
        document.getElementById('tab-week').classList.add('hidden');
        document.getElementById('tab-' + tab).classList.remove('hidden');
    }
</script>

<?php require_once '../includes/footer.php'; ?>
