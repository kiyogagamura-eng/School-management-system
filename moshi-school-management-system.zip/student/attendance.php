<?php
require_once '../includes/bootstrap.php';
requireRole(['student', 'teacher']);

$page_title = "My Attendance";

$student_id = 0;
if ($_SESSION['role'] === 'student') {
    $stmt = $pdo->prepare("SELECT student_id FROM students WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $student_id = $stmt->fetchColumn();
} else {
    $student_id = $_GET['id'] ?? 0;
}

// 1. Basic Stats Fetch
try {
    // Current Period context
    $current_month = date('m');
    $current_year = date('Y');

    // Basic Counts
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $total_sessions_marked = $stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status = 'present'");
    $stmt->execute([$student_id]);
    $present_count = $stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status = 'late'");
    $stmt->execute([$student_id]);
    $late_count = $stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status = 'absent'");
    $stmt->execute([$student_id]);
    $absent_count_marked = $stmt->fetchColumn();

    // 2. Fetch School Events & Holidays (Needed for expected sessions)
    $stmt = $pdo->prepare("SELECT event_date, title, event_type FROM school_events WHERE MONTH(event_date) = ? AND YEAR(event_date) = ?");
    $stmt->execute([$current_month, $current_year]);
    $events_raw = $stmt->fetchAll();
    $events_map = [];
    foreach ($events_raw as $ev) {
        $events_map[$ev['event_date']] = $ev;
    }

    // 3. Auto-Attendance Logic: Expected sessions from start of month to today
    $start_of_month = date('Y-m-01');
    $today_date = date('Y-m-d');
    $expected_sessions_total = 0;
    $current_ptr = strtotime($start_of_month);
    $today_ts = strtotime($today_date);
    
    $days_to_check = [];
    while ($current_ptr <= $today_ts) {
        $date_str = date('Y-m-d', $current_ptr);
        $day_name = date('l', $current_ptr);
        $is_holiday = (isset($events_map[$date_str]) && $events_map[$date_str]['event_type'] == 'holiday');
        if (!in_array($day_name, ['Saturday', 'Sunday']) && !$is_holiday) {
            $days_to_check[] = $day_name;
        }
        $current_ptr = strtotime("+1 day", $current_ptr);
    }

    if (!empty($days_to_check)) {
        $counts = array_count_values($days_to_check);
        foreach ($counts as $day => $freq) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM timetables WHERE class_id = (SELECT class_id FROM students WHERE student_id = ?) AND day_of_week = ? AND is_break = 0");
            $stmt->execute([$student_id, $day]);
            $expected_sessions_total += ($stmt->fetchColumn() * $freq);
        }
    }

    // 4. Final Calculations
    $auto_absent_sessions = max(0, $expected_sessions_total - ($present_count + $late_count + $absent_count_marked));
    $absent_count = $absent_count_marked + $auto_absent_sessions;
    $overall_percentage = $expected_sessions_total > 0 ? round((($present_count + $late_count) / $expected_sessions_total) * 100, 1) : 0;
    if ($overall_percentage > 100) $overall_percentage = 100;

    // Days Present (Unique Dates)
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT attendance_date) FROM attendance WHERE student_id = ? AND status IN ('present', 'late')");
    $stmt->execute([$student_id]);
    $days_present = $stmt->fetchColumn();

    // 5. Recent History
    $stmt = $pdo->prepare("
        SELECT a.*, s.subject_name 
        FROM attendance a
        LEFT JOIN subjects s ON a.subject_id = s.subject_id
        WHERE a.student_id = ?
        ORDER BY a.attendance_date DESC, a.period DESC
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $recent_history = $stmt->fetchAll();

    // 6. Calendar Data & Map
    $stmt = $pdo->prepare("SELECT attendance_date, status FROM attendance WHERE student_id = ? AND MONTH(attendance_date) = ? AND YEAR(attendance_date) = ?");
    $stmt->execute([$student_id, $current_month, $current_year]);
    $calendar_data_raw = $stmt->fetchAll();
    
    $calendar_map = [];
    foreach ($calendar_data_raw as $row) {
        if (!isset($calendar_map[$row['attendance_date']]) || $row['status'] == 'absent') {
            $calendar_map[$row['attendance_date']] = $row['status'];
        }
    }

    // Fill missing past school days in map
    $ptr = strtotime($start_of_month);
    $yesterday_ts = strtotime("-1 day", $today_ts);
    while ($ptr <= $yesterday_ts) {
        $date_str = date('Y-m-d', $ptr);
        $day_name = date('l', $ptr);
        $is_holiday = (isset($events_map[$date_str]) && $events_map[$date_str]['event_type'] == 'holiday');
        if (!in_array($day_name, ['Saturday', 'Sunday']) && !$is_holiday && !isset($calendar_map[$date_str])) {
            $calendar_map[$date_str] = 'absent';
        }
        $ptr = strtotime("+1 day", $ptr);
    }

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/main.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    :root {
        --gold: #d4af37;
        --soft-gold: rgba(212, 175, 55, 0.08);
        --border-gold: rgba(212, 175, 55, 0.12);
        --dark-bg: #0b0f19;
        --card-bg: #0f172a;
        --card-dark: #111a2e;
    }

    .at-page { max-width: 1200px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .at-hero {
        background: #0f172a;
        border-radius: 20px;
        padding: 30px;
        border: 1px solid rgba(212, 175, 55, 0.2);
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    }
    .at-hero-info { display: flex; align-items: center; gap: 20px; }
    .at-hero-icon { 
        width: 60px; height: 60px; background: rgba(212, 175, 55, 0.1); 
        border-radius: 15px; display: flex; align-items: center; 
        justify-content: center; color: #d4af37; font-size: 24px;
    }
    .at-hero h2 { color: #d4af37 !important; }
    .at-hero-meta { display: flex; gap: 40px; }
    .at-meta-item { display: flex; align-items: center; gap: 10px; }
    .at-meta-icon { color: #64748b; font-size: 18px; }
    .at-meta-label { font-size: 0.75rem; color: #64748b; font-weight: 700; text-transform: uppercase; display: block; }
    .at-meta-value { font-size: 1rem; font-weight: 800; color: #f8fafc; }

    /* Stats Grid */
    .at-stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 30px;
    }
    .at-stat-card {
        background: #0f172a;
        border-radius: 20px;
        padding: 25px;
        border: 1px solid rgba(212, 175, 55, 0.08);
        display: flex;
        align-items: center;
        gap: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        transition: all 0.3s;
    }
    .at-stat-card:hover { transform: translateY(-3px); border-color: rgba(212, 175, 55, 0.2); }
    .at-stat-icon-circle {
        width: 50px; height: 50px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 20px;
    }
    .bg-maroon-soft { background: rgba(212, 175, 55, 0.1); color: #d4af37; }
    .bg-gray-soft { background: rgba(100, 116, 139, 0.1); color: #94a3b8; }
    .bg-slate-soft { background: rgba(148, 163, 184, 0.08); color: #cbd5e1; }
    .bg-dark-soft { background: rgba(30, 41, 59, 0.5); color: #94a3b8; }
    
    .at-stat-label { font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .at-stat-value { display: block; font-size: 1.5rem; font-weight: 900; color: #f8fafc; line-height: 1.2; }
    .at-stat-sub { font-size: 0.75rem; color: #94a3b8; font-weight: 600; }

    /* Main Dashboard Layout */
    .at-main-grid {
        display: grid;
        grid-template-columns: 1fr 320px;
        gap: 30px;
    }

    /* Left Side: Charts & Table */
    .at-card {
        background: #0f172a;
        border-radius: 24px;
        padding: 25px;
        border: 1px solid rgba(212, 175, 55, 0.08);
        box-shadow: 0 4px 20px rgba(0,0,0,0.25);
        margin-bottom: 30px;
    }
    .at-card-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 25px;
    }
    .at-card-title { font-size: 0.95rem; font-weight: 900; color: #d4af37; text-transform: uppercase; letter-spacing: 0.5px; }
    
    .at-chart-container {
        display: grid; grid-template-columns: 240px 1fr; gap: 30px;
    }
    
    /* Table Styling */
    .at-table { width: 100%; border-collapse: collapse; }
    .at-table th { 
        text-align: left; padding: 15px; font-size: 0.75rem; 
        text-transform: uppercase; color: #d4af37; font-weight: 800; 
        background: rgba(212, 175, 55, 0.08); border-bottom: 1px solid rgba(212, 175, 55, 0.15);
    }
    .at-table td { padding: 15px; border-bottom: 1px solid rgba(212, 175, 55, 0.06); font-size: 0.85rem; color: #cbd5e1; }
    .at-table tr:hover { background: rgba(212, 175, 55, 0.03); }
    
    .at-status-badge {
        padding: 6px 12px; border-radius: 50px; font-weight: 800; font-size: 0.7rem; text-transform: uppercase;
    }
    .badge-present { background: rgba(52, 211, 153, 0.15); color: #34d399; border: 1px solid rgba(52,211,153,0.2); }
    .badge-absent { background: rgba(248, 113, 113, 0.1); color: #f87171; border: 1px solid rgba(248,113,113,0.15); }
    .badge-late { background: rgba(251, 191, 36, 0.1); color: #fbbf24; border: 1px solid rgba(251,191,36,0.15); }

    /* Calendar & Sidebar */
    .at-calendar { margin-bottom: 30px; }
    .at-cal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; font-weight: 800; color: #f8fafc; }
    .at-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; text-align: center; }
    .at-cal-day-label { font-size: 0.65rem; font-weight: 800; color: #64748b; padding-bottom: 5px; }
    .at-cal-date { 
        aspect-ratio: 1; display: flex; align-items: center; justify-content: center; 
        font-size: 0.8rem; font-weight: 700; border-radius: 10px; cursor: pointer;
        color: #cbd5e1;
        position: relative;
    }
    .at-cal-date:hover { background: rgba(212, 175, 55, 0.08); }
    .at-dot { 
        width: 5px; height: 5px; border-radius: 50%; 
        position: absolute; bottom: 5px; 
    }
    .dot-present { background: #34d399; }
    .dot-absent { background: #f87171; }
    .dot-late { background: #fbbf24; }
    .dot-event { background: #60a5fa; }
    .dot-holiday { background: #94a3b8; }
    .date-holiday { background: rgba(148, 163, 184, 0.1) !important; color: #64748b !important; }
    .date-event { border: 1px solid rgba(96, 165, 250, 0.3); }
    .date-current { background: #d4af37 !important; color: #0b0f19 !important; }

    .at-summary-list { list-style: none; padding: 0; margin: 0; }
    .at-summary-item { 
        display: flex; justify-content: space-between; align-items: center; 
        padding: 12px 0; border-bottom: 1px solid rgba(212, 175, 55, 0.06); font-size: 0.85rem;
    }
    .at-summary-label { display: flex; align-items: center; gap: 10px; color: #94a3b8; font-weight: 600; }
    .at-summary-value { font-weight: 800; color: #f8fafc; }
    
    .btn-mini {
        background: transparent; border: 1px solid rgba(212,175,55,0.3);
        color: #d4af37; padding: 6px 12px; border-radius: 20px;
        font-size: 0.75rem; font-weight: 700; text-decoration: none;
        transition: 0.2s;
    }
    .btn-mini:hover { background: rgba(212,175,55,0.1); }
    
    .at-alert-box {
        background: rgba(52, 211, 153, 0.08); color: #34d399; border-radius: 16px; 
        padding: 20px; text-align: center; margin-top: 20px;
        border: 1px solid rgba(52, 211, 153, 0.2);
    }

    @media (max-width: 1024px) {
        .at-stats-grid { grid-template-columns: repeat(2, 1fr); }
        .at-main-grid { grid-template-columns: 1fr; }
        .at-chart-container { grid-template-columns: 1fr; }
    }
</style>

<div class="at-page">
    <!-- Hero Banner -->
    <div class="at-hero">
        <div class="at-hero-info">
            <div class="at-hero-icon"><i class="fas fa-calendar-alt"></i></div>
            <div>
                <h2 style="font-size: 1.2rem; font-weight: 900; margin: 0; color: #d4af37;">MY ATTENDANCE</h2>
                <p style="font-size: 0.8rem; color: #94a3b8; margin: 5px 0 0;">Maintaining high attendance is key to academic success.</p>
            </div>
        </div>
        <div class="at-hero-meta no-print">
            <div class="at-meta-item">
                <i class="fas fa-calendar-check at-meta-icon"></i>
                <div>
                    <span class="at-meta-label">Academic Year</span>
                    <span class="at-meta-value"><?php echo date('Y'); ?></span>
                </div>
            </div>
            <div class="at-meta-item">
                <i class="fas fa-bookmark at-meta-icon"></i>
                <div>
                    <span class="at-meta-label">Term</span>
                    <span class="at-meta-value">Term 1</span>
                </div>
            </div>
            <div class="at-meta-item">
                <i class="fas fa-clock at-meta-icon"></i>
                <div>
                    <span class="at-meta-label">Last Updated</span>
                    <span class="at-meta-value"><?php echo date('M d, Y'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="at-stats-grid">
        <div class="at-stat-card">
            <div class="at-stat-icon-circle bg-maroon-soft"><i class="fas fa-chart-line"></i></div>
            <div>
                <span class="at-stat-label">Overall Attendance</span>
                <span class="at-stat-value"><?php echo $overall_percentage; ?>%</span>
                <span class="at-stat-sub" style="color: <?php echo ($overall_percentage >= 80) ? '#34d399' : '#f87171'; ?>"><?php echo ($overall_percentage >= 80) ? 'Excellent' : 'Needs Improvement'; ?></span>
            </div>
        </div>
        <div class="at-stat-card">
            <div class="at-stat-icon-circle bg-gray-soft"><i class="fas fa-user-check"></i></div>
            <div>
                <span class="at-stat-label">Sessions Attended</span>
                <span class="at-stat-value"><?php echo $present_count + $late_count; ?></span>
                <span class="at-stat-sub">out of <?php echo max($expected_sessions_total, $total_sessions_marked); ?></span>
            </div>
        </div>
        <div class="at-stat-card">
            <div class="at-stat-icon-circle bg-slate-soft"><i class="fas fa-clock"></i></div>
            <div>
                <span class="at-stat-label">Late Arrivals</span>
                <span class="at-stat-value"><?php echo $late_count; ?></span>
                <span class="at-stat-sub">Keep it up!</span>
            </div>
        </div>
        <div class="at-stat-card">
            <div class="at-stat-icon-circle bg-dark-soft"><i class="fas fa-calendar-day"></i></div>
            <div>
                <span class="at-stat-label">Days Present</span>
                <span class="at-stat-value"><?php echo $days_present; ?></span>
                <span class="at-stat-sub">out of <?php echo date('j'); ?> days</span>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="at-main-grid">
        <div class="at-left-col">
            <div class="at-card">
                <div class="at-card-header">
                    <span class="at-card-title"><i class="fas fa-chart-pie"></i> Attendance Overview</span>
                </div>
                <div class="at-chart-container">
                    <div style="position: relative;">
                        <canvas id="donutChart"></canvas>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                            <span style="font-size: 1.5rem; font-weight: 900; color: #f8fafc;"><?php echo $overall_percentage; ?>%</span><br>
                            <span style="font-size: 0.7rem; color: #64748b; font-weight: 800;">Overall</span>
                        </div>
                    </div>
                    <div>
                        <canvas id="lineChart" style="height: 200px !important;"></canvas>
                    </div>
                </div>
            </div>

            <div class="at-card">
                <div class="at-card-header">
                <span class="at-card-title"><i class="fas fa-history"></i> Recent Attendance History</span>
                <a href="attendance-history.php" class="btn-mini" style="text-decoration: none;">View All History <i class="fas fa-arrow-right"></i></a>
            </div>
                <div style="overflow-x: auto;">
                    <table class="at-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Subject</th>
                                <th>Period</th>
                                <th>Status</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_history)): ?>
                                <tr><td colspan="5" style="text-align: center; padding: 30px; color: #999;">No recent attendance records.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_history as $h): ?>
                                    <tr>
                                        <td style="font-weight: 800;"><?php echo date('M d, Y', strtotime($h['attendance_date'])); ?></td>
                                        <td><?php echo h($h['subject_name'] ?: 'General'); ?></td>
                                        <td>Period <?php echo $h['period']; ?></td>
                                        <td>
                                            <span class="at-status-badge badge-<?php echo $h['status']; ?>">
                                                <?php echo $h['status']; ?>
                                            </span>
                                        </td>
                                        <td style="color: #999; font-style: italic;"><?php echo h($h['remarks'] ?: 'On time'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="at-right-col">
            <div class="at-card">
                <div class="at-card-header" style="margin-bottom: 15px;">
                    <span class="at-card-title"><i class="fas fa-calendar-alt"></i> Attendance Calendar</span>
                </div>
                <div class="at-calendar">
                    <div class="at-cal-header">
                        <i class="fas fa-chevron-left" style="font-size: 0.7rem; color: #ccc; cursor: pointer;"></i>
                        <span style="font-size: 0.85rem;"><?php echo date('F Y'); ?></span>
                        <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: #ccc; cursor: pointer;"></i>
                    </div>
                    <div class="at-cal-grid">
                        <span class="at-cal-day-label">Mon</span>
                        <span class="at-cal-day-label">Tue</span>
                        <span class="at-cal-day-label">Wed</span>
                        <span class="at-cal-day-label">Thu</span>
                        <span class="at-cal-day-label">Fri</span>
                        <span class="at-cal-day-label">Sat</span>
                        <span class="at-cal-day-label">Sun</span>
                        
                        <?php 
                        $first_day_of_month = date('Y-m-01');
                        $first_day_idx = date('N', strtotime($first_day_of_month));
                        $days_in_month = date('t');
                        
                        // Empty slots for days before the 1st
                        for ($i = 1; $i < $first_day_idx; $i++) echo '<span></span>';
                        
                        for ($d = 1; $d <= $days_in_month; $d++) {
                            $current_date_str = date('Y-m-') . sprintf("%02d", $d);
                            $status = $calendar_map[$current_date_str] ?? null;
                            $event = $events_map[$current_date_str] ?? null;
                            $is_today = ($current_date_str == date('Y-m-d'));
                            
                            $date_class = '';
                            if ($is_today) $date_class = 'date-current';
                            elseif ($event && $event['event_type'] == 'holiday') $date_class = 'date-holiday';
                            elseif ($event && $event['event_type'] == 'event') $date_class = 'date-event';
                            
                            echo '<div class="at-cal-date '.$date_class.'" title="'.($event ? $event['title'] : $current_date_str).'">';
                            echo $d;
                            if ($status) {
                                echo '<span class="at-dot dot-'.$status.'"></span>';
                            } elseif ($event) {
                                echo '<span class="at-dot dot-'.$event['event_type'].'"></span>';
                            }
                            echo '</div>';
                        }
                        ?>
                    </div>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 5px; font-size: 0.65rem; color: #999; font-weight: 700;">
                        <span><i class="fas fa-circle" style="color: #34d399; font-size: 6px;"></i> Present</span>
                        <span><i class="fas fa-circle" style="color: #f87171; font-size: 6px;"></i> Absent</span>
                        <span><i class="fas fa-circle" style="color: #fbbf24; font-size: 6px;"></i> Late</span>
                        <span><i class="fas fa-circle" style="color: #60a5fa; font-size: 6px;"></i> Event</span>
                        <span><i class="fas fa-circle" style="color: #94a3b8; font-size: 6px;"></i> Holiday</span>
                    </div>
                </div>

                <div class="at-card-header" style="margin: 20px 0 10px;">
                    <span class="at-card-title">Attendance Summary</span>
                </div>
                <ul class="at-summary-list">
                    <li class="at-summary-item">
                        <span class="at-summary-label"><i class="fas fa-history" style="font-size: 0.8rem;"></i> Total Sessions</span>
                        <span class="at-summary-value"><?php echo $expected_sessions_total; ?></span>
                    </li>
                    <li class="at-summary-item">
                        <span class="at-summary-label"><i class="fas fa-check-circle" style="color: #34d399; font-size: 0.8rem;"></i> Present</span>
                        <span class="at-summary-value" style="color: #34d399;"><?php echo $present_count; ?> (<?php echo $expected_sessions_total > 0 ? round(($present_count/$expected_sessions_total)*100) : 0; ?>%)</span>
                    </li>
                    <li class="at-summary-item">
                        <span class="at-summary-label"><i class="fas fa-times-circle" style="color: #f87171; font-size: 0.8rem;"></i> Absent</span>
                        <span class="at-summary-value" style="color: #f87171;"><?php echo $absent_count; ?> (<?php echo $expected_sessions_total > 0 ? round(($absent_count/$expected_sessions_total)*100) : 0; ?>%)</span>
                    </li>
                    <li class="at-summary-item">
                        <span class="at-summary-label"><i class="fas fa-clock" style="color: #fbbf24; font-size: 0.8rem;"></i> Late Arrivals</span>
                        <span class="at-summary-value" style="color: #fbbf24;"><?php echo $late_count; ?> (<?php echo $expected_sessions_total > 0 ? round(($late_count/$expected_sessions_total)*100) : 0; ?>%)</span>
                    </li>
                </ul>

                <div class="at-alert-box no-print">
                    <i class="fas fa-trophy" style="font-size: 1.5rem; margin-bottom: 10px;"></i>
                    <div style="font-weight: 800; font-size: 0.85rem;">EXCELLENT ATTENDANCE!</div>
                    <div style="font-size: 0.75rem; opacity: 0.8;">Keep up the great work!</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // 1. Donut Chart
    const ctxDonut = document.getElementById('donutChart').getContext('2d');
    new Chart(ctxDonut, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [<?php echo $present_count + $late_count; ?>, <?php echo $absent_count; ?>],
                backgroundColor: ['#d4af37', 'rgba(212,175,55,0.1)'],
                borderWidth: 0,
                cutout: '80%'
            }]
        },
        options: {
            plugins: { legend: { display: false }, tooltip: { enabled: false } },
            responsive: true,
            maintainAspectRatio: false
        }
    });

    // 2. Line Chart Trend
    const ctxLine = document.getElementById('lineChart').getContext('2d');
    new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($trend_labels); ?>,
            datasets: [{
                label: 'Attendance %',
                data: <?php echo json_encode($trend_values); ?>,
                borderColor: '#d4af37',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: '#d4af37'
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, max: 100, ticks: { font: { size: 10 } } },
                x: { ticks: { font: { size: 10 } } }
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>
