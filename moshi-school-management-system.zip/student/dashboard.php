<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "Student Dashboard";

// 1. Fetch Student Context
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, c.form_level, c.stream, u.username, u.profile_pic 
    FROM students s 
    JOIN users u ON s.user_id = u.user_id 
    LEFT JOIN classes c ON s.class_id = c.class_id 
    WHERE s.user_id = ?
");
$stmt->execute([$user_id]);
$student = $stmt->fetch();

if (!$student) {
    die("Student profile not found. Please contact administration.");
}

$student_id = $student['student_id'];
$class_id = $student['class_id'];
$student_full_name = $student['first_name'] . ' ' . $student['last_name'];
$initials = strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1));
$admission_number = $student['admission_number'];

// 2. Fetch Calculated Statistics
$calc_year = date('Y');

// A) Total Subjects
$stmt = $pdo->prepare("SELECT COUNT(*) FROM class_subjects WHERE class_id = ?");
$stmt->execute([$class_id]);
$subjects_count = $stmt->fetchColumn();

// B) Assignments count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM study_materials WHERE class_id = ? AND material_type = 'assignment'");
$stmt->execute([$class_id]);
$assignments_count = $stmt->fetchColumn();

// C) Average Score
$stmt = $pdo->prepare("
    SELECT (SUM(r.marks_obtained) / SUM(e.max_marks)) * 100 
    FROM results r 
    JOIN exams e ON r.exam_id = e.exam_id 
    WHERE r.student_id = ? AND r.status = 'published'
");
$stmt->execute([$student_id]);
$average_score = round($stmt->fetchColumn() ?: 0, 1);

// D) Attendance Percentage
$start_date = $calc_year . '-01-01';
$end_date = date('Y-m-d');
$stmt = $pdo->prepare("SELECT event_date FROM school_events WHERE YEAR(event_date) = ? AND event_type = 'holiday'");
$stmt->execute([$calc_year]);
$holidays = $stmt->fetchAll(PDO::FETCH_COLUMN);

$expected_sessions_total = 0;
$current_ptr = strtotime($start_date);
$end_ts = strtotime($end_date);
$days_to_check = [];
while ($current_ptr <= $end_ts) {
    $date_str = date('Y-m-d', $current_ptr);
    $day_name = date('l', $current_ptr);
    if (!in_array($day_name, ['Saturday', 'Sunday']) && !in_array($date_str, $holidays)) {
        $days_to_check[] = $day_name;
    }
    $current_ptr = strtotime("+1 day", $current_ptr);
}
if (!empty($days_to_check)) {
    $counts = array_count_values($days_to_check);
    foreach ($counts as $day => $freq) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM timetables WHERE class_id = ? AND day_of_week = ? AND is_break = 0");
        $stmt->execute([$class_id, $day]);
        $expected_sessions_total += ($stmt->fetchColumn() * $freq);
    }
}
$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status IN ('present', 'late') AND YEAR(attendance_date) = ?");
$stmt->execute([$student_id, $calc_year]);
$attended_sessions = $stmt->fetchColumn();
$attendance_pct = ($expected_sessions_total > 0) ? round(($attended_sessions / $expected_sessions_total) * 100) : 0;
if ($attendance_pct > 100) $attendance_pct = 100;

// E) Announcements count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM announcements WHERE (target_role = 'student' OR target_role = 'all') AND is_active = 1");
$stmt->execute();
$announcements_count = $stmt->fetchColumn();

// F) Class Rank
$stmt = $pdo->prepare("
    SELECT rank FROM (
        SELECT r.student_id, SUM(r.marks_obtained) as total_marks,
        RANK() OVER (ORDER BY SUM(r.marks_obtained) DESC) as rank
        FROM results r
        JOIN students s2 ON r.student_id = s2.student_id
        WHERE s2.class_id = ? AND r.status = 'published'
        GROUP BY r.student_id
    ) as rankings WHERE student_id = ?
");
$stmt->execute([$class_id, $student_id]);
$rank_row = $stmt->fetch();
$class_rank = $rank_row['rank'] ?? '--';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ? AND status = 'Active'");
$stmt->execute([$class_id]);
$total_in_class = $stmt->fetchColumn();

// 3. Fetch Latest Results (Last 5)
$stmt = $pdo->prepare("
    SELECT r.*, e.exam_name, s.subject_name 
    FROM results r 
    JOIN exams e ON r.exam_id = e.exam_id 
    JOIN subjects s ON r.subject_id = s.subject_id 
    WHERE r.student_id = ? AND r.status = 'published'
    ORDER BY r.entered_date DESC LIMIT 5
");
$stmt->execute([$student_id]);
$latest_results = $stmt->fetchAll();

// 4. Upcoming Exams
$stmt = $pdo->prepare("
    SELECT e.*, s.subject_name 
    FROM exams e 
    JOIN subjects s ON e.subject_id = s.subject_id 
    WHERE (e.class_id = ? OR e.class_id IS NULL) AND e.exam_date >= CURDATE()
    ORDER BY e.exam_date ASC LIMIT 5
");
$stmt->execute([$class_id]);
$upcoming_exams = $stmt->fetchAll();

// 5. Weekly Timetable
$stmt = $pdo->prepare("
    SELECT t.*, s.subject_name, tc.first_name, tc.last_name
    FROM timetables t
    LEFT JOIN subjects s ON t.subject_id = s.subject_id
    LEFT JOIN teachers tc ON t.teacher_id = tc.teacher_id
    WHERE (t.class_id = ? OR t.is_break = 1)
    ORDER BY t.start_time ASC
");
$stmt->execute([$class_id]);
$timetable_raw = $stmt->fetchAll();

$weekly_timetable = [];
$periods = [];
foreach ($timetable_raw as $tt) {
    $day = $tt['day_of_week'];
    $period = $tt['period_number'];
    $weekly_timetable[$day][$period] = $tt;
    
    $p_key = $tt['start_time'] . '-' . $tt['end_time'];
    if (!isset($periods[$p_key])) {
        $periods[$p_key] = [
            'start' => $tt['start_time'],
            'end' => $tt['end_time'],
            'num' => $period,
            'is_break' => $tt['is_break'],
            'break_name' => $tt['break_name']
        ];
    }
}
uasort($periods, function($a, $b) { return strcmp($a['start'], $b['start']); });

// 6. Latest Announcements
$stmt = $pdo->prepare("
    SELECT * FROM announcements 
    WHERE (target_role = 'student' OR target_role = 'all') AND is_active = 1
    ORDER BY created_at DESC LIMIT 3
");
$stmt->execute();
$announcements = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<div class="dashboard-content">
    <!-- Premium Hero Banner -->
    <div class="hero-banner fade-in">
        <div class="hero-profile-area">
            <div class="hero-initials">
                <?php echo $initials; ?>
            </div>
            <div class="hero-welcome">
                <h1>Welcome Back, <?php echo h($student['first_name']); ?>!</h1>
                <div class="hero-meta">
                    <span>Admission No: <b><?php echo h($admission_number); ?></b></span> • 
                    <span>Class: <b>Form <?php echo h($student['form_level'] . $student['stream']); ?></b></span> •
                    <span>Rank: <b>#<?php echo $class_rank; ?> / <?php echo $total_in_class; ?></b></span>
                </div>
                <div class="status-badge">
                    <i class="fas fa-circle" style="font-size: 8px; margin-right: 5px;"></i> Active Student
                </div>
            </div>
        </div>

        <div class="banner-stats-container">
            <div class="banner-stat-box">
                <div class="banner-stat-label">Attendance</div>
                <div class="banner-stat-value"><?php echo $attendance_pct; ?>%</div>
            </div>
        </div>
    </div>

    <!-- Summary Cards -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card-premium fade-in">
            <div class="stat-icon icon-gold">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $subjects_count; ?></div>
                <div class="stat-label">Subjects</div>
            </div>
        </div>
        <div class="stat-card-premium fade-in" style="animation-delay: 0.1s;">
            <div class="stat-icon icon-purple">
                <i class="fas fa-file-signature"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $assignments_count; ?></div>
                <div class="stat-label">Assignments</div>
            </div>
        </div>
        <div class="stat-card-premium fade-in" style="animation-delay: 0.2s;">
            <div class="stat-icon icon-green">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $average_score; ?>%</div>
                <div class="stat-label">Average Score</div>
            </div>
        </div>
        <div class="stat-card-premium fade-in" style="animation-delay: 0.3s;">
            <div class="stat-icon icon-orange">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo $announcements_count; ?></div>
                <div class="stat-label">Announcements</div>
            </div>
        </div>
    </div>

    <!-- Main Content Layout -->
    <div class="dashboard-main-grid">
        <!-- LEFT COLUMN -->
        <div class="dashboard-left">
            <!-- Latest Results -->
            <div class="section-card fade-in">
                <div class="section-header">
                    <h3><i class="fas fa-chart-bar" style="margin-right: 10px;"></i> Latest Results</h3>
                    <a href="results.php" class="view-all">View all results</a>
                </div>
                <div class="table-responsive">
                    <table class="premium-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Exam Name</th>
                                <th>Subject</th>
                                <th>Marks</th>
                                <th>Grade</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($latest_results)): foreach($latest_results as $idx => $res): ?>
                            <tr>
                                <td><?php echo $idx + 1; ?></td>
                                <td>
                                    <?php 
                                        $ex_name = $res['exam_name'];
                                        if (stripos($ex_name, 'Annual') !== false) {
                                            $ex_name = 'Annual Examination';
                                        } else {
                                            $ex_name = preg_replace('/\b20\d{2}\b/', '', $ex_name);
                                        }
                                        echo h(trim($ex_name)); 
                                    ?>
                                </td>
                                <td><?php echo h($res['subject_name']); ?></td>
                                <td><?php echo round($res['marks_obtained']); ?> / 100</td>
                                <td>
                                    <?php 
                                        $g = $res['grade'] ?? 'F';
                                        $g_cls = 'grade-' . strtolower(substr($g, 0, 1));
                                        if (!in_array($g_cls, ['grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-f'])) $g_cls = 'grade-c';
                                    ?>
                                    <span class="grade-badge <?php echo $g_cls; ?>"><?php echo h($g); ?></span>
                                </td>
                                <td><?php echo date('d M Y', strtotime($res['entered_date'])); ?></td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="6" style="text-align: center; padding: 40px; color: #64748b;">No results published yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Weekly Timetable -->
            <div class="section-card fade-in">
                <div class="section-header">
                    <h3><i class="fas fa-calendar-alt" style="margin-right: 10px;"></i> My Timetable</h3>
                    <a href="timetable.php" class="view-all">View full timetable</a>
                </div>
                <div class="timetable-grid">
                    <table class="timetable-table">
                        <thead>
                            <tr>
                                <th style="width: 100px;">Time</th>
                                <?php foreach(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as $day): ?>
                                <th><?php echo $day; ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($periods as $p): ?>
                            <tr>
                                <td style="text-align: center; font-size: 0.8rem; font-weight: 700; color: #64748b; vertical-align: middle;">
                                    <?php echo date('H:i', strtotime($p['start'])); ?> - <?php echo date('H:i', strtotime($p['end'])); ?>
                                </td>
                                <?php foreach(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as $day): 
                                    $entry = $weekly_timetable[$day][$p['num']] ?? null;
                                    $is_break = $p['is_break'] || ($entry && $entry['is_break']);
                                ?>
                                <td <?php echo $is_break ? 'style="background: rgba(0,0,0,0.02);"' : ''; ?>>
                                    <?php if ($entry && !$entry['is_break']): ?>
                                        <div class="timetable-slot bg-slot">
                                            <div class="slot-subject"><?php echo h($entry['subject_name']); ?></div>
                                            <div class="slot-teacher">Mr. <?php echo h($entry['last_name']); ?></div>
                                        </div>
                                    <?php elseif ($is_break): ?>
                                        <div style="text-align: center; color: #64748b; font-weight: 800; font-size: 0.72rem; margin-top: 25px;">
                                            <?php echo h($p['break_name'] ?: 'BREAK'); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div class="dashboard-right">
            <!-- Upcoming Exams -->
            <div class="section-card fade-in">
                <div class="section-header">
                    <h3>Upcoming Exams</h3>
                </div>
                <div class="exam-list">
                    <?php if (!empty($upcoming_exams)): foreach($upcoming_exams as $exam): ?>
                    <div class="exam-item">
                        <div class="exam-date-box">
                            <div class="month"><?php echo date('M', strtotime($exam['exam_date'])); ?></div>
                            <div class="day"><?php echo date('d', strtotime($exam['exam_date'])); ?></div>
                        </div>
                        <div class="exam-info">
                            <div class="subject">
                                <?php 
                                    $u_name = $exam['exam_name'];
                                    if (stripos($u_name, 'Annual') !== false) {
                                        $u_name = 'Annual Examination';
                                    } else {
                                        $u_name = preg_replace('/\b20\d{2}\b/', '', $u_name);
                                    }
                                    echo h(trim($u_name)); 
                                ?>
                             </div>
                             <div style="font-size: 0.8rem; color: #64748b; font-weight: 600;"><?php echo h($exam['subject_name']); ?></div>
                             <div class="time">08:00 AM</div>
                        </div>
                    </div>
                    <?php endforeach; else: ?>
                    <div style="text-align: center; padding: 25px; color: #64748b;">No upcoming exams.</div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="section-card fade-in">
                <div class="section-header">
                    <h3>Quick Links</h3>
                </div>
                <div class="quick-links-grid">
                    <a href="../profile.php" class="quick-link-item">
                        <i class="fas fa-user-circle" style="color: #8b0000;"></i>
                        <div class="quick-link-label">My Profile</div>
                    </a>
                    <a href="timetable.php" class="quick-link-item">
                        <i class="fas fa-book" style="color: #8b0000;"></i>
                        <div class="quick-link-label">My Classes</div>
                    </a>
                    <a href="results.php" class="quick-link-item">
                        <i class="fas fa-poll" style="color: #8b0000;"></i>
                        <div class="quick-link-label">Results</div>
                    </a>
                    <a href="attendance.php" class="quick-link-item">
                        <i class="fas fa-calendar-check" style="color: #8b0000;"></i>
                        <div class="quick-link-label">Attendance</div>
                    </a>
                    <a href="studies.php" class="quick-link-item">
                        <i class="fas fa-book-reader" style="color: #8b0000;"></i>
                        <div class="quick-link-label">Study Materials</div>
                    </a>
                    <a href="#" onclick="window.print(); return false;" class="quick-link-item">
                        <i class="fas fa-print" style="color: #64748b;"></i>
                        <div class="quick-link-label">Print / PDF</div>
                    </a>
                </div>
            </div>

            <!-- Announcements -->
            <div class="section-card fade-in">
                <div class="section-header">
                    <h3>Announcements</h3>
                </div>
                <div style="padding: 15px 25px;">
                    <?php if (!empty($announcements)): foreach($announcements as $ann): ?>
                    <div style="display: flex; gap: 15px; margin-bottom: 20px;">
                        <div style="width: 35px; height: 35px; border-radius: 8px; background: rgba(139, 0, 0, 0.1); display: flex; align-items: center; justify-content: center; color: #8b0000; flex-shrink:0;">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <div style="flex: 1;">
                            <div style="font-weight: 800; font-size: 0.85rem; color: #1e293b;"><?php echo h($ann['title']); ?></div>
                            <div style="font-size: 0.78rem; color: #64748b; line-height: 1.4; margin-top: 4px;">
                                <?php echo h(substr($ann['content'], 0, 75)) . '...'; ?>
                            </div>
                            <div style="font-size: 0.7rem; color: #600000; font-weight: 700; margin-top: 6px;">
                                <?php echo date('d M Y', strtotime($ann['created_at'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; else: ?>
                    <div style="text-align: center; padding: 25px; color: #64748b;">No announcements.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Help Support -->
    <div class="need-help fade-in">
        <div class="help-text">
            <h4>Need Assistance?</h4>
            <p>Contact your class teacher or the school administration office for support.</p>
        </div>
        <a href="mailto:support@moshisims.com" class="btn btn-primary" style="border-radius: 12px; display: inline-flex; align-items: center; gap: 10px; background: #8b0000; border: none; color:#1e293b; font-weight:700; text-decoration:none; padding:10px 20px;">
            <i class="far fa-envelope"></i> Contact Support
        </a>
    </div>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item active">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
