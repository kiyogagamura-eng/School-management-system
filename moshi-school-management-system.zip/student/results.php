<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "My Academic Roadmap";

// Fetch student details
$stmt = $pdo->prepare("SELECT student_id, first_name, last_name, admission_number, class_id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    die("Student record not found.");
}

$student_id = $student['student_id'];
$class_id = $student['class_id'];
$history = getStudentAcademicHistory($student_id);

// Prepare trend data
$trend_labels = [];
$trend_points = [];
$available_years = array_reverse(array_keys($history));

foreach ($available_years as $yr) {
    if ($history[$yr]['overall_stats']['division'] !== 'N/A') {
        $trend_labels[] = $yr;
        $trend_points[] = $history[$yr]['overall_stats']['total_points'];
    }
}

$selected_year = $_GET['year'] ?? (array_keys($history)[0] ?? null);
$current_year = (int)date('Y');
$error_msg = "";

$min_year_stmt = $pdo->query("SELECT MIN(academic_year) FROM academic_terms");
$min_year = (int)$min_year_stmt->fetchColumn();
if (!$min_year || $min_year < 2000 || $min_year > $current_year) {
    $min_year = 2024;
}

if ($selected_year && ((int)$selected_year > $current_year)) {
    $error_msg = "The selected academic year has not arrived yet (You cannot choose a future year like $selected_year).";
    $selected_year = (string)$current_year;
} elseif ($selected_year && ((int)$selected_year < $min_year)) {
    $error_msg = "The selected academic year is in the past (You cannot choose a year before $min_year).";
    $selected_year = (string)$current_year;
}

// 1. Fetch Class and Form Info
$class_info = ['class_name' => '', 'form_level' => 0];
if ($class_id) {
    $cls = $pdo->prepare("SELECT class_name, form_level FROM classes WHERE class_id = ?");
    $cls->execute([$class_id]);
    $class_info = $cls->fetch(PDO::FETCH_ASSOC) ?: $class_info;
}

// 2. Calculate Attendance % for the selected year (Real Timetable Logic)
$calc_year = $selected_year ?: date('Y');
$start_date = $calc_year . '-01-01';
$end_date = ($calc_year == date('Y')) ? date('Y-m-d') : $calc_year . '-12-31';

// Get Holidays
$stmt = $pdo->prepare("SELECT event_date FROM school_events WHERE YEAR(event_date) = ? AND event_type = 'holiday'");
$stmt->execute([$calc_year]);
$holidays = $stmt->fetchAll(PDO::FETCH_COLUMN);

$expected_sessions_total = 0;
$current_ptr = strtotime($start_date);
$end_ts = strtotime($end_date);

$days_to_check = [];
while ($current_ptr <= $end_ts) {
    $date_str = date('Y-m-d', $current_ptr);
    $day_name = date('l', $current_ptr);
    if (!in_array($day_name, ['Saturday', 'Sunday']) && !in_array($date_str, $holidays)) {
        $days_to_check[] = $day_name;
    }
    $current_ptr = strtotime("+1 day", $current_ptr);
}

if (!empty($days_to_check)) {
    $counts = array_count_values($days_to_check);
    foreach ($counts as $day => $freq) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM timetables WHERE class_id = ? AND day_of_week = ? AND is_break = 0");
        $stmt->execute([$class_id, $day]);
        $expected_sessions_total += ($stmt->fetchColumn() * $freq);
    }
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status IN ('present', 'late') AND YEAR(attendance_date) = ?");
$stmt->execute([$student_id, $calc_year]);
$attended_sessions = $stmt->fetchColumn();

$attendance_pct = ($expected_sessions_total > 0) ? round(($attended_sessions / $expected_sessions_total) * 100, 1) : 0;
if ($attendance_pct > 100) $attendance_pct = 100;

// 6. Fetch Class Teacher, Headmaster, and other roles for comments
$class_teacher = null;
$headmaster = null;
$academic_teacher = null;

try {
    // Get Class Teacher
    $stmt = $pdo->prepare("
        SELECT t.first_name, t.last_name, t.staff_position 
        FROM classes c 
        JOIN teachers t ON c.class_teacher_id = t.teacher_id 
        WHERE c.class_id = ?
    ");
    $stmt->execute([$class_id]);
    $class_teacher = $stmt->fetch();

    // Get Headmaster
    $stmt = $pdo->query("SELECT first_name, last_name, staff_position FROM teachers WHERE staff_position = 'Headmaster' LIMIT 1");
    $headmaster = $stmt->fetch();

    // Get Academic Teacher
    $stmt = $pdo->query("SELECT first_name, last_name, staff_position FROM teachers WHERE staff_position = 'Academic Teacher' LIMIT 1");
    $academic_teacher = $stmt->fetch();
} catch (PDOException $e) {
    // Fallback to null
}

// 3. Calculate Ranks (This is a simplified version, ideally based on selected year/term)
// Class Rank
$stmt = $pdo->prepare("
    SELECT rank FROM (
        SELECT r.student_id, SUM(r.marks_obtained) as total_marks,
        RANK() OVER (ORDER BY SUM(r.marks_obtained) DESC) as rank
        FROM results r
        JOIN students s2 ON r.student_id = s2.student_id
        WHERE s2.class_id = ?
        GROUP BY r.student_id
    ) as rankings WHERE student_id = ?
");
$stmt->execute([$class_id, $student_id]);
$class_rank = $stmt->fetchColumn() ?: '--';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ? AND status = 'Active'");
$stmt->execute([$class_id]);
$total_in_class = $stmt->fetchColumn();

// Stream Rank (Across all classes in the same form level)
$stmt = $pdo->prepare("
    SELECT rank FROM (
        SELECT s2.student_id, SUM(r.marks_obtained) as total_marks,
        RANK() OVER (ORDER BY SUM(r.marks_obtained) DESC) as rank
        FROM results r
        JOIN students s2 ON r.student_id = s2.student_id
        JOIN classes c ON s2.class_id = c.class_id
        WHERE c.form_level = ?
        GROUP BY s2.student_id
    ) as rankings WHERE student_id = ?
");
$stmt->execute([$class_info['form_level'], $student_id]);
$stream_rank = $stmt->fetchColumn() ?: '--';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students s JOIN classes c ON s.class_id = c.class_id WHERE c.form_level = ? AND s.status = 'Active'");
$stmt->execute([$class_info['form_level']]);
$total_in_stream = $stmt->fetchColumn();

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/student_dashboard.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
    * { font-family: 'Inter', sans-serif; }

    .ar-page { max-width: 1150px; margin: 0 auto; padding: 20px 15px 60px; }

    /* Hero Header - Dark & Gold Theme */
    .ar-hero {
        background: #ffffff;
        border: 1px solid rgba(139, 0, 0, 0.2);
        border-radius: 24px;
        padding: 40px;
        color: #334155;
        display: grid;
        grid-template-columns: auto 1fr auto;
        gap: 30px;
        align-items: center;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(139, 0, 0, 0.05);
    }
    
    .ar-profile-box {
        display: flex;
        align-items: center;
        gap: 20px;
        z-index: 1;
    }
    .ar-avatar {
        width: 100px;
        height: 100px;
        border-radius: 20px;
        object-fit: cover;
        border: 2px solid #8b0000;
        background: rgba(139, 0, 0, 0.1);
    }
    .ar-student-info h1 {
        font-size: 1.8rem;
        font-weight: 900;
        color: #8b0000;
        margin: 0 0 5px;
        letter-spacing: -0.5px;
    }
    .ar-student-info p {
        margin: 0;
        color: #64748b;
        font-size: 0.95rem;
        font-weight: 500;
    }
    .ar-student-info p b {
        color: #1e293b;
    }
    .ar-status-badge {
        display: inline-block;
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        margin-top: 8px;
        border: 1px solid rgba(52, 211, 153, 0.25);
    }

    .ar-hero-stats { display: flex; gap: 15px; z-index: 1; }
    .ar-hero-stat {
        background: rgba(139, 0, 0, 0.08);
        border: 1px solid rgba(139, 0, 0, 0.15);
        border-radius: 18px;
        padding: 15px 20px;
        text-align: center;
        min-width: 110px;
    }
    .ar-hero-stat-label { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; color: #8b0000; opacity: 0.8; display: block; margin-bottom: 5px; font-weight: 800; }
    .ar-hero-stat-val { font-size: 1.4rem; font-weight: 900; color: #1e293b; display: block; }

    /* Stats Grid - 6 Cards */
    .ar-stats-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 15px;
        margin-bottom: 30px;
    }
    .ar-stat-card {
        background: #ffffff;
        border-radius: 20px;
        padding: 20px 15px;
        text-align: center;
        border: 1px solid rgba(139, 0, 0, 0.08);
        box-shadow: 0 5px 15px rgba(139, 0, 0, 0.05);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .ar-stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(139, 0, 0, 0.1); border-color: rgba(139, 0, 0, 0.2); }
    .ar-stat-icon {
        width: 40px;
        height: 40px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        font-size: 1.2rem;
    }
    .ar-stat-label { font-size: 0.65rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 2px; }
    .ar-stat-value { font-size: 1.2rem; font-weight: 900; color: #1e293b; }

    .bg-maroon { background: rgba(139, 0, 0, 0.1); color: #8b0000; }
    .bg-gray { background: rgba(100, 116, 139, 0.1); color: #64748b; }
    .bg-slate { background: rgba(148, 163, 184, 0.08); color: #334155; }
    .bg-stone { background: rgba(30, 41, 59, 0.5); color: #64748b; border: 1px solid rgba(139, 0, 0, 0.05); }

    /* Year Pills */
    .ar-years {
        display: flex;
        gap: 10px;
        justify-content: center;
        margin-bottom: 30px;
        flex-wrap: wrap;
    }
    .ar-year-pill {
        padding: 12px 30px;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 800;
        font-size: 0.9rem;
        color: #64748b;
        background: #ffffff;
        border: 1px solid rgba(139, 0, 0, 0.15);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .ar-year-pill:hover { border-color: #8b0000; color: #8b0000; transform: translateY(-2px); }
    .ar-year-pill.active {
        background: #8b0000;
        color: #1e293b;
        border-color: #8b0000;
        box-shadow: 0 10px 25px rgba(139, 0, 0, 0.25);
        transform: translateY(-2px);
    }

    /* Chart Container */
    .ar-chart-box {
        background: #ffffff;
        border-radius: 24px;
        padding: 30px;
        margin-bottom: 30px;
        border: 1px solid rgba(139, 0, 0, 0.1);
        box-shadow: 0 5px 20px rgba(139, 0, 0, 0.05);
    }
    .ar-chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .ar-chart-title { font-size: 0.9rem; font-weight: 800; color: #8b0000; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; gap: 10px; }
    .ar-chart-legend { display: flex; gap: 20px; font-size: 0.8rem; font-weight: 600; color: #64748b; }
    .ar-legend-item { display: flex; align-items: center; gap: 6px; }
    .ar-dot { width: 8px; height: 8px; border-radius: 50%; }

    /* Table & Results Area */
    .ar-term-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin: 40px 0 20px;
        padding: 0 5px;
    }
    .ar-term-dot { width: 12px; height: 12px; border-radius: 4px; background: #8b0000; box-shadow: 0 0 10px rgba(139, 0, 0, 0.3); }
    .ar-term-name { font-size: 0.9rem; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; color: #8b0000; }

    .ar-exam {
        background: #ffffff;
        border-radius: 20px;
        border: 1px solid rgba(139, 0, 0, 0.08);
        margin-bottom: 20px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(139, 0, 0, 0.05);
    }
    .ar-exam-head {
        padding: 24px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        background: rgba(139, 0, 0, 0.02);
        transition: background 0.2s;
    }
    .ar-exam-head:hover { background: rgba(139, 0, 0, 0.05); }
    .ar-exam-title { font-weight: 800; color: #1e293b; font-size: 1.1rem; display: flex; align-items: center; gap: 12px; }
    .ar-exam-title i { color: #8b0000; opacity: 0.8; }
    
    .ar-table { width: 100%; border-collapse: collapse; }
    .ar-table th {
        padding: 10px 15px;
        text-align: left;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: #8b0000;
        background: rgba(139, 0, 0, 0.08);
        font-weight: 700;
        border-bottom: 2px solid rgba(139, 0, 0, 0.15);
    }
    .ar-table td { padding: 8px 15px; border-bottom: 1px solid rgba(139, 0, 0, 0.06); font-size: 0.85rem; color: #334155; font-weight: 500; }
    .ar-table tr:hover { background: rgba(139, 0, 0, 0.03); }
    
    .grade-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 10px;
        font-weight: 900;
        font-size: 0.9rem;
        min-width: 38px;
        text-align: center;
    }
    .grade-a { background: rgba(52, 211, 153, 0.15); color: #34d399; border: 1px solid rgba(52, 211, 153, 0.2); }
    .grade-b { background: rgba(96, 165, 250, 0.15); color: #60a5fa; border: 1px solid rgba(96, 165, 250, 0.2); }
    .grade-c { background: rgba(251, 191, 36, 0.15); color: #fbbf24; border: 1px solid rgba(251, 191, 36, 0.2); }
    .grade-d { background: rgba(251, 146, 60, 0.15); color: #fb923c; border: 1px solid rgba(251, 146, 60, 0.2); }
    .grade-f { background: rgba(248, 113, 113, 0.15); color: #f87171; border: 1px solid rgba(248, 113, 113, 0.2); }

    /* Comments Section */
    .ar-comments {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
        margin-top: 30px;
        padding-top: 25px;
        border-top: 2px dashed rgba(139, 0, 0, 0.15);
    }
    .ar-comment-box {
        background: #f1f5f9;
        border-radius: 16px;
        padding: 20px;
        border: 1px solid rgba(139, 0, 0, 0.08);
        position: relative;
    }
    .ar-comment-header { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
    .ar-comment-icon { width: 32px; height: 32px; border-radius: 50%; background: #8b0000; color: #1e293b; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; }
    .ar-comment-label { font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #8b0000; }
    .ar-comment-text { font-size: 0.9rem; color: #64748b; line-height: 1.6; font-style: italic; }
    .ar-signature { margin-top: 15px; font-size: 0.8rem; font-weight: 700; color: #600000; }

    @media (max-width: 992px) {
        .ar-hero { grid-template-columns: 1fr; text-align: center; }
        .ar-profile-box { flex-direction: column; }
        .ar-hero-stats { justify-content: center; flex-wrap: wrap; }
        .ar-stats-grid { grid-template-columns: repeat(3, 1fr); }
        .ar-comments { grid-template-columns: 1fr; }
    }
    @media (max-width: 600px) {
        .ar-stats-grid { grid-template-columns: repeat(2, 1fr); }
    }

    /* Empty State */
    .ar-empty { text-align: center; padding: 80px 20px; color: #64748b; }
    .ar-empty i { font-size: 3.5rem; margin-bottom: 15px; opacity: 0.4; }
    .ar-empty h3 { color: #64748b; font-weight: 700; }

    @media (max-width: 768px) {
        .ar-hero { flex-direction: column; text-align: center; gap: 20px; padding: 25px 20px; }
        .ar-hero-stats { justify-content: center; }
        .ar-summary { grid-template-columns: 1fr 1fr; }
    }

    @media print {
        .ar-hero, .ar-years, .no-print, .ar-print-btn, .ar-arrow, .ar-chart-box { display: none !important; }
        .ar-exam-body { display: block !important; }
        .ar-exam { border: none !important; box-shadow: none !important; margin-bottom: 40px; }
        .ar-table { border: 1px solid #ddd !important; }
    }

    .ar-print-btn {
        background: transparent;
        border: 1.5px solid #8b0000;
        color: #8b0000;
        padding: 8px 18px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 0.75rem;
        cursor: pointer;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    .ar-print-btn:hover { background: #8b0000; color: #1e293b; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(212,175,55,0.25); }
</style>

<div class="ar-page">
    <?php if (!empty($error_msg)): ?>
        <div style="background: #fef2f2; border-left: 5px solid #ef4444; color: #991b1b; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: 700;">
            <i class="fas fa-exclamation-circle"></i> <?php echo h($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Hero Header -->
    <div class="ar-hero no-print">
        <div class="ar-profile-box">
            <?php 
                $profile_pic = !empty($student['profile_pic']) ? BASE_URL . $student['profile_pic'] : 'https://ui-avatars.com/api/?name=' . urlencode($student['first_name'] . ' ' . $student['last_name']) . '&background=fff5f5&color=8b0000&size=128';
            ?>
            <img src="<?php echo $profile_pic; ?>" class="ar-avatar" alt="Avatar">
            <div class="ar-student-info">
                <h1><?php echo strtoupper(h($student['first_name'] . ' ' . $student['last_name'])); ?></h1>
                <p>Admission No: <b><?php echo h($student['admission_number']); ?></b> &bull; Class: <b><?php echo h($class_info['class_name']); ?></b></p>
                <span class="ar-status-badge">Active Student</span>
            </div>
        </div>
        
        <div class="ar-hero-stats">
            <?php 
                $current_div = isset($history[$selected_year]) ? $history[$selected_year]['overall_stats']['division'] : 'N/A';
                $div_display = ($current_div !== 'N/A') ? 'DIV ' . $current_div : 'N/A';
            ?>
            <div class="ar-hero-stat">
                <span class="ar-hero-stat-label">Current Division</span>
                <span class="ar-hero-stat-val"><?php echo $div_display; ?></span>
            </div>
            
            <div class="ar-hero-stat">
                <span class="ar-hero-stat-label">Best 7 Points</span>
                <span class="ar-hero-stat-val"><?php echo end($trend_points) ?: '--'; ?></span>
            </div>

            <div class="ar-hero-stat">
                <span class="ar-hero-stat-label">Attendance</span>
                <span class="ar-hero-stat-val"><?php echo $attendance_pct; ?>%</span>
            </div>
        </div>
    </div>

    <!-- Year Content -->
    <?php if ($selected_year && isset($history[$selected_year])): 
        $yr_data = $history[$selected_year];
        $summary = $yr_data['overall_stats'];
        
        // Dynamic Statistics Calculation
        $distinct_subjects = [];
        $total_passed = 0;
        $total_failed = 0;
        $total_marks_sum = 0;
        $total_max_marks_sum = 0;
        $entry_count = 0;
        $teacher_comments_list = [];

        foreach ($yr_data['terms'] as $term_name => $term_content) {
            foreach ($term_content['exams'] as $exam_id => $exam_group) {
                foreach ($exam_group['results'] as $r) {
                    $distinct_subjects[$r['subject_id']] = true;
                    $total_marks_sum += $r['marks_obtained'];
                    $total_max_marks_sum += $r['max_marks'] ?? 100;
                    $entry_count++;
                    if ($r['grade'] != 'F') $total_passed++;
                    else $total_failed++;
                    
                    if (!empty($r['teacher_comments'])) $teacher_comments_list[] = $r['teacher_comments'];
                    if (!empty($r['remarks'])) $teacher_comments_list[] = $r['remarks'];
                }
            }
        }
        $total_subjects_count = count($distinct_subjects);
        $avg_marks_yr = $total_max_marks_sum > 0 ? round(($total_marks_sum / $total_max_marks_sum) * 100, 1) : 0;
        
        // Get a representative teacher comment
        $representative_comment = !empty($teacher_comments_list) ? $teacher_comments_list[0] : "Academic performance is consistent. Aim for higher grades next term.";
    ?>

    <!-- Stats Grid - 6 Cards like Design A -->
    <div class="ar-stats-grid">
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-maroon"><i class="fas fa-book"></i></div>
            <span class="ar-stat-label">Total Subjects</span>
            <span class="ar-stat-value"><?php echo $total_subjects_count; ?></span>
        </div>
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-maroon"><i class="fas fa-check-circle"></i></div>
            <span class="ar-stat-label">Subjects Passed</span>
            <span class="ar-stat-value"><?php echo $total_passed; ?></span>
        </div>
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-gray"><i class="fas fa-times-circle"></i></div>
            <span class="ar-stat-label">Subjects Failed</span>
            <span class="ar-stat-value"><?php echo $total_failed; ?></span>
        </div>
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-slate"><i class="fas fa-medal"></i></div>
            <span class="ar-stat-label">Class Position</span>
            <span class="ar-stat-value"><?php echo $class_rank . ' / ' . $total_in_class; ?></span>
        </div>
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-gray"><i class="fas fa-trophy"></i></div>
            <span class="ar-stat-label">Stream Position</span>
            <span class="ar-stat-value"><?php echo $stream_rank . ' / ' . $total_in_stream; ?></span>
        </div>
        <div class="ar-stat-card">
            <div class="ar-stat-icon bg-maroon"><i class="fas fa-percentage"></i></div>
            <span class="ar-stat-label">Average Score</span>
            <span class="ar-stat-value"><?php echo $avg_marks_yr; ?>%</span>
        </div>
    </div>

    <!-- Trend Chart Box -->
    <?php if (count($trend_points) > 1): ?>
    <div class="ar-chart-box no-print">
        <div class="ar-chart-header">
            <div class="ar-chart-title"><i class="fas fa-chart-line"></i> Performance Trend</div>
            <div class="ar-chart-legend">
                <div class="ar-legend-item"><span class="ar-dot" style="background: #8b0000;"></span> Best 7 Points</div>
                <div class="ar-legend-item"><span class="ar-dot" style="background: #e2e8f0;"></span> Average Marks</div>
            </div>
        </div>
        <div style="height: 250px;"><canvas id="trendChart"></canvas></div>
        <p style="font-size: 0.72rem; color: #999; margin-top: 15px; text-align: center;">Lower points = better performance per NECTA standards</p>
    </div>
    <script>
        new Chart(document.getElementById('trendChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($trend_labels); ?>,
                datasets: [{
                    label: 'Total Points',
                    data: <?php echo json_encode($trend_points); ?>,
                    borderColor: '#8b0000',
                    backgroundColor: 'rgba(139,0,0,0.05)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 4,
                    pointRadius: 6,
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 3,
                    pointBorderColor: '#8b0000',
                    pointHoverRadius: 9,
                    pointHoverBackgroundColor: '#8b0000'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { 
                    y: { 
                        reverse: true, 
                        min: 7, 
                        max: 35,
                        grid: { color: '#f1f1f1' },
                        ticks: { font: { weight: 'bold' } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { weight: 'bold' } }
                    }
                }
            }
        });
    </script>
    <?php endif; ?>

    <!-- Year Selector -->
    <div class="ar-years no-print">
        <?php foreach ($history as $year => $data): ?>
            <a href="?year=<?php echo urlencode($year); ?>" class="ar-year-pill <?php echo $selected_year === (string)$year ? 'active' : ''; ?>">
                <?php echo h($year); ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Terms & Exams Area -->
    <?php foreach ($yr_data['terms'] as $term_name => $term_content): ?>
        <div class="ar-term-header">
            <div class="ar-term-dot"></div>
            <div class="ar-term-name"><?php echo h($term_name); ?></div>
        </div>

        <?php foreach ($term_content['exams'] as $exam_id => $exam_group): ?>
            <div class="ar-exam" id="exam_<?php echo $exam_id; ?>">
                <div class="ar-exam-head" onclick="toggleExam(<?php echo $exam_id; ?>)">
                    <div class="ar-exam-title">
                        <i class="fas fa-file-signature"></i>
                        <?php echo h($exam_group['exam_name']); ?>
                        <span style="background: rgba(139, 0, 0, 0.1); color: #8b0000; padding: 4px 12px; border-radius: 50px; font-size: 0.7rem; font-weight: 800; border: 1px solid rgba(212,175,55,0.2);"><?php echo count($exam_group['results']); ?> SUBJECTS</span>
                    </div>
                    <div class="ar-exam-actions">
                        <a href="print-report.php?student_id=<?php echo $student_id; ?>&exam_name=<?php echo urlencode($exam_group['exam_name']); ?>&year=<?php echo $selected_year; ?>" target="_blank" class="ar-print-btn no-print" onclick="event.stopPropagation();">
                            <i class="fas fa-file-pdf"></i> DOWNLOAD REPORT CARD
                        </a>
                        <i class="fas fa-chevron-down ar-arrow" id="arrow_<?php echo $exam_id; ?>" style="color: #8b0000; margin-left: 10px;"></i>
                    </div>
                </div>
                <div class="ar-exam-body" id="content_<?php echo $exam_id; ?>" style="display: <?php echo count($yr_data['terms']) === 1 ? 'block' : 'none'; ?>; padding: 0 0 30px;">
                    <table class="ar-table">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th width="15%">Code</th>
                                <th width="35%">Subject</th>
                                <th class="center">Marks</th>
                                <th class="center">Grade</th>
                                <th class="center">Points</th>
                                <th class="center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i = 1;
                            $exam_passed = 0;
                            $exam_failed = 0;
                            $last_teacher_comment = '';
                            foreach ($exam_group['results'] as $r): 
                                $gc = strtolower($r['grade']);
                                $gc_class = in_array($gc, ['a','b','c','d','f']) ? "grade-$gc" : 'grade-f';
                                if ($r['grade'] != 'F') $exam_passed++; else $exam_failed++;
                                if (!empty($r['teacher_comments'])) $last_teacher_comment = $r['teacher_comments'];
                            ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td style="font-size: 0.75rem; color: #64748b; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;"><?php echo h($r['subject_code']); ?></td>
                                    <td style="font-weight: 800; color: #1e293b;"><?php echo h($r['subject_name']); ?></td>
                                    <td class="center" style="font-weight: 900; font-size: 1.1rem;"><?php echo number_format($r['marks_obtained'], 1); ?></td>
                                    <td class="center"><span class="grade-badge <?php echo $gc_class; ?>"><?php echo h($r['grade']); ?></span></td>
                                    <td class="center" style="font-weight: 800;"><?php echo $r['point_value']; ?></td>
                                    <td class="center">
                                        <?php if ($r['grade'] != 'F'): ?>
                                            <span style="color: #34d399; font-weight: 800; font-size: 0.75rem;"><i class="fas fa-check"></i> PASS</span>
                                        <?php else: ?>
                                            <span style="color: #f87171; font-weight: 800; font-size: 0.75rem;"><i class="fas fa-times"></i> FAIL</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Comments Section like Design A -->
                    <div class="ar-comments" style="margin: 30px 30px 0;">
                        <div class="ar-comment-box">
                            <div class="ar-comment-header">
                                <div class="ar-comment-icon"><i class="fas fa-user-tie"></i></div>
                                <span class="ar-comment-label">Teacher Comment</span>
                            </div>
                            <p class="ar-comment-text"><?php echo h($representative_comment); ?></p>
                            <div class="ar-signature">— <?php 
                                echo $class_teacher ? h("Mr. " . $class_teacher['first_name'] . " " . $class_teacher['last_name'] . ", " . $class_teacher['staff_position']) : "Class Teacher"; 
                            ?></div>
                        </div>

                        <div class="ar-comment-box">
                            <div class="ar-comment-header">
                                <div class="ar-comment-icon" style="background: #475569;"><i class="fas fa-book-reader"></i></div>
                                <span class="ar-comment-label">Academic Comment</span>
                            </div>
                            <p class="ar-comment-text">The student has met all academic requirements for this period. Subject selection is well-balanced.</p>
                            <div class="ar-signature" style="color: #64748b;">— <?php 
                                echo $academic_teacher ? h("Mr. " . $academic_teacher['first_name'] . " " . $academic_teacher['last_name'] . ", " . $academic_teacher['staff_position']) : "Academic Teacher"; 
                            ?></div>
                        </div>

                        <div class="ar-comment-box">
                            <div class="ar-comment-header">
                                <div class="ar-comment-icon" style="background: #334155;"><i class="fas fa-user-graduate"></i></div>
                                <span class="ar-comment-label">Headmaster Comment</span>
                            </div>
                            <p class="ar-comment-text">Consistent performance. The school is proud of your academic discipline. Continue being a role model to others.</p>
                            <div class="ar-signature" style="color: #334155;">— <?php 
                                echo $headmaster ? h("Mr. " . $headmaster['first_name'] . " " . $headmaster['last_name'] . ", " . $headmaster['staff_position']) : "Headmaster"; 
                            ?></div>
                        </div>

                        <div class="ar-comment-box" style="grid-column: 1 / -1; display: flex; justify-content: space-between; align-items: center; border: 1px solid rgba(139, 0, 0, 0.2); background: rgba(139, 0, 0, 0.05);">
                           <div style="display: flex; align-items: center; gap: 15px;">
                                <div class="ar-comment-icon" style="background: #8b0000; color: #1e293b;"><i class="fas fa-check-double"></i></div>
                                <div>
                                    <span class="ar-comment-label" style="color: #8b0000;">Pass Summary</span>
                                    <div style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">
                                        Subjects Passed: <b><?php echo $exam_passed; ?></b> &bull; Failed: <b><?php echo $exam_failed; ?></b>
                                    </div>
                                </div>
                           </div>
                           <div style="text-align: right;">
                               <span class="ar-comment-label" style="color: #8b0000;">Pass Percentage</span>
                               <div style="font-size: 1.4rem; font-weight: 900; color: #8b0000;"><?php echo round(($exam_passed / ($exam_passed + $exam_failed)) * 100); ?>%</div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endforeach; ?>

    <?php endif; ?>
</div>

<script>
    function toggleExam(id) {
        let content = document.getElementById('content_' + id);
        let arrow = document.getElementById('arrow_' + id);
        if (content.style.display === 'none') {
            content.style.display = 'block';
            arrow.style.transform = 'rotate(180deg)';
        } else {
            content.style.display = 'none';
            arrow.style.transform = 'rotate(0)';
        }
    }

    function printExam(id) {
        document.getElementById('content_' + id).style.display = 'block';
        let allExams = document.querySelectorAll('.ar-exam');
        allExams.forEach(e => { if (e.id !== 'exam_' + id) e.classList.add('no-print'); });
        window.print();
        allExams.forEach(e => e.classList.remove('no-print'));
    }
</script>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item active">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
