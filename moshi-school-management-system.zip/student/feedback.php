<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "Parent Profile & Feedback"; // Parents share student login or have separate in real app, here we use student context

$stmt = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_feedback'])) {
    $feedback = trim($_POST['feedback_text']);
    if (empty($feedback)) {
        $error = "Feedback cannot be empty.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO feedback (user_id, feedback_text) VALUES (?, ?)");
            $stmt->execute([$_SESSION['user_id'], $feedback]);
            $success = "Your feedback has been sent to the school administration.";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>
<?php
require_once '../includes/header.php';
?>

<style>
    .fb-page { max-width: 800px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .fb-hero {
        background: #fff5f5;
        border: 1px solid #8b0000;
        border-radius: 24px;
        padding: 40px;
        color: #1a1a1a;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(139, 0, 0, 0.05);
    }
    .fb-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #8b0000; }
    .fb-hero-sub { color: #64748b; font-size: 0.95rem; font-weight: 500; }

    .fb-card {
        background: white;
        border-radius: 24px;
        border: 1px solid #eee;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0,0,0,0.02);
    }
    .fb-card-header {
        background: #fff5f5;
        padding: 20px 30px;
        border-bottom: 1px solid #fecaca;
        color: #8b0000;
        font-weight: 800;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .fb-card-body { padding: 30px; }

    .fb-info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 25px;
        margin-bottom: 30px;
        padding-bottom: 25px;
        border-bottom: 1px solid #f1f5f9;
    }
    .fb-info-label { font-size: 0.7rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px; }
    .fb-info-value { font-size: 1rem; font-weight: 700; color: #1e293b; }

    .fb-textarea {
        width: 100%;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 20px;
        font-family: inherit;
        font-size: 0.95rem;
        resize: vertical;
        transition: all 0.3s;
        background: #f8fafc;
        margin-bottom: 20px;
    }
    .fb-textarea:focus {
        outline: none;
        border-color: #8b0000;
        background: white;
        box-shadow: 0 0 0 4px rgba(139,0,0,0.05);
    }

    .fb-submit {
        background: #8b0000;
        color: white;
        border: none;
        padding: 16px 32px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.3s;
        width: 100%;
        letter-spacing: 1px;
    }
    .fb-submit:hover {
        background: #7a0000;
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(139,0,0,0.2);
    }

    .fb-alert-success {
        background: #fff5f5;
        color: #8b0000;
        padding: 20px;
        border-radius: 16px;
        margin-bottom: 25px;
        border: 1px solid #fecaca;
        display: flex;
        align-items: center;
        gap: 15px;
        font-weight: 700;
    }
</style>

<div class="fb-page">
    <div class="fb-hero">
        <h1 class="fb-hero-title"><i class="fas fa-comments"></i> FEEDBACK PORTAL</h1>
        <p class="fb-hero-sub">Communicate directly with the school administration regarding your child's progress.</p>
    </div>

    <?php if ($success): ?>
        <div class="fb-alert-success">
            <i class="fas fa-check-circle" style="font-size: 1.5rem;"></i>
            <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <div class="fb-card">
        <div class="fb-card-header">
            <i class="fas fa-user-shield"></i> PARENT INFORMATION
        </div>
        <div class="fb-card-body">
            <div class="fb-info-grid">
                <div>
                    <span class="fb-info-label">Parent Name</span>
                    <div class="fb-info-value"><?php echo h($student['parent_name'] ?: 'Not Specified'); ?></div>
                </div>
                <div>
                    <span class="fb-info-label">Contact Phone</span>
                    <div class="fb-info-value"><?php echo h($student['parent_phone'] ?: 'Not Specified'); ?></div>
                </div>
                <div style="grid-column: span 2;">
                    <span class="fb-info-label">Student Name</span>
                    <div class="fb-info-value"><?php echo h($student['first_name'] . ' ' . $student['last_name']); ?> (<?php echo h($student['admission_number']); ?>)</div>
                </div>
            </div>

            <h4 style="color: #8b0000; margin-bottom: 20px; font-weight: 900; font-size: 1.1rem;">SEND MESSAGE TO ADMINISTRATION</h4>
            <form action="" method="POST">
                <textarea name="feedback_text" class="fb-textarea" rows="5" placeholder="Type your concerns, suggestions or questions here..." required></textarea>
                <button type="submit" name="send_feedback" class="fb-submit">
                    <i class="fas fa-paper-plane" style="margin-right: 8px;"></i> SUBMIT FEEDBACK
                </button>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
