<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "School Announcements";

// Fetch all active announcements
try {
    $stmt = $pdo->prepare("
        SELECT * FROM announcements 
        WHERE (target_role = 'student' OR target_role = 'all') AND is_active = 1
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    $announcements = [];
}

require_once '../includes/header.php';
?>

<style>
    .announcements-page { max-width: 900px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .announcements-hero {
        background: #0f172a;
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 35px;
        color: #cbd5e1;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .announcements-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #d4af37 !important; }
    .announcements-hero-sub { color: #94a3b8; font-size: 0.95rem; font-weight: 500; }

    .announcement-card {
        background: #0f172a;
        border-radius: 16px;
        padding: 25px;
        margin-bottom: 20px;
        border: 1px solid rgba(212, 175, 55, 0.08);
        border-left: 6px solid #d4af37;
        box-shadow: var(--card-shadow);
        transition: all 0.3s;
    }
    
    .announcement-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--hover-shadow);
        border-color: rgba(212, 175, 55, 0.2);
    }

    .ann-icon {
        width: 45px;
        height: 45px;
        border-radius: 12px;
        background: rgba(212, 175, 55, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #d4af37;
        font-size: 1.2rem;
        flex-shrink: 0;
    }

    .ann-header {
        display: flex;
        gap: 15px;
        align-items: center;
        margin-bottom: 15px;
    }

    .ann-title {
        font-size: 1.15rem;
        font-weight: 800;
        color: #f8fafc;
        margin: 0;
    }

    .ann-date {
        font-size: 0.75rem;
        color: #aa8416;
        font-weight: 700;
    }

    .ann-content {
        color: #cbd5e1;
        font-size: 0.9rem;
        line-height: 1.6;
        margin: 0;
    }
</style>

<div class="announcements-page">
    <div class="announcements-hero no-print">
        <h1 class="announcements-hero-title"><i class="fas fa-bullhorn"></i> ANNOUNCEMENTS</h1>
        <p class="announcements-hero-sub">Stay up to date with official school communications and announcements.</p>
    </div>

    <?php if (empty($announcements)): ?>
        <div class="card" style="text-align: center; padding: 100px 40px; border-radius: 24px; border: 1px dashed rgba(212, 175, 55, 0.2); background: #0f172a;">
            <i class="fas fa-bullhorn" style="font-size: 4rem; color: #64748b; margin-bottom: 20px;"></i>
            <h2 style="color: #d4af37; font-weight: 900;">NO ANNOUNCEMENTS</h2>
            <p style="color: #94a3b8;">There are no new announcements from administration at this moment.</p>
        </div>
    <?php else: ?>
        <div class="announcements-list">
            <?php foreach ($announcements as $ann): ?>
                <div class="announcement-card fade-in">
                    <div class="ann-header">
                        <div class="ann-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <div>
                            <h3 class="ann-title"><?php echo h($ann['title']); ?></h3>
                            <span class="ann-date"><?php echo date('d M Y, H:i A', strtotime($ann['created_at'])); ?></span>
                        </div>
                    </div>
                    <p class="ann-content"><?php echo nl2br(h($ann['content'])); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
