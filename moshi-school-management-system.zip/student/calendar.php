<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "School Calendar & Events";

// Fetch school events
try {
    $stmt = $pdo->prepare("
        SELECT * FROM school_events 
        WHERE event_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
        ORDER BY event_date ASC
    ");
    $stmt->execute();
    $events = $stmt->fetchAll();
} catch (PDOException $e) {
    $events = [];
}

require_once '../includes/header.php';
?>

<style>
    .calendar-page { max-width: 900px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .calendar-hero {
        background: #0f172a;
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 35px;
        color: #cbd5e1;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .calendar-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #d4af37 !important; }
    .calendar-hero-sub { color: #94a3b8; font-size: 0.95rem; font-weight: 500; }

    .event-card {
        background: #0f172a;
        border-radius: 16px;
        padding: 20px 25px;
        margin-bottom: 20px;
        border: 1px solid rgba(212, 175, 55, 0.08);
        box-shadow: var(--card-shadow);
        display: flex;
        align-items: center;
        gap: 25px;
        transition: all 0.3s;
    }
    
    .event-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--hover-shadow);
        border-color: rgba(212, 175, 55, 0.2);
    }

    .event-date-badge {
        text-align: center;
        background: rgba(212, 175, 55, 0.1);
        border: 1px solid rgba(212, 175, 55, 0.25);
        color: #d4af37;
        padding: 12px;
        border-radius: 14px;
        min-width: 75px;
    }

    .event-date-badge .day {
        font-size: 1.5rem;
        font-weight: 900;
        line-height: 1.1;
    }

    .event-date-badge .month {
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.7px;
    }

    .event-info {
        flex: 1;
    }

    .event-title {
        font-size: 1.1rem;
        font-weight: 800;
        color: #f8fafc;
        margin: 0 0 5px 0;
    }

    .event-desc {
        color: #cbd5e1;
        font-size: 0.85rem;
        line-height: 1.5;
        margin: 0;
    }

    .event-type {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 50px;
        font-size: 0.65rem;
        font-weight: 800;
        text-transform: uppercase;
        margin-top: 10px;
    }

    .type-holiday { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.25); }
    .type-exam { background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.25); }
    .type-event { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.25); }
</style>

<div class="calendar-page">
    <div class="calendar-hero no-print">
        <h1 class="calendar-hero-title"><i class="fas fa-calendar-alt"></i> ACADEMIC EVENTS</h1>
        <p class="calendar-hero-sub">Keep track of holidays, exams, sports, and all other scheduled school events.</p>
    </div>

    <?php if (empty($events)): ?>
        <div class="card" style="text-align: center; padding: 100px 40px; border-radius: 24px; border: 1px dashed rgba(212, 175, 55, 0.2); background: #0f172a;">
            <i class="fas fa-calendar-alt" style="font-size: 4rem; color: #64748b; margin-bottom: 20px;"></i>
            <h2 style="color: #d4af37; font-weight: 900;">NO UPCOMING EVENTS</h2>
            <p style="color: #94a3b8;">There are no academic events scheduled for this period.</p>
        </div>
    <?php else: ?>
        <div class="calendar-list">
            <?php foreach ($events as $e): 
                $date_ts = strtotime($e['event_date']);
                $day = date('d', $date_ts);
                $month = date('M', $date_ts);
                $type_class = 'type-event';
                if (strtolower($e['event_type']) === 'holiday') {
                    $type_class = 'type-holiday';
                } elseif (strtolower($e['event_type']) === 'exam' || strpos(strtolower($e['title']), 'exam') !== false) {
                    $type_class = 'type-exam';
                }
            ?>
                <div class="event-card fade-in">
                    <div class="event-date-badge">
                        <div class="day"><?php echo $day; ?></div>
                        <div class="month"><?php echo $month; ?></div>
                    </div>
                    <div class="event-info">
                        <h3 class="event-title"><?php echo h($e['title']); ?></h3>
                        <p class="event-desc"><?php echo h($e['description'] ?: 'No additional description provided.'); ?></p>
                        <span class="event-type <?php echo $type_class; ?>"><?php echo h($e['event_type']); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
