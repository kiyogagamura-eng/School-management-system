<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$student_id = $_GET['student_id'] ?? 0;
$exam_name = $_GET['exam_name'] ?? '';
$year = $_GET['year'] ?? date('Y');

// Security check: Student can only view their own report
$stmt = $pdo->prepare("SELECT student_id, first_name, last_name, admission_number, class_id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$me = $stmt->fetch();

if (!$me || $me['student_id'] != $student_id) {
    die("Unauthorized access.");
}

// Fetch results for the specific exam and year
$stmt = $pdo->prepare("
    SELECT r.*, s.subject_name, s.subject_code, e.exam_name, e.max_marks, e.pass_marks, t.term_name, gs.point_value
    FROM results r
    JOIN exams e ON r.exam_id = e.exam_id
    JOIN subjects s ON r.subject_id = s.subject_id
    JOIN academic_terms t ON e.term_id = t.term_id
    LEFT JOIN grading_scale gs ON r.grade = gs.grade
    WHERE r.student_id = ? AND e.exam_name = ? AND r.status = 'published'
    ORDER BY s.subject_name ASC
");
$stmt->execute([$student_id, $exam_name]);
$results = $stmt->fetchAll();

if (empty($results)) {
    die("No published results found for this exam.");
}

// Fetch Class Info
$stmt = $pdo->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$stmt->execute([$me['class_id']]);
$class_name = $stmt->fetchColumn();

// Summary Stats
$total_marks = 0;
$max_possible = 0;
$passed = 0;
foreach ($results as $r) {
    $total_marks += $r['marks_obtained'];
    $max_possible += $r['max_marks'];
    if ($r['grade'] != 'F') $passed++;
}
$average = count($results) > 0 ? round($total_marks / count($results), 1) : 0;
$division_info = calculateOLevelDivision($results);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Card - <?php echo h($me['first_name'] . ' ' . $me['last_name']); ?></title>
    <style>
        @media print { 
            .no-print { display: none; }
            body { padding: 0; background: white; }
            .report-container { box-shadow: none; margin: 0; width: 100%; }
        }
        
        * { box-sizing: border-box; }
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
            color: #1e293b; 
            line-height: 1.6; 
            padding: 20px; 
            background: #f1f5f9; 
            margin: 0;
        }
        
        .report-container { 
            background: white; 
            max-width: 210mm; 
            min-height: 297mm; 
            margin: 0 auto; 
            padding: 40px; 
            box-shadow: 0 10px 40px rgba(139, 0, 0, 0.05); 
            position: relative; 
            border-radius: 8px;
        }
        
        @media (max-width: 210mm) {
            body { padding: 10px; }
            .report-container { 
                padding: 20px; 
                width: 100%; 
                min-height: auto;
            }
            .student-details { grid-template-columns: 1fr !important; gap: 10px !important; }
            .summary-box { grid-template-columns: 1fr 1fr !important; }
            .signatures { grid-template-columns: 1fr !important; gap: 40px !important; }
            .school-name { font-size: 1.2rem !important; }
            .report-title { font-size: 0.9rem !important; padding: 5px 15px !important; }
            table { font-size: 0.8rem; }
            th, td { padding: 8px !important; }
        }

        .header { text-align: center; border-bottom: 3px double #8b0000; padding-bottom: 20px; margin-bottom: 30px; }
        .school-logo { width: 80px; margin-bottom: 10px; }
        .school-name { font-size: 24px; font-weight: 900; color: #8b0000; margin: 0; letter-spacing: -0.5px; }
        .school-info { font-size: 11px; color: #64748b; margin: 3px 0; font-weight: 500; }
        .report-title { font-size: 16px; font-weight: 800; background: #8b0000; color: white; display: inline-block; padding: 8px 30px; border-radius: 50px; margin: 20px 0; text-transform: uppercase; letter-spacing: 1px; }
        
        .student-details { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px; font-size: 13px; }
        .detail-row { display: flex; border-bottom: 1px solid #f1f5f9; padding: 6px 0; justify-content: space-between; }
        .detail-label { font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 11px; }
        .detail-value { font-weight: 800; color: #1e293b; text-align: right; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; border: 1px solid #e2e8f0; }
        th { background: #fff5f5; border: 1px solid #e2e8f0; padding: 12px; font-size: 11px; text-transform: uppercase; color: #8b0000; font-weight: 800; }
        td { border: 1px solid #e2e8f0; padding: 12px; font-size: 13px; }
        .center { text-align: center; }
        .bold { font-weight: 800; }
        
        .summary-box { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px; }
        .stat-card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 15px; text-align: center; border-radius: 12px; }
        .stat-val { font-size: 18px; font-weight: 900; color: #8b0000; display: block; line-height: 1.2; }
        .stat-lbl { font-size: 9px; color: #64748b; text-transform: uppercase; font-weight: 800; letter-spacing: 0.5px; }

        .comments-section { border: 1px solid #e2e8f0; border-radius: 12px; padding: 25px; margin-bottom: 40px; font-size: 13px; background: #fafafa; }
        .comment-item { margin-bottom: 20px; }
        .comment-label { font-weight: 800; color: #8b0000; margin-bottom: 8px; display: block; font-size: 11px; text-transform: uppercase; }
        
        .signatures { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 30px; margin-top: 60px; text-align: center; font-size: 11px; }
        .sig-line { border-top: 2px solid #1e293b; padding-top: 10px; margin-top: 30px; font-weight: 800; text-transform: uppercase; color: #1e293b; }
        
        .watermark { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-45deg); font-size: 80px; color: rgba(139,0,0,0.03); font-weight: 900; pointer-events: none; white-space: nowrap; text-transform: uppercase; }
        
        .print-btn {
            background: #8b0000; 
            color: white; 
            border: none; 
            padding: 16px 40px; 
            border-radius: 50px; 
            font-weight: 800; 
            cursor: pointer; 
            box-shadow: 0 10px 25px rgba(139,0,0,0.2);
            font-size: 0.9rem;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .print-btn:hover { background: #7a0000; transform: translateY(-2px); }
    </style>
</head>
<body>

<div class="no-print" style="text-align: center; margin-bottom: 30px;">
    <button onclick="window.print()" class="print-btn">
        <i class="fas fa-print"></i> PRINT OR SAVE AS PDF
    </button>
    <p style="color: #64748b; font-size: 0.75rem; margin-top: 12px; font-weight: 600;">Select "Save as PDF" to download this report to your device.</p>
</div>

<div class="report-container">
    <div class="watermark">OFFICIAL REPORT</div>
    
    <div class="header">
        <img src="../assets/img/logo.png" class="school-logo" alt="Logo" onerror="this.src='https://ui-avatars.com/api/?name=SCHOOL&background=940000&color=fff'">
        <h1 class="school-name">MOSHI PUBLIC SECONDARY SCHOOL</h1>
        <p class="school-info">P.O. Box 1234, Moshi, Kilimanjaro | Tel: +255 712 345 678</p>
        <p class="school-info">Email: info@moshipublic.sc.tz | Website: www.moshipublic.sc.tz</p>
        <div class="report-title">Academic Progress Report</div>
    </div>

    <div class="student-details">
        <div>
            <div class="detail-row"><span class="detail-label">Student Name</span> <span class="detail-value"><?php echo strtoupper(h($me['first_name'] . ' ' . $me['last_name'])); ?></span></div>
            <div class="detail-row"><span class="detail-label">Admission No</span> <span class="detail-value"><?php echo h($me['admission_number']); ?></span></div>
            <div class="detail-row"><span class="detail-label">Class / Level</span> <span class="detail-value"><?php echo h($class_name); ?></span></div>
        </div>
        <div>
            <div class="detail-row"><span class="detail-label">Academic Year</span> <span class="detail-value"><?php echo $year; ?></span></div>
            <div class="detail-row"><span class="detail-label">Term</span> <span class="detail-value"><?php echo h($results[0]['term_name']); ?></span></div>
            <div class="detail-row"><span class="detail-label">Examination</span> <span class="detail-value"><?php echo h($exam_name); ?></span></div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%" class="center">#</th>
                <th width="45%">Subject Name</th>
                <th width="15%" class="center">Marks (%)</th>
                <th width="10%" class="center">Grade</th>
                <th width="25%">Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php $sn = 1; foreach ($results as $r): ?>
                <tr>
                    <td class="center" style="color: #64748b; font-weight: 700;"><?php echo $sn++; ?></td>
                    <td class="bold"><?php echo h($r['subject_name']); ?></td>
                    <td class="center bold" style="font-size: 1.1rem; color: #8b0000;"><?php echo number_format($r['marks_obtained'], 1); ?></td>
                    <td class="center bold"><?php echo h($r['grade']); ?></td>
                    <td style="font-size: 11px; color: #64748b; font-style: italic;"><?php echo h($r['remarks'] ?: 'Satisfactory'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="summary-box">
        <div class="stat-card">
            <span class="stat-lbl">Total Score</span>
            <span class="stat-val"><?php echo $total_marks; ?> / <?php echo $max_possible; ?></span>
        </div>
        <div class="stat-card">
            <span class="stat-lbl">Average %</span>
            <span class="stat-val"><?php echo $average; ?>%</span>
        </div>
        <div class="stat-card">
            <span class="stat-lbl">Division / Points</span>
            <span class="stat-val"><?php echo $division_info['division'] != '0' ? 'DIV ' . $division_info['division'] . ' (' . $division_info['total_points'] . ')' : 'N/A'; ?></span>
        </div>
        <div class="stat-card">
            <span class="stat-lbl">Overall Status</span>
            <span class="stat-val" style="color: <?php echo $passed == count($results) ? '#059669' : '#8b0000'; ?>">
                <?php echo $passed == count($results) ? 'PASSED' : 'RETAKE'; ?>
            </span>
        </div>
    </div>

    <div class="comments-section">
        <div class="comment-item">
            <span class="comment-label">Class Teacher's Remarks:</span>
            <p style="color: #94a3b8; font-style: italic;">____________________________________________________________________________________________________</p>
        </div>
        <div class="comment-item">
            <span class="comment-label">Headmaster's Final Verdict:</span>
            <p style="color: #94a3b8; font-style: italic;">____________________________________________________________________________________________________</p>
        </div>
    </div>

    <div class="signatures">
        <div>
            <div class="sig-line">Class Teacher</div>
        </div>
        <div>
            <div class="sig-line">Parent / Guardian</div>
        </div>
        <div>
            <div class="sig-line">Headmaster & Stamp</div>
        </div>
    </div>

    <div style="text-align: center; margin-top: 50px; font-size: 10px; color: #999;">
        This is a computer-generated report. Printed on: <?php echo date('d M Y, H:i'); ?>
    </div>
</div>

<script>
    // Auto open print dialog if directed
    <?php if (isset($_GET['autoprint'])): ?>
    window.onload = function() { window.print(); }
    <?php endif; ?>
</script>

</body>
</html>
