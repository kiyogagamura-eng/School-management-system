<?php
require_once '../includes/bootstrap.php';
requireRole('student');

$page_title = "Online Quizzes";

require_once '../includes/header.php';
?>

<style>
    .quizzes-page { max-width: 900px; margin: 0 auto; padding: 20px 15px 60px; }
    
    /* Hero Section */
    .quizzes-hero {
        background: #0f172a;
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 35px;
        color: #cbd5e1;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
        box-shadow: var(--card-shadow);
    }
    .quizzes-hero-title { font-size: 1.8rem; font-weight: 900; margin-bottom: 5px; color: #d4af37 !important; }
    .quizzes-hero-sub { color: #94a3b8; font-size: 0.95rem; font-weight: 500; }
</style>

<div class="quizzes-page">
    <div class="quizzes-hero no-print">
        <h1 class="quizzes-hero-title"><i class="fas fa-laptop-code"></i> ONLINE QUIZZES</h1>
        <p class="quizzes-hero-sub">Practice and test your knowledge under real-time constraints.</p>
    </div>

    <div class="card" style="text-align: center; padding: 100px 40px; border-radius: 20px; border: 1px dashed rgba(212, 175, 55, 0.2); background: #0f172a; box-shadow: var(--card-shadow);">
        <i class="fas fa-clock" style="font-size: 4rem; color: #64748b; margin-bottom: 20px;"></i>
        <h2 style="color: #d4af37; font-weight: 900; text-transform: uppercase;">Quizzes Feature Coming Soon</h2>
        <p style="color: #cbd5e1; max-width: 500px; margin: 10px auto 0; font-size: 0.9rem; line-height: 1.6;">Our school ICT department is currently building this interactive assessment module. Soon you will be able to take quizzes assigned by your subject teachers directly here!</p>
    </div>
</div>

<!-- Mobile Bottom Navigation Bar -->
<div class="mobile-bottom-nav">
    <a href="<?php echo BASE_URL; ?>student/dashboard.php" class="mobile-bottom-nav-item">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/timetable.php" class="mobile-bottom-nav-item">
        <i class="fas fa-graduation-cap"></i>
        <span>Academics</span>
    </a>
    <a href="<?php echo BASE_URL; ?>student/results.php" class="mobile-bottom-nav-item">
        <i class="fas fa-chart-bar"></i>
        <span>Grades</span>
    </a>
    <a href="<?php echo BASE_URL; ?>profile.php" class="mobile-bottom-nav-item">
        <i class="fas fa-user"></i>
        <span>Profile</span>
    </a>
</div>

<?php require_once '../includes/footer.php'; ?>
