<?php
require_once '../includes/bootstrap.php';
requireRole(['student', 'teacher']);

$page_title = "Attendance History";

$student_id = 0;
if ($_SESSION['role'] === 'student') {
    $stmt = $pdo->prepare("SELECT student_id FROM students WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $student_id = $stmt->fetchColumn();
} else {
    $student_id = $_GET['id'] ?? 0;
}

// Fetch Full History
$stmt = $pdo->prepare("
    SELECT a.*, s.subject_name 
    FROM attendance a
    LEFT JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.student_id = ?
    ORDER BY a.attendance_date DESC, a.period DESC
");
$stmt->execute([$student_id]);
$history = $stmt->fetchAll();

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="../assets/css/main.css">
<style>
    .ah-page { max-width: 1000px; margin: 0 auto; padding: 40px 15px; }
    .ah-page h2 { color: #d4af37 !important; }
    .ah-page p { color: #94a3b8; }
    .ah-card { background: #0f172a; border-radius: 20px; border: 1px solid rgba(212, 175, 55, 0.1); overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
    .ah-table { width: 100%; border-collapse: collapse; }
    .ah-table th { background: rgba(212, 175, 55, 0.08); padding: 15px; text-align: left; font-size: 0.75rem; color: #d4af37; font-weight: 800; text-transform: uppercase; border-bottom: 2px solid rgba(212, 175, 55, 0.15); }
    .ah-table td { padding: 15px; border-bottom: 1px solid rgba(212, 175, 55, 0.06); font-size: 0.85rem; color: #cbd5e1; }
    .ah-table tr:hover { background: rgba(212, 175, 55, 0.03); }
    .ah-status { padding: 4px 12px; border-radius: 50px; font-weight: 800; font-size: 0.7rem; text-transform: uppercase; }
    .badge-present { background: rgba(52, 211, 153, 0.15); color: #34d399; border: 1px solid rgba(52,211,153,0.2); }
    .badge-absent { background: rgba(248, 113, 113, 0.1); color: #f87171; border: 1px solid rgba(248,113,113,0.15); }
    .badge-late { background: rgba(251, 191, 36, 0.1); color: #fbbf24; border: 1px solid rgba(251,191,36,0.15); }
    .btn-back { background: transparent; border: 1px solid rgba(212,175,55,0.3); color: #d4af37; padding: 8px 16px; border-radius: 50px; text-decoration: none; font-weight: 800; font-size: 0.75rem; transition: all 0.3s; }
    .btn-back:hover { background: rgba(212,175,55,0.1); }
</style>

<div class="ah-page">
    <div style="margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h2 style="font-weight: 900; margin: 0; color: #d4af37;">FULL ATTENDANCE HISTORY</h2>
            <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 5px;">A complete record of your presence in all academic sessions.</p>
        </div>
        <a href="attendance.php" class="btn-back">
            <i class="fas fa-arrow-left"></i> BACK TO DASHBOARD
        </a>
    </div>

    <div class="ah-card">
        <table class="ah-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Subject</th>
                    <th>Period</th>
                    <th>Status</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($history as $h): ?>
                    <tr>
                        <td style="font-weight: 800; color: #f8fafc;"><?php echo date('M d, Y', strtotime($h['attendance_date'])); ?></td>
                        <td><?php echo h($h['subject_name'] ?: 'General'); ?></td>
                        <td>Period <?php echo $h['period']; ?></td>
                        <td>
                            <span class="ah-status badge-<?php echo $h['status']; ?>">
                                <?php echo $h['status']; ?>
                            </span>
                        </td>
                        <td style="color: #64748b; font-style: italic;"><?php echo h($h['remarks'] ?: '-'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
