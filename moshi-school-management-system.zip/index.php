<?php
require_once 'includes/bootstrap.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'];
    $dashboard_map = [
        'headteacher' => 'headteacher/dashboard.php',
        'dos' => 'dos/dashboard.php',
        'admin' => 'admin/dashboard.php',
        'teacher' => 'teacher/dashboard.php',
        'student' => 'student/dashboard.php',
        'parent' => 'student/dashboard.php', // Parents use student portal
        'discipline' => 'discipline/dashboard.php'
    ];
    $target = isset($dashboard_map[$role]) ? $dashboard_map[$role] : 'index.php';
    header("Location: $target");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate CSRF token
    requireCSRF();
    
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        // Check rate limiting
        $rate_check = checkLoginAttempts($username);
        if ($rate_check !== true) {
            $error = $rate_check;
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if ($user['status'] == 'active') {
                    // Reset failed attempts
                    resetFailedLogins($username);
                    
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['last_activity'] = time();
                    
                    // Log login
                    $log_stmt = $pdo->prepare("UPDATE users SET last_login = NOW(), last_login_ip = ? WHERE user_id = ?");
                    $log_stmt->execute([$_SERVER['REMOTE_ADDR'], $user['user_id']]);
                    
                    logActivity($user['user_id'], 'login', 'User logged in successfully');

                    $role = $user['role'];
                    $dashboard_map = [
                        'headteacher' => 'headteacher/dashboard.php',
                        'dos' => 'dos/dashboard.php',
                        'admin' => 'admin/dashboard.php',
                        'teacher' => 'teacher/dashboard.php',
                        'student' => 'student/dashboard.php',
                        'parent' => 'student/dashboard.php',
                        'discipline' => 'discipline/dashboard.php'
                    ];
                    $target = isset($dashboard_map[$role]) ? $dashboard_map[$role] : 'index.php';
                    header("Location: $target");
                    exit();
                } else {
                    $error = "Your account is " . $user['status'] . ". Please contact administrator.";
                }
            } else {
                // Record failed login attempt
                recordFailedLogin($username);
                $error = "Invalid username or password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #FFF5F5 0%, #FFFFFF 100%);
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 40px;
            background: #FFFFFF;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(139, 0, 0, 0.1);
            border-top: 5px solid var(--corporate-red);
            animation: fadeIn 0.6s ease-out;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-logo h2 {
            margin-top: 10px;
            font-size: 1.5rem;
            color: var(--corporate-red);
        }
        .error-msg {
            background-color: var(--accent-soft-red);
            color: var(--corporate-red);
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            border-left: 3px solid var(--corporate-red);
        }
        .forgot-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
        }
        .password-container {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--secondary-text);
            font-size: 1rem;
            z-index: 10;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        .password-toggle:hover {
            opacity: 1;
        }
        .fas, .fab, .far, .fa-solid, .fa-brands, .fa-regular, i {
            font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands", sans-serif !important;
            font-weight: 900 !important;
        }
    </style>
    <script>
        // Force page reload if loaded from browser back-forward cache (bfcache)
        window.addEventListener('pageshow', function (event) {
            if (event.persisted) {
                window.location.reload();
            }
        });
    </script>
</head>
<body>
    <div class="login-box shadow-premium">
        <div class="login-logo">
            <!-- School Logo -->
            <div style="width: 90px; height: 90px; background: white; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(139, 0, 0, 0.1); overflow: hidden; border: 3px solid var(--corporate-red);">
                <img src="<?php echo BASE_URL; ?>assets/images/logo.png" alt="School Logo" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <h2><?php echo APP_NAME; ?></h2>
        </div>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="hidden" name="<?php echo CSRF_TOKEN_NAME; ?>" value="<?php echo generateCSRFToken(); ?>">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" placeholder="Enter your username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" style="padding-right: 40px;" required>
                    <span class="password-toggle" id="togglePassword">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </span>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">ACCESS SYSTEM</button>
        </form>

        <div style="margin-top: 30px; text-align: center; font-size: 0.75rem; color: var(--secondary-text);">
            &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?><br>
            <span style="color: var(--corporate-red);">Government of Tanzania</span>
        </div>
    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');
        const eyeIcon = document.querySelector('#eyeIcon');

        togglePassword.addEventListener('click', function () {
            // toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            // toggle the eye slash icon
            if (type === 'password') {
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            } else {
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            }
        });
    </script>
</body>
</html>
